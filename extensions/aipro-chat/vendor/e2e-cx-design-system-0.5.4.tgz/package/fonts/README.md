# Noto Sans KR

Source: https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@100..900&display=swap&subset=korean

Google Fonts v39 WOFF2 unicode subsets, variable weights 100–900. The UI uses 400, 500 and 700. Font files are unmodified and served locally. License: OFL.txt (SIL Open Font License 1.1); also distributed at public/licenses/noto-sans-kr-OFL.txt. Upstream: https://github.com/google/fonts/tree/main/ofl/notosanskr

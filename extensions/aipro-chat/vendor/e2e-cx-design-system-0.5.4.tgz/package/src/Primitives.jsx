import React, {useId,useRef,useEffect} from 'react';
import {Icon} from './Icon';
import {EmptyState} from './EmptyState';
import {CxSelect as SelectControl} from './CxSelect';

export function CxButton({variant='secondary',busy=false,disabled,children,className='',type='button',onClick,...props}) {
  return <button {...props} type={type} className={`cx-button cx-kit-button ${variant==='primary'?'cx-button--primary':variant==='danger'?'cx-button--danger':''} ${className}`} disabled={disabled||busy} aria-busy={busy||undefined} onClick={event=>{event.currentTarget.focus({preventScroll:true});onClick?.(event);}}>{busy&&<span className="status-spinner" aria-hidden="true"/>}{children}</button>;
}
export function CxAppShell({brand='CX',navigation,actions,footer,children}) {
  const mainId=useId();
  return <div className="app-shell cx-kit-shell"><a className="cx-kit-skip" href={`#${mainId}`}>본문으로 이동</a><header className="cx-kit-topbar"><div className="cx-kit-brand"><span className="app-mark"><Icon name="report" size={24}/></span><strong>{brand}</strong></div>{navigation&&<nav aria-label="주 메뉴">{navigation}</nav>}<div className="cx-kit-actions">{actions}</div></header><main id={mainId} tabIndex={-1} className="cx-kit-main">{children}</main>{footer&&<footer className="site-footer cx-kit-footer">{footer}</footer>}</div>;
}
export function CxPageHeader({title,description,actions}) { return <header className="cx-kit-page-header"><div><h1>{title}</h1>{description&&<p>{description}</p>}</div>{actions&&<div className="cx-kit-actions">{actions}</div>}</header>; }
export function CxCard({title,actions,children,className=''}) {return <section className={`cx-kit-card ${className}`}>{(title||actions)&&<header className="cx-kit-card-header">{title&&<h2>{title}</h2>}{actions}</header>}<div className="cx-kit-card-body">{children}</div></section>;}
export function CxField({label,hint,error,required,children,id:provided}) {
  const generated=useId(),id=provided||generated,description=[hint&&`${id}-hint`,error&&`${id}-error`].filter(Boolean).join(' ')||undefined;
  const child=React.Children.only(children);
  return <div className="cx-kit-field"><label htmlFor={id}>{label}{required&&<span aria-hidden="true"> *</span>}</label>{React.cloneElement(child,{id,required:required||child.props.required,'aria-invalid':!!error||child.props['aria-invalid'],'aria-describedby':[child.props['aria-describedby'],description].filter(Boolean).join(' ')||undefined})}{hint&&<p id={`${id}-hint`}>{hint}</p>}{error&&<p className="cx-kit-field-error" id={`${id}-error`} role="alert">{error}</p>}</div>;
}
export function CxInput({className='',...props}) {return <input {...props} className={`text-input cx-kit-input ${className}`}/>;}
export function CxSelect({className='',children,...props}) {return <SelectControl {...props} className={`native-select cx-kit-input ${className}`}>{children}</SelectControl>;}
export function CxTextarea({className='',...props}) {return <textarea {...props} className={`text-area cx-kit-input cx-kit-textarea ${className}`}/>;}
export function CxCheckbox({label,mixed=false,...props}) {const ref=useRef(null);useEffect(()=>{ref.current.indeterminate=mixed;},[mixed]);return <label className="cx-kit-checkbox"><input {...props} ref={ref} type="checkbox" className="cx-checkbox" aria-checked={mixed?'mixed':props.checked}/><span>{label}</span></label>;}
export function CxStatus({tone='neutral',children}) {return <span className={`cx-kit-status is-${tone}`}><span aria-hidden="true"/>{children}</span>;}
export function CxNotice({tone='info',children}) {return <div className={`cx-kit-notice is-${tone}`} role={tone==='danger'?'alert':'status'}><Icon name={tone==='danger'?'alertCircle':'infoCircle'}/><div>{children}</div></div>;}
export function CxTable({caption,columns,rows,rowKey='id',emptyTitle='조회 결과가 없습니다.',emptyDescription='조회 조건을 바꾸어 다시 확인하세요.'}) {
  return <div className="cx-kit-table-scroll" role="region" aria-label={caption} tabIndex={0}><table className="cx-kit-table"><caption className="visually-hidden">{caption}</caption><thead><tr>{columns.map(col=><th key={col.key} scope="col" className={col.numeric?'is-numeric':undefined}>{col.label}</th>)}</tr></thead><tbody>{rows.map(row=><tr key={row[rowKey]}>{columns.map(col=><td key={col.key} className={col.numeric?'is-numeric':undefined}>{col.render?col.render(row[col.key],row):row[col.key]}</td>)}</tr>)}{!rows.length&&<tr><td colSpan={columns.length}><EmptyState title={emptyTitle} description={emptyDescription}/></td></tr>}</tbody></table></div>;
}

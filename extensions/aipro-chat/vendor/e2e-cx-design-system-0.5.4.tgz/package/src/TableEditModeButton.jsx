import React, { useRef, useState } from 'react';
import { CxConfirmation } from './CxConfirmation';
import { confirmationCopy } from './confirmationCopy';
import { ActionButton } from './ActionButton';
import {useFeedback} from './Toast';

// Discard only after the user explicitly chooses it in the mode-change dialog.
export function TableEditModeButton({ active, onChange, onEnter, dirty, onSave, onDiscard, disabled }) {
  const [confirm,setConfirm]=useState(false),[saving,setSaving]=useState(false),[entering,setEntering]=useState(false);
  const [,notify]=useFeedback();
  const pending=useRef(false);
  const toggle=async()=>{
    if(disabled||pending.current)return;
    if(!active){
      pending.current=true;setEntering(true);notify('');
      try {if(onEnter&&await onEnter()===false)return;onChange(true);}
      catch(reason){notify(reason?.message||'수정 모드로 전환하지 못했습니다. 다시 시도하세요.',true);}
      finally{pending.current=false;setEntering(false);}
      return;
    }
    if(dirty){notify('');setConfirm(true);}else onChange(false);
  };
  const save=async()=>{
    if(pending.current||disabled)return;
    pending.current=true;setSaving(true);notify('');
    try {const result=await onSave();setConfirm(false);if(result)onChange(false);}
    catch(reason){notify(reason?.message||'저장하지 못했습니다. 다시 시도하세요.',true);}
    finally{pending.current=false;setSaving(false);}
  };
  const discard=()=>{
    if(pending.current||disabled)return;
    try {
      if(onDiscard()===false)return;
      setConfirm(false);onChange(false);notify('저장 전 수정을 취소했습니다.');
    } catch(reason){notify(reason?.message||'읽기 모드로 전환하지 못했습니다. 다시 시도하세요.',true);}
  };
  return <><ActionButton action={active?'read':'editAll'} className="table-edit-mode" aria-pressed={active} busy={entering||saving} disabled={disabled} onClick={toggle}/>
    {confirm&&<CxConfirmation {...confirmationCopy('read')} className="table-edit-confirm" busy={saving} confirmDisabled={disabled} onCancel={()=>setConfirm(false)} onDiscard={onDiscard?discard:undefined} onConfirm={save}/>}
  </>;
}

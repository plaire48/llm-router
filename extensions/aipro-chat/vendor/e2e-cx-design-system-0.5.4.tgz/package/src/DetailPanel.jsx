import React, {useEffect,useId,useRef} from 'react';
import {createPortal} from 'react-dom';
import {ActionButton} from './ActionButton';
import {activateModal} from './modalFocus';

// Portable adaptation: help is supplied by the host instead of importing E2E application state.
export function DetailPanel({title,subtitle,onClose,children,footer,className='',embedded=false,hideHeading=false,variant='drawer',role='dialog',describedBy,initialFocus,onHelp,hideHelp=false,busy=false}) {
  const titleId=useId(),panel=useRef(null),close=useRef(onClose);
  close.current=()=>{if(!busy)onClose?.();};
  useEffect(()=>embedded?undefined:activateModal(panel.current,{initialFocus,confirmation:variant==='confirmation'||role==='alertdialog',onClose:()=>close.current()}),[embedded]);
  const content=<section ref={panel} tabIndex={embedded?undefined:-1} className={`${embedded?'cx-inline-editor':'cx-detail-panel'} ${className}`} role={embedded?'region':role} aria-modal={embedded?undefined:true} aria-busy={busy||undefined} aria-labelledby={titleId} aria-describedby={describedBy||(role==='alertdialog'?`${titleId}-body`:undefined)}>
    <header className={embedded&&hideHeading?'visually-hidden':'cx-panel-header'}><div className="cx-panel-heading"><h2 id={titleId} tabIndex={embedded?undefined:-1}>{title}</h2>{subtitle&&<p>{subtitle}</p>}</div>{!embedded&&<div className="cx-panel-header-actions">{onHelp&&!hideHelp&&variant!=='confirmation'&&role!=='alertdialog'&&<ActionButton action="help" onClick={onHelp}/>}<ActionButton action="close" disabled={busy} onClick={()=>close.current()}/></div>}</header>
    <div id={`${titleId}-body`} className="cx-panel-body">{children}</div>{footer&&<footer className="cx-panel-footer">{footer}</footer>}
  </section>;
  return embedded?content:createPortal(<div className={`cx-panel-backdrop ${variant==='confirmation'?'is-confirmation':variant==='modal'?'is-modal':''}`} onMouseDown={e=>e.target===e.currentTarget&&close.current()}>{content}</div>,document.body);
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {renderReadme} from '../scripts/readme-markdown.mjs';
const root=new URL('../',import.meta.url);
test('README replaces text and produces navigable Markdown with tables and real code examples',async()=>{
  const text=await readFile(new URL('README.md',root),'utf8');
  await assert.rejects(access(new URL('README.txt',root)),{code:'ENOENT'});
  const {html}=renderReadme(text),published=await readFile(new URL('docs/USAGE.html',root),'utf8');
  assert.ok(published.includes(html));
  assert.equal([...html.matchAll(/<table>/g)].length,3);
  for(const [,anchor] of html.matchAll(/href="#([^"]+)"/g))assert.ok(html.includes(`id="${anchor}"`),anchor);
  assert.match(html,/<code class="language-jsx">\/\/ src\/App\.jsx/);
  assert.match(html,/<code class="language-css">\/\* src\/app\.css \*\//);
  assert.match(html,/href="read\/docs\/COMPONENTS.md.html"/);
  assert.match(html,/href="TABLES.html"/);
});
test('Markdown rendering keeps HTML and JSX samples inert while retaining local document navigation',()=>{
  const {html}=renderReadme('# Usage\n\n<script>alert(1)</script>\n\n```jsx\n<img onerror="alert(1)" />\n```\n\n[Table](docs/TABLES.txt)\n\n[Tokens](tokens/catalog.json)');
  assert.doesNotMatch(html,/<(?:script|img)\b/);
  assert.match(html,/&lt;script&gt;/);
  assert.match(html,/&lt;img/);
  assert.match(html,/href="TABLES.html"/);
  assert.match(html,/href="read\/tokens\/catalog.json.html"/);
});

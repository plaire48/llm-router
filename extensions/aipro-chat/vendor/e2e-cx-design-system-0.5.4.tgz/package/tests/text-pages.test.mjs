import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {documentLink} from '../catalog/documentLink.js';
const root=fileURLToPath(new URL('../',import.meta.url));
const manifest=JSON.parse(await readFile(resolve(root,'docs/text-pages.json'),'utf8'));
const decode=bytes=>new TextDecoder('utf-8',{fatal:true}).decode(bytes);
const unescape=text=>text.replaceAll('&quot;','"').replaceAll('&gt;','>').replaceAll('&lt;','<').replaceAll('&amp;','&');

test('every published text view preserves the exact UTF-8 source and resolves local resources',async()=>{
  for(const {source,page,sha256} of manifest.pages){
    const bytes=await readFile(resolve(root,source)),htmlBytes=await readFile(resolve(root,page)),html=decode(htmlBytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'),sha256,source);
    assert.equal(htmlBytes.subarray(0,3).toString('hex'),'efbbbf',page);
    assert.match(html.slice(0,1024),/<meta charset="UTF-8">/);
    if(page.startsWith('docs/read/')){
      const content=html.match(/id="document-source"><code>([\s\S]*)<\/code><\/pre>/)?.[1];assert.notEqual(content,undefined,page);
      assert.equal(unescape(content),decode(bytes),source);
      assert.doesNotMatch(content,/<(?:script|img|iframe|link|style)\b/i,source+' must remain escaped text');
    }
    for(const match of html.matchAll(/(?:href|src)="([^"]+)"/g)){
      const href=unescape(match[1]);if(/^(?:https?:|mailto:|#)/.test(href))continue;
      await access(resolve(dirname(resolve(root,page)),decodeURIComponent(href.split('#')[0])));
    }
  }
});

test('all document link helpers lead to generated HTML and site entry points have UTF-8 signatures',async()=>{
  const pages=new Set(manifest.pages.map(item=>item.page));
  for(const item of manifest.pages)assert.ok(pages.has(documentLink(item.source).replace(/^\.\.\//,'')),item.source);
  for(const file of ['index.html','catalog/index.html','docs/USAGE.html','docs/TEMPLATES.html','docs/TABLES.html','docs/FEEDBACK.html','docs/SKILLS.html','docs/DESIGN-INVENTORY.html']){
    const bytes=await readFile(resolve(root,file));assert.equal(bytes.subarray(0,3).toString('hex'),'efbbbf',file);assert.match(decode(bytes).slice(0,1024),/<meta charset="utf-8">/i);
  }
});

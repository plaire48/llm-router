import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import postcss from 'postcss';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {CxSelect, SearchField, DateRangeFilter, ActionLink, CommitReference, CommunityStatus} from '../dist/index.js';
import {parseCalendarDay, rangeError, chooseRangeDay} from '../src/calendarRange.js';
const root = fileURLToPath(new URL('../', import.meta.url));
const read = path => readFile(new URL('../' + path, import.meta.url), 'utf8');
const inventory = JSON.parse(await read('reference/inventory.json'));
const index = JSON.parse(await read('agent/design-index.json'));
const details = JSON.parse(await read('reference/design-details.json'));

test('design index covers each captured UI and every source CSS declaration without losing contexts', async () => {
  assert.deepEqual(index.components.map(item=>item.file).sort(), inventory.components.map(item=>item.file).sort());
  for (const item of index.components) assert.ok(index.groups.some(group=>group.id===item.group), item.file);
  assert.equal(details.sourceRevision, inventory.sourceRevision);
  for (const file of inventory.cssOrder) {
    let count=0;
    postcss.parse(await read(file)).walkDecls(()=>count++);
    const rows=details.declarations.filter(item=>item.file===file);
    assert.equal(rows.length,count,file);
    const lines=(await read(file)).split('\n');
    for(const row of rows) assert.ok(lines[row.line-1].includes(row.property), file+':'+row.line);
  }
  for(const file of index.fontSupport) assert.equal(createHash('sha256').update(await read(file.file)).digest('hex'),file.sha256);
  assert.equal(details.fontFaces.length,inventory.fonts.length);
  assert.ok(details.surfaces.some(site=>site.element==='DetailPanel'&&site.file.endsWith('WorkHistory.jsx')));
  assert.ok(details.inlineStyles.some(site=>site.file.endsWith('DateRangeFilter.jsx')));
  assert.ok(details.scriptDesignValues.some(site=>site.property==='cardColors'&&site.expression.includes('#2365a0')));
});

test('current tokens retain separate pointer, viewport and legacy theme conditions', () => {
  const controls=details.declarations.filter(row=>row.file.endsWith('cx-density.css')&&row.property==='--cx-control');
  assert.deepEqual(controls.map(row=>[row.value,row.conditions]),[['32px',[]],['44px',['@media (pointer: coarse)']]]);
  const fields=details.declarations.filter(row=>row.file.endsWith('cx-density.css')&&row.property==='--cx-field-font');
  assert.ok(fields.some(row=>row.value==='16px'&&row.conditions.includes('@media (max-width: 700px)')));
  const light=details.declarations.find(row=>row.selector===":root:not([data-theme='dark'])"&&row.property==='color-scheme');
  assert.equal(light.legacyDark,false);
  assert.equal(index.foundations.find(row=>row.token==='--brand-surface').resolved,'#f8f8fd');
  assert.equal(index.foundations.find(row=>row.token==='--cx-row-height').resolved,'40px');
});

test('new portable APIs render semantics without product dependencies or an open browser', () => {
  const render=(type,props,...children)=>renderToStaticMarkup(React.createElement(type,props,...children));
  assert.match(render(CxSelect,{'aria-label':'상태',defaultValue:'a'},React.createElement('option',{value:'a'},'사용')),/<select/);
  assert.match(render(SearchField,{label:'검색',value:'alpha',onChange:()=>{}}),/aria-label="검색"/);
  assert.match(render(DateRangeFilter,{from:'',to:'',onChange:()=>{}}),/aria-expanded="false"/);
  const disabled=render(ActionLink,{action:'openExternal',href:'https://example.test/',disabled:true});
  assert.match(disabled,/aria-disabled="true"/);assert.doesNotMatch(disabled,/href=/);
  assert.doesNotMatch(render(CommitReference,{sha:'invalid',url:'https://example.test'}),/<a/);
  assert.doesNotMatch(render(CommitReference,{sha:'a'.repeat(40),url:'javascript:alert(1)'}),/<a/);
  assert.match(render(CommitReference,{sha:'a'.repeat(40),url:'https://example.test'}),/aaaaaa/);
  assert.equal(render(CommunityStatus,{}),'');
  assert.match(render(CommunityStatus,{error:'오류'}),/role="alert"/);
});

test('date ranges reject invalid dates and reversed intervals, preserve leap days', () => {
  assert.equal(parseCalendarDay('2026-02-30'),null);
  assert.equal(parseCalendarDay('2025-02-29'),null);
  assert.ok(parseCalendarDay('2024-02-29'));
  assert.ok(rangeError('2026-09-20','2026-09-10'));
  assert.equal(rangeError('2026-09-10','2026-09-20'),'');
  assert.deepEqual(chooseRangeDay('2026-09-20','2026-09-10','end'),{from:'2026-09-10',to:'2026-09-20',phase:'start'});
});

test('agent Korean design search locates modal references and semantic color tokens', () => {
  const lookup=query=>JSON.parse(execFileSync(process.execPath,[root+'skills/cx-ui/scripts/lookup.mjs',root,query],{encoding:'utf8'}));
  assert.ok(lookup('모달').design.references.some(row=>row.file.endsWith('DetailPanel.jsx')));
  assert.ok(lookup('색상').design.groups.length||lookup('색상').design.foundations.length);
});

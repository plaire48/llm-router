import copy
import importlib.util
import pathlib
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("ghes_pages", pathlib.Path(__file__).parents[1] / "scripts/configure-ghes-pages.py")
pages = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pages)
HEAD = "a" * 40


class FakeAPI:
    def __init__(self, site=None, builds=None, overrides=None):
        self.site = copy.deepcopy(site)
        self.calls = []
        self.builds = builds or [{"commit": HEAD, "status": "built"}]
        self.overrides = overrides or {}
        self.last_build = self.builds[-1]

    def request(self, method, path, body=None):
        self.calls.append((method, path, copy.deepcopy(body)))
        route = path.removeprefix(pages.RESOURCE)
        if (method, route) in self.overrides:
            return self.overrides[(method, route)]
        if route == "":
            return 200, {"full_name": pages.REPOSITORY, "default_branch": "main"}
        if route == "/branches/main":
            return 200, {"commit": {"sha": HEAD}}
        if route.startswith("/contents/"):
            return 200, {}
        if route == "/pages":
            if method == "GET":
                return (200, copy.deepcopy(self.site)) if self.site is not None else (404, {})
            if method == "POST":
                self.site = {**body, "html_url": "https://pages.internal.example/custom/CX/"}
                return 201, self.site
            if method == "PUT":
                self.site.update(body)
                return 204, {}
        if route == "/pages/builds":
            return 201, {"status": "queued"}
        if route == "/pages/builds/latest":
            return 200, self.builds.pop(0) if self.builds else self.last_build
        raise AssertionError((method, route))


class PagesTests(unittest.TestCase):
    def run_configure(self, api, attempts=3):
        return pages.configure(api, expected_sha=HEAD, attempts=attempts, pause=lambda seconds: None)

    def test_first_upload_creates_main_root_and_uses_server_site_url(self):
        api = FakeAPI()
        result = self.run_configure(api)
        self.assertEqual(result["status"], "built")
        self.assertEqual(result["url"], "https://pages.internal.example/custom/CX/")
        creation = [body for method, path, body in api.calls if method == "POST" and path.endswith("/pages")]
        self.assertEqual(creation, [{"build_type": "legacy", "source": {"branch": "main", "path": "/"}}])

    def test_already_configured_site_only_requests_build(self):
        api = FakeAPI(site={"source": pages.SOURCE, "build_type": "legacy"})
        self.run_configure(api)
        self.assertEqual([path for method, path, _ in api.calls if method != "GET"], [pages.RESOURCE + "/pages/builds"])

    def test_changes_source_without_changing_domain_or_visibility(self):
        api = FakeAPI(site={"source": {"branch": "old", "path": "/docs"}, "build_type": "workflow", "cname": "cx.internal", "public": False})
        self.run_configure(api)
        self.assertEqual(api.site["source"], pages.SOURCE)
        self.assertEqual(api.site["cname"], "cx.internal")
        self.assertFalse(api.site["public"])

    def test_repository_404_cannot_be_misread_as_pages_not_enabled(self):
        api = FakeAPI(overrides={("GET", ""): (404, {})})
        with self.assertRaisesRegex(pages.PagesError, "저장소 조회"):
            self.run_configure(api)
        self.assertTrue(all(method == "GET" for method, _, _ in api.calls))

    def test_non_main_default_is_not_silently_changed(self):
        api = FakeAPI(overrides={("GET", ""): (200, {"full_name": pages.REPOSITORY, "default_branch": "master"})})
        with self.assertRaisesRegex(pages.PagesError, "기본 브랜치"):
            self.run_configure(api)
        self.assertEqual(len(api.calls), 1)

    def test_missing_css_stops_before_pages_mutation(self):
        api = FakeAPI(overrides={("GET", "/contents/dist/styles.css?ref=" + HEAD): (404, {})})
        with self.assertRaisesRegex(pages.PagesError, "dist/styles.css"):
            self.run_configure(api)
        self.assertTrue(all(method == "GET" for method, _, _ in api.calls))

    def test_insufficient_creation_permission_is_actionable(self):
        api = FakeAPI(overrides={("POST", "/pages"): (403, {})})
        with self.assertRaisesRegex(pages.PagesError, "CX_PAGES_TOKEN"):
            self.run_configure(api)

    def test_existing_pages_server_error_does_not_create_or_overwrite(self):
        api = FakeAPI(overrides={("GET", "/pages"): (500, {})})
        with self.assertRaisesRegex(pages.PagesError, "HTTP 500"):
            self.run_configure(api)
        self.assertTrue(all(method == "GET" for method, _, _ in api.calls))

    def test_old_success_is_not_current_publication(self):
        api = FakeAPI(builds=[{"status": "built", "commit": "b" * 40}])
        with self.assertRaisesRegex(pages.PagesError, "게시 완료"):
            self.run_configure(api, attempts=2)

    def test_queued_then_current_commit_built(self):
        api = FakeAPI(builds=[{"status": "queued", "commit": HEAD}, {"status": "built", "commit": HEAD}])
        self.assertEqual(self.run_configure(api)["commit"], HEAD)

    def test_current_build_failure_is_not_success(self):
        api = FakeAPI(builds=[{"status": "errored", "commit": HEAD}])
        with self.assertRaisesRegex(pages.PagesError, "빌드가 실패"):
            self.run_configure(api)

    def test_superseded_workflow_does_not_mutate_settings(self):
        api = FakeAPI()
        result = pages.configure(api, expected_sha="b" * 40)
        self.assertEqual(result["status"], "superseded")
        self.assertTrue(all(method == "GET" for method, _, _ in api.calls))

    def test_other_host_rejected_before_reading_credentials_or_network(self):
        with patch.dict(pages.os.environ, {"GITHUB_SERVER_URL": "https://github.com"}), patch("sys.argv", ["configure-ghes-pages.py"]):
            with self.assertRaisesRegex(pages.PagesError, "GITHUB_SERVER_URL"):
                pages.main()


if __name__ == "__main__":
    unittest.main()

import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,readdir,cp,writeFile,utimes,rm,mkdir,access} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';
import {buildSkillDownload} from '../scripts/skill-download.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
test('standalone ZIP installs only explicitly chosen tools, repeats safely and preserves conflicting copies',async()=>{
  const dir=await mkdtemp(resolve(tmpdir(),'cx-skill-install-'));
  try{
    const download=resolve(dir,'다운로드 폴더'),project=resolve(dir,'업무 프로젝트');
    execFileSync('unzip',['-q',resolve(root,'downloads/cx-ui-skill.zip'),'-d',download]);
    await mkdir(project);
    await writeFile(resolve(project,'AGENTS.md'),'Project rules');
    await writeFile(resolve(project,'CLAUDE.md'),'Claude rules');
    const run=(...args)=>spawnSync(process.execPath,[resolve(download,'cx-ui/scripts/install.mjs'),project,...args],{cwd:dir,encoding:'utf8'});
    const unspecified=run();assert.notEqual(unspecified.status,0);
    assert.deepEqual((await readdir(project)).sort(),['AGENTS.md','CLAUDE.md']);
    const missing=run('--target','all','--check');assert.equal(missing.status,1);
    assert.deepEqual(JSON.parse(missing.stdout).installations.map(i=>i.status),['missing','missing']);
    const first=run('--target','codex');assert.equal(first.status,0,first.stderr);
    await assert.rejects(access(resolve(project,'.claude')),{code:'ENOENT'});
    const second=run('--target','claude');assert.equal(second.status,0,second.stderr);
    const metadata=JSON.parse(await readFile(resolve(root,'downloads/cx-ui-skill.json'),'utf8'));
    for(const tool of ['.agents','.claude'])for(const file of metadata.files){
      assert.equal(hash(await readFile(resolve(project,tool,'skills',file.path))),file.sha256);
    }
    assert.equal(run('--target','all').status,0);
    const check=run('--target','all','--check');assert.equal(check.status,0,check.stderr);
    assert.deepEqual(JSON.parse(check.stdout).installations.map(i=>i.status),['current','current']);
    // Both targets are checked before either is written.
    await rm(resolve(project,'.agents'),{recursive:true});
    const customized=resolve(project,'.claude/skills/cx-ui/SKILL.md');
    await writeFile(customized,'Team changes');
    assert.notEqual(run('--target','all').status,0);
    await assert.rejects(access(resolve(project,'.agents')),{code:'ENOENT'});
    assert.equal(await readFile(customized,'utf8'),'Team changes');
    assert.equal(await readFile(resolve(project,'AGENTS.md'),'utf8'),'Project rules');
    assert.equal(await readFile(resolve(project,'CLAUDE.md'),'utf8'),'Claude rules');
  }finally{await rm(dir,{recursive:true,force:true});}
});

test('downloaded skill ZIP contains the complete canonical folder and all relative references',async()=>{
  const dir=await mkdtemp(resolve(tmpdir(),'cx-skill-zip-'));
  try{
    const metadata=JSON.parse(await readFile(resolve(root,'downloads/cx-ui-skill.json'),'utf8'));
    const archive=resolve(root,'downloads/cx-ui-skill.zip');
    assert.equal(hash(await readFile(archive)),metadata.sha256);
    assert.equal(metadata.version,JSON.parse(await readFile(resolve(root,'package.json'),'utf8')).version);
    execFileSync('unzip',['-t',archive],{stdio:'pipe'});
    execFileSync('unzip',['-q',archive,'-d',dir]);
    assert.deepEqual(await readdir(dir),['cx-ui']);
    const sourceFiles=[];
    async function compare(folder=''){
      const source=resolve(root,'skills/cx-ui',folder),target=resolve(dir,'cx-ui',folder);
      const entries=(await readdir(source,{withFileTypes:true})).sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);
      assert.deepEqual((await readdir(target)).sort(),entries.map(e=>e.name));
      for(const entry of entries){
        const relative=[folder,entry.name].filter(Boolean).join('/');
        if(entry.isDirectory())await compare(relative);
        else {
          const bytes=await readFile(resolve(target,entry.name));
          assert.deepEqual(bytes,await readFile(resolve(source,entry.name)));sourceFiles.push('cx-ui/'+relative);
          assert.equal(metadata.files.find(item=>item.path==='cx-ui/'+relative)?.sha256,hash(bytes));
          if(relative.endsWith('.md'))for(const match of bytes.toString().matchAll(/\]\(([^)#]+)(?:#[^)]*)?\)/g)){
            if(/^[a-z]+:/i.test(match[1]))continue;
            await readFile(resolve(dirname(resolve(target,entry.name)),match[1]));
          }
        }
      }
    }
    await compare();assert.deepEqual(metadata.files.map(item=>item.path),sourceFiles);
  }finally{await rm(dir,{recursive:true,force:true});}
});

test('skill archive is reproducible across source timestamps and changes with content',async()=>{
  const dir=await mkdtemp(resolve(tmpdir(),'cx-skill-repro-'));
  try{
    await cp(resolve(root,'skills'),resolve(dir,'skills'),{recursive:true});
    await cp(resolve(root,'package.json'),resolve(dir,'package.json'));
    await buildSkillDownload(dir);
    const first=await readFile(resolve(dir,'downloads/cx-ui-skill.zip'));
    assert.deepEqual(first,await readFile(resolve(root,'downloads/cx-ui-skill.zip')));
    const skill=resolve(dir,'skills/cx-ui/SKILL.md');
    await utimes(skill,new Date('2001-01-01'),new Date('2001-01-01'));
    await buildSkillDownload(dir);assert.deepEqual(first,await readFile(resolve(dir,'downloads/cx-ui-skill.zip')));
    await writeFile(skill,(await readFile(skill,'utf8'))+'\n변경한 지침\n');
    const updated=await buildSkillDownload(dir);assert.notEqual(updated.sha256,hash(first));
  }finally{await rm(dir,{recursive:true,force:true});}
});

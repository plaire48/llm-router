import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const json=async file=>JSON.parse(await readFile(new URL('../'+file,import.meta.url),'utf8'));
test('distributed table lookup exposes reference behavior without inventing public APIs',async()=>{
  const result=JSON.parse(execFileSync(process.execPath,['skills/cx-ui/scripts/lookup.mjs','.','고정'],{cwd:root,encoding:'utf8'}));
  assert.ok(result.library.tables.features.some(item=>item.id==='pin'));
  assert.ok(result.library.tables.knownGaps.some(item=>item.id==='group-pin-limit'));
  assert.equal(result.library.tables.publicComponent,'CxTable');
  const contract=await json('agent/table-contract.json'),pkg=await json('package.json');
  assert.equal(contract.version,pkg.version);
  assert.deepEqual(contract.features.filter(item=>item.status==='portable').map(item=>item.id),['basic']);
  assert.ok(contract.features.some(item=>item.id==='unimplemented'));
});
test('audit evidence and newly distributed data helpers match the captured product',async()=>{
  const evidence=await json('docs/TABLE-AUDIT.json'),inventory=await json('reference/inventory.json');
  assert.equal(evidence.sourceRevision,inventory.sourceRevision);
  assert.deepEqual([...new Set(evidence.results.map(item=>item.engine))].sort(),['chromium','firefox','webkit']);
  for(const engine of ['chromium','firefox','webkit'])assert.deepEqual(evidence.results.filter(item=>item.engine===engine).map(item=>item.width).sort((a,b)=>a-b),[390,1440]);
  for(const name of ['reportInteractions','automationRate']){
    const file=`reference/modules/${name}.js`,entry=inventory.modules.find(item=>item.file===file);
    assert.ok(entry);assert.equal(entry.availability,'reference-only');
    assert.equal(createHash('sha256').update(await readFile(new URL('../'+file,import.meta.url))).digest('hex'),entry.sha256);
  }
});

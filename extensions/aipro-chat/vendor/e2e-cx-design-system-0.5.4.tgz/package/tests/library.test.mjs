import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdtemp,mkdir,writeFile,readlink,symlink,readdir,rm,access} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tmpdir} from 'node:os';
import {execFileSync,spawnSync} from 'node:child_process';
import postcss from 'postcss';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const read=path=>readFile(resolve(root,path),'utf8');
const run=(script,args=[])=>execFileSync(process.execPath,[resolve(root,script),...args],{encoding:'utf8'});
const registry=JSON.parse(await read('templates/registry.json'));

test('token-only CSS preserves every captured variable selector and media condition',async()=>{
  const collect=css=>{const rows=[];postcss.parse(css).walkDecls(decl=>{if(!decl.prop.startsWith('--'))return;let node=decl.parent;const context=[];while(node.type!=='root'){context.unshift(node.type==='rule'?node.selector:`@${node.name} ${node.params}`);node=node.parent;}rows.push({property:decl.prop,value:decl.value,context});});return rows;};
  const only=await read('dist/tokens.css');
  postcss.parse(only).walkDecls(decl=>assert.ok(decl.prop.startsWith('--'),decl.toString()));
  const inventory=JSON.parse(await read('reference/inventory.json'));
  const expected=(await Promise.all(inventory.cssOrder.map(async file=>collect(await read(file))))).flat();
  const actual=collect(only);
  assert.deepEqual(actual.slice(0,expected.length),expected);
  assert.ok(actual.some(row=>row.property==='--cx-control'&&row.value==='44px'&&row.context.includes('@media (pointer: coarse)')));
  assert.ok(actual.some(row=>row.property==='--cx-field-font'&&row.value==='16px'&&row.context.includes('@media (max-width: 700px)')));
});

test('template copy commands preserve source bytes, and reject unknown IDs or occupied/symlink targets without writes',async()=>{
  const temp=await mkdtemp(resolve(tmpdir(),'cx-template-test-'));
  try{
    assert.equal(JSON.parse(run('scripts/create.mjs',['--list'])).templates.length,registry.templates.length);
    assert.equal(JSON.parse(run('scripts/template.mjs',['list'])).templates.length,registry.templates.length);
    for(const template of registry.templates){
      const dest=resolve(temp,template.id);
      run('scripts/template.mjs',['add',template.id,'--to',dest]);
      for(const file of template.files)assert.deepEqual(await readFile(resolve(dest,file.target)),await readFile(resolve(root,file.source)));
      assert.equal(JSON.parse(await readFile(resolve(dest,'CX-TEMPLATE.json'),'utf8')).template,template.id);
      const again=spawnSync(process.execPath,[resolve(root,'scripts/template.mjs'),'add',template.id,'--to',dest]);assert.notEqual(again.status,0);
      assert.equal((await readdir(dest)).length,3);
    }
    const missing=resolve(temp,'missing');
    assert.notEqual(spawnSync(process.execPath,[resolve(root,'scripts/template.mjs'),'add','unknown','--to',missing]).status,0);
    await assert.rejects(access(missing));
    const target=resolve(temp,'target'),link=resolve(temp,'link');await mkdir(target);await symlink(target,link);
    assert.notEqual(spawnSync(process.execPath,[resolve(root,'scripts/template.mjs'),'add','login','--to',link]).status,0);
    assert.equal(await readlink(link),target);assert.deepEqual(await readdir(target),[]);
    const archive=resolve(temp,'fixture.tgz');await writeFile(archive,'fixture');
    for(const args of [['--template','unknown'],['--template','login','--template','app-shell']]){
      assert.notEqual(spawnSync(process.execPath,[resolve(root,'scripts/create.mjs'),missing,'--package',archive,...args]).status,0);await assert.rejects(access(missing));
    }
  }finally{await rm(temp,{recursive:true,force:true});}
});

test('installed-style agent lookup connects Korean purposes and exact tokens to real templates',()=>{
  const lookup=query=>JSON.parse(run('skills/cx-ui/scripts/lookup.mjs',[root,query]));
  assert.ok(lookup('설정').library.templates.some(item=>item.id==='settings-form'));
  assert.ok(lookup('로그인').library.templates.some(item=>item.id==='login'));
  const controls=lookup('--cx-control').library.tokens;
  assert.ok(controls.some(item=>item.id==='--cx-control'&&item.css==='var(--cx-control)'&&item.usedBy.includes('actions')));
});

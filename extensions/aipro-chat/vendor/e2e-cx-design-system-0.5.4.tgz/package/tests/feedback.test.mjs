import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createToastStore} from '../src/toastStore.js';
import {renderReadme} from '../scripts/readme-markdown.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const json=async file=>JSON.parse(await readFile(new URL('../'+file,import.meta.url),'utf8'));

test('toast replacement and source cleanup cannot dismiss newer or unrelated errors',()=>{
  const store=createToastStore();
  store.show({source:'a',message:'저장 실패',error:true});const old=store.getSnapshot().id;
  store.show({source:'b',message:'저장하는 중…'});assert.equal(store.getSnapshot().id,old);
  store.show({source:'b',message:'저장했습니다.'});const next=store.getSnapshot().id;
  assert.notEqual(old,next);store.dismiss(old);assert.equal(store.getSnapshot().id,next);
  store.show({source:'a',message:''});assert.equal(store.getSnapshot().id,next);
  store.show({source:'b',message:'저장하는 중...'});assert.equal(store.getSnapshot(),null);
  store.show({source:'b',message:'저장했습니다.'});const sameText=store.getSnapshot().id;
  store.show({source:'b',message:'저장했습니다.'});assert.notEqual(store.getSnapshot().id,sameText);
});

test('toast success and pending filtering follow the documented message contract',()=>{
  const store=createToastStore();
  for(const message of ['저장했습니다.','저장 완료','복사했습니다.','초기화했습니다.','불러왔습니다.','내보냈습니다.','적용했습니다.']){
    store.show({source:'a',message});assert.equal(store.getSnapshot().success,true);
  }
  store.show({source:'a',message:'변경 사항이 없습니다.'});assert.equal(store.getSnapshot().success,false);
  store.show({source:'a',message:'연결 중…',error:true});assert.equal(store.getSnapshot().error,true);
  store.show({source:'a',message:'저장 완료',error:true});assert.equal(store.getSnapshot().success,false);
  store.show({source:'a',message:'  '});assert.equal(store.getSnapshot(),null);
});

test('consumer lookup exposes the feedback contract and source evidence for the installed version',async()=>{
  const result=JSON.parse(execFileSync(process.execPath,['skills/cx-ui/scripts/lookup.mjs','.','토스트'],{cwd:root,encoding:'utf8'}));
  assert.ok(result.library.feedback.features.some(item=>item.id==='anatomy'));
  assert.equal(result.library.feedback.timing.durationMs,3000);
  assert.ok(result.library.feedback.apis.some(item=>item.name==='useFeedback'));
  const contract=await json('agent/feedback-contract.json'),pkg=await json('package.json');
  assert.equal(contract.version,pkg.version);
  for(const source of contract.sources)assert.equal(createHash('sha256').update(await readFile(new URL('../'+source.file,import.meta.url))).digest('hex'),source.sha256,source.file);
});

test('nested Markdown guide links resolve to readable local pages',()=>{
  const {html}=renderReadme('# Guide\n\n[API](../src/Toast.jsx) [Home](../README.md) [Here](#guide) [Rules](COMPONENTS.md)',{source:'docs/FEEDBACK.md',targetPage:'docs/FEEDBACK.html'});
  assert.match(html,/href="read\/src\/Toast.jsx.html"/);
  assert.match(html,/href="USAGE.html"/);
  assert.match(html,/href="#guide"/);
  assert.match(html,/href="read\/docs\/COMPONENTS.md.html"/);
});

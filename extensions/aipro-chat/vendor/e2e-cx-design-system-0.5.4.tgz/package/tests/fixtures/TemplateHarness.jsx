import React,{useCallback,useRef,useState} from 'react';
import Settings from './screens/settings-form/App.jsx';
import History from './screens/history-list/App.jsx';
import Login from './screens/login/App.jsx';
import List from './screens/list-detail/App.jsx';
import './screens/login/app.css';
import './screens/list-detail/app.css';
import '@e2e/cx-design-system/tokens.css';
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const initial={name:'서버 설정',description:'저장된 값',visibility:'team',notifications:true};
export default function App(){
  const [type,setType]=useState('settings'),[mode,setMode]=useState('success'),[calls,setCalls]=useState(0),[signed,setSigned]=useState(false);const request=useRef(0);
  const save=useCallback(async draft=>{setCalls(n=>n+1);await pause(180);if(mode==='error')throw null;if(mode==='invalid')return {};return {...draft,name:draft.name.trim()+' 완료'};},[mode]);
  const login=useCallback(async()=>{setCalls(n=>n+1);await pause(180);if(mode==='error')throw null;if(mode==='invalid')return false;setSigned(true);},[mode]);
  const history=useCallback(async({query})=>{const ticket=++request.current;setCalls(n=>n+1);await pause(query==='slow'?500:60);if(mode==='error')throw null;if(mode==='invalid')return {};if(mode==='empty')return [];return [{id:ticket,name:query||'서버 이력',actor:'담당자',date:'2026-09-16',status:'수정',before:'전',after:'후',sha:'a'.repeat(40)}];},[mode]);
  return <><label>검증 화면<select value={type} onChange={e=>{setType(e.target.value);setCalls(0);setSigned(false);}}>{['settings','list','history','login'].map(value=><option key={value}>{value}</option>)}</select></label><label>콜백 결과<select value={mode} onChange={e=>setMode(e.target.value)}>{['success','error','invalid','empty','absent'].map(value=><option key={value}>{value}</option>)}</select></label><output aria-label="호출 수">{calls}</output><output aria-label="인증 연결 결과">{signed?'세션 연결 확인':'대기'}</output>{type==='settings'?<Settings initialValue={initial} onSave={save}/>:type==='list'?<List onSave={save}/>:type==='history'?<History loadHistory={history}/>:<Login onLogin={mode==='absent'?undefined:login}/>}</>;
}

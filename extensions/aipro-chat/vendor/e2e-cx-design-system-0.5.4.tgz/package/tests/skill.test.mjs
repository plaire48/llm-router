import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, mkdir, readFile, writeFile, rm, symlink, realpath, access, readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {installSkill} from '../scripts/install-skill.mjs';
import {selectInstallOptions} from '../skills/cx-ui/scripts/install.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)), '..');
async function fixture(run) {
  const dir=await mkdtemp(resolve(tmpdir(), 'cx-skill-'));
  try { await writeFile(resolve(dir,'package.json'),'{"name":"consumer"}'); await run(dir); }
  finally { await rm(dir,{recursive:true,force:true}); }
}

test('interactive choices have no default and preserve the chosen project and tool',async()=>{
  for(const [choice,target] of [['1','codex'],['2','claude'],['3','all']]){
    const answers=[choice,'"/tmp/업무 프로젝트"'];
    assert.deepEqual(await selectInstallOptions({},async()=>answers.shift()),{project:'/tmp/업무 프로젝트',target,check:false});
  }
  assert.equal(await selectInstallOptions({},async()=>'0'),null);
  await assert.rejects(selectInstallOptions({},async()=>''),/도구를 선택하지/);
  await assert.rejects(selectInstallOptions({target:'codex'},async()=>''),/프로젝트 폴더/);
  const explicit={project:'/tmp/project',target:'claude',check:true};
  assert.deepEqual(await selectInstallOptions(explicit,async()=>assert.fail('explicit selection must not prompt')),explicit);
});

test('unspecified installation target never writes a skill',()=>fixture(async dir=>{
  await assert.rejects(installSkill(dir),/Target must/);
  const result=spawnSync(process.execPath,[resolve(root,'scripts/install-skill.mjs'),dir],{encoding:'utf8'});
  assert.notEqual(result.status,0);
  assert.deepEqual(await readdir(dir),['package.json']);
}));

test('new project generator installs only the explicit skill target',()=>fixture(async dir=>{
  for(const target of ['none','codex','claude','all']){
    const project=resolve(dir,target);
    const args=[resolve(root,'scripts/create.mjs'),project,'--package',resolve(root,'package.json')];
    if(target!=='none')args.push('--skill-target',target);
    const result=spawnSync(process.execPath,args,{encoding:'utf8'});
    assert.equal(result.status,0,result.stderr);
    for(const [tool,folder,instructions] of [['codex','.agents','AGENTS.md'],['claude','.claude','CLAUDE.md']]){
      if(target===tool||target==='all'){
        await access(resolve(project,folder,'skills/cx-ui/SKILL.md'));await access(resolve(project,instructions));
      }else{
        await assert.rejects(access(resolve(project,folder)),{code:'ENOENT'});
        await assert.rejects(access(resolve(project,instructions)),{code:'ENOENT'});
      }
    }
  }
}));

test('skill installation is local, repeatable and preserves existing instructions',()=>fixture(async dir=>{
  await writeFile(resolve(dir,'AGENTS.md'),'Existing project rules');
  await writeFile(resolve(dir,'CLAUDE.md'),'Existing Claude rules');
  const first=await installSkill(dir,{target:'all'});
  assert.equal(first.changed,true);
  assert.deepEqual(first.installations.map(item=>item.tool),['codex','claude']);
  for(const item of first.installations)for(const path of ['SKILL.md','agents/openai.yaml','scripts/lookup.mjs','references/workflows.md']) {
    assert.deepEqual(await readFile(resolve(item.destination,path)),await readFile(resolve(root,'skills/cx-ui',path)));
  }
  assert.equal((await installSkill(dir,{target:'all'})).changed,false);
  assert.equal(await readFile(resolve(dir,'AGENTS.md'),'utf8'),'Existing project rules');
  assert.equal(await readFile(resolve(dir,'CLAUDE.md'),'utf8'),'Existing Claude rules');
}));

test('skill installation refuses to overwrite local edits',()=>fixture(async dir=>{
  const {destination}=await installSkill(dir,{target:'all'});
  await writeFile(resolve(destination,'SKILL.md'),'Customized skill');
  await assert.rejects(installSkill(dir,{target:'all'}),/Existing skill differs/);
  assert.equal(await readFile(resolve(destination,'SKILL.md'),'utf8'),'Customized skill');
}));

test('skill installation does not follow a project directory symlink',()=>fixture(async dir=>{
  const outside=await mkdtemp(resolve(tmpdir(),'cx-other-'));
  try {
    await symlink(outside,resolve(dir,'.agents'),'dir');
    await assert.rejects(installSkill(dir,{target:'all'}),/regular directory/);
    assert.deepEqual(await readdir(outside),[]);
  } finally { await rm(outside,{recursive:true,force:true}); }
}));

test('all-target preflight preserves a modified Claude skill without partially installing Codex',()=>fixture(async dir=>{
  const first=await installSkill(dir,{target:'claude'});
  await writeFile(resolve(first.destination,'SKILL.md'),'Team customization');
  await assert.rejects(installSkill(dir,{target:'all'}),/Existing skill differs/);
  await assert.rejects(access(resolve(dir,'.agents')),{code:'ENOENT'});
  assert.equal(await readFile(resolve(first.destination,'SKILL.md'),'utf8'),'Team customization');
}));

test('selected tool and read-only status work before a non-React project has package.json',()=>fixture(async dir=>{
  await rm(resolve(dir,'package.json'));
  const before=await installSkill(dir,{target:'all',check:true});
  assert.deepEqual(before.installations.map(item=>item.status),['missing','missing']);
  assert.deepEqual(await readdir(dir),[]);
  const installed=await installSkill(dir,{target:'claude'});
  assert.equal(installed.installations.length,1);
  await assert.rejects(access(resolve(dir,'.agents')),{code:'ENOENT'});
  assert.equal((await installSkill(dir,{target:'claude',check:true})).installations[0].status,'current');
  await writeFile(resolve(installed.destination,'references/workflows.md'),'Customized workflow');
  assert.equal((await installSkill(dir,{target:'claude',check:true})).installations[0].status,'different');
}));

test('CLI validates target and duplicate flags before any installation, check returns actionable status',()=>fixture(async dir=>{
  const cli=resolve(root,'scripts/install-skill.mjs');
  const run=args=>spawnSync(process.execPath,[cli,dir,...args],{encoding:'utf8'});
  for(const args of [['--target','invalid'],['--target','claude','--target','codex'],['--oops'],['--check','--check']])assert.notEqual(run(args).status,0);
  assert.deepEqual(await readdir(dir),['package.json']);
  const missing=run(['--target','all','--check']);assert.equal(missing.status,1);
  assert.ok(JSON.parse(missing.stdout).installations.every(item=>item.status==='missing'));
  const installed=run(['--target','all']);assert.equal(installed.status,0,installed.stderr);
  assert.equal(run(['--target','all','--check']).status,0);
}));

test('Claude directory symlink prevents both destinations from being written',()=>fixture(async dir=>{
  const outside=await mkdtemp(resolve(tmpdir(),'cx-claude-'));
  try {
    await symlink(outside,resolve(dir,'.claude'),'dir');
    await assert.rejects(installSkill(dir,{target:'all'}),/regular directory/);
    await assert.rejects(access(resolve(dir,'.agents')),{code:'ENOENT'});
    assert.deepEqual(await readdir(outside),[]);
  } finally {await rm(outside,{recursive:true,force:true});}
}));

test('summary lookup provides bounded discovery with actionable project commands and contract paths',()=>{
  const run=spawnSync(process.execPath,[resolve(root,'skills/cx-ui/scripts/lookup.mjs'),root,'--summary'],{encoding:'utf8'});
  assert.equal(run.status,0,run.stderr);
  const summary=JSON.parse(run.stdout);
  assert.ok(summary.portableApis.includes('ActionButton'));
  assert.equal(summary.contracts.feedback,'agent/feedback-contract.json');
  assert.ok(summary.templates.some(item=>item.id==='list-detail'));
  assert.ok(summary.project.scripts.build);
  assert.equal(summary.query,undefined);
  assert.ok(Buffer.byteLength(run.stdout)<8000,'discovery should not dump the full token/source library');
});

test('lookup reads the consumer package and rejects mismatched metadata or missing CX',()=>fixture(async dir=>{
  const lookup=resolve(root,'skills/cx-ui/scripts/lookup.mjs');
  const run=()=>spawnSync(process.execPath,[lookup,dir,'로그인'],{cwd:root,encoding:'utf8'});
  assert.notEqual(run().status,0,'must not fall back to the tool repository');
  const installed=resolve(dir,'node_modules/@e2e/cx-design-system');
  await mkdir(resolve(installed,'agent'),{recursive:true});
  await writeFile(resolve(installed,'package.json'),JSON.stringify({name:'@e2e/cx-design-system',version:'0.0.7',exports:{'./package.json':'./package.json'}}));
  const manifest={package:'@e2e/cx-design-system',version:'0.0.7',portable:[],actions:[{name:'login',icon:'logIn',label:'로그인'}],icons:['logIn']};
  await writeFile(resolve(installed,'agent/manifest.json'),JSON.stringify(manifest));
  const result=run(); assert.equal(result.status,0,result.stderr);
  const output=JSON.parse(result.stdout);
  assert.equal(output.packageRoot,await realpath(installed)); assert.equal(output.version,'0.0.7');
  assert.equal(output.actions[0].icon,'logIn');
  const summary=spawnSync(process.execPath,[lookup,dir,'--summary'],{cwd:root,encoding:'utf8'});
  assert.equal(summary.status,0,summary.stderr);
  assert.ok(!JSON.parse(summary.stdout).docs.includes('docs/FEEDBACK.md'),'older metadata must not invent newer guides');
  await writeFile(resolve(installed,'agent/manifest.json'),JSON.stringify({...manifest,version:'0.0.8'}));
  assert.notEqual(run().status,0);
}));

# CX Design System 사용 방법

**CX는 사내 서비스가 같은 디자인 기준으로 개발되도록 제공하는 공통 UI 개발 키트입니다.** 색상·폰트·간격·컴포넌트·화면 템플릿과 개발 에이전트용 스킬을 함께 관리합니다. 업무 목록, 설정, 변경 이력, 로그인 화면을 만들거나 기존 화면을 공통 디자인으로 맞출 때 사용합니다.

사내 기준 저장소는 [Manufacturing-IT/CX](https://code.sdsdev.co.kr/Manufacturing-IT/CX)입니다. 이 문서는 **사내에 배포된 CX를 받아 프로젝트에 적용하는 개발자**를 위한 안내입니다. 실제 데이터 조회·저장·권한·인증은 각 서비스에 연결합니다.

처음 도입한다면 배포 담당자에게 같은 버전의 개발 키트를 전달받으세요. 사용 목적에 따라 다음 파일을 선택합니다.

| 배포 파일 | 사용할 때 |
| --- | --- |
| `cx-design-system-0.5.4.zip` | 새 프로젝트 생성 또는 전체 문서·소스·템플릿 확인. 설치용 TGZ도 포함 |
| `e2e-cx-design-system-0.5.4.tgz` | 기존 React 프로젝트에 CX 컴포넌트·CSS·폰트 설치 |
| [스킬 ZIP](downloads/cx-ui-skill.zip) | Codex·Claude Code 또는 다른 에이전트에 개발 지침 등록 |
| `cx-pages-0.5.4.zip` | 카탈로그를 오프라인에서 열거나 사내 Pages에 게시 |

스킬 ZIP은 개발 지침과 설치·검색 도구입니다. **실제 화면을 구현하려면 개발 키트나 TGZ도 함께 준비**합니다. 파일명의 버전은 전달받은 배포본에 맞춰 사용하세요.

## 이 문서의 순서

- [1. 카탈로그에서 확인하기](#1-카탈로그에서-확인하기)
- [2. 프로젝트에 연결하기](#2-프로젝트에-연결하기)
- [3. 템플릿을 실제 서비스에 연결하기](#3-템플릿을-실제-서비스에-연결하기)
- [4. 컴포넌트를 조합해 화면 만들기](#4-컴포넌트를-조합해-화면-만들기)
- [5. 에이전트로 활용하기](#5-에이전트로-활용하기)
- [6. 디자인 기준과 공통 동작 유지하기](#6-디자인-기준과-공통-동작-유지하기)
- [7. React 없이 활용하기](#7-react-없이-활용하기)
- [8. 팀에 배포하고 업데이트하기](#8-팀에-배포하고-업데이트하기)
- [9. 필요한 자료 찾기](#9-필요한-자료-찾기)

## 1. 카탈로그에서 확인하기

팀에서 공유한 사내 CX 카탈로그를 열고 사용할 요소를 확인합니다. **컴포넌트**에서는 버튼·입력·표·모달을, **화면 템플릿**에서는 업무 화면의 미리보기와 사용 코드를 확인합니다. **토큰 라이브러리**에는 색상·글자·크기와 적용 조건이 있습니다.

오프라인에서는 개발 키트나 Pages ZIP의 압축을 풀고 루트 `index.html`을 엽니다. 별도 npm 설치 없이 카탈로그를 볼 수 있습니다. CSS·JS·폰트가 연결되어 있으므로 압축을 푼 전체 폴더 구조를 유지하세요.

목록 예제에서 검색 → 상세 수정 → 저장을 실행하고 빈 결과·저장 실패·미저장 취소 상태를 확인합니다. 예제 데이터는 메모리에서만 바뀌며 새로고침하면 초기화됩니다. 실제 서비스의 API를 연결하는 방법은 3절을 참고하세요.

## 2. 프로젝트에 연결하기

개발에는 **Node.js 22.12 이상, npm, React 19**를 사용합니다. 아래 예시는 `0.5.4` 배포본 기준입니다. 프로젝트의 사내 npm 레지스트리 설정 또는 승인된 의존성 캐시를 먼저 준비하세요. TGZ에는 CX가 들어 있으며 React·Vite 등 프로젝트의 다른 의존성까지 모두 포함되지는 않습니다.

### 기존 React 프로젝트에 추가하기

전달받은 TGZ를 프로젝트의 `vendor` 폴더에 복사합니다. 개발 키트 ZIP을 받았다면 압축을 푼 폴더의 최상위에 TGZ가 있습니다.

```text
my-app/
  package.json
  src/
  vendor/
    e2e-cx-design-system-0.5.4.tgz
```

프로젝트 폴더에서 설치합니다.

```sh
npm install ./vendor/e2e-cx-design-system-0.5.4.tgz
npm pkg set 'scripts.design:check=cx-check src'
```

앱 진입점에서 공통 CSS를 한 번 불러옵니다.

```jsx
import '@e2e/cx-design-system/styles.css';
```

에이전트와 개발하려면 같은 프로젝트에서 스킬 설치기를 실행합니다. **Codex / Claude Code / 둘 다** 중 사용할 도구를 선택한 뒤 표시된 설치 경로를 확인합니다.

```sh
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs .
```

기존 `AGENTS.md`·`CLAUDE.md`와 수정한 스킬은 덮어쓰지 않습니다. 설치 후 프로젝트를 도구에서 다시 열면 Codex는 `$cx-ui`, Claude Code는 `/cx-ui`로 사용할 수 있습니다. 구체적인 요청 예시는 5절에 있습니다.

### 새 프로젝트 만들기

개발 키트 ZIP을 압축 해제한 폴더에서 실행합니다. 아래 `../my-cx-app`은 새로 만들 빈 프로젝트 경로이며, TGZ는 개발 키트 최상위에 포함되어 있습니다.

```sh
node scripts/create.mjs ../my-cx-app --template list-detail \
  --package ./e2e-cx-design-system-0.5.4.tgz
cd ../my-cx-app
npm install
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs .
npm run dev
```

생성기는 React 화면, CX 패키지, 디자인 검사 명령과 안내 문서를 준비합니다. 템플릿을 생략하면 `list-detail`을 사용하며 이미 파일이 있는 폴더에는 생성하지 않습니다. 스킬은 위 설치기에서 도구를 선택해 추가합니다. 생성할 때 도구를 정했다면 `create.mjs`에 `--skill-target codex`, `--skill-target claude`, `--skill-target all` 중 하나를 명시할 수도 있습니다.

전달받은 개발 키트에는 실행할 파일이 준비되어 있으므로 CX 자체를 다시 빌드하거나 릴리스할 필요가 없습니다. 필요한 템플릿 목록은 개발 키트 폴더에서 다음 명령으로 확인합니다.

```sh
node scripts/create.mjs --list
```

## 3. 템플릿을 실제 서비스에 연결하기

화면의 흐름까지 필요한 경우에는 컴포넌트 하나씩 조합하는 대신 템플릿에서 시작하세요.

| 템플릿 | 포함한 화면과 동작 | 서비스 연결 지점 |
| --- | --- | --- |
| `app-shell` | 상단·제목·본문·푸터의 기본 프레임 | `navigation`, `children`, `onStart` |
| `list-detail` | 검색·목록·수정 모달·미저장 확인·실패 복구 | `initialItems`, `onSave(draft)` |
| `settings-form` | 설정 입력·저장·변경 취소 | `initialValue`, `onSave(draft)` |
| `history-list` | 검색·기간·이력·전후 비교 | `initialRows`, `loadHistory({query, from, to})` |
| `login` | 로그인 진입·처리 중·오류 표시 | `onLogin()` |

기존 프로젝트에서도 필요한 화면만 빈 폴더에 복사할 수 있습니다.

```sh
node node_modules/@e2e/cx-design-system/scripts/template.mjs list
node node_modules/@e2e/cx-design-system/scripts/template.mjs \
  add settings-form --to src/screens/settings
```

복사된 `App.jsx`와 `app.css`를 함께 연결합니다. 아래 `/api/settings`는 예시 주소이므로 실제 서비스의 저장 함수나 엔드포인트로 교체하세요. 서버가 저장된 설정 객체를 반환하는 예시입니다.

```jsx
import React from 'react';
import SettingsScreen from './screens/settings/App.jsx';
import './screens/settings/app.css';

async function saveSettings(draft) {
  const response = await fetch('/api/settings', {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(draft),
  });
  if (!response.ok) throw new Error('저장하지 못했습니다. 다시 시도하세요.');
  return response.json();
}

export default function SettingsPage({settings}) {
  return <SettingsScreen initialValue={settings} onSave={saveSettings} />;
}
```

`settings`는 `{name, visibility: 'team' 또는 'private', description, notifications: boolean}` 형태이며 데이터를 불러온 뒤 화면을 렌더링합니다. `initialValue`는 최초 렌더링의 값입니다. 이후 서버 변경을 동기화하는 정책은 서비스에서 정합니다. 기존 `CxAppShell` 안에 넣을 때는 `<SettingsScreen embedded initialValue={settings} onSave={saveSettings} />`로 프레임 중복을 피하세요.

저장 함수가 실패하면 오류를 던지고, 성공하면 서버가 확정한 값을 반환합니다. 템플릿은 저장 중 상태와 실패 후 입력 유지에 사용합니다. 로그인 성공 후 이동과 세션, 조회 권한, 동시 수정 정책은 서비스에서 연결합니다. 전체 props와 예제는 [템플릿 사용 안내](docs/TEMPLATES.txt)에 있습니다.

## 4. 컴포넌트를 조합해 화면 만들기

작은 화면은 공개 컴포넌트를 직접 조합합니다. 다음 코드를 `src/App.jsx`에 넣으면 업무 이름을 입력하고 목록에 추가할 수 있습니다. 이 예제는 서버 없이 동작하며 새로고침하면 입력한 목록이 사라집니다.

```jsx
// src/App.jsx
import React, { useRef, useState } from 'react';
import '@e2e/cx-design-system/styles.css';
import './app.css';
import {
  CxAppShell, CxPageHeader, CxCard, CxField,
  CxInput, CxTable, CxStatus, ActionButton,
} from '@e2e/cx-design-system';

export default function App() {
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [rows, setRows] = useState([]);
  const nextId = useRef(1);

  function addTask() {
    const value = name.trim();
    if (!value) {
      setError('업무 이름을 입력하세요.');
      return;
    }
    const row = { id: nextId.current++, name: value, status: '검토 중' };
    setRows(current => [...current, row]);
    setName('');
    setError('');
  }

  return (
    <CxAppShell brand="우리 서비스" footer="우리 서비스">
      <CxPageHeader title="업무 관리" />
      <div className="task-layout">
        <CxCard title="업무 추가">
          <div className="task-form">
            <CxField label="업무 이름" required error={error}>
              <CxInput value={name} onChange={event => setName(event.target.value)} />
            </CxField>
            <ActionButton action="add" iconOnly={false} onClick={addTask} />
          </div>
        </CxCard>
        <CxCard title="업무 목록">
          <CxTable caption="등록한 업무" rows={rows} columns={[
            { key: 'name', label: '업무 이름' },
            { key: 'status', label: '상태', render: value => <CxStatus tone="warning">{value}</CxStatus> },
          ]} />
        </CxCard>
      </div>
    </CxAppShell>
  );
}
```

`src/app.css`에는 화면 배치만 작성합니다. 공통 색상·글꼴·버튼 모양은 CX가 적용합니다.

```css
/* src/app.css */
.task-layout, .task-form {
  display: grid;
  gap: var(--cx-space-4);
}
.task-form > button {
  justify-self: start;
}
```

- `CxAppShell`, `CxPageHeader`, `CxCard`는 화면 프레임·제목·구획을 만듭니다.
- `CxField`는 입력의 이름·필수 여부·오류를 연결합니다.
- `CxTable`은 `columns`의 `key`로 `rows`를 표시합니다. `render`로 특정 셀을 상태 컴포넌트 등으로 바꿉니다.
- `ActionButton`은 정해진 동작의 아이콘·이름·크기를 공유합니다. 일반 동작에는 `CxButton`을 사용합니다.

추가·수정 같은 동작은 기본적으로 아이콘으로 표시하며 `iconOnly={false}`로 이름을 함께 표시합니다. 저장·로그인·로그아웃·문의는 기본적으로 이름도 표시합니다. 아래 `login`과 `saving`은 서비스에서 관리하는 함수와 상태입니다.

```jsx
<ActionButton action="login" onClick={login} />
<ActionButton action="save" busy={saving} onClick={save} />
<ActionButton action="edit" label="업무 수정" onClick={edit} />
```

실제 저장 화면에서는 API 성공 후 목록을 갱신하고, 실패하면 입력값과 오류를 남기세요. 저장 중에는 `busy`, 실행할 수 없을 때는 `disabled`를 사용합니다. 검색창의 `SearchField.onChange`는 이벤트가 아닌 문자열을 전달하고, `DateRangeFilter.onChange`는 `{from, to}`를 전달합니다. 정확한 props는 [공통 컴포넌트](docs/COMPONENTS.md)를 참고하세요.

## 5. 에이전트로 활용하기

**[스킬 ZIP을 바로 내려받을 수 있습니다.](downloads/cx-ui-skill.zip)** 압축을 푼 폴더에서 실행하면 설치할 도구와 프로젝트 폴더를 선택합니다. Node.js 22 이상이 필요하며 인터넷 연결은 필요하지 않습니다.

```sh
node cx-ui/scripts/install.mjs
```

메뉴에서 **Codex / Claude Code / 둘 다**를 고르고 사용할 프로젝트 폴더를 입력합니다. 실제 설치 경로를 확인한 뒤 설치하며, 선택하지 않은 도구의 폴더는 만들지 않습니다. Codex는 `.agents/skills/cx-ui`, Claude Code는 `.claude/skills/cx-ui`에 설치합니다.

이미 CX 패키지를 설치했다면 2절의 `install-skill.mjs .` 명령으로 현재 프로젝트에 설치할 도구를 선택합니다. 질문 없이 실행하려면 프로젝트와 `--target codex`, `--target claude`, `--target all` 중 하나를 명시합니다.

```sh
node cx-ui/scripts/install.mjs "/path/to/my-app" --target codex
```

기존 지침 파일과 수정한 스킬은 덮어쓰지 않습니다. 설치 후 프로젝트를 다시 열고 Codex는 `$cx-ui`, Claude Code는 `/cx-ui`로 호출합니다. 새 프로젝트 생성 시에는 `--skill-target codex|claude|all`로 선택하며, 생략하면 스킬 없이 생성합니다.

다른 도구는 ZIP·폴더 등록 기능을 사용하거나 `cx-ui/SKILL.md를 읽고 CX로 개발해줘`라고 요청합니다. [스킬 설치·호출 안내](docs/SKILLS.md)에 자세한 예시가 있습니다. 실제 컴포넌트·CSS·폰트는 2절의 CX 패키지를 함께 연결합니다.

에이전트에 화면 목적과 필요한 동작, 연결할 기존 함수를 함께 전달합니다. Codex 예시입니다.

```text
$cx-ui 업무 관리 화면을 만들어줘.
list-detail 템플릿을 기준으로 검색, 목록, 상세 수정과 미저장 확인을 넣어줘.
저장은 프로젝트의 기존 업무 저장 함수에 연결하고,
저장 중 중복 실행을 막고 실패해도 입력값을 유지해줘.
```

```text
$cx-ui 현재 설정 화면을 CX 기준으로 바꿔줘.
기존 데이터와 저장 동작은 유지하고 버튼, 입력, 모달, 간격을 맞춰줘.
좁은 화면과 저장 실패 상태도 확인해줘.
```

```text
$cx-ui 정렬·필터·열 고정이 있는 표를 만들어줘.
agent/table-contract.json과 docs/TABLES.txt를 먼저 확인하고,
공개 CxTable의 지원 범위와 추가 구현할 기능을 구분해줘.
페이지 간 선택, 숨긴 열의 필터, 편집값과 CSV 범위까지 검증해줘.
```

Claude Code에서는 다음과 같이 요청합니다. 두 도구가 같은 스킬 원본과 설치된 CX 기준을 읽습니다.

```text
/cx-ui 기존 업무 화면을 CX로 맞춰줘.
기존 API와 입력값은 유지하고 표·모달·토스트를 공통 기준으로 적용해줘.
저장 실패와 재시도, 좁은 화면까지 확인해줘.
```

스킬 호출을 지원하지 않는 도구에는 `.agents/skills/cx-ui/SKILL.md`를 읽고 적용하도록 요청할 수 있습니다. 스킬 등록 위치와 호출 방법은 도구에 맞게 연결합니다.

설치된 CX의 버전과 사용할 컴포넌트를 직접 검색할 수도 있습니다. 아래 명령은 프로젝트의 패키지를 사용하므로 Codex·Claude Code 중 어느 도구를 선택했는지와 관계없이 실행할 수 있습니다.

```sh
node node_modules/@e2e/cx-design-system/skills/cx-ui/scripts/lookup.mjs . --summary
node node_modules/@e2e/cx-design-system/skills/cx-ui/scripts/lookup.mjs . 로그인
```

검색어를 모달·고정·토스트 등으로 바꾸면 관련 API·토큰·사용 안내를 찾습니다.

로그인 버튼은 `ActionButton`의 `action="login"`, 단독 아이콘은 `Icon`의 `name="logIn"`입니다. 스킬은 설치된 버전의 공개 목록과 문서를 찾으므로, 없는 props나 참고 전용 화면을 공개 API처럼 사용하지 않도록 요청하세요.

완성 후에는 정적 검사와 빌드뿐 아니라 실제 화면도 확인합니다.

```sh
npm run design:check
npm run build
```

좁은 화면, 긴 한국어, 빈 결과, 입력 오류, 저장 실패·재시도, 모달 Esc·초점 복귀를 확인하세요. 정적 검사는 임의 색상·폰트와 일부 내부 스타일 변경을 찾지만 모든 동작을 검증하지는 않습니다.

## 6. 디자인 기준과 공통 동작 유지하기

색상은 `--brand-action`, `--layout-text`, `--layout-muted` 같은 역할별 변수를 사용합니다. 간격은 `--cx-space-2`, `--cx-space-4` 등으로 연결합니다. Noto Sans KR 파일은 패키지에 포함되어 외부 웹폰트 CDN이 필요하지 않습니다.

버튼·입력 기본 높이는 32px, 작은 조작 토큰은 28px입니다. 주 입력 장치가 터치인 `(pointer: coarse)`에서 두 토큰이 44px로 바뀝니다. 화면 너비만 줄이는 것과 터치 조건은 다릅니다. 임의의 `size` prop을 추가하거나 내부 버튼 크기를 고정 CSS로 덮어쓰지 마세요. 세부 값은 [디자인 기준](docs/IDENTITY.md)과 토큰 라이브러리를 참고합니다.

**현재 `CxTable`은 기본 표시용 표입니다.** 정렬·열 고정·필터·행 선택이 내장된 고급 DataGrid가 아닙니다. [표 동작 기준](docs/TABLES.txt)은 18개 기능의 원본 동작, 상태 전이와 재사용 전 보완할 항목을 설명합니다. 에이전트는 [표 기능 계약](agent/table-contract.json)으로 같은 내용을 조회합니다.

토스트의 왼쪽 원은 알림이 표시되는 약 3초를 보여줍니다. 오류·재시도 알림도 자동으로 닫히며 키보드 조작과 숨겨진 탭에서는 시간이 멈춥니다. 작업 중에는 `ActionButton busy`, 결과가 확인되면 `notifyToast`를 사용하고, 지속적 오류는 `CxNotice`로 화면에 남깁니다. [토스트·로딩 사용 방법](docs/FEEDBACK.md)에 재시도 코드, 모션 감소, 모달 초점, 진단 복사와 전체 동작을 정리했습니다. 에이전트는 `agent/feedback-contract.json`을 함께 읽습니다.

```jsx
notifyToast('저장했습니다.');
notifyToast('저장하지 못했습니다. 입력값은 유지됩니다.', { error: true });
```

`agent/manifest.json`의 `portable`에 있는 API만 패키지에서 import합니다. `reference/`는 제품 디자인의 참고 소스이며 제품 데이터·provider에 연결된 코드도 포함합니다. 파일이 들어 있다고 독립 실행 가능한 컴포넌트는 아닙니다.

## 7. React 없이 활용하기

`dist/styles.css`와 `dist/fonts/`를 웹사이트의 같은 `cx` 폴더 안에 복사합니다. 폰트 상대 경로를 유지하세요.

```html
<link rel="stylesheet" href="./cx/styles.css">
```

이후 CSS 변수로 화면을 구성할 수 있습니다. React 컴포넌트의 키보드 이동·필터·모달 초점 관리까지 CSS만으로 제공되지는 않으므로 해당 프레임워크에서 구현합니다. 전체 CSS에는 공통 reset과 제품 참고 스타일이 포함되므로 기존 스타일과의 영향을 확인하세요.

## 8. 팀에 배포하고 업데이트하기

### 같은 버전을 함께 사용하기

프로젝트의 `vendor` TGZ, `package.json`, `package-lock.json`과 선택해서 설치한 스킬 폴더를 사내 프로젝트 저장소에서 함께 관리합니다. Codex는 `.agents/skills/cx-ui`, Claude Code는 `.claude/skills/cx-ui`입니다. 팀원은 프로젝트의 사내 의존성 설치 환경에서 `npm ci`를 실행해 같은 버전을 사용합니다.

### 새 배포본으로 업데이트하기

새 TGZ를 `vendor`에 넣고 해당 파일 경로로 `npm install`을 실행합니다. [변경 기록](CHANGELOG.md)을 확인하고 lockfile을 함께 반영하세요. 복사한 템플릿과 서비스 코드는 자동으로 바뀌지 않으므로 필요한 변경을 프로젝트에 적용합니다.

스킬도 설치기를 다시 실행해 갱신합니다. 기존 파일이 새 배포본과 다르면 덮어쓰지 않고 중단합니다. 변경 내용을 비교하고 기존 폴더를 도구의 skills 경로 밖에 백업한 뒤 다시 설치하세요. 업데이트 후에는 디자인 검사·빌드와 함께 수정한 화면의 저장·오류·모달 동작을 확인합니다.

### 공통 개선을 요청하기

공통 컴포넌트나 디자인 기준에 변경이 필요하면 [사내 CX 저장소의 Issues](https://code.sdsdev.co.kr/Manufacturing-IT/CX/issues)에 사용 중인 버전, 적용 화면, 기대 동작과 재현 방법을 남깁니다. 서비스별 코드에 같은 수정이 반복된다면 공통 요소로 관리할 수 있는지 함께 검토합니다.

카탈로그를 게시하는 담당자는 [사내 Pages 배포 안내](docs/INTERNAL-PAGES.md)를, CX 소스를 수정하고 배포 파일을 만드는 담당자는 [관리와 배포](docs/GOVERNANCE.md)를 따릅니다. README와 Pages의 **사용 설명서**는 같은 원본을 사용합니다.

## 9. 필요한 자료 찾기

| 궁금한 내용 | 기준 자료 |
| --- | --- |
| 색상·폰트·크기·강조 정도 | [디자인 기준](docs/IDENTITY.md) |
| 공개 컴포넌트와 props | [공통 컴포넌트](docs/COMPONENTS.md) |
| 화면별 흐름과 조합 | [화면 패턴](docs/PATTERNS.md) |
| 템플릿 설치·복사·서비스 연결 | [템플릿 사용 안내](docs/TEMPLATES.txt) |
| 표의 정렬·고정·필터·편집 | [표 동작 기준](docs/TABLES.txt) |
| 토스트·원형 타이머·로딩·재시도 | [토스트·로딩 사용 방법](docs/FEEDBACK.md) |
| 에이전트가 읽는 진입 지침 | [에이전트 지침](agent/INSTRUCTIONS.md) |
| Codex·Claude Code 설치·호출 | [스킬 사용 안내](docs/SKILLS.md) |
| 개발 스킬의 실제 작업 순서 | [CX UI 스킬](skills/cx-ui/SKILL.md) |
| 패키지 변경·검증·배포 절차 | [관리와 배포](docs/GOVERNANCE.md) |
| 확인한 환경과 검증 한계 | [검증 기록](docs/VERIFICATION.md) |

개발자는 필요한 템플릿과 컴포넌트로 화면을 만들고, 공통 기준의 변경은 CX에서 관리합니다. 새 요소를 추가할 때는 목적·상태·사용 예제와 검증 결과를 함께 남겨 다음 프로젝트와 에이전트가 같은 기준으로 재사용할 수 있게 합니다.

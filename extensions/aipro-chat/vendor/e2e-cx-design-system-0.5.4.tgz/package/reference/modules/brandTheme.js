export const validColor = (value) => /^#[\da-f]{6}$/i.test(value || '');
const mix = (hex, target, ratio) => '#' + [1,3,5].map((index) => Math.round(parseInt(hex.slice(index,index+2),16)*(1-ratio)+target*ratio).toString(16).padStart(2,'0')).join('');
function luminance(hex) { return [1,3,5].map((i) => parseInt(hex.slice(i,i+2),16)/255).map((v) => v <= .04045 ? v/12.92 : ((v+.055)/1.055)**2.4).reduce((n,v,i) => n+v*[.2126,.7152,.0722][i],0); }

export function readBrandColor() { const color=localStorage.getItem('e2e-brand-color');return validColor(color)?color:'#1826ad'; }

export function brandTokens(color, theme) {
  const source=validColor(color)?color:'#1826ad';
  let action=source;
  // Keep white action text legible even when a very light custom color is chosen.
  while(luminance(action)>.18) action=mix(action,0,.08);
  const dark=theme==='dark';
  const palette=Object.fromEntries([[50,.97],[100,.92],[200,.84],[300,.68],[400,.48],[500,.24],[600,0]].map(([step,ratio])=>[`--brand-${step}`,mix(action,255,ratio)]));
  const blend=(foreground,background,amount)=>'#'+[1,3,5].map(i=>Math.round(parseInt(foreground.slice(i,i+2),16)*amount+parseInt(background.slice(i,i+2),16)*(1-amount)).toString(16).padStart(2,'0')).join('');
  let accent=dark?mix(action,255,.72):action;
  const surface=dark?blend(action,'#222631',.12):palette['--brand-50'];
  const soft=dark?blend(action,'#292f3d',.23):palette['--brand-100'];
  const selected=dark?blend(action,'#354052',.25):mix(action,255,.86);
  const border=dark?mix(action,255,.42):palette['--brand-300'];
  let medium=dark?mix(action,255,.62):palette['--brand-500'];
  const contrast=(a,b)=>(Math.max(luminance(a),luminance(b))+.05)/(Math.min(luminance(a),luminance(b))+.05);
  while(contrast(accent,selected)<4.5) accent=mix(accent,dark?255:0,.06);
  while(contrast(medium,soft)<3) medium=mix(medium,dark?255:0,.06);
  return {...palette,'--brand-color':source,'--brand-action':action,'--brand-ink':accent,'--brand-mid':medium,
    '--brand-surface':surface,'--brand-soft':soft,'--brand-selected':selected,'--brand-border':border,
    '--brand-canvas':dark?'#191d27':mix(action,255,.985),
    '--layout-accent':accent,'--layout-selected':selected,'--cx-button-primary':action,
    '--color-bg-primary':action,'--color-bg-primary-hover':mix(action,0,.16),'--color-fg-primary':accent,
    '--color-bg-primary-tint':soft,'--color-border-primary':border,'--color-effect-focus-primary':medium};
}

export function applyBrandTheme(color, theme) {
    const values=brandTokens(color,theme);
    const action=values['--brand-action'];
    Object.entries(values).forEach(([key,value]) => document.documentElement.style.setProperty(key,value));
    localStorage.setItem('e2e-brand-color',color);
    const icon=document.querySelector('link[rel="icon"]');
    if(icon) icon.href='data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="9" fill="${action}"/><g transform="translate(4 4)" fill="none" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Zm0 0v6h6M8 13h8m-8 4h6"/></g></svg>`);
}

// Product appearance is fixed; earlier local display preferences no longer apply.
export function applyProductTheme() {
  document.documentElement.dataset.theme = 'light';
  document.documentElement.classList.remove('dark');
  localStorage.setItem('e2e-theme', 'light');
  applyBrandTheme('#1826ad', 'light');
}

export function parseCalendarDay(value) {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return null;
  const [year,month,day]=value.split('-').map(Number),date=new Date(year,month-1,day,12);
  return date.getFullYear()===year&&date.getMonth()===month-1&&date.getDate()===day?date:null;
}
export function formatCalendarDay(date) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}
export function calendarCells(month) {
  const first=new Date(month.getFullYear(),month.getMonth(),1,12),start=new Date(first);
  start.setDate(1-first.getDay());
  const length=Math.ceil((first.getDay()+new Date(month.getFullYear(),month.getMonth()+1,0).getDate())/7)*7;
  return Array.from({length},(_,i)=>{const date=new Date(start);date.setDate(start.getDate()+i);return {date,value:formatCalendarDay(date),inMonth:date.getMonth()===month.getMonth()};});
}
export function rangeError(from,to) {
  if(!from&&!to)return '';
  if(!parseCalendarDay(from)||!parseCalendarDay(to))return '시작일과 종료일을 YYYY-MM-DD 형식으로 입력하세요.';
  return from>to?'종료일을 시작일 이후로 선택하세요.':'';
}
export function chooseRangeDay(from,value,phase) {
  return phase==='start'||!parseCalendarDay(from)?{from:value,to:'',phase:'end'}:{from:from<value?from:value,to:from<value?value:from,phase:'start'};
}

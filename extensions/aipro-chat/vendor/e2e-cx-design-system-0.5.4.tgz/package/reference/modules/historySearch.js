// Date filters use the viewer's local calendar, including the entire end date.
export function historyDay(value) {
  const date = new Date(value);
  if (!value || Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}

export function searchHistory(entries, {query='', from='', to=''} = {}) {
  const terms=query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  if (from && to && from > to) return [];
  return entries.filter(entry => {
    const day=historyDay(entry.date);
    if ((from || to) && (!day || (from && day < from) || (to && day > to))) return false;
    const text=[entry.sha,entry.message,entry.author?.name,entry.author?.login].filter(Boolean).join(' ').toLocaleLowerCase();
    return terms.every(term=>text.includes(term));
  });
}

export const shortCommit = sha => /^[a-f\d]{40}$/i.test(sha || '') ? sha.slice(0,6) : '';

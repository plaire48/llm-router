import { ActionButton } from './ActionButton';
import React, { useEffect, useId, useMemo, useRef, useState } from 'react';
import { ReactFlow, Background, MiniMap, Handle, Position, MarkerType, BaseEdge, getSmoothStepPath } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Icon } from './Icon';
import { flowCardType, numberedFlowNodes } from './agentFlowModel';
import { catalogValues } from './catalogValues';
import './flow-preview.css';

const cardIcons={file_read:'file',system_read:'search',file_write:'pencil',system_write:'play',receive_notification:'bell',send_notification:'send',human_approval:'users',decision:'decision'};
function FlowCard({data}) {
  const {node,number,label,selected,roles,cardType,container,handles,color}=data;
  return <div className={`flow-preview-card ${selected?'is-selected':''} ${container?'is-container':''} ${node.type==='memo'?'is-memo':''}`} style={{'--flow-card-color':color}}>
    {handles.filter(handle=>!/^case_\d+$/.test(handle.id)).map(handle=><Handle key={`${handle.type}-${handle.id}`} id={handle.id} type={handle.type} position={handle.position} isConnectable={false} style={{top:handle.position===Position.Left||handle.position===Position.Right?'50%':undefined}}/>)}
    <header><Icon name={cardIcons[cardType]||'workflow'} size={18}/><span>{number}</span><small>{label}</small></header>
    <strong>{node.name}</strong>
    {node.type==='memo'&&<p>{node.content}</p>}
    {node.type==='branch'&&node.cases?.length>0&&<div className="flow-preview-branches">{node.cases.map((item,index)=><span key={index}>{item.label||item.value||`분기 ${index+1}`}{handles.some(handle=>handle.id===`case_${index}`)&&<Handle id={`case_${index}`} type="source" position={Position.Right} isConnectable={false}/>}</span>)}</div>}
  </div>;
}
function Lane({data}) {return <div className="flow-preview-lane"><span>{data.label}</span></div>;}
function RoutedEdge(props) {
  const offset=props.data?.offset;
  const [path,labelX,labelY]=getSmoothStepPath({...props,...(offset?{centerX:(props.sourceX+props.targetX)/2+(Number(offset.x)||0),centerY:(props.sourceY+props.targetY)/2+(Number(offset.y)||0)}:{})});
  return <BaseEdge id={props.id} path={path} markerEnd={props.markerEnd} style={props.style} label={props.label} labelX={labelX} labelY={labelY} labelStyle={props.labelStyle} labelBgStyle={props.labelBgStyle} labelBgPadding={[6,4]} labelBgBorderRadius={4}/>;
}
const logicLabels={start:'시작',end:'종료',timer:'타이머',schedule:'일정',if_else:'조건 분기',loop:'반복',for_each:'항목별 반복',parallel:'병렬'};
const cardColors={file_read:'#2365a0',system_read:'#2365a0',file_write:'#a15c17',system_write:'#a15c17',receive_notification:'#2d78a5',send_notification:'#2d78a5',human_approval:'#6d4bb0',decision:'#6d4bb0'};
const nodeTypes={flowCard:FlowCard,taskLane:Lane},edgeTypes={routed:RoutedEdge};
const fitViewOptions={padding:.14,minZoom:.03,maxZoom:1};
const side=(value,fallback)=>value?.includes('left')?Position.Left:value?.includes('right')?Position.Right:value?.includes('top')?Position.Top:value?.includes('bottom')?Position.Bottom:fallback;
export function AgentFlowPreview({assessment,scoring,selected,onSelect,taskPicker,focusRequest}) {
  const instance=useRef(null),canvas=useRef(null),host=useRef(null),expandButton=useRef(null),viewMode=useRef('fit');
  const [expanded,setExpanded]=useState(false),[zoom,setZoom]=useState(1),[showOverview,setShowOverview]=useState(false),canvasId=useId();
  const [measurements,setMeasurements]=useState({key:null,values:{}});
  const setViewMode=mode=>{viewMode.current=mode;setShowOverview(mode==='manual');};
  const duration=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:180;
  const fit=()=>{setViewMode('fit');return instance.current?.fitView({padding:.14,minZoom:.03,maxZoom:1,duration:duration()});};
  const resizeView=()=>{setViewMode('fit');setExpanded(value=>!value);};
  const changeZoom=direction=>{setViewMode('manual');direction>0?instance.current?.zoomIn({duration:duration()}):instance.current?.zoomOut({duration:duration()});};
  const actualSize=()=>{setViewMode('manual');instance.current?.zoomTo(1,{duration:duration()});};
  const {nodes,edges}=useMemo(()=>{
    const workflow=assessment.workflow,labels=new Map(numberedFlowNodes(workflow).map(item=>[item.node.id,item.number])),cards=catalogValues(scoring.cards),positions=new Map();
    workflow.tasks.forEach((task,index)=>{let order=0;workflow.nodes.filter(node=>node.task_id===task.id).forEach(node=>{const saved=workflow.layout?.nodes[node.id];positions.set(node.id,{x:saved?.x??260+order++*220,y:saved?.y??100+index*280,width:saved?.width??156,height:saved?.height??Math.max(96,72+Math.ceil(node.name.length/10)*16)});});});
    const maxX=Math.max(600,...[...positions.values()].map(p=>p.x+p.width)),minX=Math.min(0,...[...positions.values()].map(p=>p.x-100));
    const lanes=workflow.tasks.map((task,index)=>{
      const ps=workflow.nodes.filter(n=>n.task_id===task.id).map(n=>positions.get(n.id));
      const y=ps.length?Math.min(...ps.map(p=>p.y))-42:index*280;
      return {id:`lane:${task.id}`,type:'taskLane',position:{x:minX,y},data:{label:task.name},style:{width:maxX-minX+64,height:ps.length?Math.max(...ps.map(p=>p.y+p.height))-y+32:180},selectable:false,draggable:false,zIndex:-2};
    });
    const graphNodes=workflow.nodes.map(node=>{
      const kind=flowCardType(node),cardType=assessment.settings[node.id]?.cardType||kind;
      const label=kind===null?node.type==='branch'?logicLabels[node.logic_type]||'Logic':node.type==='memo'?'Memo':logicLabels[node.event_type]||'Logic':cards.find(item=>item.id===cardType)?.label||node.module?.name||'Action';
      const position=positions.get(node.id),container=node.type==='branch'&&(node.loop||['loop','parallel','for_each'].includes(node.logic_type));
      const handles=[{id:'in',type:'target',position:Position.Left},{id:'out',type:'source',position:Position.Right}];
      workflow.edges.forEach(edge=>{if(edge.source===node.id&&edge.source_handle&&!handles.some(h=>h.id===edge.source_handle&&h.type==='source'))handles.push({id:edge.source_handle,type:'source',position:side(edge.source_handle,Position.Right)});if(edge.target===node.id&&edge.target_handle&&!handles.some(h=>h.id===edge.target_handle&&h.type==='target'))handles.push({id:edge.target_handle,type:'target',position:side(edge.target_handle,Position.Left)});});
      return {id:node.id,type:'flowCard',position:{x:position.x,y:position.y},data:{node,number:labels.get(node.id),label,cardType,container,handles,color:/^#[0-9a-f]{6}$/i.test(workflow.layout?.nodes[node.id]?.color||node.color||'')?(workflow.layout?.nodes[node.id]?.color||node.color):(cardColors[cardType]||'#60748e'),selected:selected===node.id,roles:(assessment.roles||[]).filter(role=>[...(node.role_ids||[]),node.role_id].includes(role.id)).map(role=>role.name).join(', ')},style:{width:position.width,...(container?{height:position.height}:{minHeight:96})},draggable:false,zIndex:container?0:2};
    });
    return {nodes:[...(workflow.tasks.length>1?lanes:[]),...graphNodes],edges:workflow.edges.map(edge=>{
      const connected=selected&&(edge.source===selected||edge.target===selected);
      return {id:edge.id,source:edge.source,target:edge.target,sourceHandle:edge.source_handle||'out',targetHandle:edge.target_handle||'in',type:edge.route_offset?'routed':'smoothstep',data:{offset:edge.route_offset},label:edge.label||edge.condition||'',markerEnd:{type:MarkerType.ArrowClosed,width:16,height:16,color:connected?'var(--brand-ink)':'#60738d'},style:{stroke:connected?'var(--brand-ink)':selected?'#a5b3c4':'#60738d',strokeWidth:connected?2.6:1.8},labelStyle:{fontSize:13,fontWeight:connected?600:500,fill:'#24364f'},labelBgStyle:{fill:'#fff',fillOpacity:1,stroke:'#dbe2ee'},labelBgPadding:[6,4],labelBgBorderRadius:4,zIndex:connected?3:1};
    })};
  },[assessment.workflow,assessment.roles,assessment.settings,scoring,selected]);
  // Only structural changes reset the viewport; scoring edits and selection do not.
  const graphKey=JSON.stringify([assessment.workflow.id,assessment.fileName,nodes.map(node=>[node.id,node.position,node.style]),assessment.workflow.edges]);
  // Controlled nodes must retain measured dimensions for the overview map.
  const measuredNodes=useMemo(()=>nodes.map(node=>measurements.key===graphKey&&measurements.values[node.id]?{...node,measured:measurements.values[node.id]}:node),[nodes,measurements,graphKey]);
  const measureNodes=changes=>setMeasurements(previous=>{
    const dimensions=changes.filter(change=>change.type==='dimensions'&&change.dimensions);
    if(!dimensions.length)return previous;
    const values=previous.key===graphKey?previous.values:{};
    if(dimensions.every(change=>values[change.id]?.width===change.dimensions.width&&values[change.id]?.height===change.dimensions.height))return previous;
    return {key:graphKey,values:{...values,...Object.fromEntries(dimensions.map(change=>[change.id,change.dimensions]))}};
  });
  useEffect(()=>{
    const observer=new ResizeObserver(()=>{if(viewMode.current==='fit')fit();});
    if(canvas.current)observer.observe(canvas.current);
    return()=>observer.disconnect();
  },[graphKey]);
  useEffect(()=>{
    if(!focusRequest?.id||!nodes.some(node=>node.id===focusRequest.id))return;
    setViewMode('manual');host.current?.scrollIntoView({block:'nearest',behavior:'instant'});
    instance.current?.fitView({nodes:[{id:focusRequest.id}],maxZoom:1,minZoom:.5,duration:duration(),padding:.5});
  },[focusRequest]);
  const keyboard=event=>{
    if(event.key==='Escape'&&expanded){event.preventDefault();event.stopPropagation();resizeView();expandButton.current?.focus();return;}
    if(event.target!==canvas.current)return;
    if(['+','=','-','0','Home','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
      event.preventDefault();event.stopPropagation();
      if(event.key==='Home'){fit();return;}if(event.key==='0'){actualSize();return;}
      if(['+','=','-'].includes(event.key)){changeZoom(event.key==='-'?-1:1);return;}
      const viewport=instance.current?.getViewport();if(!viewport)return;
      setViewMode('manual');instance.current.setViewport({...viewport,x:viewport.x+(event.key==='ArrowLeft'?80:event.key==='ArrowRight'?-80:0),y:viewport.y+(event.key==='ArrowUp'?80:event.key==='ArrowDown'?-80:0)});
    }
  };
  return <section ref={host} className={`flow-preview ${expanded?'is-expanded':''}`} aria-label="Agent Flow 워크플로우" onKeyDown={keyboard}>
    <div className="flow-preview-toolbar"><div className="flow-preview-task-control">{taskPicker}</div><div className="flow-preview-controls">
      <div className="flow-preview-zoom"><ActionButton action="zoomOut" title="축소" aria-label="워크플로우 축소" disabled={zoom<=.031} onClick={()=>changeZoom(-1)}/><button type="button" className="flow-preview-scale" aria-label={`현재 배율 ${Math.round(zoom*100)}%, 100%로 보기`} title="100%로 보기" onClick={actualSize}>{Math.round(zoom*100)}%</button><ActionButton action="zoomIn" title="확대" aria-label="워크플로우 확대" disabled={zoom>=1.999} onClick={()=>changeZoom(1)}/></div>
      <ActionButton action="fit" type="button" className="flow-preview-fit" aria-label="워크플로우 화면에 맞춤" onClick={fit}/>
      <ActionButton action={expanded?'collapse':'expand'} ref={expandButton} aria-label={expanded?'워크플로우 크기 복원':'워크플로우 크게 보기'} aria-pressed={expanded} aria-controls={canvasId} onClick={resizeView}/>
    </div></div>
    <div ref={canvas} id={canvasId} className="flow-preview-canvas" tabIndex={0} role="region" aria-label="워크플로우 캔버스. 방향키로 이동, 더하기와 빼기로 확대 축소, Home으로 화면 맞춤." ><ReactFlow key={graphKey} nodes={measuredNodes} onNodesChange={measureNodes} edges={edges} nodeTypes={nodeTypes} edgeTypes={edgeTypes} onInit={value=>{instance.current=value;setViewMode('fit');}} fitView fitViewOptions={fitViewOptions} onMove={(_,viewport)=>setZoom(viewport.zoom)} onMoveStart={event=>{if(event)setViewMode('manual');}} panOnScroll zoomOnScroll={false} zoomOnDoubleClick={false} minZoom={.03} maxZoom={2} nodesDraggable={false} nodesConnectable={false} edgesFocusable={false} elementsSelectable={false} deleteKeyCode={null} onNodeClick={(_,node)=>node.type==='flowCard'&&onSelect(node.id,{reveal:!expanded})} ><Background color="#dce2eb" gap={20}/>{showOverview&&nodes.filter(node=>node.type==='flowCard').length>7&&<MiniMap className="flow-preview-minimap" ariaLabel="전체 흐름과 현재 위치" pannable nodeColor={node=>node.data.selected?'#255dc2':node.data.color||'#8da2be'} nodeStrokeWidth={0} maskColor="rgba(239,243,250,.7)" maskStrokeColor="#567ac0" maskStrokeWidth={2} onClick={(_,point)=>{setViewMode('manual');instance.current?.setCenter(point.x,point.y,{zoom:instance.current.getZoom(),duration:duration()});}}/>}</ReactFlow></div>
  </section>;
}

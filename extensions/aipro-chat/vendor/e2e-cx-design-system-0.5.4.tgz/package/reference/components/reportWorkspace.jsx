import {CxSelect} from './CxSelect';
import { confirmAction } from './confirmAction';
import React, { useEffect, useMemo, useState } from 'react';
import { Icon, SearchInput } from './Icon';
import { WorkspaceFilters, WorkspaceTabs, ReportActionBar, SortHeader, SelectionCheckbox, useRowSelection } from './WorkspaceLayout';
import { GHES_CONFIG } from './config';
import { getMasterDefinition, MASTER_DEFINITIONS } from './masterCatalog';
import { getGithubSession, hasActiveGithubSession } from './session';
import { loadGithubJson, loadGithubMaster, saveGithubMaster, parseMaster, listGithubMasterHistory } from './master';
import { aggregateBy, aggregateDecisionDistribution, aggregateEnhancementTypes, aggregateNonTargetReasons, aggregateScalability, enrichWorkItem, summarizeRows } from './reportMetrics';
import { getDecisionResultItems } from './decisionLogic';
import { formatAutomationRate } from './automationRate';
import { DetailPanel } from './DetailPanel';
import { ActiveColumnFilters, ControlledTable, TableControlsContext, TablePagination, useColumnControls, usePagination } from './TableControls';
import { useWorkspaceState, TableViewport } from './WorkspaceMemory';
import { downloadReportCsv, sortReportRows } from './reportInteractions';

function numberOrNull(value) {
  if (value === '' || value === null || value === undefined) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function activeItems(document) {
  return (document?.items || []).filter((item) => item.active !== false).sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
}

function labelFor(document, id, fallback = '미입력') {
  return activeItems(document).find((item) => item.id === id)?.label || fallback;
}

function formatMinutes(value) {
  return value === null || value === undefined ? '–' : `${Math.round(value).toLocaleString()}분`;
}

function formatMd(value) {
  return value === null || value === undefined ? '–' : `${Number(value).toLocaleString(undefined, { maximumFractionDigits: 1 })} M/D`;
}

function formatRatio(value) {
  return value === null || value === undefined ? '–' : `${Number(value).toLocaleString(undefined, { maximumFractionDigits: 2 })}배`;
}

function CatalogSelect({ label, value, onChange, document, placeholder = '미입력' }) {
  return <label className="enhancement-field"><span>{label}</span><CxSelect className="native-select" value={value || ''} onChange={(event) => onChange(event.target.value || null)}><option value="">{placeholder}</option>{activeItems(document).map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect></label>;
}

function MetricCard({ label, value, tone = '' }) {
  return <div className={`report-metric-card ${tone ? `report-metric-card--${tone}` : ''}`}><Icon name={label === 'Task 수' ? 'taskList' : label === '자동화율 평균' ? 'automation' : label.includes('대상') ? 'decision' : label.includes('공수') ? 'layers' : 'clockRewind'} size={18}/><span>{label}</span><strong>{value}</strong></div>;
}

function ReportTable({ columns, rows, sort, onSort, memoryKey, page, empty = '표시할 데이터가 없습니다.' }) {
  return <TableViewport memoryKey={memoryKey} resetKey={page} className="report-table-wrap"><ControlledTable className="report-table"><thead><tr>{columns.map((column) => <SortHeader key={column.key} label={column.label} field={column.key} sort={sort} onSort={onSort} className={column.numeric ? 'numeric' : ''} />)}</tr></thead><tbody>{rows.map((row, index) => <tr key={row.key || row.id || index}>{columns.map((column) => <td key={column.key} className={column.numeric ? 'numeric' : ''}>{column.render ? column.render(row) : row[column.key] ?? '–'}</td>)}</tr>)}</tbody></ControlledTable>{!rows.length && <div className="table-empty">{empty}</div>}</TableViewport>;
}

export function EnhancementEditModal({ row, catalogs, onClose, onSave, readOnly = false }) {
  const [draft, setDraft] = useState({ ...row });
  const calculated = enrichWorkItem(draft, catalogs);
  const dirty = JSON.stringify(draft) !== JSON.stringify(row);
  const update = (key, value) => setDraft((current) => ({ ...current, [key]: value }));
  const close = async () => {if(!readOnly&&dirty&&!await confirmAction({kind:'close'}))return;onClose();};
  const save = (event) => {
    const invalid = [...event.currentTarget.closest('.cx-detail-panel').querySelectorAll('input, select, textarea')].find((field) => !field.checkValidity());
    if (invalid) { invalid.reportValidity(); return; }
    onSave({ ...draft, ...Object.fromEntries(['rate', 'expectedAutomationRate', 'automationRateDelta', 'afterMonthlySavingMinutes', 'additionalSavingMinutes', 'effortMd', 'monthlyCount', 'perCaseMinutes', 'monthlySavingMinutes'].map((key) => [key, numberOrNull(draft[key])])) });
  };
  const groups = [
    { title: '기본 정보', fields: [['responsibleGroup', '담당그룹', 'responsibleGroups'], ['appliedStatus', '적용 상태', 'appliedStatus'], ['diagnosisReviewStatus', '진단 검수여부', 'diagnosisReviewStatus']] },
    { title: '운영·자동화 상태', fields: [['humanInterventionLevel', '인적 개입 수준', 'humanInterventionLevel'], ['deploymentType', '배포유형', 'deploymentTypes'], ['frequencyId', '예상 수행빈도', 'frequencyConversion'], ['customizationNeed', '커스터마이징 필요 여부', 'customizationNeed'], ['nonAutomationCause', '자동화 불가 원인 유형', 'nonAutomationCause']] },
    { title: '대상 판정과 사유', fields: [['enhancementTarget', '고도화 대상 여부', 'enhancementTarget'], ['nonTargetReason', '미대상 사유 유형', 'nonTargetReason'], ['enhancementType', '고도화 유형', 'enhancementType'], ['enhancementItem', '고도화 항목', 'text'], ['nonTargetReasonText', '미대상 사유 원문', 'textarea']] },
    { title: '기대 효과·공수', fields: [['priority', '우선순위', 'priority'], ['effortCategory', '공수 구분', 'effortCategory'], ['expectedAutomationRate', '예상 자동화율 (%)', 'number'], ['afterMonthlySavingMinutes', '고도화 후 월 절감시간 (분)', 'number'], ['additionalSavingMinutes', '추가 절감시간 (분/월)', 'number'], ['effortMd', '투입 공수 (M/D)', 'number']] },
  ];
  return <DetailPanel className="enhancement-modal" title={readOnly ? '고도화 항목 상세' : '고도화 항목 관리'} subtitle={`${draft.process} / ${draft.activity}`} onClose={close} footer={<><span className="cx-footer-status">{readOnly ? '' : dirty ? '적용하지 않은 변경 사항이 있습니다.' : '변경 사항 없음'}</span><button className="cx-button" type="button" onClick={close}>{readOnly ? '닫기' : '취소'}</button>{!readOnly && <button className="cx-button cx-button--primary" type="button" onClick={save} disabled={!dirty}>변경 적용</button>}</>}>
    <div className="cx-detail-intro"><span className="cx-section-label">Task</span><h3>{draft.task}</h3></div>
    <div className="cx-decision-summary"><Icon name="clipboardCheck" size={21} /><div><span>자동 판정</span><strong>{calculated.decision.label}</strong><p>{calculated.decision.nextAction}</p></div></div>
    {groups.map((group) => <fieldset key={group.title} className="cx-form-section" disabled={readOnly}><legend>{group.title}</legend><div className="enhancement-form-grid">{group.fields.map(([key, label, type]) => !['text', 'textarea', 'number'].includes(type) ? <CatalogSelect key={key} label={label} value={draft[key]} onChange={(value) => update(key, value)} document={catalogs[type]} /> : <label key={key} className={`enhancement-field ${type !== 'number' ? 'enhancement-field--wide' : ''}`}><span>{label}</span>{type === 'textarea' ? <textarea className="text-area" value={draft[key] || ''} onChange={(event) => update(key, event.target.value)} /> : <input className="text-input" type={type} value={draft[key] ?? ''} min={type === 'number' ? 0 : undefined} max={key === 'expectedAutomationRate' ? 100 : undefined} step={type === 'number' ? 'any' : undefined} onChange={(event) => update(key, event.target.value)} />}</label>)}</div></fieldset>)}
  </DetailPanel>;
}

export function EnhancementWorkspace({ isEditor, user }) {
  const initialRows = useMemo(() => parseMaster(), []);
  const [rows, setRows] = useState(initialRows);
  const [baseline, setBaseline] = useState(initialRows);
  const [catalogs, setCatalogs] = useState(() => Object.fromEntries(MASTER_DEFINITIONS.map((definition) => [definition.key, definition.bundled])));
  const [sha, setSha] = useState(null);
  const [tab, setTab] = useWorkspaceState('enhancement.tab', 'items');
  const [sorts, setSorts] = useWorkspaceState('enhancement.sorts', {});
  const sort = sorts[tab] || { key: '', direction: 'asc' };
  const setSort = (next) => setSorts((current) => ({ ...current, [tab]: next }));
  const [search, setSearch] = useWorkspaceState('enhancement.search', '');
  const [processFilter, setProcessFilter] = useWorkspaceState('enhancement.processFilter', '');
  const [groupFilter, setGroupFilter] = useWorkspaceState('enhancement.groupFilter', '');
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(isEditor);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState(isEditor ? 'GHES JSON 마스터를 확인하는 중…' : '');

  const dirtyCount = rows.filter((row, index) => JSON.stringify(row) !== JSON.stringify(baseline.find((item) => item.id === row.id) || {})).length;
  const session = getGithubSession();

  useEffect(() => {
    if (!isEditor) return undefined;
    let active = true;
    const definitions = MASTER_DEFINITIONS;
    Promise.all(definitions.map(async (definition) => {
      try { return [definition.key, (await loadGithubJson({ ...session, path: definition.path }))?.document || definition.bundled]; } catch (_) { return [definition.key, definition.bundled]; }
    })).then((entries) => { if (active) setCatalogs(Object.fromEntries(entries)); });
    loadGithubMaster(session).then((remote) => {
      if (!active) return;
      if (remote?.rows?.length) { setRows(remote.rows); setBaseline(remote.rows); setSha(remote.sha); setStatus('GHES 저장소의 JSON 마스터를 불러왔습니다.'); }
      else setStatus('GHES에 저장된 업무 마스터가 없어 기본 마스터를 표시합니다. 저장하면 파일이 생성됩니다.');
    }).catch((error) => { if (active) setStatus(error.message || '원격 업무 마스터를 불러오지 못했습니다.'); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [isEditor]);

  const filteredRows = useMemo(() => rows.filter((row) => {
    const haystack = `${row.process} ${row.activity} ${row.task} ${row.responsibleGroup}`.toLowerCase();
    return (!processFilter || row.process === processFilter) && (!groupFilter || row.responsibleGroup === groupFilter) && (!search || haystack.includes(search.toLowerCase()));
  }), [rows, processFilter, groupFilter, search]);
  const summary = useMemo(() => summarizeRows(filteredRows, catalogs), [filteredRows, catalogs]);
  const processRows = useMemo(() => aggregateBy(filteredRows, 'process', catalogs), [filteredRows, catalogs]);
  const groupRows = useMemo(() => aggregateBy(filteredRows, 'responsibleGroup', catalogs), [filteredRows, catalogs]);
  const decisions = useMemo(() => aggregateDecisionDistribution(filteredRows, catalogs), [filteredRows, catalogs]);
  const nonTargetReasons = useMemo(() => aggregateNonTargetReasons(filteredRows, catalogs), [filteredRows, catalogs]);
  const enhancementTypes = useMemo(() => aggregateEnhancementTypes(filteredRows, catalogs), [filteredRows, catalogs]);
  const scalability = useMemo(() => aggregateScalability(filteredRows, catalogs), [filteredRows, catalogs]);
  const selectedRow = rows.find((row) => row.id === selectedId) || null;
  const processOptions = [...new Set(rows.map((row) => row.process))].sort((a, b) => a.localeCompare(b, 'ko'));
  const groupOptions = activeItems(catalogs.responsibleGroups);

  const updateRow = (nextRow) => { if (!isEditor) return; setRows((current) => current.map((row) => row.id === nextRow.id ? nextRow : row)); setSelectedId(null); setStatus('변경을 적용했습니다. 변경 사항 저장을 누르면 최종 저장됩니다.'); };
  const saveChanges = async () => {
    if (!isEditor || !dirtyCount || saving) return;
    setSaving(true); setStatus('GHES JSON 마스터와 변경 이력을 저장하는 중…');
    try {
      const result = await saveGithubMaster({ ...session, sha, rows, updatedBy: user, message: `Update enhancement master (${dirtyCount} rows) by @${user?.login || 'unknown-user'}` });
      setBaseline(rows); setSha(result?.content?.sha || sha); setStatus(`저장 완료 · ${dirtyCount}건을 ${user?.login || '현재 사용자'}로 반영했습니다.`);
    } catch (error) { setStatus(error.message || '저장하지 못했습니다. 변경 내용은 화면에 남아 있습니다.'); }
    finally { setSaving(false); }
  };

  const reportTabs = [['items', '고도화 항목'], ['process', 'Process별 현황'], ['group', '담당그룹별 현황'], ['diagnosis', '판정 분포'], ['reason', '미대상 사유'], ['type', '고도화 유형 공수'], ['scale', '확장성 현황']];
  const valueColumn = (key, label, render) => ({ key, label, numeric: true, render });
  const aggregateColumns = (label) => [{ key: 'label', label }, valueColumn('taskCount', 'Task 수'), valueColumn('asIsAutomationRate', 'As-Is 자동화율 (%)', (row) => formatAutomationRate(row.asIsAutomationRate)), valueColumn('asIsMonthlySavingMinutes', 'As-Is 월절감 (분)', (row) => formatMinutes(row.asIsMonthlySavingMinutes)), valueColumn('targetCount', '대상'), valueColumn('notTargetCount', '미대상'), valueColumn('unjudgedCount', '미판정'), valueColumn('additionalSavingMinutes', '추가 절감 (분/월)', (row) => formatMinutes(row.additionalSavingMinutes)), valueColumn('effortMd', '투입 공수 (M/D)', (row) => formatMd(row.effortMd)), valueColumn('paybackRatio', '회수 지표', (row) => formatRatio(row.paybackRatio))];
  const reports = {
    process: { rows: processRows, columns: aggregateColumns('Process') },
    group: { rows: groupRows, columns: aggregateColumns('담당그룹') },
    diagnosis: { rows: decisions, columns: [{ key: 'label', label: '판정 결과' }, valueColumn('taskCount', 'Task 수'), { key: 'nextAction', label: '다음 조치' }] },
    reason: { rows: nonTargetReasons, columns: [{ key: 'label', label: '미대상 사유 유형' }, valueColumn('taskCount', 'Task 수')] },
    type: { rows: enhancementTypes, columns: [{ key: 'label', label: '고도화 유형' }, valueColumn('taskCount', 'Task 수'), valueColumn('effortMd', '투입 공수 (M/D)', (row) => formatMd(row.effortMd)), valueColumn('additionalSavingMinutes', '추가 절감 (분/월)', (row) => formatMinutes(row.additionalSavingMinutes))] },
    scale: { rows: scalability, columns: [{ key: 'label', label: '커스터마이징 필요 여부' }, valueColumn('taskCount', 'Task 수'), valueColumn('targetTaskCount', '대상 Task 수'), valueColumn('additionalSavingMinutes', '추가 절감 (분/월)', (row) => formatMinutes(row.additionalSavingMinutes))] },
  };
  const itemColumns = [{ key: 'process', label: 'Process' }, { key: 'activity', label: 'Activity' }, { key: 'task', label: 'Task' }, { key: 'responsibleGroup', label: '담당그룹', value: (row) => labelFor(catalogs.responsibleGroups, row.responsibleGroup) }, { key: 'rate', label: '자동화율 (%)', value: (row) => row.metrics.currentRate }, { key: 'decision', label: '자동 판정', value: (row) => row.decision.label }, { key: 'enhancementTarget', label: '고도화 대상', value: (row) => labelFor(catalogs.enhancementTarget, row.enhancementTarget) }, { key: 'deploymentType', label: '배포유형', value: (row) => labelFor(catalogs.deploymentTypes, row.deploymentType) }, { key: 'additionalSavingMinutes', label: '추가 절감 (분/월)', value: (row) => row.metrics.additionalSavingMinutes }];
  const definition = tab === 'items' ? { rows: filteredRows.map((row) => enrichWorkItem(row, catalogs)), columns: itemColumns } : reports[tab];
  const widths = { process: 215, task: 300, responsibleGroup: 135, rate: 140, decision: 185, enhancementTarget: 140, deploymentType: 135, additionalSavingMinutes: 185, label: 300 };
  const columns = definition.columns.map((column) => ({ ...column, hidden: tab === 'items' && column.key === 'activity', width: widths[column.key] || 175 }));
  const columnControls = useColumnControls('enhancement', tab, columns, definition.rows);
  const visibleRows = sortReportRows(columnControls.rows, sort, (row, key) => { const column = columns.find((entry) => entry.key === key); return column?.value ? column.value(row) : row[key]; });
  const scope = JSON.stringify([tab, search, processFilter, groupFilter, columnControls.filters]);
  const selection = useRowSelection(visibleRows, scope);
  const pagination = usePagination('enhancement', visibleRows, JSON.stringify([scope, sort]));
  const pageSelectedCount = pagination.rows.filter((row) => selection.ids.has(row.id)).length;
  const pageSelected = pagination.rows.length > 0 && pageSelectedCount === pagination.rows.length;
  const visibleGroupKeys = new Set(visibleRows.map((row) => row.key ?? row.code));
  const summaryInput = tab === 'items' ? visibleRows : filteredRows.filter((row) => {
    if (tab === 'reason' && row.enhancementTarget !== 'NOT_TARGET') return false;
    if (tab === 'type' && row.enhancementTarget !== 'TARGET') return false;
    const key = tab === 'diagnosis' ? enrichWorkItem(row, catalogs).decision.code : row[({ process: 'process', group: 'responsibleGroup', reason: 'nonTargetReason', type: 'enhancementType', scale: 'customizationNeed' })[tab]] || '__EMPTY__';
    return visibleGroupKeys.has(key);
  });
  const displayedSummary = summarizeRows(summaryInput, catalogs);
  const exportReport = (selected) => {
    const output = selected ? visibleRows.filter((row) => selection.ids.has(row.id)) : visibleRows;
    downloadReportCsv(output, definition.columns, `고도화_${tab}_${selected ? '선택' : '조회'}_${output.length}건`);
    setStatus(`${selected ? '선택 항목' : '조회 결과'} ${output.length}건의 CSV 파일을 만들었습니다.`);
  };
  return <TableControlsContext.Provider value={columnControls}><div className="enhancement-workspace">
    <div className="report-metric-grid"><MetricCard label="Task 수" value={displayedSummary.taskCount.toLocaleString()} /><MetricCard label="자동화율 평균" value={formatAutomationRate(displayedSummary.averageRate)} /><MetricCard label="As-Is 월 절감" value={formatMinutes(displayedSummary.monthlySavingMinutes)} /><MetricCard label="대상 / 미대상 / 미판정" value={`${displayedSummary.targetCount} / ${displayedSummary.notTargetCount} / ${displayedSummary.unjudgedCount}`} /><MetricCard label="추가 절감" value={formatMinutes(displayedSummary.additionalSavingMinutes)} /><MetricCard label="투입 공수" value={formatMd(displayedSummary.effortMd)} /></div>
    <WorkspaceFilters onReset={() => { setSearch(''); setProcessFilter(''); setGroupFilter(''); columnControls.clearFilters(); }}>
      <label className="field"><span className="input-label">Process</span><CxSelect className="native-select" value={processFilter} onChange={(event) => setProcessFilter(event.target.value)}><option value="">전체 ({processOptions.length})</option>{processOptions.map((item) => <option key={item} value={item}>{item}</option>)}</CxSelect></label>
      <label className="field"><span className="input-label">담당그룹</span><CxSelect className="native-select" value={groupFilter} onChange={(event) => setGroupFilter(event.target.value)}><option value="">전체 ({groupOptions.length})</option>{groupOptions.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect></label>
    </WorkspaceFilters>
    <WorkspaceTabs items={reportTabs} active={tab} onChange={setTab} label="고도화 관리 화면" />
    <section className="enhancement-card" aria-labelledby="enhancement-title">
      <ReportActionBar pagination={pagination} search={search} onSearch={setSearch} columnControls={columnControls} id="enhancement-title" title={reportTabs.find(([key]) => key === tab)?.[1]} description="판정 근거를 확인하고 고도화 효과를 관리합니다." count={visibleRows.length} total={tab === 'items' ? rows.length : visibleRows.length} selection={tab === 'items' ? selection : null} onDownload={exportReport} onOpenSelected={() => setSelectedId([...selection.ids][0])} busy={loading || saving}>
        {isEditor ? <><button className="cx-button" type="button" onClick={() => { setRows(baseline); setStatus('수정 내용을 원래 값으로 되돌렸습니다.'); }} disabled={!dirtyCount || saving}>되돌리기</button><button className="cx-button cx-button--primary" type="button" onClick={saveChanges} disabled={!dirtyCount || saving}><Icon name="save" size={16} />{saving ? '저장 중…' : `변경 사항 저장${dirtyCount ? ` (${dirtyCount})` : ''}`}</button></> : <a className="cx-button" href="#login"><Icon name="logIn" size={16} />로그인 후 수정</a>}
      </ReportActionBar>
      {tab === 'items' ? <TableViewport memoryKey="enhancement.items.scroll" resetKey={pagination.page} className="report-table-wrap"><ControlledTable className="report-table report-table--items" selection detail><thead><tr><th className="selection-column" data-column="__select" scope="col"><SelectionCheckbox label="현재 페이지 전체 선택" checked={pageSelected} mixed={pageSelectedCount > 0 && !pageSelected} onChange={() => selection.togglePage(pagination.rows)} /></th>{itemColumns.filter((column) => column.key !== 'activity').map((column) => <SortHeader key={column.key} label={column.key === 'process' ? 'Process / Activity' : column.label} field={column.key} sort={sort} onSort={setSort} className={['rate', 'additionalSavingMinutes'].includes(column.key) ? 'numeric' : ''} />)}<th className="detail-column" data-column="__detail" scope="col"><span className="visually-hidden">상세</span></th></tr></thead><tbody>{pagination.rows.map((row) => <tr key={row.id} data-row-id={row.id} aria-selected={selection.ids.has(row.id)} className={selection.ids.has(row.id) ? 'is-selected' : ''}>
        <td className="selection-column"><SelectionCheckbox label={`${row.task} 선택`} checked={selection.ids.has(row.id)} onChange={() => selection.toggle(row.id)} /></td><td><b>{row.process}</b><small>{row.activity}</small></td><td>{row.task}</td><td>{labelFor(catalogs.responsibleGroups, row.responsibleGroup)}</td><td className="numeric">{formatAutomationRate(row.metrics.currentRate)}</td><td><span className={`decision-badge decision-badge--${row.decision.code.toLowerCase()}`}>{row.decision.label}</span></td><td>{labelFor(catalogs.enhancementTarget, row.enhancementTarget)}</td><td>{labelFor(catalogs.deploymentTypes, row.deploymentType)}</td><td className="numeric">{formatMinutes(row.metrics.additionalSavingMinutes)}</td><td className="detail-column"><button className="table-edit-button" type="button" onClick={() => setSelectedId(row.id)}>{isEditor ? '관리' : '상세'}<Icon name="chevronRight" size={14} /></button></td>
      </tr>)}</tbody></ControlledTable>{!visibleRows.length && <div className="table-empty">조건에 맞는 업무 항목이 없습니다.</div>}</TableViewport> : <ReportTable page={pagination.page} memoryKey={`enhancement.${tab}.scroll`} rows={pagination.rows} columns={definition.columns} sort={sort} onSort={setSort} />}
      <TablePagination pagination={pagination} selectedCount={selection.ids.size} />
      <div className="table-footnote"><span className="master-status" role="status" aria-live="polite">{loading && <span className="status-spinner" aria-hidden="true" />}{dirtyCount > 0 ? `저장하지 않은 변경 ${dirtyCount}건 · ` : ''}{status}</span><span>CSV · 현재 조회 조건과 정렬 기준</span></div>
    </section>
    {selectedRow && <EnhancementEditModal key={selectedRow.id} row={selectedRow} catalogs={catalogs} onClose={() => setSelectedId(null)} onSave={updateRow} readOnly={!isEditor} />}
  </div></TableControlsContext.Provider>;
}

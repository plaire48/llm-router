import {ActionButton} from './ActionButton';
import React, { useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Icon } from './Icon';
import { catalogValues } from './catalogValues';
import { importedMethodLabel, methodSelection, selectedMethodIds } from './agentFlowModel';
import { formatAutomationRate } from './automationRate';
import { modalControls } from './modalFocus';

export function ImplementationMethodsSelect({catalog,value,label,disabled,onChange,onCommit}) {
  const [open,setOpen]=useState(false),[position,setPosition]=useState({left:0,top:0});
  const trigger=useRef(null),popup=useRef(null),id=useId();
  const selected=selectedMethodIds(value),known=catalogValues(catalog),all=[...known,...selected.filter(id=>!known.some(item=>item.id===id)).map(id=>({id,label:importedMethodLabel(id),weight:null}))];
  const options=all.filter(item=>selected.includes(item.id)||item.active!==false&&catalog.items.some(current=>current.id===item.id));
  const text=all.filter(item=>selected.includes(item.id)).map(item=>item.label).join(', ');
  const weights=selected.map(id=>all.find(item=>item.id===id)?.weight??null);
  const highest=weights.length&&weights.every(weight=>weight!==null)?Math.max(...weights):null;
  const before=useRef(''),latest=useRef(value);latest.current=value;
  const close=(focus=true)=>{setOpen(false);const next=selectedMethodIds(latest.current).slice().sort().join('|');if(next!==before.current){before.current=next;onCommit?.(latest.current);}if(focus)trigger.current?.focus({preventScroll:true});};
  useLayoutEffect(()=>{
    if(!open||disabled){if(open)setOpen(false);return;}
    const place=()=>{
      const box=trigger.current.getBoundingClientRect(),height=popup.current?.offsetHeight||200,width=Math.min(280,innerWidth-24);
      setPosition({left:Math.max(12,Math.min(box.left,innerWidth-width-12)),top:Math.max(12,Math.min(box.bottom+height+6<=innerHeight?box.bottom+6:box.top-height-6,innerHeight-height-12))});
    };
    const outside=event=>{if(!popup.current?.contains(event.target)&&!trigger.current?.contains(event.target))close(false);};
    place();(popup.current?.querySelector('input:checked')||popup.current?.querySelector('input')||popup.current?.querySelector('button'))?.focus({preventScroll:true});
    document.addEventListener('pointerdown',outside);window.addEventListener('resize',place);window.addEventListener('scroll',place,true);
    return()=>{document.removeEventListener('pointerdown',outside);window.removeEventListener('resize',place);window.removeEventListener('scroll',place,true);};
  },[open,disabled]);
  const keyboard=event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}
    if(event.key==='ArrowDown'||event.key==='ArrowUp'){
      event.preventDefault();event.stopPropagation();const items=[...popup.current.querySelectorAll('input,button')],index=items.indexOf(document.activeElement);
      items[(index+(event.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus();
    }
    if(event.key==='Tab'){
      event.preventDefault();event.stopPropagation();const panel=trigger.current.closest('[aria-modal="true"]');
      const items=modalControls(panel||document).filter(item=>!popup.current.contains(item));
      const index=items.indexOf(trigger.current);close(false);(items[(index+(event.shiftKey?-1:1)+items.length)%items.length]||trigger.current)?.focus();
    }
  };
  return <><button ref={trigger} type="button" className="text-input flow-method-trigger" data-placeholder={!text||undefined} aria-label={`${label}: ${text||'선택'}`} aria-haspopup="dialog" aria-expanded={open} aria-controls={open?id:undefined} disabled={disabled} title={text||'구현 방법 선택'} onClick={()=>open?close():(before.current=selectedMethodIds(value).slice().sort().join('|'),setOpen(true))} onKeyDown={event=>{if(event.key==='ArrowDown'){event.preventDefault();before.current=selectedMethodIds(value).slice().sort().join('|');setOpen(true);}}}><span>{text||'선택'}</span><Icon name="chevronDown" size={16}/></button>
    {open&&createPortal(<div ref={popup} id={id} className="flow-method-popover" role="dialog" aria-label={`${label} 선택`} style={position} onKeyDown={keyboard}>
      <div className="flow-method-header"><strong>구현 방법</strong><ActionButton action="close" onClick={()=>close()}/></div>
      <div className="flow-method-options">{options.map(item=><label key={item.id} className={`flow-method-option${selected.includes(item.id)?' is-selected':''}`}><input type="checkbox" className="cx-checkbox" checked={selected.includes(item.id)} onChange={()=>onChange(methodSelection(selected.includes(item.id)?selected.filter(id=>id!==item.id):[...selected,item.id]))}/><span>{item.label}</span><small>{item.weight==null?'—':formatAutomationRate(item.weight)}</small></label>)}{!options.length&&<p>등록된 구현 방법이 없습니다.</p>}</div>
      <div className="flow-method-footer"><span>최고 가중치 <strong>{highest==null?'—':formatAutomationRate(highest)}</strong></span></div>
    </div>,trigger.current.closest('.cx-detail-panel')||document.body)}
  </>;
}

import { ActionButton } from './ActionButton';
import {useFeedback, ToastNotice} from './Toast';
import {GroupedSettingsGrid} from './GroupedSettingsGrid';
import {SettingsCommitInput, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import { TableEditModeButton } from './TableEditModeButton';
import { confirmAction } from './confirmAction';
import {resolveEditConflict} from './resolveEditConflict';
import React, { useEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { MasterActionButton } from './MasterActionButton';
import { MasterUsageCheckbox } from './MasterUsageCheckbox';
import { MasterDeleteDialog } from './MasterDeleteDialog';
import { optionReferences } from './masterUsage';
import { retainRemovedValues } from './catalogValues';
import { persistCatalogChanges, persistCatalogBatch } from './catalogPersistence';
import { loadGithubJson, saveGithubJson } from './master';
import { getGithubSession } from './session';
import { formatMonthlyCount, formatMinutes } from './operatingMetrics';
import { appendOptionRow, sameOptionRows, validateOptionRows } from './optionModel';
import { migrateFieldCatalog } from './fieldCatalogMigration';

export function WorkOptionsModal({ definitions, initialDocuments, initialShas, usedIds = {}, usedRows = [], referencesLoading = false, referencesError = false, isEditor, user, onClose, onSaved, onLoaded, onPendingChange, embedded = false, loadDocument = loadGithubJson, saveDocument = saveGithubJson }) {
  const [entries, setEntries] = useState(() => Object.fromEntries(definitions.map(definition => {
    const document = structuredClone(migrateFieldCatalog(definition.key,initialDocuments?.[definition.key] || definition.bundled));
    return [definition.key, {document, rows: structuredClone(document.items), sha: initialShas?.[definition.key] || null, loading: isEditor, loadError: ''}];
  })));
  const [saving, setSaving] = useState(false), [revision, setRevision] = useState(0);

  const [invalid, setInvalid] = useState(null), [focusRow, setFocusRow] = useState(null);
  const [editors, setEditors] = useState({});
  const [editAll,setEditAll]=useState(false);
  const [deleting, setDeleting] = useState(null);
  const editorKey = (key, id) => `${key}/${id}`;
  const pending = useRef(false), table = useRef(null);
  const loaded = useRef(onLoaded);
  loaded.current = onLoaded;
  const dirtyKeys = definitions.filter(({key}) => !sameOptionRows(entries[key].rows, entries[key].document.items)).map(({key}) => key);
  const dirty = dirtyKeys.length > 0;
  const loading = Object.values(entries).some(entry => entry.loading);
  const loadErrors = definitions.filter(({key}) => entries[key].loadError);
  const unavailable = !isEditor || loading || saving || referencesLoading || referencesError || loadErrors.length > 0;
  const updateEntry = (key, patch) => setEntries(current => ({...current, [key]: {...current[key], ...patch}}));
  const [,notify]=useFeedback([{label:'최신 기준 불러오기',onClick:()=>reloadLatest()}]);

  useEffect(() => {
    if (!isEditor) return;
    let active = true;
    // Retrying a failed load must not overwrite already loaded drafts.
    const targets = definitions.filter(({key}) => revision === 0 || entries[key].loadError);
    targets.forEach(definition => {
      const key = definition.key;
      updateEntry(key, {loading: true, loadError: ''});
      loadDocument({...getGithubSession(), path: definition.path}).then(remote => {
        if (!active) return;
        if (!remote && entries[key].sha) throw new Error('기준정보 파일을 찾을 수 없습니다. 다시 불러오세요.');
        const document = migrateFieldCatalog(key,remote?.document || entries[key].document);
        if (!Array.isArray(document.items)) throw new Error('선택값 목록을 확인할 수 없습니다.');
        // Older frequency options may have no count yet; let the user fill it in.
        validateOptionRows(document.items);
        updateEntry(key, {document: structuredClone(document), rows: structuredClone(document.items), sha: remote?.sha || null, loading: false, loadError: ''});
        loaded.current?.(key, document, remote?.sha || null);
      }).catch(reason => { if (active) updateEntry(key, {loading: false, loadError: reason.message}); });
    });
    return () => { active = false; };
  }, [definitions, isEditor, loadDocument, revision]);
  useEffect(() => { onPendingChange?.({dirty, saving}); }, [dirty, saving, onPendingChange]);
  useBeforeUnload(dirty);
  useEffect(() => {
    if (!focusRow) return;
    const selector = `[data-option-key="${CSS.escape(focusRow.key)}"][data-option-id="${CSS.escape(focusRow.id)}"]`;
    table.current?.querySelector(`${selector} ${focusRow.action ? '[data-master-action="edit"]' : 'input[type="text"]'}`)?.focus();
  }, [focusRow]);

  const close = async () => {
    if (pending.current) return;
    if (dirty && !await confirmAction({kind:'close'})) return;
    onClose();
  };
  const discard = () => {
    setEntries(current => Object.fromEntries(Object.entries(current).map(([key, entry]) => [key, {...entry, rows: structuredClone(entry.document.items)}])));
    setEditors({});setInvalid(null);setFocusRow(null);
  };
  const reset = async () => {
    if (unavailable || dirty && !await confirmAction({kind:'reset'})) return;
    discard();notify('마지막 저장 상태로 초기화했습니다.');
  };
  const reloadLatest = async () => {
    if (pending.current || loading || !isEditor) return;
    if (dirty && !await confirmAction({kind:'reload'})) return;
    pending.current = true; setSaving(true);
    try {
      const fresh = {};
      for (const definition of definitions) {
        const remote = await loadDocument({...getGithubSession(), path: definition.path});
        if (!remote && entries[definition.key].sha) throw new Error('기준정보 파일을 찾을 수 없습니다. 수정 내용은 유지됩니다.');
        const document = migrateFieldCatalog(definition.key,remote?.document || entries[definition.key].document);
        validateOptionRows(document.items);
        fresh[definition.key] = {document:structuredClone(document), rows:structuredClone(document.items), sha:remote?.sha || null, loading:false, loadError:''};
      }
      setEntries(fresh); setEditors({}); setInvalid(null);
      for (const definition of definitions) loaded.current?.(definition.key, fresh[definition.key].document, fresh[definition.key].sha);
      notify('최신 기준을 불러왔습니다.');
    } catch (reason) { notify(`불러오지 못했습니다. 수정 내용은 유지됩니다. ${reason.message}`, true); }
    finally { pending.current = false; setSaving(false); }
  };
  const begin = (key, row) => {
    if (unavailable) return;
    setEditors(current => ({...current, [editorKey(key, row.id)]: {...row}}));
    setFocusRow({key, id: row.id}); setInvalid(null); notify('');
  };
  const end = (key, row, cancel = false) => {
    if (unavailable) return;
    const editor = editors[editorKey(key, row.id)];
    if (!editor) return;
    if (!cancel) {
      try { validateOptionRows([row], definitions.find(definition => definition.key === key)); }
      catch (reason) {setInvalid({key, id: row.id}); setFocusRow({key, id: row.id}); notify(reason.message, true); return;}
    }
    if (cancel) {
      updateEntry(key, {rows: editor.isNew ? entries[key].rows.filter(item => item.id !== row.id) : entries[key].rows.map(item => item.id === row.id ? {...item, ...editor} : item)});
    }
    setEditors(current => { const next = {...current}; delete next[editorKey(key, row.id)]; return next; });
    setInvalid(null); notify('');
    if (cancel && editor.isNew) requestAnimationFrame(() => table.current?.querySelector(`[data-option-group="${CSS.escape(key)}"] [data-master-action="add"]`)?.focus());
    else setFocusRow({key, id: row.id, action: 'edit'});
  };
  const change = (key, id, field, value) => {
    if (unavailable) return;
    setEntries(current => ({...current, [key]: {...current[key], rows: current[key].rows.map(row => row.id === id ? {...row, [field]: value} : row)}}));
    setInvalid(null); notify('');
  };
  const add = key => {
    if (unavailable) return;
    try {
      const field = definitions.find(definition => definition.key === key).valueField;
      const rows = appendOptionRow(entries[key].rows).map((row, index) => index === entries[key].rows.length && field ? {...row, [field.key]: field.defaultValue} : row);
      setEditors(current => ({...current, [editorKey(key, rows.at(-1).id)]: {...rows.at(-1), isNew: true}}));
      updateEntry(key, {rows}); setFocusRow({key, id: rows.at(-1).id}); setInvalid(null); notify('');
    } catch (reason) { notify(reason.message, true); }
  };
  const remove = (key, row) => {
    if (unavailable || referencesLoading || referencesError) return;
    const definition = definitions.find(item => item.key === key);
    const references = optionReferences(key, usedRows, row.id, row.label);
    // Legacy callers without row details still need an explicit usage warning.
    if (!references.length && usedIds[key]?.includes(row.id)) references.push({rowId: row.id, task: '기존 Agent', field: definition.label, value: row.label});
    setDeleting({key, row, field: definition.label, references});
  };
  const confirmRemove = () => {
    if (!deleting || unavailable) return;
    const {key, row} = deleting;
    updateEntry(key, {rows: entries[key].rows.filter(item => item.id !== row.id)});
    setEditors(current => {const next = {...current}; delete next[editorKey(key, row.id)]; return next;});
    setDeleting(null); setInvalid(null); notify('저장하면 삭제됩니다.');
    requestAnimationFrame(() => {
      const group = table.current?.querySelector(`[data-option-group="${CSS.escape(key)}"]`);
      (group?.querySelector('[data-master-action="edit"]:not(:disabled)') || group?.querySelector('[data-master-action="add"]'))?.focus();
    });
  };
  const save = async () => {
    if (unavailable || pending.current) return;
    const changes = [];
    for (const definition of definitions) {
      if (!dirtyKeys.includes(definition.key)) continue;
      try {
        const rows = validateOptionRows(entries[definition.key].rows, definition);
        changes.push({definition, rows});
      } catch (reason) {
        const target = {key: definition.key, id: reason.rowId};
        const row = entries[definition.key].rows.find(item => item.id === reason.rowId);
        if (row) setEditors(current => ({...current, [editorKey(definition.key, row.id)]: current[editorKey(definition.key, row.id)] || {...row}}));
        setInvalid(target); setFocusRow(target); notify(`${definition.label}: ${reason.message}`, true); return;
      }
    }
    if (!changes.length) { setEditors({}); notify('변경 사항이 없습니다.'); return true; }
    pending.current = true; setSaving(true); setInvalid(null); notify('저장하는 중…');
    const failures = [];
    try {
      if(loadDocument===loadGithubJson&&saveDocument===saveGithubJson){
        const batch=await persistCatalogBatch({session:getGithubSession(),message:`필드 속성 ${changes.length}개 변경 @${user?.login||'user'}`,resolveConflicts:resolveEditConflict,entries:changes.map(({definition,rows})=>({key:definition.key,path:definition.path,baseline:entries[definition.key].document,knownSha:entries[definition.key].sha,submitted:{...retainRemovedValues(entries[definition.key].document,rows),updatedBy:user?{id:user.id,login:user.login,name:user.name,avatar_url:user.avatar_url}:null},validate:value=>{const current=migrateFieldCatalog(definition.key,value);return {...current,items:validateOptionRows(current.items)};}}))});
        for(const result of batch){updateEntry(result.key,{document:result.document,rows:structuredClone(result.document.items),sha:result.sha});onSaved?.(result.key,result.document,result.commit,result.sha);}
        setEditors({});notify(batch.some(entry=>entry.commit)?'저장했습니다.':'변경 사항이 없습니다.');return true;
      }
      for (const {definition, rows} of changes) {
        const entry = entries[definition.key];
        const document = {...retainRemovedValues(entry.document, rows), updatedAt: new Date().toISOString(), updatedBy: user ? {id: user.id, login: user.login, name: user.name, avatar_url: user.avatar_url} : null};
        try {
          const result = await persistCatalogChanges({baseline:entry.document, submitted:document, knownSha:entry.sha, session:getGithubSession(), path:definition.path, message:`${definition.label} 변경 @${user?.login || 'user'}`, loadDocument, saveDocument, validate:value=>{const current=migrateFieldCatalog(definition.key,value);return {...current,items:validateOptionRows(current.items)};}});
          // Advance only confirmed baselines so a retry writes failed groups only.
          updateEntry(definition.key, {document:result.document, rows:structuredClone(result.document.items), sha:result.sha});
          setEditors(current => Object.fromEntries(Object.entries(current).filter(([key]) => !key.startsWith(`${definition.key}/`))));
          onSaved?.(definition.key, result.document, result.commit, result.sha);
        } catch (reason) { failures.push(`${definition.label}: ${reason.message}`); }
      }
      if (failures.length) notify(`${changes.length - failures.length}개 항목 저장 완료. 저장하지 못한 수정 내용은 유지됩니다. ${failures.join(' / ')}`, true);
      else { setEditors({}); notify('저장했습니다.'); }
      return failures.length===0;
    } catch(reason){notify(reason.cancelled?'수정값은 유지됩니다.':reason.message,!reason.cancelled);return false;
    } finally { pending.current = false; setSaving(false); }
  };
  const groups = definitions.map(definition => ({definition, rows: entries[definition.key].rows}));
  const gridRows=groups.flatMap(({definition,rows})=>rows.map(row=>({...row,id:editorKey(definition.key,row.id),itemId:row.id,definition,selectionLabel:`${definition.label} ${row.label}`,draftOnly:!entries[definition.key].document.items.some(item=>item.id===row.id),original:entries[definition.key].document.items.find(item=>item.id===row.id)||row})));
  const numericFields=[...new Map(definitions.filter(item=>item.valueField).map(item=>[item.valueField.key,item.valueField])).values()];
  const grid=useSettingsGrid({id:'settings.workOptions',label:'필드 속성',rows:gridRows,groupOrder:row=>definitions.findIndex(definition=>definition.key===row.definition.key),columns:[
    {key:'group',label:'필드',width:180,value:row=>row.definition.label},
    {key:'label',label:'이름',width:260,filterValue:row=>row.original.label},
    ...numericFields.map(field=>({key:field.key,label:field.label,width:190,value:row=>row.definition.valueField?.key===field.key&&row[field.key]!==''&&row[field.key]!=null?Number(row[field.key]):null,filterValue:row=>row.definition.valueField?.key===field.key&&row.original[field.key]!=null?Number(row.original[field.key]):null})),
    {key:'active',label:'사용 여부',utility:true,width:48,value:row=>row.active!==false?'사용':'미사용',filterValue:row=>row.original.active!==false?'사용':'미사용'},
  ]});
  const batch=useSettingsApply(grid,{disabled:unavailable});
  const offer=(row,field,value)=>batch.offer({rowId:row.id,field:field==='label'?'이름':field==='active'?'사용 여부':row.definition.valueField?.label,value,display:field==='active'?(value?'사용':'미사용'):String(value==null||value===''?'값 지우기':value),eligible:target=>!numericFields.some(item=>item.key===field)||target.definition.valueField?.key===field,apply:targets=>{
    setEntries(current=>Object.fromEntries(Object.entries(current).map(([key,entry])=>[key,{...entry,rows:entry.rows.map(item=>targets.some(target=>target.definition.key===key&&target.itemId===item.id)?{...item,[field]:value}:item)}])));notify('');
  }});
  return <DetailPanel helpTopic="settings" busy={saving} embedded={embedded} hideHeading={embedded} title="필드 속성" className="work-options-modal" onClose={close} footer={isEditor?<><span className="list-panel-mode">{dirty ? '저장 전' : ''}</span><ActionButton action="reset" onClick={reset} disabled={unavailable || !dirty && !Object.keys(editors).length}/><TableEditModeButton active={editAll} onChange={value=>{setEditAll(value);setEditors({});}} dirty={dirty} onSave={save} onDiscard={discard} disabled={unavailable}/><ActionButton action="save" busy={saving} onClick={save} disabled={unavailable}/></>:null}>
    {loadErrors.length > 0 && <ToastNotice error message={loadErrors.map(({key,label})=>`${label}: ${entries[key].loadError}`).join('\n')} actions={[{label:'다시 불러오기',onClick:()=>setRevision(value=>value+1)}]}/>}

    <div ref={table} className="work-options-table-wrap"><GroupedSettingsGrid grid={grid} className="work-options-table" groups={definitions.map(definition=>({key:definition.key,label:definition.label,columns:['active','label',...(definition.valueField?[definition.valueField.key]:[])]}))} groupKey={row=>row.definition.key} jumpLabel="필드로 이동" addDisabled={unavailable} onAdd={key=>{grid.controls.clearFilters();grid.setOnlyChanged(false);add(key);}} focusId={focusRow&&!focusRow.action?editorKey(focusRow.key,focusRow.id):null} rowProps={row=>({'data-option-key':row.definition.key,'data-option-id':row.itemId,className:editAll||editors[row.id]?'is-editing':''})}
      renderCell={(row,field)=>{
        const editing=isEditor&&(editAll||Boolean(editors[row.id])),key=row.definition.key,label=row.selectionLabel;
        if(field==='group')return row.definition.label;
        if(field==='label')return editing?<SettingsCommitInput type="text" className="text-input" aria-label={`${label} 이름`} aria-invalid={invalid?.key===key&&invalid?.id===row.itemId||undefined} value={row.label} disabled={unavailable} onChange={event=>change(key,row.itemId,'label',event.target.value)} onCommit={value=>offer(row,'label',value)} onKeyDown={event=>{if(!editAll&&event.key==='Escape'){event.preventDefault();event.stopPropagation();end(key,entries[key].rows.find(item=>item.id===row.itemId),true);}}}/>:<span className="option-read-name">{row.label}</span>;
        if(numericFields.some(item=>item.key===field))return row.definition.valueField?.key===field?(editing?<SettingsCommitInput type="number" className="text-input" min="0" step="any" inputMode="decimal" aria-label={`${label} ${row.definition.valueField.label}`} value={row[field]??''} disabled={unavailable} onChange={event=>change(key,row.itemId,field,event.target.value)} onCommit={value=>offer(row,field,value)} onKeyDown={event=>{if(!editAll&&event.key==='Escape'){event.preventDefault();event.stopPropagation();end(key,entries[key].rows.find(item=>item.id===row.itemId),true);}}}/>:((field==='monthlyCount'?formatMonthlyCount:formatMinutes)(row[field]===null||row[field]===''?null:Number(row[field]))||'—')):'—';
        return <MasterUsageCheckbox label={label} active={row.active!==false} disabled={unavailable} onChange={value=>{change(key,row.itemId,'active',value);offer(row,'active',value);}}/>;
      }} renderActions={row=>{
        const key=row.definition.key,item={...row,id:row.itemId},editing=editAll||Boolean(editors[row.id]),label=row.selectionLabel;
        return editAll?<MasterActionButton action="delete" label={label} disabled={unavailable||referencesLoading||referencesError} onClick={()=>remove(key,item)}/>:editing?<><MasterActionButton action="complete" label={label} disabled={unavailable} onClick={()=>end(key,item)}/><MasterActionButton action="cancel" label={label} disabled={unavailable} onClick={()=>end(key,item,true)}/></>:<>{isEditor&&<MasterActionButton action="edit" label={label} disabled={unavailable} onClick={()=>begin(key,entries[key].rows.find(item=>item.id===row.itemId))}/>}<MasterActionButton action="delete" label={label} disabled={unavailable||referencesLoading||referencesError} onClick={()=>remove(key,item)}/></>;
      }}/></div>
    {batch.dialog}
    {deleting && <MasterDeleteDialog label={deleting.row.label} field={deleting.field} references={deleting.references} onCancel={() => setDeleting(null)} onConfirm={confirmRemove}/>}
  </DetailPanel>;
}

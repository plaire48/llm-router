import { ActionButton, ActionLink } from './ActionButton';
import { confirmAction } from './confirmAction';
import { confirmedUnload } from './useBeforeUnload';
import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { activateModal } from './modalFocus';
import { Icon } from './Icon';
import { HelpTrigger } from './HelpTrigger';
import { useWorkList } from './WorkListState';
import { GithubAvatar } from './AccountProfile';
import { WorkHistoryMenu, WorkLastModified } from './WorkHistory';
import { NotificationMenu } from './NotificationMenu';
import { workspaceViewFromHash, rememberInquiryReturn } from './inquiryNavigation';
const GitHubAvatar = ({profile,size}) => <GithubAvatar user={profile} size={size}/>;

export function BrandMark() {
  return <div className="app-mark agent-mark" aria-hidden="true"><Icon name="report" size={24}/></div>;
}

export function Button({ variant = 'outline', color = 'neutral', size = 'md', className = '', children, ...props }) {
  const style = variant === 'solid' ? 'btn--solid' : variant === 'ghost' ? 'btn--ghost' : 'btn--outline';
  return <button className={`btn ${style} btn--${color} btn--${size} ${className}`.trim()} {...props}>{children}</button>;
}


export function Topbar({ view, setView, onProfile, onLogout, onHelp, user, isAdmin = false, canSettings = true, notificationRole = 'user', notificationClient, onOpenNotificationUser, pendingChanges = {}, historyRevisionLoader, onRegisterLeaveGuard }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuTrigger = useRef(null), navigation = useRef(null), desktopNavigation = useRef(null);
  const menu = [['overview', 'agent', 'E2E Agent 현황'], ['talk','message','E2E Talk'], ...(canSettings ? [['settings', 'sliders', '기준 설정']] : []), ...(isAdmin ? [['admin', 'user', '관리자 설정']] : [])];
  const listState = useWorkList();
  const inquiryLeave={kind:'leave',title:'작성 중인 문의에서 나갈까요?',message:pendingChanges.leaveMessage||'작성한 내용은 저장되지 않습니다.',confirmLabel:'나가기',cancelLabel:'계속 작성'};
  const confirmLeave = async (options = {kind:'leave'}) => { if(listState?.saving||pendingChanges.saving)return false; return (!pendingChanges.dirty&&!listState?.dirtyRows.length&&!listState?.draftDirty)||confirmAction(view==='support'?inquiryLeave:{...options,...(pendingChanges.leaveMessage?{message:pendingChanges.leaveMessage}:{})}); };
  const leaveGuard=useRef(confirmLeave);
  leaveGuard.current=confirmLeave;
  useEffect(()=>{onRegisterLeaveGuard?.(()=>leaveGuard.current());return()=>onRegisterLeaveGuard?.(null);},[onRegisterLeaveGuard]);
  const navigate = async key => {
    if(key===view||listState?.saving||pendingChanges.saving)return false;
    if(view==='overview'?(listState?.dirtyRows.length||listState?.draftDirty):pendingChanges.dirty) {
      if(!await confirmAction(view==='support'?inquiryLeave:{kind:'leave',...(pendingChanges.leaveMessage?{message:pendingChanges.leaveMessage}:{})}))return false;
      if(view==='overview'&&listState.discardChanges()===false)return false;
    }
    return await setView(key)!==false;
  };
  const route=useRef({view,navigate});route.current={view,navigate};
  useEffect(()=>{
    let sequence=0;
    const change=async event=>{
      const next=workspaceViewFromHash(window.location.hash);
      if(!next||next===route.current.view)return;
      const id=++sequence,target=event.newURL;
      history.replaceState(null,'',event.oldURL);
      if(await route.current.navigate(next)&&id===sequence)history.replaceState(null,'',target);
    };
    window.addEventListener('hashchange',change);
    return()=>{sequence++;window.removeEventListener('hashchange',change);};
  },[]);
  const openHome = async (event) => {
    if (listState?.saving || pendingChanges.saving) { event.preventDefault(); return; }
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    event.preventDefault();
    if(menuOpen)closeMenu();
    if(await confirmLeave({kind:'refresh'}))confirmedUnload(()=>window.location.reload());
  };
  const displayName = user?.name || user?.login || '사용자';
  const closeMenu = () => setMenuOpen(false);
  useEffect(() => {
    const desktop = window.matchMedia('(min-width: 1281px)');
    const update = () => {
      if (!desktop.matches) return;
      const restoreNavigation = navigation.current?.contains(document.activeElement);
      setMenuOpen(false);
      if (restoreNavigation) requestAnimationFrame(() => desktopNavigation.current?.querySelector('[aria-current="page"]')?.focus());
    };
    desktop.addEventListener('change', update);
    return () => desktop.removeEventListener('change', update);
  }, []);
  useEffect(() => {
    if (!menuOpen) return;
    return activateModal(navigation.current, { initialFocus: '.agent-nav-close', onClose: closeMenu });
  }, [menuOpen]);
  const brand = <a className="agent-brand-home" href="#app" onClick={openHome} aria-label="E2E Report 새로고침" title={listState?.saving || pendingChanges.saving ? '저장이 끝나면 새로고침할 수 있습니다.' : 'E2E Agent 현황으로 이동하고 새로고침'} aria-disabled={listState?.saving || pendingChanges.saving || undefined}><BrandMark /><strong>E2E Report</strong></a>;
  const navItems = menu.map(([key, icon, label]) => <button key={key} type="button" className={`agent-nav-item ${view === key ? 'is-active' : ''}`} disabled={listState?.saving||pendingChanges.saving} onClick={async () => { if (menuOpen) closeMenu(); await navigate(key); }} aria-current={view === key ? 'page' : undefined}><Icon name={icon} size={20}/><span>{label}</span></button>);
  return <>
    {menuOpen && createPortal(<div className="agent-mobile-layer"><div className="agent-nav-backdrop" onClick={closeMenu} />
    <aside ref={navigation} id="agent-mobile-navigation" className="agent-sidebar is-open" role="dialog" aria-modal="true" aria-label="E2E Report 탐색" tabIndex={-1}>
      <div className="agent-brand">{brand}<ActionButton action="close" className="agent-nav-close" type="button" onClick={closeMenu} aria-label="메뉴 닫기"/></div>
      <nav className="agent-navigation" aria-label="E2E Report 메뉴">{navItems}</nav>
    </aside></div>, document.body)}
    <header className={`topbar agent-topbar${isAdmin?' has-admin-navigation':''}`}>
      <div className="agent-brand agent-topbar-brand">{brand}</div>
      <nav ref={desktopNavigation} className="agent-navigation agent-top-navigation" aria-label="E2E Report 메뉴">{navItems}</nav>
      <ActionButton action="menu" ref={menuTrigger} className="agent-menu-toggle" aria-expanded={menuOpen} aria-controls={menuOpen ? 'agent-mobile-navigation' : undefined} onClick={() => setMenuOpen(true)}/>
      <div className="agent-breadcrumb"><strong>{view==='support'?'문의':menu.find(([key]) => key === view)?.[2]}</strong></div>
      <div className="topbar-actions">
        <div className="topbar-history-group"><WorkLastModified/><WorkHistoryMenu loadRevision={historyRevisionLoader}/></div>
        <div className="topbar-account-actions">
          <NotificationMenu role={notificationRole} user={user} client={notificationClient} onOpenUsers={async login => {
            if (listState?.saving || pendingChanges.saving) return false;
            if (view !== 'admin') {if (!await navigate('admin')) return false;}
            else if (!await confirmLeave()) return false;
            onOpenNotificationUser?.(login);
            return true;
          }}/>
          {onHelp&&<HelpTrigger className="topbar-help" onClick={onHelp}/>}
          {user ? <><Button variant="ghost" color="neutral" size="md" className="profile-button" onClick={event=>{event.currentTarget.focus();onProfile?.();}} aria-label="내 프로필"><GitHubAvatar profile={user} size="md"/><span className="profile-name">{displayName}</span></Button><ActionButton action="logout" className="logout-button" onClick={async () => { if(await confirmLeave({kind:'logout'})) onLogout(); }}/></> : <ActionLink action="login" iconOnly={false} className="login-button" href="#login" onClick={async event => {event.preventDefault();if(onRegisterLeaveGuard||await confirmLeave({kind:'leave'})){rememberInquiryReturn();window.location.hash='login';}}}/>}
        </div>
      </div>
    </header>
  </>;
}

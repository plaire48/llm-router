import {CxSelect} from './CxSelect';
import {useFeedback} from './Toast';
import React, {useEffect, useRef, useState} from 'react';
import {SettingsGrid, SettingsGridTable} from './SettingsGrid';
import {SelectionCheckbox} from './WorkspaceLayout';
import {useWorkspaceState} from './WorkspaceMemory';
import {MasterActionButton} from './MasterActionButton';
import './grouped-settings.css';

function SettingsGroup({grid,group,rows,onAdd,addDisabled,...tableProps}) {
  const columns=group.columns.map(key=>grid.columns.find(column=>column.key===key));
  const [pinCount,setPinCount]=useWorkspaceState(`${grid.id}.${group.key}.pins`,0);
  const [,setNotice]=useFeedback();
  const pinned=grid.interactive?columns.slice(0,Math.min(pinCount,columns.length)).map(column=>column.key):[];
  const togglePin=key=>{
    const index=columns.findIndex(column=>column.key===key);
    if(index>pinned.length){setNotice(`먼저 ${columns[pinned.length].label} 열을 고정하세요.`);return;}
    setPinCount(index<pinned.length?index:index+1);setNotice('');
  };
  const groupGrid={...grid,label:group.label,columns,pinned,togglePin,stretchColumn:'label',
    controls:{...grid.controls,columns},pagination:{...grid.pagination,rows}};
  return <section className="settings-grid-group" data-settings-group={group.key} data-option-group={group.key} aria-labelledby={`${grid.id}-${group.key}-heading`}>
    <SettingsGridTable {...tableProps} grid={groupGrid} nameHeading={{label:group.label,count:rows.length,id:`${grid.id}-${group.key}-heading`}} headerAction={<MasterActionButton action="add" label={group.label} disabled={addDisabled} onClick={()=>onAdd(group.key)}/>}/>
  </section>;
}

export function GroupedSettingsGrid({grid,groups,groupKey,jumpLabel,onAdd,addDisabled,searchActive=false,...tableProps}) {
  const host=useRef(null),[jump,setJump]=useState(''),[announcement,setAnnouncement]=useState('');
  const filtered=searchActive||grid.onlyChanged||Object.keys(grid.controls.filters).length>0;
  const sections=groups.map(group=>({...group,rows:grid.pagination.rows.filter(row=>groupKey(row)===group.key)})).filter(group=>!filtered||group.rows.length);
  const sectionKeys=sections.map(group=>group.key).join(',');
  useEffect(()=>{
    const scroller=host.current?.querySelector('.settings-grid-scroll');
    if(!scroller)return;
    const update=()=>{
      const elements=[...scroller.querySelectorAll('[data-settings-group]')];
      const top=scroller.getBoundingClientRect().top+2;
      const current=elements.findLast(element=>element.getBoundingClientRect().top<=top)||elements[0];
      const atEnd=scroller.scrollHeight>scroller.clientHeight&&scroller.scrollTop+scroller.clientHeight>=scroller.scrollHeight-2;
      setJump((atEnd?elements.at(-1):current)?.dataset.settingsGroup||'');
    };
    const measure=()=>{
      scroller.style.setProperty('--settings-group-viewport',`${scroller.clientHeight}px`);
      scroller.style.setProperty('--settings-group-width',`${scroller.clientWidth}px`);
      const width=Math.max(scroller.clientWidth,...[...scroller.querySelectorAll('table')].map(table=>parseFloat(table.style.width)||0));
      scroller.style.setProperty('--settings-group-content-width',`${width}px`);
    };
    measure();update();scroller.addEventListener('scroll',update,{passive:true});
    const observer=new ResizeObserver(measure);observer.observe(scroller);
    return ()=>{observer.disconnect();scroller.removeEventListener('scroll',update);};
  },[sectionKeys,grid.controls.widths,grid.sort]);
  const moveTo=key=>{
    const scroller=host.current?.querySelector('.settings-grid-scroll');
    const section=scroller?.querySelector(`[data-settings-group="${CSS.escape(key)}"]`);
    if(!section)return;
    scroller.scrollTo({top:scroller.scrollTop+section.getBoundingClientRect().top-scroller.getBoundingClientRect().top-scroller.clientTop,left:0,behavior:'instant'});
    setJump(key);setAnnouncement(`${groups.find(group=>group.key===key).label} 항목으로 이동했습니다.`);
  };
  return <div ref={host} className="grouped-settings-grid"><SettingsGrid {...tableProps} grid={grid} renderTables={()=>sections.length?sections.map(group=><SettingsGroup key={group.key} {...tableProps} grid={grid} group={group} rows={group.rows} onAdd={onAdd} addDisabled={addDisabled}/>):<p className="table-empty">조건에 맞는 항목이 없습니다.</p>}>
    {grid.interactive&&<label className="settings-group-select-all"><SelectionCheckbox label={`${grid.label} 조회 항목 전체 선택`} checked={grid.selection.all} mixed={grid.selection.ids.size>0&&!grid.selection.all} onChange={grid.selection.toggleAll}/><span>전체 선택</span></label>}
    <label className="settings-group-jump"><span>{jumpLabel}</span><CxSelect className="native-select" aria-label={jumpLabel} value={jump} disabled={!sections.length} onChange={event=>moveTo(event.target.value)}>
      {!sections.length&&<option value="">검색 결과 없음</option>}{groups.map(group=><option key={group.key} value={group.key} disabled={!sections.some(section=>section.key===group.key)}>{group.label}</option>)}
    </CxSelect></label>
  </SettingsGrid><span className="visually-hidden" role="status">{announcement}</span></div>;
}

import { ActionButton } from './ActionButton';
import {useFeedback} from './Toast';
import {GroupedSettingsGrid} from './GroupedSettingsGrid';
import {SettingsCommitInput, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import { CxConfirmation } from './CxConfirmation';
import { confirmationCopy } from './confirmationCopy';
import { TableEditModeButton } from './TableEditModeButton';
import React, { useEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { MasterActionButton } from './MasterActionButton';
import { MasterUsageCheckbox } from './MasterUsageCheckbox';
import { MasterDeleteDialog } from './MasterDeleteDialog';
import { useWorkList } from './WorkListState';
import { retainRemovedValues } from './catalogValues';
import { SCORING_GROUPS, scoringReferences, stableJson, validateScoring } from './agentFlowModel';

export function ScoringSettings({onPendingChange}) {
  const state=useWorkList(),[draft,setDraft]=useState(()=>structuredClone(state.automationScoring)),[editors,setEditors]=useState({}),[deleting,setDeleting]=useState(null),[resetting,setResetting]=useState(false);
  const [editAll,setEditAll]=useState(false),[focusTarget,setFocusTarget]=useState(null);
  const table=useRef(null),focus=useRef(null),baseline=useRef(state.automationScoring);
  const dirty=(()=>{try{return stableJson(validateScoring(draft))!==stableJson(state.automationScoring);}catch{return true;}})(),disabled=!state.canSettings||state.loading||state.loadError||state.saving;
  const [,notify]=useFeedback();
  useEffect(()=>{if(baseline.current!==state.automationScoring){baseline.current=state.automationScoring;setDraft(structuredClone(state.automationScoring));setEditors({});}},[state.automationScoring]);
  useEffect(()=>{onPendingChange?.({dirty,saving:state.saving});},[dirty,state.saving,onPendingChange]);
  useBeforeUnload(dirty);
  useEffect(()=>{if(focus.current){table.current?.querySelector(`[data-scoring-id="${CSS.escape(focus.current)}"] input[type="text"]`)?.focus();focus.current=null;}},[editors]);
  const change=(group,id,patch)=>setDraft(current=>({...current,[group]:{...current[group],items:current[group].items.map(item=>item.id===id?{...item,...patch}:item)}}));
  const begin=(group,row)=>{setEditors(current=>({...current,[`${group}/${row.id}`]:structuredClone(row)}));focus.current=row.id;setFocusTarget(`${group}/${row.id}`);notify('');};
  const add=group=>{const row={id:`scoring-${crypto.randomUUID()}`,label:'',weight:null,active:true,sortOrder:draft[group].items.length+1};setDraft(current=>({...current,[group]:{...current[group],items:[...current[group].items,row]}}));setEditors(current=>({...current,[`${group}/${row.id}`]:{...row,isNew:true}}));focus.current=row.id;setFocusTarget(`${group}/${row.id}`);notify('');};
  const end=(group,row,cancel=false)=>{
    const key=`${group}/${row.id}`,before=editors[key];
    if(cancel){if(before.isNew)setDraft(current=>({...current,[group]:{...current[group],items:current[group].items.filter(item=>item.id!==row.id)}}));else change(group,row.id,before);}
    else {try {const next=validateScoring(draft);setDraft(next);}catch(reason){notify(reason.message,true);return;}}
    setEditors(current=>{const next={...current};delete next[key];return next;});notify('');
  };
  const discard=()=>{setResetting(false);setDraft(structuredClone(state.automationScoring));setEditors({});setDeleting(null);setFocusTarget(null);focus.current=null;};
  const reset=()=>{discard();notify('마지막 저장 상태로 초기화했습니다.');};
  const save=async()=>{
    if(disabled)return;
    try {const policy=validateScoring(draft);if(stableJson(policy)===stableJson(state.automationScoring)){notify('변경 사항이 없습니다.');return true;}
      const result=await state.saveFlow({scoringDraft:policy});if(result){setDraft(structuredClone(result.automationScoring));setEditors({});notify(result.commit?'저장하고 자동화율을 다시 계산했습니다.':'변경 사항이 없습니다.');return true;}
    }catch(reason){notify(reason.message,true);}
  };
  const gridRows=SCORING_GROUPS.flatMap(group=>draft[group.key].items.map(row=>({...row,id:`${group.key}/${row.id}`,itemId:row.id,group,selectionLabel:`${group.label} ${row.label}`,draftOnly:!state.automationScoring[group.key].items.some(item=>item.id===row.id),original:state.automationScoring[group.key].items.find(item=>item.id===row.id)||row})));
  const grid=useSettingsGrid({id:'settings.automationScoring',label:'자동화율 속성',rows:gridRows,groupOrder:row=>SCORING_GROUPS.findIndex(group=>group.key===row.group.key),columns:[
    {key:'group',label:'구분',width:190,value:row=>row.group.label},
    {key:'label',label:'이름',width:260,filterValue:row=>row.original.label},
    {key:'weight',label:'가중치 (%)',width:180,value:row=>row.weight==null||row.weight===''?null:Number(row.weight),filterValue:row=>row.original.weight==null||row.original.weight===''?null:Number(row.original.weight)},
    {key:'active',label:'사용 여부',utility:true,width:48,value:row=>row.active!==false?'사용':'미사용',filterValue:row=>row.original.active!==false?'사용':'미사용'},
  ]});
  const batch=useSettingsApply(grid,{disabled});
  const offer=(row,field,value)=>batch.offer({rowId:row.id,field:field==='label'?'이름':field==='active'?'사용 여부':'가중치 (%)',value,display:field==='active'?(value?'사용':'미사용'):String(value==null||value===''?'값 지우기':value),apply:targets=>{setDraft(current=>({...current,...Object.fromEntries(SCORING_GROUPS.map(({key})=>[key,{...current[key],items:current[key].items.map(item=>targets.some(target=>target.group.key===key&&target.itemId===item.id)?{...item,[field]:value}:item)}]))}));notify('');}});
  return <DetailPanel busy={state.saving} embedded hideHeading title="자동화율 속성" className="work-options-modal scoring-settings" footer={state.canSettings?<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" type="button" onClick={()=>setResetting(true)} disabled={disabled||!dirty}/><TableEditModeButton active={editAll} onChange={value=>{setEditAll(value);setEditors({});}} dirty={dirty} onSave={save} onDiscard={discard} disabled={disabled}/><ActionButton action="save" busy={state.saving} type="button" disabled={disabled} onClick={save}/></>:null}>

    <div ref={table} className="work-options-table-wrap"><GroupedSettingsGrid grid={grid} groups={SCORING_GROUPS.map(group=>({...group,columns:['active','label','weight']}))} groupKey={row=>row.group.key} jumpLabel="속성으로 이동" addDisabled={disabled} onAdd={key=>{grid.controls.clearFilters();grid.setOnlyChanged(false);add(key);}} focusId={focusTarget} className="work-options-table scoring-table" rowProps={row=>({'data-scoring-id':row.itemId,'data-scoring-group':row.group.key,className:editAll||editors[row.id]?'is-editing':''})} renderCell={(row,field)=>{
      const editing=editAll||Boolean(editors[row.id]),key=row.group.key;
      if(field==='group')return row.group.label;
      if(field==='label')return editing?<SettingsCommitInput type="text" className="text-input" aria-label={`${row.group.label} 이름`} value={row.label} disabled={disabled} onChange={event=>change(key,row.itemId,{label:event.target.value})} onCommit={value=>offer(row,'label',value)}/>:row.label;
      if(field==='weight')return editing?<SettingsCommitInput type="number" className="text-input" aria-label={`${row.label||row.group.label} 가중치`} min={0} max={100} step="any" inputMode="decimal" placeholder="0–100" value={row.weight??''} disabled={disabled} onChange={event=>change(key,row.itemId,{weight:event.target.value})} onCommit={value=>offer(row,'weight',value)}/>:<span className="scoring-weight">{row.weight==null||row.weight===''?'—':`${row.weight}%`}</span>;
      return <MasterUsageCheckbox label={row.label} active={row.active!==false} disabled={disabled} onChange={active=>{change(key,row.itemId,{active});offer(row,'active',active);}}/>;
    }} renderActions={row=>{
      const key=row.group.key,item=draft[key].items.find(item=>item.id===row.itemId),editing=editAll||Boolean(editors[row.id]);
      const remove=()=>setDeleting({group:key,row:item,label:row.group.label,references:scoringReferences(state.automationRates,key,item.id,item.label)});
      return editAll?<MasterActionButton action="delete" label={row.label} disabled={disabled} onClick={remove}/>:editing?<><MasterActionButton action="complete" label={row.label} disabled={disabled} onClick={()=>end(key,item)}/><MasterActionButton action="cancel" label={row.label} disabled={disabled} onClick={()=>end(key,item,true)}/></>:<>{state.canSettings&&<MasterActionButton action="edit" label={row.label} disabled={disabled} onClick={()=>begin(key,item)}/>}<MasterActionButton action="delete" label={row.label} disabled={disabled} onClick={remove}/></>;
    }}/></div>
    {batch.dialog}
    {resetting&&<CxConfirmation {...confirmationCopy('reset')} className="flow-confirm-dialog" onCancel={()=>setResetting(false)} onConfirm={reset}/>}
    {deleting&&<MasterDeleteDialog label={deleting.row.label} field={deleting.label} references={deleting.references} onCancel={()=>setDeleting(null)} onConfirm={()=>{setDraft(current=>({...current,[deleting.group]:retainRemovedValues(state.automationScoring[deleting.group],current[deleting.group].items.filter(row=>row.id!==deleting.row.id))}));setDeleting(null);notify('저장하면 목록에서 삭제됩니다. 기존 산정값은 유지됩니다.');}}/>}
  </DetailPanel>;
}

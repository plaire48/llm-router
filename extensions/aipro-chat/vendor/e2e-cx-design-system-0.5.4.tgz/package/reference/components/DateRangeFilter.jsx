import React, {useId,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {ActionButton} from './ActionButton';
import {Icon} from './Icon';
import {calendarCells,chooseRangeDay,formatCalendarDay,parseCalendarDay,rangeError} from './calendarRange';
import './date-range-filter.css';

export function DateRangeFilter({from,to,onChange}) {
  const [open,setOpen]=useState(false),[draft,setDraft]=useState({from:'',to:'',phase:'start'}),[month,setMonth]=useState(new Date()),[cursor,setCursor]=useState(''),[position,setPosition]=useState({});
  const trigger=useRef(null),popup=useRef(null),placeRef=useRef(null),id=useId();
  // WebKit can focus the containing dialog on mouse-down, closing a focus-
  // dismissed popover before its Apply click. Keep pointer focus on the button.
  const focusButton=event=>{const button=event.target.closest('button');if(button&&!button.disabled){event.preventDefault();button.focus({preventScroll:true});}};
  const error=rangeError(draft.from,draft.to),today=formatCalendarDay(new Date());
  const close=(focus=true)=>{setOpen(false);if(focus)trigger.current?.focus({preventScroll:true});};
  const show=()=>{const day=parseCalendarDay(from)||new Date();setDraft({from,to,phase:'start'});setMonth(day);setCursor(formatCalendarDay(day));setOpen(true);};
  const focusDay=date=>{const value=formatCalendarDay(date);setCursor(value);setMonth(date);requestAnimationFrame(()=>popup.current?.querySelector(`[data-calendar-day="${value}"]`)?.focus({preventScroll:true}));};
  const moveMonth=offset=>{const date=new Date(month.getFullYear(),month.getMonth()+offset,1,12);setMonth(date);setCursor(formatCalendarDay(date));};
  useLayoutEffect(()=>{
    if(!open)return;
    const place=()=>{
      const v=window.visualViewport,edge=8,x=v?.offsetLeft||0,y=v?.offsetTop||0,w=v?.width||innerWidth,h=v?.height||innerHeight,anchor=trigger.current.getBoundingClientRect();
      const width=Math.min(352,w-16),height=Math.min(popup.current?.scrollHeight||460,h-16);
      setPosition({width,maxHeight:h-16,left:Math.max(x+edge,Math.min(anchor.left,x+w-width-edge)),top:Math.max(y+edge,Math.min(anchor.bottom+8,y+h-height-edge))});
    };
    const outside=event=>{if(!popup.current?.contains(event.target)&&!trigger.current?.contains(event.target))close(false);};
    placeRef.current=place;place();popup.current?.querySelector('[tabindex="0"]')?.focus({preventScroll:true});
    document.addEventListener('pointerdown',outside);document.addEventListener('focusin',outside);
    window.addEventListener('resize',place);window.addEventListener('scroll',place,true);window.visualViewport?.addEventListener('resize',place);
    return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('focusin',outside);window.removeEventListener('resize',place);window.removeEventListener('scroll',place,true);window.visualViewport?.removeEventListener('resize',place);};
  },[open]);
  useLayoutEffect(()=>{if(open)placeRef.current?.();},[open,month.getFullYear(),month.getMonth(),Boolean(error)]);
  const keyboard=(event,value)=>{
    const date=parseCalendarDay(value),offset={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7};
    if(Object.hasOwn(offset,event.key))date.setDate(date.getDate()+offset[event.key]);
    else if(event.key==='Home')date.setDate(date.getDate()-date.getDay());
    else if(event.key==='End')date.setDate(date.getDate()+6-date.getDay());
    else if(event.key==='PageUp'||event.key==='PageDown')date.setMonth(date.getMonth()+(event.key==='PageUp'?-1:1),1);
    else return;
    event.preventDefault();focusDay(date);
  };
  return <div className="cx-date-range-field"><span id={`${id}-label`} className="history-filter-label">변경 기간</span>
    <button ref={trigger} onMouseDown={focusButton} className="cx-date-range-trigger" type="button" aria-labelledby={`${id}-label ${id}-value`} aria-haspopup="dialog" aria-expanded={open} onClick={()=>open?close():show()}><span id={`${id}-value`}>{from||to?`${from||'시작일'} ~ ${to||'종료일'}`:'전체 기간'}</span><Icon name="calendar" size={18}/></button>
    {open&&createPortal(<div ref={popup} onMouseDownCapture={focusButton} className="cx-date-range-popover" role="dialog" aria-labelledby={`${id}-title`} style={position} onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}}}>
      <header><strong id={`${id}-title`}>변경 기간</strong><ActionButton action="close" label="기간 선택 닫기" onClick={()=>close()}/></header>
      <div className="cx-range-inputs">{[['from','시작일','start'],['to','종료일','end']].map(([key,label,phase])=><label key={key}><span>{label}</span><input type="text" inputMode="text" aria-label={`변경 이력 ${label}`} placeholder="YYYY-MM-DD" maxLength={10} value={draft[key]} aria-invalid={error&&draft.from&&draft.to?true:undefined} aria-describedby={error?`${id}-error`:undefined} onFocus={()=>setDraft(current=>({...current,phase}))} onChange={event=>{const value=event.target.value;setDraft(current=>({...current,[key]:value}));const date=parseCalendarDay(value);if(date){setMonth(date);setCursor(value);}}}/></label>)}</div>
      <div className="cx-calendar-navigation"><button type="button" className="cx-icon-button" aria-label="이전 달" title="이전 달" onClick={()=>moveMonth(-1)}><Icon name="chevronLeft"/></button><strong aria-live="polite">{month.getFullYear()}년 {month.getMonth()+1}월</strong><button type="button" className="cx-icon-button" aria-label="다음 달" title="다음 달" onClick={()=>moveMonth(1)}><Icon name="chevronRight"/></button></div>
      <div className="cx-calendar-week" aria-hidden="true">{['일','월','화','수','목','금','토'].map(day=><span key={day}>{day}</span>)}</div>
      <div className="cx-calendar-days" role="group" aria-label="날짜 선택">{calendarCells(month).map(({date,value,inMonth})=>{
        const start=value===draft.from,end=value===draft.to,edge=start||end,range=draft.from&&draft.to&&!error,inside=range&&value>draft.from&&value<draft.to;
        return <div key={value} className={`cx-calendar-cell ${range&&(edge||inside)?'is-in-range':''} ${start?'is-range-start':''} ${end?'is-range-end':''}`}><button type="button" data-calendar-day={value} tabIndex={cursor===value?0:-1} aria-label={`${date.getFullYear()}년 ${date.getMonth()+1}월 ${date.getDate()}일`} aria-pressed={Boolean(edge||inside)} aria-current={value===today?'date':undefined} className={`${inMonth?'':'is-outside'} ${edge?'is-selected':''} ${inside?'is-in-range':''}`} onFocus={()=>setCursor(value)} onKeyDown={event=>keyboard(event,value)} onClick={()=>{setDraft(current=>chooseRangeDay(current.from,value,current.phase));setCursor(value);setMonth(date);}}><span className="cx-calendar-day-label">{date.getDate()}</span></button></div>;
      })}</div>
      <p className="cx-range-hint" id={`${id}-error`} aria-live="polite">{draft.from&&draft.to&&error?error:draft.from&&draft.to&&!error?'':draft.phase==='end'?'종료일을 선택하세요.':'시작일을 선택하세요.'}</p>
      <footer><ActionButton action="reset" label="기간 초기화" disabled={!draft.from&&!draft.to} onClick={()=>setDraft({from:'',to:'',phase:'start'})}/><ActionButton action="apply" disabled={Boolean(error)} onClick={()=>{onChange({from:draft.from,to:draft.to});close();}}/></footer>
    </div>,trigger.current?.closest('.cx-detail-panel')||document.body)}
  </div>;
}

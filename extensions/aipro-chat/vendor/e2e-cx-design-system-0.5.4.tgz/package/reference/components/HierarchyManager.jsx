import {CxSelect} from './CxSelect';
import { ActionButton } from './ActionButton';
import {useFeedback, ToastNotice} from './Toast';
import {SettingsGrid, SettingsCommitInput, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import { TableEditModeButton } from './TableEditModeButton';
import { confirmAction } from './confirmAction';
import React, { useEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { MasterActionButton } from './MasterActionButton';
import { MasterUsageCheckbox } from './MasterUsageCheckbox';
import { MasterDeleteDialog } from './MasterDeleteDialog';
import { hierarchyReferences } from './masterUsage';
import { useWorkList } from './WorkListState';
import { applyHierarchyNames, orderedNodes, nodePath, hierarchySelection, upsertHierarchyNode, removeHierarchyNode } from './hierarchyModel';
import { processOrganizationReferences } from './processOrganizations';
import './hierarchy.css';

function HierarchyLevelTable({definition,level,label,nodes,parentId,source,names,editAll,canEdit,unavailable,selected,form,onSelect,onName,onUsage,onEdit,onRemove,onBatch,onAdd,addDisabled}) {
  const rows=nodes.map(node=>({...node,selectionLabel:`${label} ${node.label}`,name:names[node.id]??node.label,draftOnly:!source.items.some(item=>item.id===node.id),original:source.items.find(item=>item.id===node.id)||node}));
  const grid=useSettingsGrid({id:`settings.${definition.key}.${level}`,label,rows,scope:parentId,columns:[
    {key:'active',label:'사용 여부',utility:true,width:48,value:row=>row.active!==false?'사용':'미사용',filterValue:row=>row.original.active!==false?'사용':'미사용'},
    {key:'label',label:'이름',width:170,value:row=>row.name,filterValue:row=>row.original.label},
  ]});
  const batch=useSettingsApply(grid,{disabled:unavailable});
  const offer=(row,field,value)=>batch.offer({rowId:row.id,field:field==='active'?'사용 여부':'이름',value,display:field==='active'?(value?'사용':'미사용'):value,apply:targets=>onBatch(field,targets,value)});
  return <><SettingsGrid grid={grid} compact nameHeading={{label,count:nodes.length}} headerAction={<MasterActionButton action="add" label={label} disabled={addDisabled} onClick={onAdd}/>} rowProps={node=>({'data-hierarchy-id':node.id,className:`${selected===node.id?'is-current':''} ${form?.id===node.id?'is-editing':''}`})} renderCell={(node,field)=>field==='active'?<MasterUsageCheckbox label={node.label} active={node.active!==false} disabled={unavailable} onChange={value=>{onUsage(node,value);offer(node,'active',value);}}/>:editAll?<div className="hierarchy-bulk-name"><SettingsCommitInput className="text-input" aria-label={`${label} ${node.label} 이름`} value={node.name} disabled={unavailable} onFocus={()=>onSelect(node)} onChange={event=>onName(node.id,event.target.value)} onCommit={value=>offer(node,'label',value)}/>{level!==definition.levels.at(-1)[0]&&<ActionButton action="detail" type="button" aria-label={`${node.label} 하위 항목 보기`} onClick={()=>onSelect(node)}/>}</div>:<button className="hierarchy-select" aria-pressed={selected===node.id} onClick={()=>onSelect(node)}><span>{node.label}</span></button>} renderActions={node=><>{canEdit&&!editAll&&<MasterActionButton action="edit" label={node.label} disabled={unavailable} onClick={event=>onEdit(node,event.currentTarget)}/>}<MasterActionButton action="delete" label={node.label} disabled={unavailable} onClick={()=>onRemove(node)}/></>}/>{batch.dialog}</>;
}

export function HierarchyManager({ definition, onClose, embedded = false, onPendingChange }) {
  const state=useWorkList();
  const source=state.catalogs[definition.key];
  const [document,setDocument]=useState(source);
  const [selected,setSelected]=useState([]);
  const [form,setForm]=useState(null);
  const [editAll,setEditAll]=useState(false),[names,setNames]=useState({});
  const changeEditMode=value=>{setEditAll(value);if(!value)setNames({});};

  const [saving,setSaving]=useState(false);
  const [deleting,setDeleting]=useState(null);
  const pending=useRef(false),input=useRef(null),actionTrigger=useRef(null),hierarchy=useRef(null);
  // Temporary rename aliases do not turn A → B → A into a saved change.
  const visibleValues=items=>items.map(({legacyPaths,...item})=>item);
  const dirty=JSON.stringify(visibleValues(document.items))!==JSON.stringify(visibleValues(source.items))||document.items.some(item=>Object.hasOwn(names,item.id)&&String(names[item.id]).trim()!==item.label);
  const [,notify]=useFeedback([{label:'최신 기준 불러오기',onClick:()=>reloadLatest()}]);
  const formDirty=Boolean(form&&JSON.stringify(form.draft)!==JSON.stringify(form.original));
  useEffect(()=>{onPendingChange?.({dirty:dirty||formDirty,saving});},[dirty,formDirty,saving,onPendingChange]);
  const discard=()=>{setDocument(source);setNames({});setForm(null);setDeleting(null);};
  const reset=async()=>{if((dirty||formDirty)&&!await confirmAction({kind:'reset'}))return;discard();notify('마지막 저장 상태로 초기화했습니다.');};
  const unavailable=!state.canSettings||state.loading||state.loadError||state.structureLoading||Boolean(state.structureErrors[definition.key])||saving||state.saving;
  useEffect(()=>{setDocument(source);setNames({});},[source]);
  useEffect(()=>{
    if(form)input.current?.focus();
    else if(actionTrigger.current?.isConnected){actionTrigger.current.focus();actionTrigger.current=null;}
  },[Boolean(form),form?.id,form?.draft.level]);
  useBeforeUnload(dirty||formDirty);
  const chooseDefaults=items=>hierarchySelection(definition,items);
  useEffect(()=>{setSelected(chooseDefaults(source.items));},[definition.key,source]);
  const close=async()=>{if(saving)return;if((dirty||formDirty)&&!await confirmAction({kind:'close'}))return;onClose();};
  const cancelForm=async()=>{if(formDirty&&!await confirmAction({kind:'discard'}))return false;setForm(null);return true;};
  const begin=async(level,parentId,node,trigger)=>{
    if(formDirty&&!await confirmAction({kind:'leave',message:'현재 항목에서 수정한 내용이 사라집니다.'}))return;
    actionTrigger.current=trigger;
    const draft=node?{...node}:{level,parentId:parentId||null,label:'',active:true,sortOrder:document.items.filter(item=>item.level===level&&item.parentId===(parentId||null)).length+1};
    setForm({id:node?.id||null,draft,original:{...draft}});notify('');
  };
  const select=(node,index)=>{
    setSelected(hierarchySelection(definition,document.items,[...selected.slice(0,index),node.id]));
  };
  const apply=event=>{
    event.preventDefault();if(unavailable||!form)return;
    try {const next=upsertHierarchyNode(definition,document,form.draft,form.id);setDocument(next.document);setSelected(nodePath(next.document.items,next.item.id).map(node=>node.id));setForm(null);notify('수정 완료');}
    catch(error){notify(error.message,true);}
  };
  const remove=node=>{
    if(unavailable)return;
    if(formDirty){notify('수정을 완료하거나 취소한 뒤 삭제하세요.',true);return;}
    const descendants=document.items.filter(item=>item.id!==node.id&&nodePath(document.items,item.id).some(parent=>parent.id===node.id)).map(item=>({...item,path:nodePath(document.items,item.id).map(part=>part.label).join(' / ')}));
    const references=[...hierarchyReferences(definition,document,[...state.rows,...state.savedRows,...(state.editing?[state.editing.draft]:[])],node.id),...processOrganizationReferences(definition.key,node.id,state.catalogs.standardProcesses,state.catalogs.organizations,state.catalogs.processOrganizations)];
    setDeleting({node,references,descendants});
  };
  const confirmRemove=()=>{
    if(unavailable||!deleting)return;
    try {
      const next=removeHierarchyNode(definition,document,deleting.node.id,[...state.rows,...state.savedRows],{confirmed:true});
      setDocument(next);setForm(null);setSelected(chooseDefaults(next.items));setDeleting(null);notify('저장하면 삭제됩니다.');
      requestAnimationFrame(()=>hierarchy.current?.querySelector('[data-master-action="add"]')?.focus());
    } catch(error){notify(error.message,true);}
  };
  const setUsage=(node,active)=>{
    if(unavailable)return;
    setDocument(current=>({...current,items:current.items.map(item=>item.id===node.id?{...item,active}:item)}));
    if(form?.id===node.id)setForm(current=>({...current,draft:{...current.draft,active}}));
    notify('');
  };
  const save=async()=>{
    if(unavailable||form||pending.current)return;
    if(!dirty){setDocument(source);setNames({});notify('변경 사항이 없습니다.');return true;}
    pending.current=true;setSaving(true);notify('저장하는 중…');
    try {const submitted=applyHierarchyNames(definition,document,names);const next=await state.saveStructure(definition.key,submitted);setDocument(next);setNames({});notify('저장했습니다.');return true;}
    catch(error){notify(`저장하지 못했습니다. 수정 내용은 유지됩니다. ${error.message}`,true);}
    finally {pending.current=false;setSaving(false);}
  };
  const reloadLatest=async()=>{
    if(pending.current||saving||state.saving||!state.canSettings)return;
    if((dirty||formDirty)&&!await confirmAction({kind:'reload'}))return;
    pending.current=true;setSaving(true);
    try {const next=await state.reloadStructure(definition.key);setDocument(next);setNames({});setForm(null);notify('최신 기준을 불러왔습니다.');}
    catch(reason){notify(`불러오지 못했습니다. 수정 내용은 유지됩니다. ${reason.message}`,true);}
    finally {pending.current=false;setSaving(false);}
  };
  const formLevel=definition.levels.findIndex(([level])=>level===form?.draft.level);
  const parents=formLevel>0?orderedNodes(document.items.filter(item=>item.level===definition.levels[formLevel-1][0])):[];
  return <DetailPanel helpTopic="settings" busy={saving} embedded={embedded} hideHeading={embedded} title={definition.label} className="hierarchy-panel" onClose={close} footer={state.canSettings?<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" onClick={reset} disabled={unavailable||(!dirty&&!form)}/><TableEditModeButton active={editAll} onChange={changeEditMode} dirty={dirty||formDirty} onSave={save} onDiscard={discard} disabled={unavailable||Boolean(form)}/><ActionButton action="save" busy={saving} onClick={save} disabled={unavailable||Boolean(form)}/></>:null}>
    {state.structureErrors[definition.key]&&<ToastNotice error message={state.structureErrors[definition.key]} actions={[{label:'최신 기준 불러오기',onClick:reloadLatest}]}/>}

    <div ref={hierarchy} className="hierarchy-columns">{definition.levels.map(([level,label],index)=>{
      const parentId=index?selected[index-1]:null;
      const nodes=orderedNodes(document.items.filter(item=>item.level===level&&(!index||parentId&&item.parentId===parentId)));
      return <section className="hierarchy-column" key={level} aria-label={`${label} 목록`}>
        <HierarchyLevelTable onAdd={event=>begin(level,parentId,null,event.currentTarget)} addDisabled={unavailable||index>0&&!parentId} definition={definition} level={level} label={label} nodes={nodes} parentId={parentId} source={source} names={names} editAll={editAll} canEdit={state.canSettings} unavailable={unavailable} selected={selected[index]} form={form} onSelect={node=>select(node,index)} onName={(id,value)=>{setNames(current=>({...current,[id]:value}));notify('');}} onUsage={setUsage} onEdit={(node,trigger)=>begin(level,node.parentId,node,trigger)} onRemove={remove} onBatch={(field,targets,value)=>{
          if(field==='label')setNames(current=>({...current,...Object.fromEntries(targets.map(node=>[node.id,value]))}));
          else {setDocument(current=>({...current,items:current.items.map(item=>targets.some(node=>node.id===item.id)?{...item,active:value}:item)}));if(form&&targets.some(node=>node.id===form.id))setForm(current=>({...current,draft:{...current.draft,active:value}}));}
          notify('');
        }}/>
      </section>;
    })}</div>
    {form&&<form className="hierarchy-edit" onSubmit={apply}><div className="hierarchy-form-heading"><h3>{definition.levels[formLevel][1]} {form.id?'수정':'추가'}</h3></div><div className="hierarchy-form-fields">{formLevel>0&&<label><span>상위 {definition.levels[formLevel-1][1]}</span><CxSelect className="native-select" aria-label="상위 항목" value={form.draft.parentId||''} disabled={unavailable} onChange={event=>setForm({...form,draft:{...form.draft,parentId:event.target.value}})} required><option value="">선택하세요</option>{parents.map(node=><option key={node.id} value={node.id}>{nodePath(document.items,node.id).map(parent=>parent.label).join(' / ')}</option>)}</CxSelect></label>}<label><span>이름</span><input ref={input} className="text-input" aria-label="항목 이름" required value={form.draft.label} disabled={unavailable} onChange={event=>setForm({...form,draft:{...form.draft,label:event.target.value}})}/></label></div><div className="hierarchy-form-actions"><ActionButton action="cancel" label="취소" onClick={cancelForm} disabled={saving}/><ActionButton action={form.id?'complete':'add'} type="submit" disabled={unavailable}/></div></form>}

    {deleting&&<MasterDeleteDialog showUsageCount={definition.key!=='standardProcesses'} label={deleting.node.label} field={definition.levels.find(([level])=>level===deleting.node.level)[1]} references={deleting.references} descendants={deleting.descendants} onCancel={()=>setDeleting(null)} onConfirm={confirmRemove}/>}
  </DetailPanel>;
}

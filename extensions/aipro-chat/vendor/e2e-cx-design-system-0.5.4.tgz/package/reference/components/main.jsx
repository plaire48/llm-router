import {CxSelect} from './CxSelect';
import React, { useEffect, useRef, useState } from 'react';
import {useHashScreen} from './useHashScreen';
import { createRoot } from 'react-dom/client';
import './styles/recovered.css';
import './assets/fonts/noto-sans-kr/font.css';
import './app.css';
import './cx.css';
import './table.css';
import './agent.css';
import './work-list.css';
import { WorkList } from './WorkList';
import { MasterSettingsWorkspace } from './MasterSettings';
import { AdminSettings } from './AdminSettings';
const E2ETalk=React.lazy(()=>import('./E2ETalk'));
import { createAdminClient, roleCapabilities } from './adminClient';
import { WorkListProvider, useWorkList } from './WorkListState';
import { LIST_CATALOGS } from './workListModel';
import { BrandMark, Button, Topbar } from './AppChrome';
import { AppFooter } from './AppFooter';
const InquiryWorkspace=React.lazy(()=>import('./InquiryWorkspace'));
import { inquiryOrigin, workspaceViewFromHash } from './inquiryNavigation';
import { applyProductTheme } from './brandTheme';
import { AccountProvider, AccountProfile, useAccount, GithubAvatar } from './AccountProfile';
import { LoginScreen } from './LoginScreen';
import HelpPanel from './HelpPanel';
import './github-workspace.css';
import './cx-system.css';
import './cx-density.css';
import { WorkspaceFilters, WorkspaceTabs, AutomationRateBar, AutomationSummaryTable, ReportActionBar, SortHeader, SelectionCheckbox, useRowSelection } from './WorkspaceLayout';


import { Icon, SearchInput } from './Icon';
import { DetailPanel } from './DetailPanel';
import { ActiveColumnFilters, ControlledTable, TableControlsContext, TablePagination, useColumnControls, usePagination } from './TableControls';
import { WorkspaceMemory, useWorkspaceState, TableViewport, workspaceScroller } from './WorkspaceMemory';
import { downloadReportCsv, groupAutomationRows, sortReportRows } from './reportInteractions';
import { listGithubMasterHistory, loadGithubJson, loadGithubMaster, parseMaster, saveGithubJson, saveGithubMaster } from './master';
import { hasActiveGithubSession as hasSession, clearGithubSession as clearSession, getGithubSession, readGithubUser, verifyGithubSession } from './session';
import { notifyToast } from './Toast';
import { getMasterDefinition, getMasterOptions, MASTER_DEFINITIONS } from './masterCatalog';
import { formatAutomationRate, getAutomationRate, normalizeAutomationRate, summarizeAutomationRate } from './automationRate';
import { EnhancementWorkspace } from './reportWorkspace';


const VIEW_COPY = {
  overview: { kicker: 'MASTER DATA', title: '업무 자동화율 마스터', page: '업무 자동화 현황', description: '업무의 자동화 수준을 파악하고, 개선할 지점을 찾아보세요.', support: '업무 자동화율은 JSON 마스터에서 입력·관리하며, 모든 화면의 계산은 이 값을 기준으로 합니다.' },
  report: { kicker: 'DIAGNOSIS · ENHANCEMENT', title: '고도화 판정·관리', page: '고도화 판정·관리', description: '업무별 판정 근거를 검토하고, 고도화 효과와 투입 공수를 비교하세요.', support: 'Action 수 없이 업무 자동화율 마스터와 판정 기준 마스터를 사용해 계산합니다.' },
  history: { kicker: 'AUDIT TRAIL', title: '업무 자동화율 변경 이력', page: '변경 이력', description: '마스터 JSON 변경 시점과 실제 GHES 사용자를 확인합니다.', support: '저장마다 생성된 GHES 커밋을 기준으로 변경 이력을 조회합니다.' },
  settings: { kicker: 'BASE SETTINGS', title: '기준 설정 베이스', page: '기준 설정', description: '업무 분류와 판정에 사용되는 기준정보를 한곳에서 관리하세요.', support: '부서, 권한, 리포트 기준정보를 관리할 수 있도록 구성할 영역입니다.' }
};

function GitHubAvatar({ profile, size }) { return <GithubAvatar user={profile} size={size}/>; }

async function fetchGithubProfile({ host, token, login }) {
  const response = await fetch(`https://${host}/api/v3/users/${encodeURIComponent(login)}`, {
    cache: 'no-store',
    headers: { Accept: 'application/vnd.github+json', Authorization: `Bearer ${token}` }
  });
  const profile = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(profile.message || `GHES 사용자 프로필 조회 실패: HTTP ${response.status}`);
  if (!profile.login) throw new Error('GHES 사용자 프로필 응답에 login이 없습니다.');
  return profile;
}
function SelectPreview({ label }) {
  return <label className="field"><span className="input-label">{label}</span><div className="select select--outline select--md is-disabled"><span className="select__value is-placeholder">선택 예정</span><Icon name="chevronDown" size={16} /></div></label>;
}


function Stats() {
  const items = [['대상 리포트', '–', '기준 미연결'], ['작성 중', '–', '데이터 연동 예정'], ['검토 필요', '–', '상태 규칙 협의 예정'], ['최근 반영', '–', '이력 저장 예정']];
  return <section className="stats" aria-label="E2E Report 요약">{items.map(([label, value, sub]) => <article className="stat-card" key={label}><span>{label}</span><strong>{value}</strong><small>{sub}</small></article>)}</section>;
}

function WorkspacePlaceholder({ copy }) {
  return <section className="workspace-card" aria-labelledby="workspace-title"><header className="workspace-header"><div><p className="card-kicker">{copy.kicker}</p><h2 id="workspace-title">{copy.title}</h2><p>{copy.support}</p></div><div className="workspace-actions"><Button variant="outline" color="neutral" size="md"><Icon name="arrowRight" size={20} />화면 새로고침</Button></div></header><div className="workspace-body"><div className="filter-row"><SelectPreview label="기준 기간" /><SelectPreview label="부서/업무" /><SelectPreview label="상태" /><span>필터 항목은 실제 데이터 구조 협의 후 연결됩니다.</span></div><div className="empty-state"><div className="empty-icon"><Icon name="layoutGrid02" size={24} /></div><h3>이 메뉴의 데이터 모델을 연결할 준비가 되었습니다</h3><p>업무 자동화율 마스터를 기준으로 실제 리포트와 이력 기능을 확장할 수 있습니다.<br />메뉴별 업무 규칙을 정하면 이 영역에 기능을 연결합니다.</p><div className="next-actions"><span>메뉴·권한</span><span>리포트 구성</span><span>데이터 연계</span><span>반영·이력</span></div></div></div></section>;
}

function MasterStats({ rows, dirtyCount }) {
  const summary = summarizeAutomationRate(rows);
  const average = formatAutomationRate(summary.averageRate);
  const processes = new Set(rows.map((row) => row.process)).size;
  const activities = new Set(rows.map((row) => `${row.process}|${row.activity}`)).size;
  const rateSubtext = summary.missingCount ? `${summary.missingCount}건 미입력 · 마스터 기준` : dirtyCount ? `${dirtyCount}건 수정 중` : '마스터 기준 평균';
  const items = [['Task', rows.length, '조회 범위의 업무', 'taskList'], ['Process', processes, '연결된 업무 프로세스', 'workflow'], ['Activity', activities, '프로세스별 활동', 'layers'], ['평균 자동화율', average, rateSubtext, 'automation']];
  return <section className="stats master-stats" aria-label="업무 자동화율 마스터 요약">{items.map(([label, value, sub, icon]) => <article className="stat-card" key={label}><Icon name={icon} size={20}/><span>{label}</span><strong>{value}</strong><small>{sub}</small></article>)}</section>;
}

function formatHistoryDate(value) {
  if (!value) return '날짜 없음';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '날짜 없음' : new Intl.DateTimeFormat('ko-KR', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function MasterHistory({ history, loading, error, isEditor, onRefresh, onOpenProfile }) {
  return <section className="history-panel" aria-labelledby="master-history-title"><header className="history-header"><div><p className="card-kicker">AUDIT TRAIL</p><h3 id="master-history-title">업무 자동화율 변경 이력</h3><p>JSON 마스터 파일에 반영된 Git 커밋과 실제 GHES 사용자를 기준으로 표시합니다.</p></div><Button variant="outline" color="neutral" size="md" onClick={onRefresh} disabled={!isEditor || loading}><Icon name="refresh" size={18} />{loading ? '조회 중…' : '새로고침'}</Button></header><div className="history-body">{!isEditor ? <p className="history-empty">이력 확인은 사내 GitHub 로그인 후 사용할 수 있습니다.</p> : loading ? <p className="history-empty"><span className="status-spinner" aria-hidden="true" />변경 이력을 불러오는 중입니다.</p> : error ? <p className="history-empty history-empty--error">{error}</p> : history.length ? <ol className="history-list">{history.map((item) => <li className="history-item" key={item.sha}><button type="button" className="history-profile-button" onClick={() => onOpenProfile?.(item.author)} disabled={!item.author?.login} aria-label={`${item.author?.name || '알 수 없는 사용자'} GitHub 프로필 보기`}><GitHubAvatar profile={item.author} size="sm" /><span className="history-profile-button__copy"><strong>{item.author?.name || '알 수 없는 사용자'}</strong><small>{item.author?.login ? `@${item.author.login}` : '프로필 정보 없음'}</small></span></button><div className="history-item__copy"><strong>{item.message}</strong><span>{formatHistoryDate(item.date)}</span></div>{item.htmlUrl && <a className="history-link" href={item.htmlUrl} target="_blank" rel="noreferrer">커밋 보기</a>}</li>)}</ol> : <p className="history-empty">아직 저장된 변경 이력이 없습니다.</p>}</div></section>;
}

function HistoryWorkspace({ isEditor, onOpenProfile }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(isEditor);
  const [error, setError] = useState('');

  const refresh = async () => {
    if (!isEditor) return;
    setLoading(true);
    setError('');
    try {
      setHistory(await listGithubMasterHistory(getGithubSession()));
    } catch (historyError) {
      setError(historyError.message || '변경 이력을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, [isEditor]);
  return <MasterHistory history={history} loading={loading} error={error} isEditor={isEditor} onRefresh={refresh} onOpenProfile={onOpenProfile} />;
}
function workItemSignature(row) {
  return `${row.rate ?? ''}|${row.deploymentType ?? ''}`;
}

function MasterWorkspace({ isEditor, user, onOpenProfile }) {
  const initialRows = React.useMemo(() => parseMaster(), []);
  const [rows, setRows] = useState(initialRows);
  const [baseline, setBaseline] = useState(initialRows);
  const [sha, setSha] = useState(null);
  const [processFilter, setProcessFilter] = useWorkspaceState('overview.processFilter', '');
  const [activityFilter, setActivityFilter] = useWorkspaceState('overview.activityFilter', '');
  const [tableView, setTableView] = useWorkspaceState('overview.tableView', 'items');
  const [search, setSearch] = useWorkspaceState('overview.search', '');
  const [sort, setSort] = useWorkspaceState('overview.sort', { key: '', direction: 'asc' });
  const [summarySort, setSummarySort] = useWorkspaceState('overview.summarySort', { key: 'averageRate', direction: 'desc' });
  const [detailId, setDetailId] = useState(null);
  const [status, setStatus] = useState(isEditor ? 'GHES JSON 마스터를 확인하는 중…' : '');
  const [loading, setLoading] = useState(isEditor);
  const [saving, setSaving] = useState(false);
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(isEditor);
  const [historyError, setHistoryError] = useState('');
  const [metadata, setMetadata] = useState({ updatedAt: null, updatedBy: null });
  const [deploymentTypeOptions, setDeploymentTypeOptions] = useState(() => getMasterOptions('deploymentTypes'));
  const deploymentTypeDefinition = getMasterDefinition('deploymentTypes');

  const refreshHistory = async () => {
    if (!isEditor) return;
    setHistoryLoading(true);
    setHistoryError('');
    try {
      setHistory(await listGithubMasterHistory(getGithubSession()));
    } catch (error) {
      setHistoryError(error.message || '변경 이력을 불러오지 못했습니다.');
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    if (!isEditor) return undefined;
    loadGithubJson({ ...getGithubSession(), path: deploymentTypeDefinition.path }).then((remote) => {
      if (active && remote?.document) setDeploymentTypeOptions(getMasterOptions('deploymentTypes', remote.document));
    }).catch(() => {
      // Bundled master options remain available when the remote option master is unavailable.
    });
    return () => { active = false; };
  }, [isEditor]);

  useEffect(() => {
    if (!isEditor) {
      setHistory([]);
      setHistoryLoading(false);
      return undefined;
    }
    let active = true;
    const session = getGithubSession();
    setLoading(true);
    loadGithubMaster(session).then((remote) => {
      if (!active) return;
      if (remote?.rows?.length) {
        setRows(remote.rows);
        setBaseline(remote.rows);
        setSha(remote.sha);
        setMetadata(remote.metadata || { updatedAt: null, updatedBy: null });
        setStatus('GHES 저장소의 JSON 마스터를 불러왔습니다.');
      } else {
        setStatus('GHES에 저장된 JSON 마스터가 없어 기본 마스터를 표시합니다. 저장하면 파일이 생성됩니다.');
      }
    }).catch((error) => { if (active) setStatus(error.message || 'GHES JSON 마스터를 불러오지 못했습니다. 기본 마스터를 표시합니다.'); }).finally(() => { if (active) setLoading(false); });
    refreshHistory();
    return () => { active = false; };
  }, [isEditor]);
  const baselineMap = React.useMemo(() => new Map(baseline.map((row) => [row.id, workItemSignature(row)])), [baseline]);
  const dirtyCount = rows.filter((row) => workItemSignature(row) !== baselineMap.get(row.id)).length;
  const processOptions = React.useMemo(() => [...new Set(rows.map((row) => row.process))].sort((a, b) => a.localeCompare(b, 'ko')), [rows]);
  const activityOptions = React.useMemo(() => [...new Set(rows.filter((row) => !processFilter || row.process === processFilter).map((row) => row.activity))].sort((a, b) => a.localeCompare(b, 'ko')), [rows, processFilter]);
  const filteredRows = rows.filter((row) => {
    const haystack = `${row.process} ${row.activity} ${row.task}`.toLowerCase();
    return (!processFilter || row.process === processFilter) && (!activityFilter || row.activity === activityFilter) && (!search || haystack.includes(search.toLowerCase()));
  });

  const deploymentLabel = (row) => deploymentTypeOptions.find((option) => option.value === row.deploymentType)?.label || '';
  const detailRow = rows.find((row) => row.id === detailId);
  const itemColumns = [{ key: 'process', label: 'Process' }, { key: 'activity', label: 'Activity' }, { key: 'task', label: 'Task' }, { key: 'deploymentType', label: '배포유형', value: deploymentLabel }, { key: 'rate', label: '업무 자동화율 (%)', value: getAutomationRate }];
  const summaryColumns = [{ key: 'process', label: 'Process' }, ...(tableView === 'activity' ? [{ key: 'activity', label: 'Activity' }] : []), { key: 'taskCount', label: '업무 수' }, { key: 'inputCount', label: '입력 완료' }, { key: 'missingCount', label: '미입력' }, { key: 'averageRate', label: '평균 자동화율 (%)' }];
  const widths = { process: 190, activity: 195, task: 260, deploymentType: 120, rate: 170, taskCount: 150, inputCount: 150, missingCount: 150, averageRate: 250 };
  const columns = (tableView === 'items' ? itemColumns : summaryColumns).map((column) => ({ ...column, width: widths[column.key] }));
  const candidates = tableView === 'items' ? filteredRows : groupAutomationRows(filteredRows, tableView);
  const columnControls = useColumnControls('overview', tableView, columns, candidates);
  const currentSort = tableView === 'items' ? sort : summarySort;
  const exportRows = sortReportRows(columnControls.rows, currentSort, (row, key) => { const column = columns.find((entry) => entry.key === key); return column?.value ? column.value(row) : row[key]; });
  const visibleRows = tableView === 'items' ? exportRows : exportRows.flatMap((group) => group.rows);
  const scope = JSON.stringify([processFilter, activityFilter, search, tableView, columnControls.filters]);
  const selection = useRowSelection(visibleRows, scope);
  const pagination = usePagination('overview', exportRows, JSON.stringify([scope, currentSort]));
  const pageSelectedCount = pagination.rows.filter((row) => selection.ids.has(row.id)).length;
  const pageSelected = pagination.rows.length > 0 && pageSelectedCount === pagination.rows.length;
  const exportReport = (selected) => {
    const output = selected ? exportRows.filter((row) => selection.ids.has(row.id)) : exportRows;
    downloadReportCsv(output, tableView === 'items' ? itemColumns : summaryColumns, `업무자동화율_${tableView}_${selected ? '선택' : '조회'}_${output.length}건`);
    setStatus(`${selected ? '선택 항목' : '조회 결과'} ${output.length}건의 CSV 파일을 만들었습니다.`);
  };

  const updateRate = (id, rawValue) => {
    const normalized = normalizeAutomationRate(rawValue);
    setRows((current) => current.map((row) => row.id === id ? { ...row, rate: normalized } : row));
  };

  const updateDeploymentType = (id, value) => {
    setRows((current) => current.map((row) => row.id === id ? { ...row, deploymentType: value || null } : row));
  };

  const resetChanges = () => { setRows(baseline); setStatus('수정 내용을 원래 값으로 되돌렸습니다.'); };

  const saveChanges = async () => {
    if (!dirtyCount || saving) return;
    setSaving(true);
    setStatus('GHES JSON 마스터와 변경 이력을 저장하는 중…');
    try {
      const session = getGithubSession();
      const login = user?.login || 'unknown-user';
      const result = await saveGithubMaster({ ...session, sha, rows, updatedBy: user, message: `Update 업무 자동화율 master (${dirtyCount} rows) by @${login}` });
      setBaseline(rows);
      setSha(result?.content?.sha || sha);
      setMetadata({ updatedAt: new Date().toISOString(), updatedBy: user || null });
      setStatus(`저장 완료 · ${dirtyCount}건을 ${login} 사용자로 반영했습니다.`);
      await refreshHistory();
    } catch (error) {
      setStatus(error.message || '저장하지 못했습니다. 변경 내용은 화면에 남아 있습니다.');
    } finally { setSaving(false); }
  };

  const lastEditor = metadata.updatedBy?.name || metadata.updatedBy?.login;
  const tabs = [['items', 'E2E Agent 현황'], ['process', 'Process별 현황'], ['activity', 'Activity별 현황']];
  return <TableControlsContext.Provider value={columnControls}><div className="master-workspace">
    <MasterStats rows={visibleRows} dirtyCount={dirtyCount} />
    <WorkspaceFilters onReset={() => { setSearch(''); setProcessFilter(''); setActivityFilter(''); columnControls.clearFilters(); }}>
      <label className="field"><span className="input-label">Process</span>
        <CxSelect className="native-select" value={processFilter} onChange={(event) => { setProcessFilter(event.target.value); setActivityFilter(''); }}>
          <option value="">전체 ({processOptions.length})</option>{processOptions.map((option) => <option key={option} value={option}>{option}</option>)}
        </CxSelect>
      </label>
      <label className="field"><span className="input-label">Activity</span>
        <CxSelect className="native-select" value={activityFilter} onChange={(event) => setActivityFilter(event.target.value)}>
          <option value="">전체 ({activityOptions.length})</option>{activityOptions.map((option) => <option key={option} value={option}>{option}</option>)}
        </CxSelect>
      </label>
    </WorkspaceFilters>
    <WorkspaceTabs items={tabs} active={tableView} onChange={setTableView} label="업무 자동화율 보기" />
    <section className="master-card" aria-labelledby="master-title">
      <ReportActionBar pagination={pagination} search={search} onSearch={setSearch} columnControls={columnControls} id="master-title" title={tableView === 'items' ? 'E2E Agent 현황' : tableView === 'process' ? 'Process별 자동화율' : 'Activity별 자동화율'} count={exportRows.length} total={tableView === 'items' ? rows.length : groupAutomationRows(rows, tableView).length} selection={tableView === 'items' ? selection : null} onDownload={exportReport} onOpenSelected={() => setDetailId([...selection.ids][0])} busy={saving || loading}>
        {isEditor ? <><button className="cx-button" type="button" onClick={resetChanges} disabled={!dirtyCount || saving}>되돌리기</button><button className="cx-button cx-button--primary" type="button" onClick={saveChanges} disabled={!dirtyCount || saving}><Icon name="save" size={16} />{saving ? '저장 중…' : `변경 사항 저장${dirtyCount ? ` (${dirtyCount})` : ''}`}</button></> : null}
      </ReportActionBar>
      {tableView === 'items' ? <TableViewport memoryKey="overview.items.scroll" resetKey={pagination.page} className="master-table-wrap">
        <ControlledTable className="master-table work-items-table" selection detail>
          <thead><tr><th className="selection-column" data-column="__select" scope="col"><SelectionCheckbox label="현재 페이지 전체 선택" checked={pageSelected} mixed={pageSelectedCount > 0 && !pageSelected} onChange={() => selection.togglePage(pagination.rows)} /></th><SortHeader label="Process" field="process" sort={sort} onSort={setSort} /><SortHeader label="Activity" field="activity" sort={sort} onSort={setSort} /><SortHeader label="Task" field="task" sort={sort} onSort={setSort} /><SortHeader label="배포유형" field="deploymentType" sort={sort} onSort={setSort} className="deployment-column" /><SortHeader label="업무 자동화율" unit="%" field="rate" sort={sort} onSort={setSort} className="rate-column" /><th className="detail-column" data-column="__detail" scope="col"><span className="visually-hidden">상세</span></th></tr></thead>
          <tbody>{pagination.rows.map((row) => <tr key={row.id} data-row-id={row.id} aria-selected={selection.ids.has(row.id)} className={`${workItemSignature(row) !== baselineMap.get(row.id) ? 'is-dirty' : ''} ${selection.ids.has(row.id) ? 'is-selected' : ''}`}>
            <td className="selection-column"><SelectionCheckbox label={`${row.task} 선택`} checked={selection.ids.has(row.id)} onChange={() => selection.toggle(row.id)} /></td>
            <td title={row.process}>{row.process}</td><td title={row.activity}>{row.activity}</td><td title={row.task}>{row.task}</td>
            <td className="deployment-column">{isEditor ? <CxSelect className="native-select deployment-select" value={row.deploymentType ?? ''} disabled={saving} onChange={(event) => updateDeploymentType(row.id, event.target.value)} aria-label={`${row.task} 배포유형`}><option value="">미선택</option>{deploymentTypeOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</CxSelect> : deploymentTypeOptions.find((option) => option.value === row.deploymentType)?.label || '–'}</td>
            <td className="rate-column">{isEditor ? <div className="rate-editor"><input className="rate-input" type="number" min="0" max="100" step="1" value={getAutomationRate(row) ?? ''} disabled={saving} onChange={(event) => updateRate(row.id, event.target.value)} aria-label={`${row.task} 업무 자동화율`} /><span>%</span></div> : <AutomationRateBar value={getAutomationRate(row)} />}</td>
            <td className="detail-column"><button className="cx-icon-button" type="button" onClick={() => setDetailId(row.id)} aria-label={`${row.task} 상세`} title="업무 상세"><Icon name="chevronRight" size={17} /></button></td>
          </tr>)}</tbody>
        </ControlledTable>
        {!visibleRows.length && <div className="table-empty">조건에 맞는 마스터 항목이 없습니다.</div>}
      </TableViewport> : <AutomationSummaryTable page={pagination.page} items={pagination.rows} rows={visibleRows} by={tableView} sort={summarySort} onSort={setSummarySort} />}
      <TablePagination pagination={pagination} selectedCount={selection.ids.size} />
      <div className="table-footnote"><span className="master-status" role="status" aria-live="polite">{loading && <span className="status-spinner" aria-hidden="true" />}{status}</span>{metadata.updatedAt && <span>최근 저장 {formatHistoryDate(metadata.updatedAt)}{lastEditor ? ` · ${lastEditor}` : ''}</span>}</div>
    </section>
    {detailRow && <DetailPanel title="업무 상세" subtitle={`${detailRow.process} / ${detailRow.activity}`} onClose={() => setDetailId(null)}><div className="cx-detail-intro"><span className="cx-section-label">Task</span><h3>{detailRow.task}</h3></div><section className="cx-detail-section"><h3>자동화 현황</h3><dl className="cx-detail-facts"><div><dt>업무 자동화율</dt><dd>{formatAutomationRate(getAutomationRate(detailRow))}</dd></div><div><dt>배포유형</dt><dd>{deploymentLabel(detailRow) || '미입력'}</dd></div></dl><AutomationRateBar value={getAutomationRate(detailRow)} /></section><p className="cx-panel-note">{isEditor ? '자동화율과 배포유형은 목록에서 수정할 수 있습니다.' : '로그인하면 업무 자동화율과 배포유형을 수정할 수 있습니다.'}</p></DetailPanel>}
    {isEditor && <details className="inline-history"><summary>변경 이력</summary><MasterHistory history={history} loading={historyLoading} error={historyError} isEditor={isEditor} onRefresh={refreshHistory} onOpenProfile={onOpenProfile} /></details>}
  </div></TableControlsContext.Provider>;
}
function AppShell({ user, ...props }) {
  // A background profile refresh must not remount the list and discard drafts.
  return <AccountProvider user={user}><AccountWorkspace {...props}/></AccountProvider>;
}

function AccountWorkspace({ onLogout, onRegisterLeaveGuard }) {
  const { user } = useAccount();
  const [role,setRole] = useState('user');
  const capabilities = roleCapabilities(role), isAdmin = capabilities.admin, isEditor = capabilities.edit;
  useEffect(() => {
    let active = true;
    setRole('user');
    if(user?.login) {
      try { createAdminClient().role().then(value=>{if(active)setRole(value);}).catch(error=>{if(active)notifyToast(error,{source:'roles',error:true});}); }
      catch { /* No verified GHES session: privileged navigation stays hidden. */ }
    }
    return()=>{active=false;};
  },[user?.login]);

  const [view, updateView] = useState(()=>workspaceViewFromHash(location.hash)||'overview');
  const [notificationUser,setNotificationUser] = useState({login:'',revision:0});
  const scrollPositions = useRef({}), shellRef = useRef(null);
  const [settingsPending,setSettingsPending]=useState({dirty:false,saving:false});
  const setView = async (next) => { if(next==='admin'&&!isAdmin||next==='settings'&&!capabilities.settings)return false; if(next===view)return true; if(settingsPending.saving)return false; scrollPositions.current[view] = workspaceScroller(shellRef.current)?.scrollTop || 0; history.replaceState(null,'',next==='talk'?'#talk':next==='support'?'#support':'#app');updateView(next); return true; };
  useEffect(() => { const scroller = workspaceScroller(shellRef.current); if(scroller) scroller.scrollTop = scrollPositions.current[view] || 0; }, [view]);
  const [dialog, setDialog] = useState(null);
  return <WorkListProvider isEditor={isEditor} canSettings={capabilities.settings} canRead={Boolean(user?.login)} user={user}><div className="app-shell list-app-shell">
    <Topbar canSettings={capabilities.settings} isAdmin={isAdmin} notificationRole={role} onOpenNotificationUser={login=>setNotificationUser(current=>({login,revision:current.revision+1}))} pendingChanges={settingsPending} view={view} setView={setView} onRegisterLeaveGuard={onRegisterLeaveGuard} onProfile={() => setDialog('profile')} onHelp={() => setDialog('help')} onLogout={onLogout} user={user} />
    <main ref={shellRef} className="shell">

      {view==='support'?<React.Suspense fallback={<p role="status">문의를 불러오는 중…</p>}><InquiryWorkspace key={`${user?.id||'guest'}:${role}`} user={user} role={role} onPendingChange={setSettingsPending}/></React.Suspense>:view==='talk'?<React.Suspense fallback={<p role="status">E2E Talk를 불러오는 중…</p>}><E2ETalk key={user?.id||'guest'} user={user} role={role} onPendingChange={setSettingsPending}/></React.Suspense>:view === 'overview' || !capabilities.settings || view === 'admin' && !isAdmin ? <WorkList /> : view === 'admin' ? <AdminSettings key={notificationUser.revision} focusLogin={notificationUser.login} onPendingChange={setSettingsPending} user={user}/> : <MasterSettingsWorkspace onPendingChange={setSettingsPending} isEditor={isEditor} user={user} />}
    </main>
    <AppFooter page={view==='support'?inquiryOrigin().page:view==='talk'?'E2E Talk':view === 'admin' ? '관리자 설정' : view === 'settings' ? '기준 설정' : 'E2E Agent 현황'}/>
    {dialog === 'profile' ? <AccountProfile onClose={() => setDialog(null)}/> : dialog === 'help' ? <HelpPanel initialTopic={view==='support'?'support':view==='talk'?'talk':view==='admin'?'admin':view==='settings'?'settings':'find'} onClose={() => setDialog(null)} user={user} /> : null}
  </div></WorkListProvider>;
}

const readAppScreen=()=>window.location.hash === '#login' ? 'login' : workspaceViewFromHash(window.location.hash) || hasSession() ? 'app' : 'login';
function App() {
  const {screen,setScreen,registerLeaveGuard}=useHashScreen(readAppScreen);
  const [loginHelp,setLoginHelp]=useState(false);
  const [sessionUser, setSessionUser] = useState(readGithubUser);
  const [sessionRetry, setSessionRetry] = useState(0);
  const verifiedToken = useRef(null);
  useEffect(() => {
    if (screen !== 'app' || !hasSession()) { setSessionUser(null); return undefined; }
    const token = getGithubSession().token;
    if (verifiedToken.current === token && sessionUser?.login) return undefined;
    const controller = new AbortController();
    verifyGithubSession({ signal: controller.signal }).then(result => {
      if (controller.signal.aborted || result.status === 'stale') return;
      if (result.status === 'verified') {
        setSessionUser(result.user);
        verifiedToken.current = token;
        notifyToast('', { source: 'session' });
      } else if (result.status === 'expired') {
        setSessionUser(null);
        setScreen('login'); window.location.hash = 'login';
        notifyToast(result.message, { source: 'session', error: true });
      } else if (result.status === 'error') {
        notifyToast(result.message, { source: 'session', error: true, actions: [
          {label:'다시 확인', onClick:()=>setSessionRetry(value=>value+1)},
          {label:'다시 로그인', onClick:()=>{window.location.hash='login';}}
        ] });
      }
    });
    return () => { controller.abort(); };
  }, [screen, sessionRetry]);
  const openApp = () => { setScreen('app');window.location.hash = 'app'; };
  const logout = () => { clearSession(); verifiedToken.current=null;setSessionUser(null);setScreen('login');window.location.hash = 'login'; };
  const loggedIn = profile => {
    // Device Flow has already verified GET /user with this exact token.
    verifiedToken.current=getGithubSession().token;setSessionUser(profile);
    const inquiryReturn=sessionStorage.getItem('e2e-inquiry:return');sessionStorage.removeItem('e2e-inquiry:return');
    const returnTo=sessionStorage.getItem('e2e-talk:return');sessionStorage.removeItem('e2e-talk:return');
    if(workspaceViewFromHash(inquiryReturn||'')==='support'){window.location.hash=inquiryReturn;setScreen('app');}
    else if(/^#talk(?:=[a-f\d-]+)?$/i.test(returnTo||'')){window.location.hash=returnTo;setScreen('app');}else openApp();
    notifyToast('', {source:'session'});
  };
  return screen === 'login' ? <><LoginScreen onView={openApp} onHelp={()=>setLoginHelp(true)} onLogin={loggedIn} />{loginHelp&&<HelpPanel initialTopic="account" onClose={()=>setLoginHelp(false)}/>}</> : <WorkspaceMemory><AppShell onLogout={logout} onRegisterLeaveGuard={registerLeaveGuard} isEditor={hasSession()} user={hasSession()?(sessionUser||readGithubUser()):null} /></WorkspaceMemory>;
}
applyProductTheme();
createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);

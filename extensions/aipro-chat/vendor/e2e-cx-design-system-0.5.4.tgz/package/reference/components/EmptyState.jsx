import React from 'react';
import { Icon } from './Icon';

export function EmptyState({ icon = 'search', title, description, children }) {
  return <div className="cx-empty-state" role="status">
    <span className="cx-empty-symbol"><Icon name={icon} size={24}/></span>
    <strong>{title}</strong>
    {description && <p>{description}</p>}
    {children && <div className="cx-empty-actions">{children}</div>}
  </div>;
}

import { ActionButton } from './ActionButton';
import React, {useEffect, useRef, useState} from 'react';
import {ActiveColumnFilters, ControlledTable, PageSizeSelect, TableControlsContext, TablePagination, useColumnControls, usePagination} from './TableControls';
import {SelectionCheckbox, SortHeader, useRowSelection} from './WorkspaceLayout';
import {useWorkspaceState} from './WorkspaceMemory';
import {columnValue, downloadReportCsv, sortReportRows} from './reportInteractions';
import {SelectionApplyDialog} from './SelectionApplyDialog';
import {useFeedback} from './Toast';
import {Icon} from './Icon';
import './selection-apply.css';
import './column-pinning.css';
import './settings-grid.css';

const columnChanged=(row,column)=>Boolean(column.filterValue)&&String(columnValue(row,column)??'').trim()!==String(column.filterValue(row)??'').trim();
const rowChanged=(row,columns)=>Boolean(row.draftOnly)||columns.some(column=>columnChanged(row,column));

export function useSettingsGrid({id, rows, columns, scope='', label, paginate=false, groupOrder, interactive=false, editAll=false}) {
  const [storedOnlyChanged,setOnlyChanged]=useWorkspaceState(`${id}.onlyChanged`,false);
  const onlyChanged=interactive&&storedOnlyChanged;
  const changedCount=rows.filter(row=>rowChanged(row,columns)).length;
  const [sort,setSort]=useWorkspaceState(`${id}.sort`,{key:'',direction:'asc'});
  const [pinCount,setPinCount]=useWorkspaceState(`${id}.pins`,0),[revealRequest,setRevealRequest]=useState(null);
  const [notice,setNotice]=useFeedback();
  const [pinLimit,setPinLimit]=useState(Infinity);
  // Drafts stay in place while typing, like the Agent list. Export uses current values.
  const queryColumns=columns.map(column=>({...column,value:column.filterValue||column.value}));
  const savedControls=useColumnControls(id,'items',queryColumns,onlyChanged?rows.filter(row=>rowChanged(row,columns)):rows);
  const controls=interactive?savedControls:{...savedControls,rows,filters:{},widths:{}};
  const visibleSort=interactive&&columns.some(column=>column.key===sort.key)?sort:{key:'',direction:'asc'};
  const sorted=sortReportRows(controls.rows,visibleSort,(row,key)=>columnValue(row,queryColumns.find(column=>column.key===key)));
  if(groupOrder)sorted.sort((a,b)=>groupOrder(a)-groupOrder(b));
  const queryScope=JSON.stringify([scope,controls.filters,onlyChanged]);
  const pages=usePagination(id,sorted,JSON.stringify([queryScope,sort]));
  const pagination=interactive&&paginate?pages:{...pages,page:1,pageCount:1,pageSize:Math.max(1,sorted.length),start:0,end:sorted.length,total:sorted.length,rows:sorted,size:'all'};
  const savedSelection=useRowSelection(sorted,queryScope);
  const selection=interactive?savedSelection:{...savedSelection,ids:new Set(),all:false,notice:''};
  const pinned=interactive?columns.slice(0,Math.min(pinCount,columns.length,pinLimit)).map(column=>column.key):[];
  const togglePin=key=>{
    const index=columns.findIndex(column=>column.key===key);
    if(index>pinned.length){setNotice(`먼저 ${columns[pinned.length].label} 열을 고정하세요.`);return;}
    if(index===pinned.length&&index>=pinLimit){setNotice(`현재 화면에서는 ${pinLimit}개 열까지 고정할 수 있습니다. 더 고정하려면 창을 넓혀 주세요.`);return;}
    setPinCount(index<pinned.length?index:index+1);setNotice('');
  };
  const download=selected=>downloadReportCsv(selected?sorted.filter(row=>selection.ids.has(row.id)):sorted,columns,label+(selected?'_선택':'_조회'));
  const reveal=rowId=>{if(!sorted.some(row=>row.id===rowId)){controls.clearFilters();setOnlyChanged(false);}setRevealRequest({id:rowId});};
  return {id,label,columns,controls,interactive,editAll,paginate:interactive&&paginate,onlyChanged,setOnlyChanged,changedCount,sort:visibleSort,setSort,sorted,pagination,selection,pinned,setPinLimit,togglePin,notice,download,reveal,revealRequest,completeReveal:()=>setRevealRequest(null)};
}

export function SettingsGrid({grid,renderCell,renderActions,rowProps=()=>({}),children,empty='조건에 맞는 항목이 없습니다.',className='',compact=false,showCount=true,focusId,renderTables,nameHeading,headerAction}) {
  const {controls,pagination,selection,interactive}=grid;
  const host=useRef(null),focusRequest=useRef({id:null,pending:false});
  useEffect(()=>{
    if(focusRequest.current.id!==focusId)focusRequest.current={id:focusId,pending:Boolean(focusId)};
    if(!focusRequest.current.pending)return;
    const index=grid.sorted.findIndex(row=>row.id===focusId);
    if(index<0)return;
    const page=Math.floor(index/pagination.pageSize)+1;
    if(page!==pagination.page){pagination.setPage(page);return;}
    const input=host.current?.querySelector(`[data-settings-row="${CSS.escape(focusId)}"] input:not([type="checkbox"])`);
    if(input){input.focus();focusRequest.current.pending=false;}
  },[focusId,pagination.page,grid.sorted.length]);
  useEffect(()=>{
    if(!grid.revealRequest)return;
    const index=grid.sorted.findIndex(row=>row.id===grid.revealRequest.id);
    if(index<0)return;
    const page=Math.floor(index/pagination.pageSize)+1;
    if(page!==pagination.page){pagination.setPage(page);return;}
    const row=host.current?.querySelector(`[data-settings-row="${CSS.escape(grid.revealRequest.id)}"]`);
    if(row){row.scrollIntoView({block:'nearest'});grid.completeReveal();}
  },[grid.revealRequest,pagination.page,grid.sorted.length]);
  return <TableControlsContext.Provider value={controls}><div ref={host} className={`settings-grid ${compact?'settings-grid--compact':''} ${interactive?'':'settings-grid--simple'}`} data-settings-grid={grid.id}>
    {(showCount&&!compact||interactive||children)&&<div className="settings-grid-toolbar">
      {showCount&&<span className="settings-grid-count">전체 <strong>{pagination.total.toLocaleString('ko-KR')}</strong></span>}{grid.paginate&&<PageSizeSelect pagination={pagination}/>}
      {interactive&&(grid.changedCount>0||grid.onlyChanged)&&<label className="list-changed-filter"><input type="checkbox" className="cx-checkbox" checked={grid.onlyChanged} onChange={event=>grid.setOnlyChanged(event.target.checked)}/>미저장 <span>{grid.changedCount}</span></label>}{children}{interactive&&<div className="settings-grid-utilities"><ActionButton action="download" type="button" aria-label={`${grid.label} 내보내기`} title="조회 결과 내보내기" disabled={!grid.sorted.length} onClick={()=>grid.download(false)}/><ActionButton action="resetWidths" type="button" aria-label={`${grid.label} 열 너비 초기화`} title="열 너비 초기화" onClick={controls.resetWidths} disabled={!controls.hasCustomWidths}/></div>}
    </div>}
    {interactive&&!!selection.ids.size&&<div className="settings-grid-selection"><ActionButton action="clearSelection" type="button" aria-label={`${grid.label} 선택 해제`} onClick={selection.clear}/><strong>{selection.ids.size}건 선택</strong>{grid.editAll&&selection.ids.size>1&&<span className="selection-edit-hint">한 셀을 변경해 일괄 적용</span>}<ActionButton action="download" label="선택 내보내기" type="button" onClick={()=>grid.download(true)}/></div>}
    {interactive&&<ActiveColumnFilters controls={controls}/>}
    <div className="settings-grid-scroll" role="region" aria-label={`${grid.label} 표`} tabIndex={0}>{renderTables ? renderTables() : <SettingsGridTable grid={grid} renderCell={renderCell} renderActions={renderActions} rowProps={rowProps} empty={empty} className={className} compact={compact} nameHeading={nameHeading} headerAction={headerAction}/>}</div>{grid.paginate&&<TablePagination pagination={pagination} selectedCount={selection.ids.size} as="div"/>}
  </div></TableControlsContext.Provider>;
}

// A table can share selection and query controls while showing only its own columns.
export function SettingsGridTable({grid,renderCell,renderActions,rowProps=()=>({}),empty='조건에 맞는 항목이 없습니다.',className='',compact=false,nameHeading,headerAction}) {
  const {columns,controls,sort,setSort,pagination,selection,pinned,interactive}=grid;
  const selectedOnPage=pagination.rows.filter(row=>selection.ids.has(row.id)).length;
  return <TableControlsContext.Provider value={controls}><ControlledTable className={`master-crud-table work-list-table settings-data-table ${nameHeading?'settings-data-table--named':''} ${className}`} selection={interactive} stretchColumn={grid.stretchColumn||(nameHeading&&columns.some(column=>column.utility)?'label':undefined)} detail={Boolean(renderActions)} detailWidth={compact?96:112} onPinLimitChange={interactive?grid.setPinLimit:undefined} frozenColumns={pinned.length?['__select',...pinned]:[]}>
      <caption className="visually-hidden">{grid.label}</caption><thead><tr>{interactive&&<th scope="col" data-column="__select" className="selection-column"><SelectionCheckbox label={`${grid.label} ${grid.paginate?'현재 페이지':'조회 항목'} 전체 선택`} checked={pagination.rows.length>0&&selectedOnPage===pagination.rows.length} mixed={selectedOnPage>0&&selectedOnPage<pagination.rows.length} onChange={()=>selection.togglePage(pagination.rows)}/></th>}{columns.map(column=>interactive?<SortHeader key={column.key} field={column.key} label={column.label} sort={sort} onSort={setSort} pinned={pinned.includes(column.key)} onPin={grid.togglePin} pinHint={pinned.includes(column.key)?`${column.label}부터 오른쪽 열 고정 해제`:column.key===columns[pinned.length]?.key?`${column.label} 열 고정`:`먼저 ${columns[pinned.length]?.label} 열을 고정하세요.`}/>:<th key={column.key} data-column={column.key} className={column.utility?'settings-utility-column':undefined} scope="col">{column.utility?<span className="visually-hidden">{column.label}</span>:nameHeading&&column.key==='label'?<h3 className="settings-name-heading" id={nameHeading.id}><span>{nameHeading.label}</span><span className="master-heading-count">{nameHeading.count.toLocaleString('ko-KR')}</span></h3>:column.label}</th>)}{renderActions&&<th data-column="__detail" scope="col"><span className="visually-hidden">항목 수정</span>{headerAction&&<div className="master-row-actions">{headerAction}</div>}</th>}</tr></thead>
      <tbody>{pagination.rows.map(row=>{const attrs=rowProps(row);return <tr key={row.id} {...attrs} data-settings-row={row.id} aria-selected={interactive?selection.ids.has(row.id):undefined} className={`${attrs.className||''} ${selection.ids.has(row.id)?'is-checked':''}`}>{interactive&&<td className="selection-column"><SelectionCheckbox label={`${row.selectionLabel||row.label||grid.label} 선택`} checked={selection.ids.has(row.id)} onChange={()=>selection.toggle(row.id)}/></td>}{columns.map(column=><td key={column.key} className={[column.utility?'settings-utility-column':'',columnChanged(row,column)?'is-changed':''].filter(Boolean).join(' ')||undefined} title={columnChanged(row,column)?`변경 전: ${column.filterValue(row)??'—'}`:undefined} data-field={column.key} data-column-pinned={pinned.includes(column.key)||undefined} style={pinned.includes(column.key)?{left:`var(--frozen-${column.key})`}:undefined}>{renderCell(row,column.key)}</td>)}{renderActions&&<td className="settings-grid-actions"><div className="master-row-actions">{renderActions(row)}</div></td>}</tr>;})}{!pagination.rows.length&&<tr><td className="table-empty" colSpan={columns.length+Number(interactive)+Boolean(renderActions)}>{empty}</td></tr>}</tbody>
    </ControlledTable></TableControlsContext.Provider>;
}

// Text/number edits ask once on blur or Enter, never after each keystroke.
export function SettingsCommitInput({onCommit,onFocus,onBlur,onKeyDown,value,...props}) {
  const original=useRef(value);
  return <input {...props} value={value} onFocus={event=>{original.current=event.currentTarget.value;onFocus?.(event);}} onBlur={event=>{const next=event.currentTarget.value;const previous=String(original.current??'').trim(),current=next.trim(),same=props.type==='number'&&previous!==''&&current!==''?Number(previous)===Number(current):previous===current;if(!same){original.current=next;onCommit?.(next);}onBlur?.(event);}} onKeyDown={event=>{if(event.key==='Enter'&&!event.nativeEvent.isComposing){event.preventDefault();event.stopPropagation();event.currentTarget.blur();}else onKeyDown?.(event);}}/>;
}

export function useSettingsApply(grid,{disabled=false}={}) {
  const [pending,setPending]=useState(null);
  const [,notify]=useFeedback();
  const offer=({rowId,field,value,display,apply,eligible=()=>true})=>{
    if(!grid.interactive||disabled||!grid.selection.ids.has(rowId))return;
    const targets=grid.sorted.filter(row=>grid.selection.ids.has(row.id)&&eligible(row));
    if(targets.length<2)return;
    notify('');setPending({field,value,display,apply,targets,skipped:grid.selection.ids.size-targets.length});
  };
  const apply = () => {
    try {
      pending.apply(pending.targets,pending.value);
      notify(`선택한 ${pending.targets.length}건에 적용했습니다. 저장을 눌러 반영하세요.`);
      setPending(null);
    } catch (reason) { notify(reason.message,true); }
  };
  const dialog=grid.interactive&&pending&&<SelectionApplyDialog count={pending.targets.length} field={pending.field} value={pending.display??(String(pending.value??'')||'값 지우기')} skipped={pending.skipped} className="settings-apply-confirm" busy={disabled} onCancel={()=>setPending(null)} onConfirm={apply}/>;
  return {offer,dialog};
}

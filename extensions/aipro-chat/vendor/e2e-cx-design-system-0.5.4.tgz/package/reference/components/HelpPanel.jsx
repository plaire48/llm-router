import {CxSelect} from './CxSelect';
import { ActionButton } from './ActionButton';
import {SearchField} from './SearchField';
import React, { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { Icon } from './Icon';
import { GithubAvatar } from './AccountProfile';
import { githubIdentityLabel } from './githubIdentity';
import { HELP_TOPICS, searchHelp, ENHANCEMENT_HELP_RULES, ENHANCEMENT_HELP_SUMMARY, ENHANCEMENT_HELP_NOTE } from './helpContent';
import './help.css';

const helpSentences = text => String(text).split(/\n+|(?<=[.!?])\s+/u);
function HelpText({text, emphasizeFirst = false}) {
  // Separate complete sentences; decimal points and file extensions stay intact.
  return helpSentences(text).map((sentence,index) => emphasizeFirst && index === 0 ? <strong className="help-answer-summary" key={index}>{sentence}</strong> : <span className="help-copy-sentence" key={index}>{sentence}</span>);
}

function SampleControl({icon, children, primary = false, iconOnly = false}) {
  return <span className={`help-sample-control${primary ? ' is-primary' : ''}${iconOnly ? ' is-icon-only' : ''}`} role={iconOnly?'img':undefined} aria-label={iconOnly?children:undefined} title={iconOnly?children:undefined}>{icon && <Icon name={icon} size={20}/>}<span className={iconOnly?'visually-hidden':undefined}>{children}</span></span>;
}
function Example({title = '화면 예시', children}) {
  return <figure className="help-example"><figcaption>{title}</figcaption>{children}</figure>;
}
function ExampleProfile({user, showLogin=false, fallbackName='변경자 이름'}) {
  return <span className="help-sample-profile">{user ? <GithubAvatar user={user} size="md"/> : <span className="help-avatar-placeholder" aria-label="GitHub 프로필 사진 위치"><Icon name="githubMark" size={24}/></span>}<strong>{showLogin?githubIdentityLabel(user||{name:fallbackName,login:'github-id'}):user?.name || user?.login || fallbackName}</strong></span>;
}

function FindExample({onEnhancementHelp}) {
  return <Example>
    <div className="help-sample-toolbar"><div className="help-sample-tabs"><strong>전체</strong><span>배포 현황</span><span>자동화 현황</span><span>고도화 현황</span></div><span className="help-sample-search"><Icon name="search" size={16}/>Agent 또는 담당자 검색</span></div>
    <div className="help-example-table-wrap"><table className="help-example-table help-find-table"><thead><tr><th><span className="help-sample-check"/></th>{['Process','Activity','Task','부서'].map(label=><th scope="col" key={label}><span>{label}<Icon name="filter" size={16}/></span></th>)}<th><span className="visually-hidden">수정 및 상세</span></th></tr></thead><tbody><tr><td><span className="help-sample-check"/></td>{['요청 관리','요청 접수','요청 내용 확인','담당 그룹'].map(label=><td key={label}>{label}</td>)}<td><span className="help-sample-row-end"><Icon name="pencil" size={18}/><span className="help-highlight-icon"><Icon name="chevronRight" size={18}/></span></span></td></tr></tbody></table></div>
    <div className="help-icon-key">{[["download","내보내기"],["columns","열 선택"],["columnWidth","열 너비 초기화"],["filterClear","필터 해제"],["clockRewind","변경 이력"]].map(([icon,label])=><span key={icon}><Icon name={icon} size={20}/>{label}</span>)}</div><p className="help-example-caption">아이콘에 마우스를 올리거나 Tab 키로 이동하면 이름이 나옵니다.</p>
    <button type="button" className="cx-button help-enhancement-link" onClick={onEnhancementHelp}>고도화 제안 판단 순서<Icon name="chevronRight" size={16}/></button>
  </Example>;
}
function EnhancementGuide() {
  return <>
    <p><HelpText text={ENHANCEMENT_HELP_SUMMARY} emphasizeFirst/></p>
    <table className="help-enhancement-rules">
      <caption className="visually-hidden">고도화 제안 판단 순서와 결과</caption>
      <thead><tr><th scope="col">순서</th><th scope="col">확인 조건</th><th scope="col">고도화 제안</th></tr></thead>
      <tbody>{ENHANCEMENT_HELP_RULES.map((rule,index)=><tr key={rule.code} data-proposal-rule={rule.code}>
        <th scope="row"><span className="help-step-number">{index+1}</span></th>
        <td><strong>{rule.condition}</strong><span>{rule.detail}</span></td>
        <td className="help-enhancement-result"><span className="help-enhancement-result-label" aria-hidden="true">고도화 제안</span><strong>{rule.result}</strong></td>
      </tr>)}</tbody>
    </table>
    <p className="help-enhancement-note"><HelpText text={ENHANCEMENT_HELP_NOTE}/></p>
  </>;
}
function EditExample() {
  return <><Example title="체크한 Agent에 같은 값 적용">
    <div className="help-edit-sequence"><div><span className="help-highlight-icon"><Icon name="check" size={20}/></span><strong>Agent 선택</strong><small>바꿀 행을 체크</small></div><Icon name="arrowRight" size={18}/><div><span className="help-highlight-icon"><Icon name="pencil" size={20}/></span><strong>값 하나 수정</strong><small>체크한 행에서 변경</small></div><Icon name="arrowRight" size={18}/><div><span className="help-highlight-icon is-solid"><Icon name="check" size={20}/></span><strong>선택 항목에 적용</strong><small>안내창에서 대상 확인</small></div></div>
    <p className="help-example-caption"><HelpText text="현재 행만 수정을 고르면 다른 행은 바뀌지 않습니다. 적용 후에는 목록에서 저장하세요."/></p>
  </Example><Example title="수정 완료와 저장의 차이">
    <div className="help-edit-sequence"><div><span className="help-highlight-icon"><Icon name="pencil" size={20}/></span><strong>값 수정</strong><small>행의 입력값 변경</small></div><Icon name="arrowRight" size={18}/><div><span className="help-highlight-icon"><Icon name="check" size={20}/></span><strong>수정 완료</strong><small>아직 저장 전</small></div><Icon name="arrowRight" size={18}/><div><span className="help-highlight-icon is-solid"><Icon name="save" size={20}/></span><strong>저장</strong><small>최종 반영과 이력 생성</small></div></div>
    <div className="help-example-actionbar"><span>마지막 저장 상태로 되돌리기</span><SampleControl icon="resetFilters" iconOnly>초기화</SampleControl><SampleControl icon="pencil" iconOnly>전체 수정</SampleControl><SampleControl icon="save" primary>저장</SampleControl></div>
    <div className="help-icon-key">{[["resetFilters","초기화"],["pencil","전체 수정"],["eye","읽기 모드"]].map(([icon,label])=><span key={icon}><Icon name={icon} size={20}/>{label}</span>)}</div>
  </Example></>;
}

function RateExample() {
  const [card, setCard] = useState('80'), [selected, setSelected] = useState(['API', 'Script']), [possible, setPossible] = useState(false);
  const methods = [{label:'API',weight:50},{label:'Script',weight:75},{label:'프롬프트',weight:25}];
  const method = selected.length ? Math.max(...methods.filter(item=>selected.includes(item.label)).map(item=>item.weight)) : null;
  const valid = card.trim() !== '' && Number.isFinite(Number(card)) && Number(card) >= 0 && Number(card) <= 100 && method !== null;
  const action = valid ? Number(card) * Number(method) / 100 : null;
  const second = possible ? action : 0;
  const average = valid ? (action + second) / 2 : null;
  const percent = value => value === null ? '—' : `${Number(value.toFixed(2)).toLocaleString('ko-KR')}%`;
  return <Example title="계산 예시 (저장되지 않음)">
    <fieldset className="help-method-choices"><legend>구현 방법 선택</legend>{methods.map(item=><label key={item.label}><input type="checkbox" className="cx-checkbox" checked={selected.includes(item.label)} onChange={()=>setSelected(current=>current.includes(item.label)?current.filter(label=>label!==item.label):[...current,item.label])}/><span>{item.label} {item.weight}%</span></label>)}</fieldset>
    <div className="help-rate-formula"><label><span>카드 가중치 (%)</span><input className="text-input" type="number" min="0" max="100" step="any" inputMode="decimal" value={card} aria-invalid={card.trim() === '' || Number(card) < 0 || Number(card) > 100 || undefined} onChange={event => setCard(event.target.value)}/></label><span>×</span><div className="help-rate-value"><span>최고 구현 가중치</span><strong>{percent(method)}</strong></div><span>=</span><div className="help-rate-value"><span>Action 1</span><strong>{percent(action)}</strong></div></div>
    {!valid && <p className="help-input-error" role="alert">카드 가중치에 0~100을 입력하고 구현 방법을 하나 이상 선택하세요.</p>}
    <div className="help-rate-second"><strong>Action 2</strong><label><span className="visually-hidden">예시 Action 2 자동화 가능 여부</span><CxSelect className="native-select" value={possible ? 'possible' : 'impossible'} onChange={event => setPossible(event.target.value === 'possible')}><option value="impossible">자동화 불가능</option><option value="possible">자동화 가능</option></CxSelect></label><strong>{percent(second)}</strong></div>
    <div className="help-rate-result" role="status"><span>Task 자동화율</span><span>({percent(action)} + {percent(second)}) ÷ 2 = </span><strong>{percent(average)}</strong></div>
    <p className="help-example-caption"><span><HelpText text="로직 카드는 제외하고, 자동화 불가능한 Action은 0%로 평균에 포함합니다. 예시의 두 Action은 같은 가중치를 사용합니다."/></span></p>
  </Example>;
}
function AutomationExample() {
  return <><Example title="Activity 업로드 후 Task별 확인">
    <div className="help-flow-scope"><div><Icon name="upload" size={24}/><strong>Activity YAML</strong></div><Icon name="arrowRight" size={20}/><div className="help-flow-tasks"><span><Icon name="workflow" size={18}/><strong>Task A</strong><small>워크플로우 / 자동화율</small></span><span><Icon name="workflow" size={18}/><strong>Task B</strong><small>워크플로우 / 자동화율</small></span></div></div>
  </Example><Example title="자동화율 수정과 입력 방식">
    <div className="help-icon-key"><span><Icon name="pencil" size={18}/>자동화율 직접 수정</span><span><Icon name="user" size={18}/>수동 입력</span><span><Icon name="automation" size={18}/>자동 계산</span><span><Icon name="infoCircle" size={18}/>입력 방식 미기록</span></div>
    <p className="help-example-caption"><HelpText text="Task 옆 연필로 값을 입력하고 저장하세요. 관련 Action이나 가중치를 다시 저장하면 자동 계산값으로 갱신됩니다."/></p>
  </Example><RateExample/></>;
}
function SettingsExample() {
  const rows = [['workflow','표준 프로세스','Process → Activity → Task'],['organization','부서','사업부 → 팀 → 그룹'],['organization','담당 부서','표준 프로세스와 부서 연결'],['taskList','필드 속성','적용유형, 배포여부, 예상 수행빈도 등'],['percent','자동화율 산정','Task별 워크플로우와 자동화율'],['sliders','자동화율 속성','Action 카드 종류, 구현 방법, 가중치'],['clock','고도화 대상 속성','효과성 최소 시간 (분/월)']];
  return <><Example title="표 헤더와 행 아이콘 예시">
    <div className="help-example-table-wrap"><table className="help-example-table help-settings-table"><thead><tr><th scope="col" className="help-usage-column"><span className="visually-hidden">사용 여부</span></th><th scope="col"><span className="help-settings-heading">예상 수행빈도 <small>6</small></span></th><th scope="col">월 환산횟수</th><th scope="col"><span className="help-sample-add"><Icon name="plus" size={18}/><span className="visually-hidden">추가</span></span></th></tr></thead><tbody><tr><td className="help-usage-column"><span className="help-sample-check is-checked"><Icon name="check" size={13}/><span className="visually-hidden">사용</span></span></td><td>5회 미만</td><td>3.0</td><td><span className="help-sample-row-end"><Icon name="pencil" size={18}/><Icon name="trash" size={18}/></span></td></tr></tbody></table></div>
    <div className="help-icon-key">{[['plus','추가'],['pencil','수정'],['trash','삭제']].map(([icon,label])=><span key={icon}><Icon name={icon} size={18}/>{label}</span>)}<span><span className="help-sample-check is-checked"><Icon name="check" size={13}/></span>사용</span></div>
  </Example><Example title="어디에서 관리하나요?">
    <dl className="help-settings-map">{rows.map(([icon,title,description]) => <div key={title}><dt><Icon name={icon} size={18}/>{title}</dt><dd>{description}</dd></div>)}</dl>
  </Example></>;
}
function SupportExample() {
  return <Example title="목록에서 작성과 답변까지">
    <dl className="help-support-actions">
      <div><dt><SampleControl icon="pencil" iconOnly>문의하기</SampleControl></dt><dd>제목, 유형과 본문을 작성합니다.</dd></div>
      <div><dt><SampleControl icon="user" iconOnly>내 문의</SampleControl></dt><dd>내가 접수한 문의만 표시합니다.</dd></div>
      <div><dt><SampleControl icon="panelLeftClose" iconOnly>문의 내역 접기</SampleControl></dt><dd>목록을 접어 본문을 넓힙니다. 같은 자리에서 다시 펼칩니다.</dd></div>
      <div><dt><SampleControl icon="user">담당자 선택</SampleControl></dt><dd>담당자를 선택하고 접수하면 함께 배정됩니다.</dd></div>
      <div><dt><SampleControl icon="undo" iconOnly>답글</SampleControl></dt><dd>원답변 작성자를 언급해 답글을 남깁니다.</dd></div>
      <div><dt><SampleControl icon="users" iconOnly>담당자 배정</SampleControl></dt><dd>관리자는 문의 상세에서 담당자를 추가합니다.</dd></div><div><dt><SampleControl icon="linkExternal" iconOnly>GitHub에서 보기</SampleControl></dt><dd>GitHub에서 담당자를 해제하거나 처리 상태를 바꿉니다.</dd></div>
      <div><dt><SampleControl>접수 확인</SampleControl></dt><dd>결과가 불명확할 때 등록 여부만 확인합니다.</dd></div>
    </dl>
  </Example>;
}
function HistoryExample({user}) {
  return <Example>
    <div className="help-history-top"><span>최종 변경일 <strong>2026. 9. 10.</strong></span><SampleControl icon="clockRewind" iconOnly>변경 이력</SampleControl></div>
    <div className="help-history-tabs" aria-label="이력 구분 예시"><strong>전체</strong><span>E2E Agent 현황</span><span>기준 설정</span></div>
    <div className="help-history-size"><SampleControl icon="search">커밋 ID, 수정자, 변경 제목</SampleControl><SampleControl icon="calendar">변경 기간</SampleControl></div>
    <div className="help-history-person"><ExampleProfile user={user} showLogin/><span>저장 시각 <code>a1b2c3</code></span><Icon name="chevronUp" size={18}/></div>
    <div className="help-example-table-wrap"><table className="help-example-table"><caption className="help-history-target">Task 이름</caption><thead><tr>{['항목','변경 전','변경 후'].map(text => <th scope="col" key={text}>{text}</th>)}</tr></thead><tbody><tr><th scope="row">배포여부</th><td>미배포</td><td className="help-changed-value">배포</td></tr></tbody></table></div>
    <div className="help-history-pagination" aria-label="페이지 이동 예시"><Icon name="chevronLeft" size={16}/><strong>1</strong><span>2</span><span>3</span><Icon name="chevronRight" size={16}/></div>
  </Example>;
}
function AccountExample({user}) {
  return <><Example title="로그인 순서">
    <div className="help-device-example"><Icon name="githubMark" size={24}/><div><span>GitHub 인증 코드 예시</span><strong>ABCD-EFGH</strong></div><Icon name="copy01" size={18}/><SampleControl icon="linkExternal">인증 페이지 열기</SampleControl></div>
  </Example><Example title="프로필 구성 예시">
    <div className="help-account-preview"><ExampleProfile user={user} showLogin fallbackName="사용자 이름"/><span className="help-account-role">현재 역할</span><p>GitHub에 등록한 소개</p><dl><div><dt>이메일</dt><dd>조회 가능한 주소</dd></div><div><dt>소속</dt><dd>GitHub 프로필의 소속 정보</dd></div><div><dt>위치와 링크</dt><dd>위치, 웹사이트, 소셜 계정</dd></div></dl><span className="help-account-link">GitHub 프로필 수정<Icon name="linkExternal" size={14}/></span></div>
    <p className="help-example-caption"><HelpText text="작성자나 @아이디에 마우스를 올리면 공개 이메일과 소개가 보입니다. 누르면 오른쪽에 상세 프로필이 열립니다."/></p>
  </Example></>;
}

function TalkExample() {
  return <><Example title="게시글과 피드 보기"><div className="help-edit-sequence"><div><span className="help-highlight-icon"><Icon name="list" size={20}/></span><strong>게시글 보기</strong><small>제목과 본문 요약 중심</small></div><div><span className="help-highlight-icon"><Icon name="feed" size={20}/></span><strong>피드 보기</strong><small>이미지와 카드 중심</small></div></div><p className="help-example-caption">검색창 오른쪽에서 바꾸세요. 두 보기에서 같은 글과 반응을 확인합니다.</p></Example><Example title="E2E Talk와 문의의 공통 에디터">
    <div className="help-editor-tools">{[['bold','굵게'],['list','목록'],['table','표'],['code','코드 블록'],['image','이미지 업로드'],['moreHorizontal','서식 더 보기']].map(([icon,label])=><SampleControl key={icon} icon={icon} iconOnly>{label}</SampleControl>)}</div>
    <div className="help-editor-preview"><span className="help-editor-title">함께 나누는 Agent 경험</span><p><span className="help-mention-example">@github-id</span>에게 의견을 물어보세요.</p><div className="help-code-example"><span>Python</span><code>print("Hello, Agent")</code></div></div>
    <p className="help-example-caption"><HelpText text="이미지는 본문에 붙여넣거나 이미지 아이콘으로 추가하세요. 등록 전에는 미리보기로 확인하세요."/></p>
  </Example></>;
}

function AdminExample() {
  return <><Example title="사용자 목록에서 팀 수정">
    <div className="help-example-actionbar"><span className="help-sample-search"><Icon name="search" size={16}/>사용자 검색</span></div>
    <div className="help-example-table-wrap"><table className="help-example-table"><thead><tr><th scope="col"><span className="help-sample-check"/><span className="visually-hidden">선택</span></th><th scope="col">이름</th><th scope="col">아이디</th><th scope="col">권한</th><th scope="col"><SampleControl icon="plus" iconOnly>사용자 추가</SampleControl></th></tr></thead><tbody><tr><td><span className="help-sample-check"/></td><td><ExampleProfile fallbackName="사용자 이름"/></td><td>github-id</td><td>E2E 사용자</td><td><span className="help-sample-row-end"><Icon name="pencil" size={18}/></span></td></tr></tbody></table></div>
    <p className="help-example-caption"><HelpText text="행 오른쪽 연필을 누르고 팀을 선택해 저장하세요. 새 사용자는 표 오른쪽 위 +로 추가하세요." emphasizeFirst/></p>
  </Example><Example title="역할별 이용 범위"><table className="help-example-table help-role-table"><thead><tr><th scope="col">역할</th><th scope="col">이용 범위</th></tr></thead><tbody>
    <tr><th scope="row">E2E 사용자</th><td>현황 조회, Talk와 문의 작성</td></tr><tr><th scope="row">E2E 관리자</th><td>사용자 기능과 현황 수정</td></tr><tr><th scope="row">시스템 관리자</th><td>기준 설정과 관리자 설정을 포함한 모든 메뉴</td></tr>
  </tbody></table><p className="help-example-caption">역할은 GHES 팀과 저장소 권한으로 정해집니다.</p></Example></>;
}

function NotificationExample({user}) {
  return <Example title="알림 표시 예시">
    <div className="help-example-actionbar"><SampleControl icon="bell" iconOnly>알림</SampleControl><span>새 알림부터 확인</span></div>
    <div className="help-notification-example">
      <ExampleProfile user={user} showLogin fallbackName="등록자 이름"/>
      <strong>문의에 변경이 있습니다.</strong>
      <span>화면을 새로고침해도 변경 값이 보이지 않아요</span>
      <small>2시간 전</small>
    </div>
    <p className="help-example-caption">알림 창을 열면 숫자는 사라지고 목록은 유지됩니다. 문의는 GitHub 이슈, E2E Talk는 해당 글로 연결됩니다.</p>
  </Example>;
}

export default function HelpPanel({onClose, initialTopic = 'find', user}) {
  const [active, setActive] = useState(HELP_TOPICS.some(topic => topic.id === initialTopic) ? initialTopic : 'find');
  const [query, setQuery] = useState(''), [expanded, setExpanded] = useState(null);
  const [jump, setJump] = useState(null);
  const id = useId(), article = useRef(null), content = useRef(null), navigation = useRef(null), searchInput = useRef(null), questionRefs = useRef({});
  const topic = HELP_TOPICS.find(item => item.id === active), searching = Boolean(query.trim());
  useEffect(() => {
    if (window.matchMedia('(max-width:700px)').matches) navigation.current?.querySelector('[aria-current="page"]')?.scrollIntoView({block:'nearest',inline:'nearest'});
  }, [active, searching]);
  const results = searchHelp(query);
  const clearSearch = () => { setQuery(''); searchInput.current?.focus(); };
  useLayoutEffect(() => {
    if (!jump) return;
    const target = jump.question ? questionRefs.current[jump.question] : article.current;
    if (jump.question) target?.scrollIntoView({block:'start'});
    else content.current?.scrollTo({top:0});
    if (jump.focus) target?.focus({preventScroll:true});
  }, [jump]);
  const choose = (next, question, focus = false) => {
    setActive(next); setExpanded(question || null); setQuery('');
    setJump({question,focus});
  };
  const illustrations = {find: <FindExample onEnhancementHelp={()=>choose('find','enhancement-order',true)}/>, talk:<TalkExample/>, edit: <EditExample/>, automation: <AutomationExample/>, settings: <SettingsExample/>, history: <HistoryExample user={user}/>, account: <AccountExample user={user}/>, support: <SupportExample/>, notifications: <NotificationExample user={user}/>, admin:<AdminExample/>};
  const related={talk:[['account',null,'작성자 프로필'],['notifications','notification-missing','알림과 이메일 확인']],support:[['talk','talk-editor','에디터 사용'],['notifications','notification-missing','알림과 이메일 확인']],account:[['admin',null,'역할과 권한 관리']],admin:[['support','support-assignee','문의 담당자 배정']]}[active]||[];
  return <DetailPanel title="도움말" className="help-panel" variant="drawer" hideHelp footer={false} onClose={onClose}>
    <div className="help-search-bar"><SearchField className="help-search" ref={searchInput} label="도움말 검색" placeholder="예: 저장, YAML, 가중치" value={query} onChange={setQuery} clearLabel="도움말 검색 지우기"/></div>
    <div className="help-layout"><nav ref={navigation} className="help-navigation" aria-label="도움말 주제">{HELP_TOPICS.map(item => <button key={item.id} type="button" className={item.id === active && !searching ? 'is-active' : ''} aria-current={item.id === active && !searching ? 'page' : undefined} onClick={() => choose(item.id, null, true)}><Icon name={item.icon} size={19}/><span>{item.title}</span></button>)}</nav>
      <div ref={content} className="help-content">
        {searching ? <section aria-label="도움말 검색 결과"><h3 className="help-results-title" role="status">검색 결과 {results.length}개</h3>{results.length ? <ul className="help-search-results">{results.map(result => <li key={`${result.topic}/${result.question || 'guide'}`}><button type="button" onClick={() => choose(result.topic, result.question, true)}><span className="help-result-topic">{HELP_TOPICS.find(item => item.id === result.topic).title}</span><strong>{result.title}<Icon name="chevronRight" size={18}/></strong><span><HelpText text={helpSentences(result.excerpt)[0]}/></span></button></li>)}</ul> : <div className="help-no-results"><Icon name="search" size={28}/><p>일치하는 안내가 없습니다.</p><span>짧은 단어로 다시 검색하거나 주제를 선택하세요.</span><button type="button" className="cx-button" onClick={clearSearch}>검색 지우기</button></div>}</section> : <article key={active} aria-labelledby={`${id}-topic`}>
          {(topic.path.length!==1||topic.path[0]!==topic.title)&&<div className="help-location">{topic.path.map((part,index) => <React.Fragment key={part}>{index > 0 && <Icon name="chevronRight" size={13}/>}<span>{part}</span></React.Fragment>)}</div>}
          <h3 ref={article} tabIndex={-1} id={`${id}-topic`} className="help-topic-title">{topic.title}</h3>
          <p className="help-topic-lead">{topic.lead}</p>
          <ol className="help-instructions">{topic.steps.map(([,title,description],index) => <li key={title}><span className="help-step-number">{index + 1}</span><div><h4>{title}</h4><p><HelpText text={description}/></p></div></li>)}</ol>
          {illustrations[active]}
          {related.length>0&&<nav className="help-related" aria-label="관련 도움말">{related.map(([next,question,label])=><button type="button" key={`${next}/${question}`} onClick={()=>choose(next,question,true)}>{label}<Icon name="chevronRight" size={16}/></button>)}</nav>}
          <section className="help-questions" aria-labelledby={`${id}-questions`}><h4 id={`${id}-questions`}>이럴 때는</h4>{topic.questions.map(([key,title,answer]) => <div className="help-question" key={key}><button ref={element => {questionRefs.current[key] = element;}} type="button" aria-expanded={expanded === key} aria-controls={expanded === key ? `${id}-${key}` : undefined} onClick={() => setExpanded(expanded === key ? null : key)}><span>{title}</span><Icon name={expanded === key ? 'chevronUp' : 'chevronDown'} size={18}/></button>{expanded === key && (key === "enhancement-order" ? <div id={`${id}-${key}`} className="help-enhancement-answer"><EnhancementGuide/></div> : <p id={`${id}-${key}`}><HelpText text={answer} emphasizeFirst/></p>)}</div>)}</section>
        </article>}
      </div>
    </div>
  </DetailPanel>;
}

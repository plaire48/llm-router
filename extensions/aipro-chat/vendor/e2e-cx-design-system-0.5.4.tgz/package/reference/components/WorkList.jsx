import {CxSelect} from './CxSelect';
import { CommitReference } from './CommitReference';
import {SearchField} from './SearchField';
import { ActionButton, ActionLink } from './ActionButton';
import { HelpButton } from './HelpButton';
import {ColumnVisibilityMenu} from './ColumnVisibilityMenu';
import {GithubAvatar} from './AccountProfile';
import { TableEditModeButton } from './TableEditModeButton';
import {useFeedback} from './Toast';
import { SelectionApplyConfirmation } from './SelectionApplyConfirmation';
import React, { useEffect, useRef, useState } from 'react';
import { AutomationRateSource } from './AutomationRateSource';
import { WorkLongTextInput, WorkLongTextPreview } from './WorkLongText';
import { CxTabs } from './CxTabs';
import { Icon } from './Icon';
import { EmptyState } from './EmptyState';
import { DetailPanel } from './DetailPanel';
import { SortHeader, SelectionCheckbox, useRowSelection } from './WorkspaceLayout';
import { ActiveColumnFilters, ControlledTable, PageSizeSelect, TableControlsContext, TablePagination, useColumnControls, usePagination } from './TableControls';
import { TableViewport, useWorkspaceState } from './WorkspaceMemory';
import { downloadReportCsv, sortReportRows } from './reportInteractions';
import { WORK_FIELDS, WORK_VIEWS, visibleWorkFields, changedWorkFields, sameWorkValue, workFieldValue, workFieldNumber, workTextLength, workFieldEnabled } from './workListModel';
import { useWorkList } from './WorkListState';
import { averageAutomationRate, formatAutomationRate } from './automationRate';
import './column-pinning.css';

function FieldControl({ row, field, catalogs, onChange, onCommit, onExpand, prefix = '' }) {
  const value=row[field.key] ?? '';
  const beforeInput=useRef(value);
  const label=`${prefix}${field.label}`;
  const {status,saving,loading,loadError,isEditor}=useWorkList();
  const enabled=workFieldEnabled(row,field);
  const disabled=saving||loading||loadError||!isEditor||!enabled;
  const hint=!enabled?(field.key==='appliedStatusDetail'?'미배포일 때 입력할 수 있습니다.':'적용 효과가 하일 때 입력할 수 있습니다.'):undefined;
  if(field.key==='lastModifiedCommit')return <CommitReference sha={row.lastModifiedCommit} url={row.lastModifiedCommitUrl}/>;
  if(field.readOnly) return <span className="list-derived-value list-cell-value">{field.key==='lastModifiedBy'&&row.lastModifiedBy&&<GithubAvatar user={row.lastModifiedBy} size="sm"/>}<span>{workFieldValue(row,field,catalogs)||'—'}</span></span>;
  const invalid=field.required&&!String(value).trim()&&status.includes('입력하세요');
  if(field.catalog) {
    const entries=(catalogs[field.catalog]?.items||[]).filter(item=>item.active!==false || item.id===value).sort((a,b)=>(a.sortOrder||0)-(b.sortOrder||0));
    return <CxSelect disabled={disabled} className="native-select list-cell-input" aria-label={label} value={value} onChange={event=>{onChange(field.key,event.target.value);if(!sameWorkValue(value,event.target.value))onCommit?.(field,event.target.value);}}><option value="">선택 안 함</option>{value&&!entries.some(item=>item.id===value)&&<option value={value}>{workFieldValue(row,field,catalogs)} (기존 값)</option>}{entries.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect>;
  }
  const Input=field.multiline?WorkLongTextInput:'input';
  return <Input {...(field.multiline?{field,label,onExpand}:{})} disabled={disabled} title={hint} className="text-input list-cell-input" aria-label={label} aria-invalid={invalid||undefined} value={value} required={field.required} onFocus={()=>{beforeInput.current=value;}} onChange={event=>onChange(field.key,event.target.value)} onBlur={event=>{const next=event.target.value;if(!sameWorkValue(beforeInput.current,next)&&(!field.maxLength||workTextLength(next)<=field.maxLength)){beforeInput.current=next;onCommit?.(field,next);}}} onKeyDown={event=>{if(event.key==='Enter'&&!field.multiline&&!event.nativeEvent.isComposing&&!event.ctrlKey&&!event.metaKey){event.preventDefault();event.currentTarget.blur();}}}/>;
}

export function WorkList() {
  const state=useWorkList();
  const {rows,catalogs,editing,saving,loading,editAll,bulkDrafts}=state;
  const [search,setSearch]=useWorkspaceState('worklist.search','');
  const [preset,setPreset]=useWorkspaceState('worklist.preset','all');
  const [pinnedCounts,setPinnedCounts]=useWorkspaceState('worklist.pinnedCounts',{});
  const [,setPinNotice]=useFeedback();
  const [,setPinError]=useFeedback();
  const [pinLimit,setPinLimit]=useState(Infinity);
  const [sort,setSort]=useWorkspaceState('worklist.sort',{key:'',direction:'asc'});
  const [onlyChanged,setOnlyChanged]=useWorkspaceState('worklist.onlyChanged',false);
  const [detailId,setDetailId]=useState(null);
  const [detailFocus,setDetailFocus]=useState(null);
  const openLongText=(id,field)=>{setDetailId(id);setDetailFocus({field});};
  const [selectionChange,setSelectionChange]=useState(null);
  const editInput=useRef(null);
  const previousEditing=useRef(null);
  const presets=WORK_VIEWS;
  const [hiddenViews,setHiddenViews]=useWorkspaceState('worklist.hiddenColumns',{});
  const presetFields=visibleWorkFields(preset);
  const requestedHidden=(hiddenViews[preset]||[]).filter(key=>presetFields.some(field=>field.key===key));
  const hidden=presetFields.some(field=>!requestedHidden.includes(field.key))?requestedHidden:requestedHidden.filter(key=>key!=='task');
  const fields=presetFields.filter(field=>!hidden.includes(field.key));
  const detailViews=[...WORK_VIEWS.filter(view=>view.key!=='all'&&(preset==='all'||view.key===preset)),{key:'audit',label:'최근 수정'}];
  const columns=WORK_FIELDS.map(field=>({...field,value:row=>workFieldValue(row,field,catalogs),hidden:!fields.includes(field)}));
  const pinnedCount=Math.min(pinnedCounts[preset]||0,fields.length,pinLimit);
  const activePinned=fields.slice(0,pinnedCount).map(field=>field.key);
  const selectColumns=next=>{
    const nextFields=presetFields.filter(field=>!next.includes(field.key));
    if(!nextFields.length)return;
    let keptPinned=0;
    for(const field of nextFields){if(!activePinned.includes(field.key))break;keptPinned++;}
    setHiddenViews(current=>({...current,[preset]:next}));
    setPinnedCounts(current=>({...current,[preset]:keptPinned}));
  };
  const togglePin=key=>{
    const index=fields.findIndex(field=>field.key===key),label=fields[index].label;
    if(index>pinnedCount){setPinError(`먼저 ${fields[pinnedCount].label} 열을 고정하세요.`);setPinNotice('');return;}
    if(index===pinnedCount&&index>=pinLimit){setPinError(`현재 화면에서는 ${pinLimit}개 열까지 고정할 수 있습니다. 더 고정하려면 창을 넓혀 주세요.`);setPinNotice('');return;}
    setPinnedCounts(current=>({...current,[preset]:index<pinnedCount?index:index+1}));
    setPinError('');
    setPinNotice(index<pinnedCount?`${label}부터 오른쪽 열의 고정을 해제했습니다.`:`${label}까지 ${index+1}개 열을 고정했습니다.`);
  };
  const candidates=rows.filter(row=>(!onlyChanged||state.dirtyRows.some(item=>item.id===row.id))&&(!search||WORK_FIELDS.some(field=>workFieldValue(row,field,catalogs).toLowerCase().includes(search.toLowerCase()))));
  const controls=useColumnControls('worklist','items',columns,candidates);
  const output=sortReportRows(controls.rows,sort,(row,key)=>{const field=WORK_FIELDS.find(field=>field.key===key);return field?.numeric?workFieldNumber(row,field,catalogs):workFieldValue(row,field,catalogs);});
  const averageRate=averageAutomationRate(output);
  const hierarchyCounts=[
    {label:'Process',count:new Set(output.map(row=>row.process).filter(Boolean)).size},
    {label:'Activity',count:new Set(output.filter(row=>row.activity).map(row=>JSON.stringify([row.process,row.activity]))).size},
    {label:'Task',count:output.length},
  ];
  const scope=JSON.stringify([search,onlyChanged,controls.filters]);
  const pagination=usePagination('worklist',output,JSON.stringify([scope,sort]));
  const selection=useRowSelection(output,scope);
  const offerSelectionApply=(rowId,field,value)=>{
    if(selection.ids.size>1&&selection.ids.has(rowId)){
      const ids=[...selection.ids].filter(id=>workFieldEnabled(editing?.id===id?editing.draft:bulkDrafts[id]||rows.find(row=>row.id===id),field));
      if(ids.length>1)setSelectionChange({ids,skipped:selection.ids.size-ids.length,field,value:String(value??'').trim()||null});
    }
  };
  const selectedOnPage=pagination.rows.filter(row=>selection.ids.has(row.id)).length;
  const details=bulkDrafts[detailId]||rows.find(row=>row.id===detailId);
  const download=(selected)=>{const exportRows=selected?output.filter(row=>selection.ids.has(row.id)):output;const exportColumns=WORK_FIELDS.map(field=>columns.find(column=>column.key===field.key));downloadReportCsv(exportRows,exportColumns,'E2E_Agent_현황_'+(selected?'선택':'조회'));};
  const reset=()=>{setSearch('');setOnlyChanged(false);controls.clearFilters();};
  useEffect(()=>{
    if(editing) {
      const target=detailId?document.querySelector('.cx-detail-panel .list-cell-input'):editInput.current?.querySelector('.list-cell-input');
      target?.focus({preventScroll:true});
    } else if(previousEditing.current) {
      const target=detailId?document.querySelector('.cx-panel-footer button:last-child'):document.querySelector(`[data-row-id="${CSS.escape(previousEditing.current)}"] .list-row-actions button`) || document.getElementById('work-list-title');
      target?.focus({preventScroll:true});
    }
    previousEditing.current=editing?.id||null;
  },[editing?.id,preset,detailId]);
  useEffect(()=>{
    if(!detailId||!detailFocus)return;
    const frame=requestAnimationFrame(()=>{
      const field=document.querySelector(`.list-detail-section [data-detail-field="${detailFocus.field}"]`);
      field?.scrollIntoView({block:'start'});
      (field?.querySelector('textarea')||field)?.focus({preventScroll:true});
    });
    return()=>cancelAnimationFrame(frame);
  },[detailId,detailFocus]);
  const editingElsewhere=editing&&!pagination.rows.some(row=>row.id===editing.id);
  const closeDetails=async()=>{if(editing?.id===detailId&&!await state.cancel({kind:'close'}))return;setDetailId(null);setDetailFocus(null);};
  const beginDetailEdit=async row=>{
    await state.begin(row);
    if(!state.isEditor)requestAnimationFrame(()=>{
      const panel=document.querySelector('.agent-detail-panel');
      panel?.querySelector('.cx-panel-body')?.scrollTo({top:0});
      panel?.querySelector('.list-edit-notice a')?.focus({preventScroll:true});
    });
  };
  return <TableControlsContext.Provider value={controls}><div className="work-list-workspace">

    <section className="work-list-card" aria-labelledby="work-list-title" aria-busy={loading||saving}>
      <header className="list-action-header"><div className="list-heading-row"><div className="list-heading-group"><div className="list-heading"><Icon name="agent" size={24}/><h1 id="work-list-title" tabIndex={-1}>E2E Agent 현황</h1><HelpButton initialTopic={editAll||editing?'edit':'find'}/></div><div className="list-result-meta"><dl className="list-hierarchy-counts" aria-label="조회 결과 개수">{hierarchyCounts.map(item=><div key={item.label}><dt>{item.label}</dt><dd>{item.count.toLocaleString('ko-KR')}</dd></div>)}</dl><dl className="list-average-rate" title="조회된 Agent 중 자동화율이 있는 값의 평균입니다."><dt>자동화율</dt><dd aria-live="polite">{averageRate===null?'—':formatAutomationRate(averageRate)}</dd></dl><PageSizeSelect pagination={pagination}/></div></div></div>

      <div className="list-toolbar-layout" role="group" aria-label="Agent 목록 작업"><div className="list-table-actions"><div className="list-view-row"><CxTabs className="list-column-presets" items={presets} active={preset} onChange={value=>{setPreset(value);setPinError('');setPinNotice('');}} label="표시할 열" idPrefix="list-tab" panelId="list-view-panel"/>{(state.dirtyRows.length>0||onlyChanged)&&<label className="list-changed-filter"><input type="checkbox" className="cx-checkbox" checked={onlyChanged} onChange={event=>setOnlyChanged(event.target.checked)}/>미저장 <span>{state.dirtyRows.length}</span></label>}</div>
      {selection.ids.size>0&&<div className="list-selection-bar is-selected"><div><ActionButton action="clearSelection" type="button" aria-label="선택 해제" onClick={selection.clear}/><strong>{selection.ids.size}건 선택</strong>{editAll&&selection.ids.size>1&&<span className="selection-edit-hint">한 셀을 변경해 일괄 적용</span>}</div><div><ActionButton action="download" label="선택 내보내기" type="button" onClick={()=>download(true)}/></div></div>}<div className="list-heading-actions"><div className="search-box table-toolbar-search"><SearchField label="Agent 검색" placeholder="Agent 또는 담당자 검색" value={search} onChange={setSearch}/></div></div></div><div className="list-save-actions"><div className="list-utility-actions"><ColumnVisibilityMenu fields={presetFields} hidden={hidden} onChange={selectColumns} view={preset}/><ActionButton action="download" type="button" onClick={()=>download(false)} disabled={!output.length} aria-label="목록 내보내기" title="전체 조회 결과 내보내기"/><ActionButton action="resetWidths" type="button" onClick={controls.resetWidths} disabled={!controls.hasCustomWidths} aria-label="열 너비 초기화" title={controls.hasCustomWidths?'열 너비를 기본값으로 되돌리기':'현재 기본 열 너비입니다.'}/></div>{state.isEditor&&<><div className="list-edit-actions"><ActionButton action="reset" type="button" onClick={state.reset} disabled={loading||saving||(!state.dirtyRows.length&&!editing&&!state.draftDirty)} title="마지막 저장 상태로 되돌리기"/><TableEditModeButton active={editAll} onChange={state.setEditAll} onEnter={state.beginAll} dirty={Boolean(state.dirtyRows.length||state.draftDirty)} onSave={state.save} onDiscard={state.discardChanges} disabled={loading||saving||state.loadError}/></div><ActionButton action="save" busy={saving} type="button" onClick={state.save} disabled={loading||saving||state.loadError||Boolean(selectionChange)}/></>}</div></div><ActiveColumnFilters controls={controls}/>
      {state.loginRequired&&!detailId&&<div className="list-edit-notice" role="status"><Icon name="logIn" size={18}/><span>수정하려면 로그인하세요.</span><ActionLink action="login" href="#login"/></div>}

      {editingElsewhere&&<div className="list-edit-notice">수정 중인 Agent가 현재 조회 범위 밖에 있습니다.<ActionButton action="edit" label="수정 계속하기" onClick={()=>setDetailId(editing.id)}/></div>}


    </header>
    <div id="list-view-panel" role="tabpanel" aria-labelledby={`list-tab-${preset}`}><TableViewport memoryKey="worklist.scroll" resetKey={pagination.page} className="list-table-viewport"><ControlledTable className="work-list-table" onPinLimitChange={setPinLimit} frozenColumns={activePinned.length?['__select',...activePinned]:[]} selection detail detailWidth={104}><caption className="visually-hidden">E2E Agent 현황: 배포 현황, 자동화 현황 및 고도화 현황</caption><thead><tr><th scope="col" className="selection-column" data-column="__select"><SelectionCheckbox label="현재 페이지 전체 선택" checked={pagination.rows.length>0&&selectedOnPage===pagination.rows.length} mixed={selectedOnPage>0&&selectedOnPage<pagination.rows.length} onChange={()=>selection.togglePage(pagination.rows)}/></th>{fields.map(field=><SortHeader key={field.key} field={field.key} label={field.label} sort={sort} onSort={setSort} pinned={activePinned.includes(field.key)} onPin={togglePin} pinHint={activePinned.includes(field.key)?`${field.label}부터 오른쪽 열 고정 해제`:field.key===fields[pinnedCount]?.key?`${field.label} 열 고정`:`먼저 ${fields[pinnedCount]?.label} 열을 고정하세요.`} className={field.numeric?'numeric':''}/>)}<th scope="col" data-column="__detail" className="list-row-actions"><span className="visually-hidden">수정 및 상세</span></th></tr></thead><tbody>{pagination.rows.map(row=>{
      const isEditing=editAll||editing?.id===row.id&&!detailId;
      const draft=editAll?(bulkDrafts[row.id]||row):editing?.draft;
      const changed=changedWorkFields(bulkDrafts[row.id]||row,state.baseline.get(row.id));
      return <tr key={row.id} data-row-id={row.id} className={`${selection.ids.has(row.id)?'is-selected':''} ${isEditing?'is-editing':''} ${changed.length?'has-changes':''}`} aria-selected={selection.ids.has(row.id)} ref={!editAll&&isEditing?editInput:null} onKeyDown={event=>{if(!isEditing||editAll)return;if(event.key==='Escape'){event.stopPropagation();event.preventDefault();state.cancel();}else if(event.key==='Enter'&&(event.metaKey||event.ctrlKey)){event.preventDefault();state.apply();}}}><td className="selection-column"><SelectionCheckbox label={`${row.task} 선택`} checked={selection.ids.has(row.id)} onChange={()=>selection.toggle(row.id)}/></td>{fields.map(field=>{
        const different=!field.readOnly&&(isEditing?!sameWorkValue(draft[field.key],state.baseline.get(row.id)?.[field.key]):changed.some(item=>item.key===field.key));
        const value=workFieldValue(row,field,catalogs);
        return <td key={field.key} data-field={field.key} data-column-pinned={activePinned.includes(field.key)||undefined} style={activePinned.includes(field.key)?{left:`var(--frozen-${field.key})`}:undefined} className={`${different?'is-changed':''} ${field.key==='task'?'task-cell':''} ${field.numeric?'numeric':''}`} title={field.multiline?undefined:different?`변경 전: ${workFieldValue(state.baseline.get(row.id)||{},field,catalogs)||'미입력'}`:value}>{isEditing?<FieldControl row={draft} field={field} catalogs={catalogs} onChange={editAll?(field,value)=>state.updateBulk(row.id,field,value):state.update} onCommit={(field,value)=>offerSelectionApply(row.id,field,value)} onExpand={field.multiline?()=>openLongText(row.id,field.key):undefined} prefix={`${row.task}: `}/>:field.multiline?<><WorkLongTextPreview value={value} label={`${row.task}: ${field.label}`} onOpen={()=>openLongText(row.id,field.key)}/>{different&&<span className="list-change-dot" aria-label="미저장 변경"/>}</>:<span className={`list-cell-value ${!value?'is-empty':''}`}>{field.key==='lastModifiedBy'&&row.lastModifiedBy&&<GithubAvatar user={row.lastModifiedBy} size="sm"/>}{['appliedStatus','diagnosisReviewStatus'].includes(field.key)&&value&&<i className={`list-status-dot status-${row[field.key]}`} aria-hidden="true"/>}<span className="list-value-text">{field.key==='lastModifiedCommit'?<CommitReference sha={row.lastModifiedCommit} url={row.lastModifiedCommitUrl}/>:value||'—'}</span>{field.key==='rate'&&<AutomationRateSource entry={state.automationRates[row.standardTaskId]||{rate:row.rate}} label={row.task}/>}{different&&<span className="list-change-dot" aria-label="미저장 변경"/>}</span>}</td>;
      })}<td className="list-row-actions">{editAll?<ActionButton action="detail" type="button" aria-label={`${row.task} 상세`} title="상세 보기" onClick={()=>setDetailId(row.id)}/>:isEditing?<><ActionButton action="complete" type="button" className="list-apply" aria-label={`${row.task} 수정 완료`} title="행 수정 완료" onClick={state.apply}/><ActionButton action="cancel" type="button" aria-label={`${row.task} 수정 취소`} title="행 수정 취소" onClick={state.cancel}/></>:<>{state.isEditor&&<ActionButton action="edit" type="button" aria-label={`${row.task} 수정`} title="이 행 수정" onClick={()=>state.begin(row)} disabled={saving||loading}/>}<ActionButton action="detail" type="button" aria-label={`${row.task} 상세`} title="상세 보기" onClick={()=>setDetailId(row.id)}/></>}</td></tr>;
    })}</tbody></ControlledTable>{!pagination.rows.length&&<EmptyState title="조건에 맞는 Agent가 없습니다." description="검색어나 필터를 바꾸세요."><ActionButton action="clearFilters" type="button" onClick={reset}/></EmptyState>}</TableViewport></div>
    <TablePagination pagination={pagination} selectedCount={selection.ids.size}/>

    </section>
    {selectionChange&&<SelectionApplyConfirmation change={selectionChange} onClose={()=>setSelectionChange(null)}/>}
    {details&&<DetailPanel helpTopic={editAll||editing?.id===details.id?"edit":"find"} className="agent-detail-panel" busy={saving} title="E2E Agent 상세" subtitle={details.task} onClose={closeDetails} footer={state.isEditor?<><span className="list-panel-mode">{editing?.id===details.id?'수정 중':state.dirtyRows.length?`미저장 ${state.dirtyRows.length}건`:''}</span>{editAll?null:editing?.id===details.id?<><ActionButton action="cancel" type="button" onClick={state.cancel}/><ActionButton action="complete" type="button" onClick={state.apply}/></>:<ActionButton action="edit" type="button" onClick={()=>beginDetailEdit(details)} disabled={saving||loading}/>}{state.isEditor&&<ActionButton action="save" busy={saving} type="button" onClick={state.save} disabled={saving||loading}/>}</>:null}>{state.loginRequired&&<div className="list-edit-notice" role="status"><Icon name="logIn" size={18}/><span>수정하려면 로그인하세요.</span><ActionLink action="login" href="#login"/></div>}{detailViews.map(({key:part,label:sectionLabel})=><section className="list-detail-section" key={part}><h3>{sectionLabel}</h3><div>{WORK_FIELDS.filter(field=>field.group===part).map(field=><label key={field.key} data-detail-field={field.key} className={field.multiline?'list-detail-long-field':undefined} tabIndex={field.multiline?-1:undefined}><span>{field.label}{field.required&&!field.readOnly&&(editAll||editing?.id===details.id)?' *':''}</span>{editAll||editing?.id===details.id?<FieldControl row={editAll?details:editing.draft} field={field} catalogs={catalogs} onChange={editAll?(field,value)=>state.updateBulk(details.id,field,value):state.update} onCommit={(field,value)=>offerSelectionApply(details.id,field,value)}/>:field.multiline?<span className="list-detail-long-text">{workFieldValue(details,field,catalogs)||'—'}</span>:<span className={field.key==='rate'?'rate-detail-value':field.key==='lastModifiedBy'?'list-cell-value':undefined}>{field.key==='lastModifiedBy'&&details.lastModifiedBy&&<GithubAvatar user={details.lastModifiedBy} size="sm"/>}<strong>{field.key==='lastModifiedCommit'?<CommitReference sha={details.lastModifiedCommit} url={details.lastModifiedCommitUrl}/>:workFieldValue(details,field,catalogs)||'—'}</strong>{field.key==='rate'&&<AutomationRateSource entry={state.automationRates[details.standardTaskId]||{rate:details.rate}} label={details.task}/>}</span>}</label>)}</div></section>)}</DetailPanel>}
  </div></TableControlsContext.Provider>;
}

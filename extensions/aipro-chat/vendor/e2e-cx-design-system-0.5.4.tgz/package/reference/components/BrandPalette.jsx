import React, { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';

const PRESETS = [['#1826ad', '시그니처 블루'], ['#087f72', '딥 틸'], ['#7140ad', '바이올렛'], ['#394451', '그라파이트']];
import { applyBrandTheme, readBrandColor } from './brandTheme';

export function BrandPalette({ theme }) {
  const [color, setColor] = useState(readBrandColor);
  const details = useRef(null);
  useEffect(() => { applyBrandTheme(color,theme); },[color,theme]);
  useEffect(() => {
    const close=(event)=>{if(details.current?.open&&!details.current.contains(event.target))details.current.open=false;};
    document.addEventListener('pointerdown',close);return()=>document.removeEventListener('pointerdown',close);
  },[]);
  return <details ref={details} className="brand-palette" onKeyDown={(event)=>{if(event.key==='Escape'){details.current.open=false;details.current.querySelector('summary').focus();}}}><summary aria-label="브랜드 색상 변경" title="브랜드 색상 변경"><Icon name="palette" size={18}/></summary><div className="brand-palette-panel"><strong>화면 색상</strong><div role="group" aria-label="색상 프리셋">{PRESETS.map(([value,label])=><button key={value} type="button" aria-label={label} aria-pressed={value===color} title={label} style={{background:value}} onClick={()=>setColor(value)}>{value===color&&<Icon name="check" size={17}/>}</button>)}</div><label>직접 선택<input type="color" aria-label="브랜드 색상 직접 선택" value={color} onChange={(event)=>setColor(event.target.value)}/><span>{color.toUpperCase()}</span></label><div className="brand-tone-preview" aria-hidden="true">{[50,100,200,300,400,500,600].map(step=><span key={step} style={{background:`var(--brand-${step})`}}/>)}</div></div></details>;
}

import React from 'react';
import {GithubAvatar} from './AccountProfile';
import {githubIdentityLabel} from './githubIdentity';
import './user-identity.css';

// A compact, shared person label for selection lists and selected recipients.
export function UserIdentity({user,chip=false}) {
 const name=user?.name?.trim(),login=user?.login||'';
 return <span className={`cx-person-identity${chip?' cx-person-chip':''}`} title={githubIdentityLabel(user)}><GithubAvatar user={user} size="sm"/><span className="cx-person-name">{name||login}</span>{name&&login&&<span className="cx-person-login">({login})</span>}</span>;
}

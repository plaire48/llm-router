import { ActionButton } from './ActionButton';
import {useFeedback} from './Toast';
import React, { useEffect, useRef, useState } from 'react';
import { BrandMark, Button } from './AppChrome';
import { Icon } from './Icon';
import { authorizeDevice } from './deviceFlow';
import { fetchGithubUser } from './githubIdentity';
import { GHES_CONFIG } from './config';
import './login.css';
import { applyProductTheme } from './brandTheme';
import { AppFooter } from './AppFooter';
import { HelpTrigger } from './HelpTrigger';

export function LoginScreen({ onView, onLogin, onHelp, authorize = authorizeDevice }) {
  useEffect(applyProductTheme, []);
  const [device, setDevice] = useState(null);
  const [copied, setCopied] = useState(false);
  const [,notify] = useFeedback();
  const [starting, setStarting] = useState(false);
  const attempt = useRef(null);
  useEffect(() => () => attempt.current?.abort(), []);
  const closeDevice = () => {
    attempt.current?.abort(); attempt.current = null;
    setStarting(false); setDevice(null); setCopied(false); notify('');
  };
  const startLogin = async () => {
    if(attempt.current) return;
    const controller = new AbortController();
    attempt.current = controller;
    setStarting(true); notify('');
    try {
      const result = await authorize({ host: GHES_CONFIG.host, clientId: GHES_CONFIG.clientId, scope: GHES_CONFIG.scope, signal: controller.signal, onDevice: setDevice, fetchUser: fetchGithubUser });
      if(controller.signal.aborted) return;
      localStorage.setItem('gh_host', GHES_CONFIG.host);
      localStorage.setItem('gh_owner', GHES_CONFIG.owner);
      localStorage.setItem('gh_repo', GHES_CONFIG.repo);
      localStorage.setItem('gh_token', result.token);
      localStorage.setItem('gh_user', JSON.stringify(result.profile));
      onLogin(result.profile);
    } catch(error) {
      if(error.name !== 'AbortError') notify(error.message || '사내 GitHub 로그인 서버에 연결하지 못했습니다.', true);
    } finally {
      if(attempt.current===controller) {attempt.current=null;setStarting(false);setDevice(null);}
    }
  };

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(device.code);
      setCopied(true); setTimeout(() => setCopied(false), 1600);
    } catch (_) { notify('코드를 복사하지 못했습니다. 코드를 직접 선택해 복사하세요.', true); }
  };

  return <div className="login-layout"><main className="login-page">
    <section className="login-window" aria-labelledby="login-title">
      {onHelp&&<HelpTrigger className="login-help" onClick={onHelp}/>}
      <div className="login-card">
        <header className="login-heading">
          <div className="login-mark"><BrandMark /></div>
          <h1 id="login-title">E2E Report</h1>
          <p className="login-subtitle">Agent 현황을 확인하고 관리하세요.</p>
        </header>
        <div className="login-actions">
          <Button variant="solid" color="primary" size="lg" className="block" onClick={startLogin} disabled={starting} aria-describedby="login-edit-note">
            {starting ? <span className="status-spinner" aria-hidden="true"/> : <Icon name="githubMark" size={20}/>}
            {starting ? device ? 'GitHub 인증 대기 중…' : '인증 코드 준비 중…' : '사내 GitHub 로그인'}
          </Button>
          <Button variant="outline" color="neutral" size="lg" className="block" onClick={onView} aria-label="E2E Agent 현황 바로가기">바로가기 <Icon name="arrowRight" size={20}/></Button>
        </div>
        <p id="login-edit-note" className="login-note">현황 수정 권한은 시스템 관리자에게 요청하세요.</p>
        {device && <section className="device-box" aria-labelledby="device-title">
          <h2 id="device-title">GitHub 인증</h2>
          <p>아래 코드를 인증 페이지에 입력하세요.</p>
          <div className="device-code-row"><strong aria-label="인증 코드">{device.code}</strong><ActionButton action="copy" success={copied} className="login-copy" onClick={copyCode} aria-label={copied ? '인증 코드 복사 완료' : '인증 코드 복사'} title={copied ? '복사 완료' : '코드 복사'}/></div>

          <a className="btn btn--solid btn--primary btn--lg block" href={device.uri} target="_blank" rel="noreferrer">인증 페이지 열기 <Icon name="linkExternal" size={20}/></a>
          <Button variant="ghost" color="neutral" size="md" className="block" onClick={closeDevice}>인증 취소</Button>
        </section>}

      </div>
    </section>
  </main><AppFooter page="로그인"/></div>;
}

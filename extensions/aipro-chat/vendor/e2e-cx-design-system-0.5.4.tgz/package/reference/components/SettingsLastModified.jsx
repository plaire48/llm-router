import React, { useEffect, useState } from 'react';
import { GithubAvatar } from './AccountProfile';
import { modificationDate, modificationName } from './workModification';
import { FIELD_OPTION_CATALOGS } from './workListModel';
import { STRUCTURE_DEFINITIONS } from './hierarchyModel';
import { PROCESS_ORGANIZATIONS } from './processOrganizations';
import { ENHANCEMENT_ATTRIBUTES } from './enhancementCriteria';
import { MASTER_PATH } from './master';
import { AUTOMATION_SETTINGS_PATH, usesSeparateAutomationFile } from './config';
import { stableJson } from './agentFlowModel';
import {CommitPreview} from './CommitPreview.jsx';

export function settingsPaths(key) {
  if(key==='enhancementAttributes')return [ENHANCEMENT_ATTRIBUTES.path];
  if(key==='workOptions')return FIELD_OPTION_CATALOGS.map(item=>item.path);
  if(['automationRates','automationScoring'].includes(key))return [usesSeparateAutomationFile()?AUTOMATION_SETTINGS_PATH:MASTER_PATH];
  return [...STRUCTURE_DEFINITIONS,PROCESS_ORGANIZATIONS,ENHANCEMENT_ATTRIBUTES].filter(item=>item.key===key).map(item=>item.path);
}

export function automationSectionChanged(key, revision) {
  return key==='automationScoring'
    ? stableJson(revision.currentAutomationScoring)!==stableJson(revision.previousAutomationScoring)
    : stableJson(revision.currentAutomationRates)!==stableJson(revision.previousAutomationRates);
}

export function SettingsLastModified({activeKey,state}) {
  const {history,catalogs}=state;
  const automated=['automationRates','automationScoring'].includes(activeKey);
  const [calculated,setCalculated]=useState(null),[loading,setLoading]=useState(false);
  const paths=settingsPaths(activeKey);
  const entries=history.items.filter(item=>item.paths?.some(path=>paths.includes(path)));
  useEffect(()=>{
    let active=true;
    setCalculated(null);setLoading(automated&&entries.length>0);
    if(automated)void (async()=>{
      try {for(const entry of entries){
        const revision=await history.revision(entry);
        if(!active)return;
        if(automationSectionChanged(activeKey,revision)){setCalculated({key:activeKey,entry});break;}
      }} catch { /* A failed read cannot establish a latest revision. */ }
      finally {if(active)setLoading(false);}
    })();
    return()=>{active=false;};
  },[activeKey,history.items,history.revision]);
  const documents=activeKey==='workOptions'?FIELD_OPTION_CATALOGS.map(item=>catalogs[item.key]):[catalogs[activeKey==='enhancementAttributes'?ENHANCEMENT_ATTRIBUTES.key:activeKey]];
  const fallback=documents.filter(doc=>doc?.updatedAt&&Number.isFinite(Date.parse(doc.updatedAt))).sort((a,b)=>Date.parse(b.updatedAt)-Date.parse(a.updatedAt))[0];
  const latest=automated?(calculated?.key===activeKey?calculated.entry:null):entries[0];
  const date=latest?.date||fallback?.updatedAt,author=latest?.author||fallback?.updatedBy;
  return <div className="settings-modified" aria-label="선택한 기준 설정의 최근 수정 정보" aria-busy={loading||history.loading}>
    <span className="settings-modified-date"><span>최근 수정일</span>{date?<time dateTime={date}>{modificationDate(date)}</time>:<span>{loading||history.loading?'조회 중…':'—'}</span>}</span>
    <span className="settings-modified-person" aria-label="최근 수정자">{author&&<GithubAvatar user={author} size="sm"/>}<strong>{modificationName(author)||author?.name||'—'}</strong></span>
    {latest?.sha&&<CommitPreview key={`${activeKey}:${latest.repositoryScope||''}:${latest.sha}`} entry={latest} history={history} catalogs={catalogs}/>}
  </div>;
}

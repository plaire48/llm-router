import {CxSelect} from './CxSelect';
import { ActionButton } from './ActionButton';
import {SearchField} from './SearchField';
import {useFeedback, ToastNotice} from './Toast';
import {SettingsGrid, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import React, {useEffect, useRef, useState} from 'react';
import {useWorkList} from './WorkListState';
import {DetailPanel} from './DetailPanel';
import {Icon} from './Icon';
import {MasterActionButton} from './MasterActionButton';
import {TableEditModeButton} from './TableEditModeButton';
import {confirmAction} from './confirmAction';
import {nodeIsActive, nodePath, orderedNodes} from './hierarchyModel';
import {PROCESS_LEVELS, ORGANIZATION_LEVELS, effectiveOrganization, organizationPath, orderedProcessNodes, updateAssignments} from './processOrganizations';
import './process-organizations.css';

export function ProcessOrganizationsWorkspace({onPendingChange}) {
  const state=useWorkList(),standard=state.catalogs.standardProcesses,organizations=state.catalogs.organizations,source=state.catalogs.processOrganizations;
  const [query,setQuery]=useState(''),[drafts,setDrafts]=useState({}),[editors,setEditors]=useState({}),[editAll,setEditAll]=useState(false);
  const pending=useRef(false),panel=useRef(null);
  const assigned=new Map(source.items.map(item=>[item.id,item.organizationId]));
  const changed=Object.keys(drafts).filter(id=>(drafts[id]||null)!==(assigned.get(id)||null)),dirty=changed.length>0;
  const unavailable=!state.canSettings||state.loading||state.loadError||state.saving;
  const displayDocument={...source,items:[...source.items.filter(item=>!Object.hasOwn(drafts,item.id)),...Object.entries(drafts).map(([id,organizationId])=>({id,organizationId}))]};
  const [,notify]=useFeedback([{label:'최신 기준 불러오기',onClick:()=>reload()}]);
  useEffect(()=>{setDrafts({});setEditors({});},[source]);
  useEffect(()=>{onPendingChange?.({dirty,saving:state.saving});},[dirty,state.saving,onPendingChange]);
  useBeforeUnload(dirty);
  const entries=orderedProcessNodes(standard,'task').map(node=>{
    const path=nodePath(standard.items,node.id),effective=effectiveOrganization(displayDocument,standard,node.id),organization=organizationPath(organizations,effective.organizationId);
    return {node,path,effective,organization};
  }).filter(item=>!query.trim()||[...item.path,...item.organization].some(node=>node.label.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())));
  const columns=PROCESS_LEVELS;
  const patch=(id,value)=>{setDrafts(current=>({...current,[id]:value}));notify('');};
  const begin=id=>{
    setEditors(current=>({...current,[id]:{value:drafts[id],hadDraft:Object.hasOwn(drafts,id)}}));
    requestAnimationFrame(()=>panel.current?.querySelector(`[data-assignment-id="${CSS.escape(id)}"] select`)?.focus());
  };
  const end=(id,cancel=false)=>{
    if(cancel)setDrafts(current=>{const next={...current};if(editors[id].hadDraft)next[id]=editors[id].value;else delete next[id];return next;});
    setEditors(current=>{const next={...current};delete next[id];return next;});
  };
  const discard=()=>{setDrafts({});setEditors({});};
  const reset=async()=>{
    if(dirty&&!await confirmAction({kind:'reset'}))return;
    discard();notify('마지막 저장 상태로 초기화했습니다.');
  };
  const save=async()=>{
    if(unavailable||pending.current)return false;
    if(!dirty){setDrafts({});setEditors({});notify('변경 사항이 없습니다.');return true;}
    pending.current=true;
    try {
      updateAssignments(source,drafts,standard,organizations);
      const result=await state.saveAssignments(drafts);if(!result)return false;
      setDrafts({});setEditors({});notify('저장했습니다.');return true;
    }catch(reason){notify(reason.message,true);return false;}
    finally{pending.current=false;}
  };
  const reload=async()=>{
    if(state.saving||!state.canSettings)return;
    if(dirty&&!await confirmAction({kind:'reload'}))return;
    try{await state.reloadAssignments();setDrafts({});setEditors({});notify('최신 기준을 불러왔습니다.');}catch(reason){notify(reason.message,true);}
  };
  const grid=useSettingsGrid({id:'settings.processOrganizations',interactive:true,editAll,paginate:true,label:'담당 부서',scope:query,rows:entries.map(item=>({...item,id:item.node.id,selectionLabel:item.node.label,originalOrganization:organizationPath(organizations,effectiveOrganization(source,standard,item.node.id).organizationId)})),columns:[
    ...columns.map(([key,label])=>({key,label,width:210,value:row=>row.path.find(node=>node.level===key)?.label||null})),
    ...ORGANIZATION_LEVELS.map(([key,label])=>({key,label,width:210,value:row=>row.organization.find(node=>node.level===key)?.label||null,filterValue:row=>row.originalOrganization.find(node=>node.level===key)?.label||null})),
  ]});
  const batch=useSettingsApply(grid,{disabled:unavailable});
  const changeOrganization=(row,key,value)=>{
    const index=ORGANIZATION_LEVELS.findIndex(([name])=>name===key),parent=index?row.organization.find(node=>node.level===ORGANIZATION_LEVELS[index-1][0]):null;
    patch(row.id,value||parent?.id||null);
    batch.offer({rowId:row.id,field:ORGANIZATION_LEVELS[index][1],value,display:value?organizationPath(organizations,value).map(node=>node.label).join(' / '):index?'선택 해제':'상위 연결 사용',apply:targets=>{
      setDrafts(current=>({...current,...Object.fromEntries(targets.map(target=>[target.id,value||(index?target.organization.find(node=>node.level===ORGANIZATION_LEVELS[index-1][0])?.id:null)||null]))}));notify('');
    }});
  };
  return <DetailPanel embedded hideHeading title="담당 부서" className="process-organizations-panel" busy={state.saving} footer={state.canSettings?<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" type="button" disabled={unavailable||!dirty&&!Object.keys(editors).length} onClick={reset}/><TableEditModeButton active={editAll} onChange={value=>{setEditAll(value);setEditors({});}} dirty={dirty} onSave={save} onDiscard={discard} disabled={unavailable}/><ActionButton action="save" busy={state.saving} type="button" disabled={unavailable} onClick={save}/></>:null}>

    {state.structureErrors.processOrganizations&&<ToastNotice error message={state.structureErrors.processOrganizations} actions={[{label:'최신 기준 불러오기',onClick:reload}]}/>}
    <div id="assignment-table-panel">
      <div ref={panel}><SettingsGrid grid={grid} className="assignment-table" rowProps={row=>({'data-assignment-id':row.id,className:changed.includes(row.id)?'has-changes':''})} renderCell={(row,key)=>{
        if(columns.some(([name])=>name===key))return row.path.find(item=>item.level===key)?.label||'—';
        const index=ORGANIZATION_LEVELS.findIndex(([name])=>name===key),label=ORGANIZATION_LEVELS[index][1],parent=index?row.organization.find(item=>item.level===ORGANIZATION_LEVELS[index-1][0]):null,value=row.organization.find(item=>item.level===key)?.id||'';
        const options=orderedNodes(organizations.items.filter(item=>item.level===key&&(!index||parent&&item.parentId===parent.id)&&nodeIsActive(organizations.items,item.id)));
        return editAll||editors[row.id]?<CxSelect className="native-select assignment-select" aria-label={`${row.node.label} ${label}`} value={value} disabled={unavailable||index>0&&!parent} onChange={event=>changeOrganization(row,key,event.target.value)}><option value="">{index?`${label} 선택`:row.node.parentId?'상위 연결 사용':'선택 안 함'}</option>{value&&!options.some(item=>item.id===value)&&<option value={value} disabled>{row.organization.find(item=>item.id===value)?.label} (기존 값)</option>}{options.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect>:row.organization.find(item=>item.level===key)?.label||'—';
      }} renderActions={row=>{
        const editing=editAll||Boolean(editors[row.id]),explicit=Object.hasOwn(drafts,row.id)?drafts[row.id]:assigned.get(row.id);
        return editing?<>{!editAll&&<><MasterActionButton action="complete" label={`${row.node.label} 연결`} disabled={unavailable} onClick={()=>end(row.id)}/><MasterActionButton action="cancel" label={`${row.node.label} 연결`} disabled={unavailable} onClick={()=>end(row.id,true)}/></>}{row.node.parentId&&<ActionButton action="inherit" type="button" aria-label={`${row.node.label} 상위 연결 사용`} title="상위 연결 사용" disabled={unavailable||!explicit} onClick={()=>{patch(row.id,null);batch.offer({rowId:row.id,field:'담당 부서',value:null,display:'상위 연결 사용',apply:targets=>setDrafts(current=>({...current,...Object.fromEntries(targets.map(item=>[item.id,null]))}))});}}/>}</>:state.canSettings?<MasterActionButton action="edit" label={`${row.node.label} 연결`} disabled={unavailable} onClick={()=>begin(row.id)}/>:null;
      }}><div className="search-box assignment-search"><SearchField label="담당 부서 연결 검색" placeholder="Task 또는 부서 검색" value={query} onChange={setQuery}/></div></SettingsGrid></div>{batch.dialog}
    </div>
  </DetailPanel>;
}

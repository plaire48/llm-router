import { SettingsLastModified } from './SettingsLastModified';
import { HelpButton } from './HelpButton';
import { confirmAction } from './confirmAction';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { CxTabs } from './CxTabs';
import { useWorkspaceState } from './WorkspaceMemory';
import { useWorkList } from './WorkListState';
import { FIELD_OPTION_CATALOGS, WORK_FIELDS } from './workListModel';
import { STRUCTURE_DEFINITIONS, structureDefinition } from './hierarchyModel';
import { HierarchyManager } from './HierarchyManager';
import { ScoringSettings } from './ScoringSettings';
import { AutomationRatesWorkspace } from './AutomationRatesWorkspace';
import { WorkOptionsModal } from './OptionManager';
import { ProcessOrganizationsWorkspace } from './ProcessOrganizationsWorkspace';
import { PROCESS_ORGANIZATIONS } from './processOrganizations';
import { EnhancementAttributesSettings } from './EnhancementAttributesSettings';

const choices = FIELD_OPTION_CATALOGS;
export const SETTINGS_SECTIONS = [...STRUCTURE_DEFINITIONS, PROCESS_ORGANIZATIONS, {key: 'workOptions', label: '필드 속성'}, {key: 'automationRates', label: '자동화율 산정'}, {key: 'automationScoring', label: '자동화율 속성'}, {key:'enhancementAttributes',label:'고도화 대상 속성'}];
export function MasterSettingsWorkspace({ isEditor, user, OptionEditor = WorkOptionsModal, onPendingChange }) {
  const state = useWorkList();
  const [activeKey, setActiveKey] = useWorkspaceState('settings.activeKey', SETTINGS_SECTIONS[0].key);
  const [busy, setBusy] = useState(false);
  const page = useRef(null);
  const pending = useRef({dirty: false, saving: false}), notify = useRef(onPendingChange);
  notify.current = onPendingChange;
  const reportPending = useCallback(value => {
    pending.current = value;
    setBusy(Boolean(value.saving));
    notify.current?.(value);
  }, []);
  useEffect(() => () => notify.current?.({dirty: false, saving: false}), []);
  const choose = async key => {
    if (key === activeKey) return true;
    if (pending.current.saving || state.saving) return false;
    if (pending.current.dirty && !await confirmAction({kind:'leave'})) return false;
    reportPending({dirty: false, saving: false});
    setActiveKey(key);
    requestAnimationFrame(() => {
      const offset = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cx-header-offset')) || 64;
      if (page.current?.getBoundingClientRect().top < offset) page.current.scrollIntoView({block: 'start', behavior: 'instant'});
    });
    return true;
  };
  const structure = structureDefinition(activeKey);
  const usedRows = [...state.rows, ...state.savedRows, ...(state.editing ? [state.editing.draft] : [])];
  const usedIds = Object.fromEntries(choices.map(({key}) => {
    const field = WORK_FIELDS.find(item => item.catalog === key);
    return [key, [...new Set((field?usedRows.map(row => row[field.key]).filter(Boolean):[]))]];
  }));
  return <section ref={page} className="master-settings-card" aria-labelledby="master-settings-title">
    <header className="workspace-header"><div className="workspace-heading"><h1 id="master-settings-title">기준 설정</h1><HelpButton initialTopic={['automationRates','automationScoring'].includes(activeKey)?'automation':'settings'}/></div><SettingsLastModified activeKey={activeKey} state={state}/></header>
    <CxTabs className="settings-tabs" items={SETTINGS_SECTIONS} active={activeKey} onChange={choose} label="기준 설정 항목" idPrefix="settings-tab" panelId="settings-view-panel" disabled={busy || state.saving}/>
    <div id="settings-view-panel" className="settings-tab-panel" role="tabpanel" aria-labelledby={`settings-tab-${activeKey}`}>
      {structure && <HierarchyManager key={activeKey} definition={structure} embedded onPendingChange={reportPending}/>}
      {activeKey === 'processOrganizations' && <ProcessOrganizationsWorkspace onPendingChange={reportPending}/>}
      {activeKey === 'workOptions' && <OptionEditor embedded definitions={choices} initialDocuments={state.catalogs} initialShas={state.catalogShas} usedIds={usedIds} usedRows={usedRows} referencesLoading={state.loading} referencesError={state.loadError} isEditor={isEditor&&state.canSettings} user={user} onSaved={state.updateCatalog} onLoaded={state.refreshCatalog} onPendingChange={reportPending}/>}
      {activeKey === 'automationScoring' && <ScoringSettings onPendingChange={reportPending}/>}
      {activeKey === 'automationRates' && <AutomationRatesWorkspace embedded onPendingChange={reportPending}/>}
      {activeKey === 'enhancementAttributes' && <EnhancementAttributesSettings onPendingChange={reportPending}/>}
    </div>
  </section>;
}

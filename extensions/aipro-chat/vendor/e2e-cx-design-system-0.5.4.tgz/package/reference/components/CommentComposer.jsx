import React,{useEffect,useRef,useState} from 'react';
import {MentionTextInput} from './MentionTextInput';
import {UserIdentity} from './UserIdentity';
import {ActionButton} from './ActionButton';
import {useBeforeUnload} from './useBeforeUnload';
import {notifyToast} from './Toast';
import {confirmAction} from './confirmAction';

export function CommentComposer({client,number,kind='talk',onSaved,onPending,replyTo,onCancelReply,editing=null,onCancelEdit,disabled=false}) {
  const [text,setText]=useState(editing?.body||''),[busy,setBusy]=useState(false),[uncertain,setUncertain]=useState(false);
  const id=useRef(crypto.randomUUID()),field=useRef(null),label=kind==='talk'?'댓글':'답변';
  const dirty=editing?text!==editing.body:Boolean(text.trim());
  useBeforeUnload(dirty||busy);
  useEffect(()=>{onPending({dirty,saving:busy,replyLocked:busy||uncertain||Boolean(editing),leaveMessage:uncertain?`반영 여부를 확인하지 못했습니다.\n${label} 목록을 확인한 뒤 다시 작성하세요.`:undefined});return()=>onPending({dirty:false,saving:false});},[dirty,busy,uncertain,editing,onPending,label]);
  useEffect(()=>{if(replyTo){field.current?.focus();field.current?.scrollIntoView({block:'nearest',behavior:'smooth'});}},[replyTo?.id]);
  useEffect(()=>{if(editing){field.current?.focus();field.current?.scrollIntoView({block:'nearest'});}},[editing?.id]);
  const submit=async event=>{
    event.preventDefault();if(busy||disabled||!text.trim())return;setBusy(true);
    try {
      const saved=editing?await client.updateComment(number,editing,text):kind==='talk'?await client.comment(number,{body:text,id:id.current,replyTo:replyTo?.id??null}):await client.comment(number,text,id.current,replyTo?.id??null);
      setText('');setUncertain(false);id.current=crypto.randomUUID();onCancelReply?.();onSaved(saved);notifyToast(`${label}을 ${editing?'수정':'등록'}했습니다.`,{source:`${kind}-comment`});
    } catch(error) {setUncertain(value=>value||Boolean(error.uncertain));notifyToast(error,{source:`${kind}-comment`,error:true});}
    finally {setBusy(false);}
  };
  return <form className={`talk-comment-form${kind==='inquiry'?' inquiry-reply':''}`} onSubmit={submit}>
    {editing&&<div className="comment-reply-target"><span>{label} 수정</span><ActionButton action="close" label="수정 취소" disabled={busy} onClick={async()=>{if(!dirty||await confirmAction({kind:'leave',title:'수정을 취소할까요?',message:uncertain?'반영 여부를 확인하지 못했습니다. 최신 답변을 다시 확인하세요.':'수정한 내용은 저장되지 않습니다.',confirmLabel:'수정 취소',cancelLabel:'계속 수정'}))onCancelEdit?.();}}/></div>}
    {replyTo&&<div className="comment-reply-target"><span><UserIdentity user={replyTo.user} chip/> 님에게 답글</span><ActionButton action="close" label="답글 선택 해제" disabled={busy||uncertain} onClick={onCancelReply}/></div>}
    <MentionTextInput initialValue={editing?.body||''} resetKey={id.current} onChange={setText} client={client} disabled={disabled||busy||uncertain} inputRef={field} label={kind==='inquiry'?'답변':'댓글 내용'} placeholder={`${label}을 입력하세요. @로 사용자 검색`} maxLength={500}/>
    <div className="talk-comment-submit"><small>{text.length}/500</small><ActionButton action="save" label={uncertain?'결과 확인':editing?'저장':'등록'} type="submit" busy={busy} disabled={disabled||!text.trim()||(editing&&!dirty)}/></div>
  </form>;
}

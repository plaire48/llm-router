import React from 'react';
import { ActionButton, ACTIONS } from './ActionButton';

// Shared by every master: a 20px outline glyph within a 44px hit area.
export function MasterActionButton({ action, label, title, ...props }) {
  const [, name] = ACTIONS[action];
  return <ActionButton action={action} className={`master-action master-action--${action}`}
    data-master-action={action} aria-label={`${label} ${name}`} title={title || name} {...props}/>;
}

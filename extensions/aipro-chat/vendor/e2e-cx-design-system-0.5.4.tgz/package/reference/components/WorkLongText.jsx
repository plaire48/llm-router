import { ActionButton } from './ActionButton';
import React, { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { workTextLength } from './workListModel';
import './work-long-text.css';

export function WorkLongTextInput({ value, field, label, onExpand, ...inputProps }) {
  const textarea=useRef(null),hintId=useId(),count=workTextLength(value),overLimit=count>field.maxLength;
  const table=Boolean(onExpand),[expanded,setExpanded]=useState(false);
  useLayoutEffect(()=>{
    const input=textarea.current;if(!input)return;
    const resize=()=>{
      const style=getComputedStyle(input),minimum=parseFloat(style.minHeight)||32,maximum=table?192:320;
      const border=parseFloat(style.borderTopWidth)+parseFloat(style.borderBottomWidth);
      input.style.height='auto';
      input.style.overflowY='hidden';
      const height=Math.max(minimum,input.scrollHeight+border);
      input.style.height=`${Math.min(maximum,height)}px`;
      input.style.overflowY=height>maximum?'auto':'hidden';
      setExpanded(height>minimum+1);
    };
    resize();
    // Column resizing and responsive fonts can wrap text without changing its value.
    let width,frame;
    const observer=new ResizeObserver(([entry])=>{
      if(entry.contentRect.width!==width){
        width=entry.contentRect.width;cancelAnimationFrame(frame);
        // Resize outside observer delivery so changing height cannot trigger a loop.
        frame=requestAnimationFrame(resize);
      }
    });
    observer.observe(input);window.addEventListener('resize',resize);document.fonts?.addEventListener('loadingdone',resize);
    return()=>{observer.disconnect();cancelAnimationFrame(frame);window.removeEventListener('resize',resize);document.fonts?.removeEventListener('loadingdone',resize);};
  },[value,table]);
  return <div className={`work-long-input ${table?'is-table':''} ${expanded?'is-expanded':''} ${overLimit?'is-over-limit':''}`}>
    <textarea {...inputProps} ref={textarea} rows={table?1:5} className="text-input list-cell-input work-long-textarea" value={value} aria-label={label} aria-invalid={overLimit||undefined} aria-describedby={hintId}/>
    <div className="work-long-input-footer">
      {onExpand&&<ActionButton action="expand" type="button" disabled={inputProps.disabled} onClick={onExpand} aria-label={`${label} 넓게 입력`} title="넓게 입력"/>}
      <span id={hintId} className={`work-text-count ${overLimit?'is-error':''}`}>
        {overLimit&&<span>한도 초과 </span>}{count.toLocaleString('ko-KR')} / {field.maxLength.toLocaleString('ko-KR')}자
      </span>
    </div>
  </div>;
}

export function WorkLongTextPreview({ value, label, onOpen }) {
  const text=useRef(null),[truncated,setTruncated]=useState(false);
  useEffect(()=>{
    const element=text.current;if(!element)return;
    const measure=()=>setTruncated(element.scrollHeight>element.clientHeight+1);
    const observer=new ResizeObserver(measure);observer.observe(element);measure();
    return()=>observer.disconnect();
  },[value]);
  return <div className={`work-long-preview ${!value?'is-empty':''}`}>
    <span ref={text} className="work-long-preview-text">{value||'—'}</span>
    {truncated&&<ActionButton action="detail" type="button" className="work-long-more" onClick={onOpen} aria-label={`${label} 전체 내용 보기`}/>}
  </div>;
}

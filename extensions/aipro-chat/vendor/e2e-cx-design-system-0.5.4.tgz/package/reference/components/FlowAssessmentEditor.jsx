import {CxSelect} from './CxSelect';
import { ActionButton } from './ActionButton';
import {useFeedback} from './Toast';
import {SettingsGrid, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import { CxConfirmation } from './CxConfirmation';
import { confirmationCopy } from './confirmationCopy';
import React, { useEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { AutomationRateSource } from './AutomationRateSource';
import { ImplementationMethodsSelect } from './ImplementationMethodsSelect';
import { Icon } from './Icon';
import { AgentFlowPreview } from './AgentFlowPreview';
import { useWorkList } from './WorkListState';
import { parseAgentFlowYaml, MAX_YAML_BYTES } from './agentFlowImport';
import { actionAverage, currentFlowTasks, flowActionRows, initialActionSettings, connectImportedTasks, stableJson, workflowForTask } from './agentFlowModel';
import { catalogValues } from './catalogValues';
import { formatAutomationRate } from './automationRate';
import { nodePath } from './hierarchyModel';
import { GithubAvatar } from './AccountProfile';
import { createFlowUpload, reconcileFlowUpload } from './flowUpload';

function CriterionSelect({catalog,value,label,disabled,onChange}) {
  const options=catalogValues(catalog).filter(item=>item.active!==false&&catalog.items.some(current=>current.id===item.id)||item.id===value);
  return <CxSelect className="text-input" aria-label={label} value={value||''} disabled={disabled} onChange={event=>onChange(event.target.value)}><option value="">선택</option>{options.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect>;
}
export default function FlowAssessmentEditor({activityId,initialTaskId,onClose,onPendingChange}) {
  const state=useWorkList(),document=state.catalogs.standardProcesses;
  const saved=state.automationRates[activityId]?.assessment||null;
  const [draft,setDraft]=useState(()=>saved&&structuredClone(saved)),[taskId,setTaskId]=useState(()=>(initialTaskId?currentFlowTasks(saved,document,activityId).find(task=>saved.taskMapping[task.id]===initialTaskId)?.id:currentFlowTasks(saved,document,activityId)[0]?.id)||''),[imported,setImported]=useState(null),[workflowId,setWorkflowId]=useState(''),[selected,setSelected]=useState(null);
  const [confirm,setConfirm]=useState(null),[reading,setReading]=useState(false);
  const [focusRequest,setFocusRequest]=useState(null);
  const fileInput=useRef(null),table=useRef(null),pending=useRef(false);
  const dirty=stableJson(draft)!==stableJson(saved),busy=state.saving||reading;
  const disabled=!state.isEditor||state.loading||state.loadError||busy;
  const path=nodePath(document.items,activityId),activity=path.at(-1);
  const tasks=document.items.filter(item=>item.level==='task'&&item.parentId===activityId);
  const availableTasks=currentFlowTasks(draft,document,activityId);
  const selectedTask=availableTasks.find(task=>task.id===taskId);
  const selectedStandardTask=tasks.find(task=>task.id===(draft?.taskMapping[selectedTask?.id]||(!selectedTask?initialTaskId:undefined)));
  const actions=flowActionRows(draft,state.automationScoring).filter(action=>action.taskId===selectedTask?.id),rate=actionAverage(actions),incomplete=actions.filter(item=>item.rate===null).length;
  const effectiveRate=state.automationRates[selectedStandardTask?.id];
  const scopedWorkflow=draft&&selectedTask?{...workflowForTask(draft.workflow,selectedTask.id),name:selectedStandardTask?.label||selectedTask.name}:null;

  const [,notify]=useFeedback();
  useEffect(()=>{onPendingChange?.({dirty:dirty||Boolean(imported),saving:busy});},[dirty,imported,busy,onPendingChange]);
  useEffect(()=>()=>onPendingChange?.({dirty:false,saving:false}),[onPendingChange]);
  useBeforeUnload(dirty||Boolean(imported));
  const close=()=>{if(busy)return;if(dirty||imported)setConfirm('close');else onClose();};
  const reset=()=>{setDraft(saved&&structuredClone(saved));setImported(null);setSelected(null);setConfirm(null);notify('초기화했습니다.');};
  const read=async event=>{
    const file=event.target.files?.[0];event.target.value='';if(!file)return;
    setReading(true);notify('');
    try {if(file.size>MAX_YAML_BYTES)throw new Error('YAML 파일은 2MB 이하로 업로드하세요.');
      const next=parseAgentFlowYaml(await file.text(),file.name);setImported(next);setWorkflowId(next.workflows[0].id);
    }catch(reason){notify(reason.message,true);}finally{setReading(false);}
  };
  const applyImport=()=>{
    try {
      const workflow=imported.workflows.find(item=>item.id===workflowId),taskMapping=connectImportedTasks(workflow,document,activityId,saved);
      setDraft(reconcileFlowUpload({workflow,fileName:imported.fileName,roles:imported.roles,settings:initialActionSettings(workflow,state.automationScoring),taskMapping,scoring:state.automationScoring,upload:createFlowUpload(state.user)},saved));
      setTaskId((initialTaskId?workflow.tasks.find(task=>taskMapping[task.id]===initialTaskId)?.id:workflow.tasks[0].id)||'');setImported(null);setSelected(null);setConfirm(null);notify('');
    }catch(reason){setConfirm(null);notify(reason.message,true);}
  };
  const patch=(id,value)=>{setDraft(current=>({...current,settings:{...current.settings,[id]:{...current.settings[id],...value}}}));notify('');};
  const select=(id,{reveal=true}={})=>{setSelected(id);if(reveal&&actions.some(action=>action.id===id))grid.reveal(id);};
  const focusAction=id=>{setSelected(id);setFocusRequest(current=>({id,version:(current?.version||0)+1}));};
  const save=async()=>{
    if(disabled||pending.current)return;
    if(!draft){notify('YAML을 먼저 업로드하세요.',true);return;}
    pending.current=true;
    try {const result=await state.saveFlow({activityId,assessment:draft});if(result){setDraft(structuredClone(result.automationRates[activityId].assessment));notify(result.commit?'저장했습니다.':'변경 사항이 없습니다.');}}
    catch(reason){notify(reason.message,true);}finally{pending.current=false;}
  };
  const savedActions=new Map(flowActionRows(saved||(draft?{...draft,settings:initialActionSettings(draft.workflow,state.automationScoring)}:null),state.automationScoring).map(action=>[action.id,action]));
  const grid=useSettingsGrid({id:'settings.flowActions',label:'Action 자동화율 산정',scope:JSON.stringify([activityId,selectedTask?.id,draft?.fileName]),rows:actions.map(action=>({...action,selectionLabel:`Action ${action.number} ${action.name}`,original:savedActions.get(action.id)||action})),columns:[
    {key:'number',label:'Action',width:240,value:row=>`${row.number}. ${row.name}`},
    {key:'cardType',label:'카드 종류',width:190,value:row=>row.cardLabel,filterValue:row=>row.original.cardLabel},
    {key:'cardWeight',label:'카드 가중치 (%)',width:140,filterValue:row=>row.original.cardWeight},
    {key:'feasibility',label:'자동화 가능 여부',width:190,value:row=>row.feasibility==='possible'?'자동화 가능':row.feasibility==='impossible'?'자동화 불가능':null,filterValue:row=>row.original.feasibility==='possible'?'자동화 가능':row.original.feasibility==='impossible'?'자동화 불가능':null},
    {key:'method',label:'구현 방법',width:230,value:row=>row.methodLabel,filterValue:row=>row.original.methodLabel},
    {key:'methodWeight',label:'구현 가중치 (%)',width:140,value:row=>row.feasibility==='impossible'?null:row.methodWeight,filterValue:row=>row.original.feasibility==='impossible'?null:row.original.methodWeight},
    {key:'rate',label:'자동화율 (%)',width:120,filterValue:row=>row.original.rate},
  ]});
  const batch=useSettingsApply(grid,{disabled});
  const offer=(action,field,value)=>{
    const display=field==='cardType'?catalogValues(state.automationScoring.cards).find(item=>item.id===value)?.label:field==='feasibility'?(value==='possible'?'자동화 가능':value==='impossible'?'자동화 불가능':'선택 해제'):catalogValues(state.automationScoring.methods).filter(item=>(Array.isArray(value)?value:[value]).includes(item.id)).map(item=>item.label).join(', ');
    batch.offer({rowId:action.id,field:field==='cardType'?'카드 종류':field==='method'?'구현 방법':'자동화 가능 여부',value,display:display||'선택 해제',eligible:row=>field!=='method'||row.feasibility!=='impossible',apply:targets=>{setDraft(current=>({...current,settings:{...current.settings,...Object.fromEntries(targets.map(row=>[row.id,{...current.settings[row.id],[field]:value}]))}}));notify('');}});
  };
  const taskPicker=draft&&<label className="flow-task-picker"><span>Task</span><CxSelect className="text-input" aria-label="워크플로우 Task" value={selectedTask?.id||''} onChange={event=>{setTaskId(event.target.value);setSelected(null);}}><option value="" disabled>Task 선택</option>{availableTasks.map(task=><option key={task.id} value={task.id}>{tasks.find(item=>item.id===draft.taskMapping[task.id])?.label||task.name}</option>)}</CxSelect></label>;
  return <DetailPanel helpTopic="automation" title={activity?.label||'Agent Flow'} subtitle={path.slice(0,-1).map(item=>item.label).join(' / ')} className="flow-assessment-panel" busy={busy} onClose={close} footer={<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" type="button" disabled={disabled||!dirty&&!imported} onClick={()=>setConfirm('reset')}/><ActionButton action="save" busy={state.saving} type="button" onClick={save} disabled={disabled||Boolean(imported)||!draft}/></>}>
    <div className="flow-upload-toolbar">
      <div className="flow-upload-info">
        <h3 className="flow-upload-brand"><Icon name="agent" size={20}/><strong>Agent Flow</strong></h3>
        {draft&&<div className="flow-file-meta" role="group" aria-label="YAML 업로드 정보">
          {draft.upload?.by&&<span className="flow-upload-person" title="업로드한 사람"><GithubAvatar user={draft.upload.by}/><span>{draft.upload.by.name||draft.upload.by.login||'사용자'}</span></span>}
          <span className="flow-file-name" title={draft.fileName}>{draft.fileName}</span>
          {draft.upload?.at&&<time dateTime={draft.upload.at} title="업로드 일시">{new Intl.DateTimeFormat('ko-KR',{dateStyle:'medium',timeStyle:'short'}).format(new Date(draft.upload.at))}</time>}
        </div>}
      </div>
      <input ref={fileInput} type="file" tabIndex={-1} accept=".yaml,.yml,application/yaml,text/yaml" aria-label="Agent Flow YAML 파일" className="visually-hidden" onChange={read} disabled={disabled}/><ActionButton action="upload" busy={reading} type="button" disabled={disabled} onClick={()=>fileInput.current.click()}/>
    </div>
    {imported&&<div className="flow-import-choice"><span className="flow-import-file"><Icon name="file" size={18}/><span>{imported.fileName}</span></span><label>Activity<CxSelect className="text-input" aria-label="불러올 Activity" value={workflowId} onChange={event=>setWorkflowId(event.target.value)}>{imported.workflows.map(workflow=><option key={workflow.id} value={workflow.id}>{workflow.name}</option>)}</CxSelect></label><div className="flow-import-actions"><ActionButton action="cancel" label="취소" onClick={()=>setImported(null)}/><ActionButton action="upload" label="불러오기" onClick={()=>draft?setConfirm('replace'):applyImport()}/></div></div>}

    {!draft?(!imported&&<div className="flow-upload-empty"><Icon name="upload" size={32}/><h3>업로드한 YAML이 없습니다</h3></div>):<>

      {selectedTask?<><AgentFlowPreview assessment={{...draft,workflow:scopedWorkflow}} scoring={state.automationScoring} selected={selected} onSelect={select} taskPicker={taskPicker} focusRequest={focusRequest}/>
      <div className="flow-rate-summary">
        <h3>Action <span>{actions.length}</span></h3>
        <div className="flow-rate-values"><div className="flow-calculated-rate" title={incomplete?`${incomplete}개 Action의 산정 항목을 확인하세요.`:'Task 내 Action 자동화율의 평균'}><span>자동화율</span><strong>{rate==null?'—':formatAutomationRate(rate)}</strong></div>
          {effectiveRate?.rateSource==='manual'&&<div className="flow-effective-rate"><span>현황 반영값</span><strong>{effectiveRate.rate==null?'—':formatAutomationRate(effectiveRate.rate)}</strong><AutomationRateSource entry={effectiveRate} label={selectedStandardTask?.label}/></div>}
        </div>
      </div>
      </>:<>{taskPicker}<p className="flow-task-missing">{!availableTasks.length?'표준 프로세스에서 Task 연결을 확인하세요.':initialTaskId?'이 Task가 포함된 YAML을 업로드하세요.':'Task를 선택하세요.'}</p></>}
      {selectedTask&&<div ref={table}><SettingsGrid grid={grid} showCount={false} className="flow-actions-table" rowProps={action=>({'data-flow-action':action.id,className:selected===action.id?'is-current':''})} renderCell={(action,field)=>{
        if(field==='number')return <><button type="button" className="flow-action-name" onClick={()=>focusAction(action.id)} aria-pressed={selected===action.id}><span>{action.number}</span><strong>{action.name}</strong></button>{action.importNotice&&<span className="flow-import-notice">{action.importNotice}</span>}</>;
        if(field==='cardType')return <CriterionSelect catalog={state.automationScoring.cards} value={action.cardType} label={`${action.name} 카드 종류`} disabled={disabled} onChange={cardType=>{patch(action.id,{cardType});offer(action,'cardType',cardType);}}/>;
        if(field==='feasibility')return <CxSelect className="text-input" aria-label={`${action.name} 자동화 가능 여부`} value={action.feasibility||''} disabled={disabled} onChange={event=>{patch(action.id,{feasibility:event.target.value});offer(action,'feasibility',event.target.value);}}><option value="">선택</option><option value="possible">자동화 가능</option><option value="impossible">자동화 불가능</option></CxSelect>;
        if(field==='method')return <ImplementationMethodsSelect catalog={state.automationScoring.methods} value={action.method} label={`${action.name} 구현 방법`} disabled={disabled||action.feasibility==='impossible'} onChange={method=>patch(action.id,{method})} onCommit={method=>offer(action,'method',method)}/>;
        const value=field==='methodWeight'&&action.feasibility==='impossible'?'—':action[field]==null?'—':formatAutomationRate(action[field]);
        return <span className={field==='rate'?'flow-action-rate':undefined}>{value}</span>;
      }}/></div>}{batch.dialog}

    </>}
    {confirm&&<CxConfirmation {...confirmationCopy(confirm==='replace'?'upload':confirm)} className="flow-confirm-dialog" busy={busy} onCancel={()=>setConfirm(null)} onConfirm={()=>confirm==='close'?onClose():confirm==='replace'?applyImport():reset()}/>}
  </DetailPanel>;
}

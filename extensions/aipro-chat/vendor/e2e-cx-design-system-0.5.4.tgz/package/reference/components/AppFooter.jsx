import React from 'react';
import { BrandMark } from './AppChrome';
import {ActionLink} from './ActionButton';
import {inquiryHash} from './inquiryNavigation';
import './service-desk.css';

export function AppFooter({ page = 'E2E Agent 현황' }) {
  return <footer className="site-footer" aria-label="E2E Report 하단">
    <div className="site-footer-content">
      <div className="site-footer-brand"><BrandMark/><span>E2E Report</span></div>
      <small className="site-footer-copyright"><span>© {new Date().getFullYear()}</span><span>전자/제조IT팀 Agent Factory</span></small>
    </div>
    <div className="site-footer-support"><ActionLink action="inquiry" iconOnly={false} className="service-desk-trigger" href={inquiryHash(page)}/></div>
  </footer>;
}

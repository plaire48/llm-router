import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {CxConfirmation} from './CxConfirmation';
import './edit-conflict.css';

const display=value=>value==null||value===''?'—':typeof value==='boolean'?(value?'사용':'미사용'):typeof value==='object'?JSON.stringify(value):String(value);
function ConflictDialog({conflicts,onFinish}){
  const [choices,setChoices]=useState({});
  return <CxConfirmation className="cx-edit-conflict" title="변경 내용 비교" message="다른 사용자가 같은 항목을 수정했습니다. 사용할 값을 선택하세요." confirmLabel="선택한 값으로 저장" cancelLabel="계속 수정" confirmDisabled={Object.keys(choices).length!==conflicts.length} onCancel={()=>onFinish(null)} onConfirm={()=>onFinish(choices)}>
    <div className="cx-conflict-scroll"><table className="cx-conflict-table"><thead><tr><th>항목</th><th>수정 전</th><th>현재 저장된 값</th><th>내 수정값</th></tr></thead><tbody>{conflicts.map((item,index)=><tr key={`${item.rowId}:${item.key}`}><th scope="row"><strong>{item.title}</strong><span>{item.label}</span></th><td data-label="수정 전">{display(item.beforeLabel??item.before)}</td>{['current','mine'].map(choice=><td key={choice} data-label={choice==='current'?'현재 저장된 값':'내 수정값'} className={choices[index]===choice?'is-selected':''}><label><input type="radio" name={`conflict-${index}`} value={choice} checked={choices[index]===choice} onChange={()=>setChoices(values=>({...values,[index]:choice}))}/><span>{display(choice==='current'?(item.currentLabel??item.current):(item.proposedLabel??item.proposed))}</span></label></td>)}</tr>)}</tbody></table></div>
  </CxConfirmation>;
}
let active=false;
export function resolveEditConflict(conflicts){
  if(active||!conflicts?.length)return Promise.resolve(null);
  active=true;
  return new Promise(resolve=>{
    const host=document.createElement('div');host.dataset.editConflict='';document.body.append(host);
    const root=createRoot(host);let settled=false;
    const finish=value=>{if(settled)return;settled=true;queueMicrotask(()=>{root.unmount();host.remove();active=false;resolve(value);});};
    root.render(<ConflictDialog conflicts={conflicts} onFinish={finish}/>);
  });
}

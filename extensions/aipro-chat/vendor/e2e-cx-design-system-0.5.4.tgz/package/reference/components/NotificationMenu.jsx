import React, {useEffect, useId, useLayoutEffect, useRef, useState} from 'react';
import {createPortal} from 'react-dom';
import {ActionButton} from './ActionButton';
import {Icon} from './Icon';
import {createNotificationProfiles} from './notificationProfiles';
import {ProfileTooltip,usePublicProfileHover} from './ProfileTooltip';
import {GithubAvatar} from './AccountProfile';
import {githubIdentityLabel} from './githubIdentity';
import {createAppNotificationClient} from './talkNotifications';
import {talkConfigured} from './talkClient';
import {notificationDateGroup, relativeNotificationTime} from './notificationTime';
import './notifications.css';
import {notificationAction} from './issueActivity';
import {GHES_CONFIG} from './config';
import {notificationReadKey, readNotificationIds, rememberNotificationIds} from './notificationReadState';
import {INQUIRY_CHANGED} from './inquiryNotificationRefresh';
import {TALK_TEAM_CHANGED} from './talkNotificationRefresh';

const formatTime = value => new Intl.DateTimeFormat('ko-KR', {month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit'}).format(new Date(value));

export function NotificationMenu({role, user, onOpenUsers, client: suppliedClient}) {
  if (!user?.login) return null;
  // Role/account transitions discard all in-memory notices and pending reads.
  return <NotificationFeed key={`${user.id || user.login}:${role}`} user={user} role={role} onOpenUsers={onOpenUsers} suppliedClient={suppliedClient}/>;
}

function NotificationFeed({user, role, onOpenUsers, suppliedClient}) {
  const id = useId(), trigger = useRef(null), panel = useRef(null);
  const [open,setOpen] = useState(false), [filter,setFilter] = useState('all'), [position,setPosition] = useState(null);
  const [result,setResult] = useState({items:[],errors:[],limited:false}), [busy,setBusy] = useState(true);
  const readKey = notificationReadKey({...GHES_CONFIG, userId:user.id || user.login});
  const [storage] = useState(() => {try {return window.localStorage;} catch {return null;}});
  const [read,setRead] = useState(() => readNotificationIds(storage, readKey));
  const [clock,setClock] = useState(Date.now);
  const [client] = useState(() => {try {return suppliedClient || createAppNotificationClient({role});} catch {return null;}});
  const refresh = useRef(() => {}),profiles = useRef(null);
  useEffect(()=>{profiles.current=createNotificationProfiles();return()=>{profiles.current?.dispose();profiles.current=null;};},[]);
  const markIds = ids => setRead(current => rememberNotificationIds(storage, readKey, current, ids));
  useEffect(() => {
    if (open && result.items.some(item => !read.has(item.id))) markIds(result.items.map(item => item.id));
  }, [open, result.items, read]);
  useEffect(() => {
    const sync = event => {if(event.key === readKey) setRead(current => new Set([...current, ...readNotificationIds(storage, readKey)]));};
    window.addEventListener('storage',sync);
    return () => window.removeEventListener('storage',sync);
  }, [readKey, storage]);
  const close = (restore = false) => {setOpen(false); if (restore) trigger.current?.focus();};
  useEffect(() => {if (!open) return;setClock(Date.now());const timer = setInterval(()=>setClock(Date.now()),30000);return()=>clearInterval(timer);},[open]);
  useEffect(() => {
    if (!client) {setResult({items:[],errors:['알림을 확인하려면 다시 로그인하세요.'],limited:false});setBusy(false);return;}
    let disposed = false, running = false, pendingRefresh = false, timer;
    const controller = new AbortController();
    const poll = async (force = false) => {
      pendingRefresh ||= force;
      if (disposed || running || document.hidden) return;
      const fresh = pendingRefresh; pendingRefresh = false;
      running = true; clearTimeout(timer); setBusy(true);
      let delay = 60000;
      try {const value = await client.load({signal:controller.signal,force:fresh});if (!disposed) {setResult(value);delay = value.pollAfterMs || delay;}}
      catch {if (!disposed) setResult(current => ({...current, errors:['알림을 불러오지 못했습니다.']}));}
      finally {running = false;if (!disposed) {setBusy(false);timer = setTimeout(() => poll(), pendingRefresh ? 0 : Math.max(delay,1000));}}
    };
    const visibility = () => {if (document.hidden) clearTimeout(timer);else poll(true);};
    const changed = () => poll(true);
    refresh.current = changed; poll();
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener(INQUIRY_CHANGED, changed);
    window.addEventListener(TALK_TEAM_CHANGED, changed);
    return () => {disposed = true;clearTimeout(timer);controller.abort();document.removeEventListener('visibilitychange',visibility);window.removeEventListener(INQUIRY_CHANGED,changed);window.removeEventListener(TALK_TEAM_CHANGED,changed);};
  },[client]);
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const anchor = trigger.current?.getBoundingClientRect();
      if (!anchor) return;
      const viewport = window.visualViewport, left = viewport?.offsetLeft || 0, top = viewport?.offsetTop || 0;
      const width = viewport?.width || innerWidth, height = viewport?.height || innerHeight;
      const panelWidth = Math.min(400,width-16), y = Math.min(anchor.bottom+8,top+height-120);
      setPosition({left:Math.max(left+8,Math.min(anchor.right-panelWidth,left+width-panelWidth-8)),top:Math.max(top+8,y),width:panelWidth,maxHeight:Math.max(100,top+height-y-8)});
    };
    place(); panel.current?.querySelector('[data-action="close"]')?.focus();
    const outside = event => {if (!panel.current?.contains(event.target) && !trigger.current?.contains(event.target)) close();};
    const escape = event => {if (event.key === 'Escape') {event.preventDefault();event.stopPropagation();close(true);}};
    document.addEventListener('pointerdown',outside);
    document.addEventListener('focusin',outside);
    panel.current?.addEventListener('keydown',escape,true);
    const element = panel.current;
    window.addEventListener('resize',place);window.addEventListener('scroll',place,true);
    window.visualViewport?.addEventListener('resize',place);
    return () => {document.removeEventListener('pointerdown',outside);document.removeEventListener('focusin',outside);element?.removeEventListener('keydown',escape,true);window.removeEventListener('resize',place);window.removeEventListener('scroll',place,true);window.visualViewport?.removeEventListener('resize',place);};
  },[open]);
  const unread = result.items.filter(item => !read.has(item.id)).length;
  const items = result.items.filter(item => filter === 'all' || item.kind === filter);
  const mark = item => markIds([item.id]);
  return <div className="notification-entry">
    <ActionButton action="notifications" ref={trigger} aria-label={unread ? `알림, 읽지 않음 ${unread}건` : '알림'} aria-expanded={open} aria-haspopup="dialog" aria-controls={open?id:undefined} onClick={() => {if(open)close();else {setOpen(true);refresh.current();}}}/>
    {unread > 0 && <span className="notification-badge" aria-hidden="true">{unread>99?'99+':unread}</span>}
    {open && createPortal(<section ref={panel} id={id} className="notification-popover" role="dialog" aria-label="알림" style={position || {visibility:'hidden'}}>
      <header className="notification-header"><h2>알림</h2><ActionButton action="refresh" busy={busy} onClick={() => refresh.current()}/><ActionButton action="close" onClick={() => close(true)}/></header>
      <div className="notification-toolbar"><div className="notification-filters" role="group" aria-label="알림 유형">{[['all','전체'],['issue','문의'],...(talkConfigured()?[['talk','E2E Talk']]:[]),['role','권한'],...(role==='system'?[['member','사용자']]:[])].map(([key,label])=><button type="button" key={key} aria-pressed={filter===key} onClick={()=>setFilter(key)}>{label}</button>)}</div></div>
      <div className="notification-content" aria-busy={busy}>
        {result.errors.length > 0 && <div className="notification-error" role="status">{result.errors.map(error=><p key={error}>{error}</p>)}</div>}
        {!items.length ? <p className="notification-empty">{busy?'불러오는 중…':result.errors.length?'새로고침으로 다시 확인하세요.':'알림이 없습니다.'}</p> : <ul className="notification-list">{items.map((item,index) => <React.Fragment key={item.id}>
          {(index===0 || notificationDateGroup(items[index-1].createdAt,clock)!==notificationDateGroup(item.createdAt,clock)) && <li className="notification-date"><h3>{notificationDateGroup(item.createdAt,clock)}</h3></li>}
          <li className={read.has(item.id)?'':'is-unread'}>
          <NotificationItem item={item} read={read.has(item.id)} clock={clock} profiles={profiles.current} onSelect={async()=>{if(item.kind==='member'){if(await onOpenUsers?.(item.user.login)===false)return;close();}mark(item);}}/>
        </li></React.Fragment>)}</ul>}
      </div>
      <footer className="notification-footer">최근 30일{result.limited?' 조회 가능한 알림':''}{role==='system'&&filter==='member'&&result.memberHistoryLimited&&<span className="notification-history-note">서버 기록이 있는 사용자 추가만 다시 표시합니다.</span>}</footer>
    </section>,document.body)}
  </div>;
}


function NotificationItem({item,read,clock,profiles,onSelect}) {
  const ref=useRef(null),id=useId(),[actor,setActor]=useState(item.user);
  const hover=usePublicProfileHover(actor,profiles);
  useEffect(()=>{
    let current=true,started=false;
    setActor(item.user);
    const resolve=()=>{if(started||!profiles||item.event==='updated'||!item.user?.login)return;started=true;profiles.read(item.user).then(value=>{if(current&&value)setActor({...item.user,...value});});};
    const observer=typeof IntersectionObserver==='undefined'?null:new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){resolve();observer.disconnect();}},{root:ref.current?.closest('.notification-content'),rootMargin:'80px'});
    if(observer)observer.observe(ref.current);else resolve();
    return()=>{current=false;observer?.disconnect();};
  },[item.user,profiles,item.event]);
  const known=item.event!=='updated'&&actor?.login;
  const identity=<b {...(known?hover.handlers:{})}>{githubIdentityLabel(actor)}</b>;
  return <>
    {React.createElement(item.kind!=='member'?'a':'button', {ref,className:'notification-item',...(item.kind!=='member'?{href:item.href,target:'_blank',rel:'noopener noreferrer'}:{type:'button'}),onClick:onSelect,onFocus:known?hover.handlers.onFocus:undefined,onBlur:known?hover.handlers.onBlur:undefined,'aria-describedby':hover.card?id:undefined}, <>
      <span className="notification-avatar" {...(known?hover.handlers:{})}><GithubAvatar user={known?actor:null} size="sm"/></span>
      <span className="notification-copy"><span className="notification-kind">{item.kind==='role'?'권한 안내':item.kind==='talk'?'E2E Talk':item.kind==='issue'?`${item.event==='created'?'새 문의':'문의 변경'} #${item.number}`:'사용자 추가'}</span><span className="notification-sentence">{item.kind!=='member'?<>{known&&<>{identity} </>}{notificationAction(item)}</>:<>{identity}{item.source==='team'?' 님의 팀 추가 이력이 있습니다.':item.source==='access'?' 님이 접근 사용자 목록에 추가되었습니다.':' 님이 저장소에 추가되었습니다.'}</>}</span>{item.kind!=='member'&&<strong>{item.title}</strong>}<time className="notification-time" dateTime={item.createdAt} title={formatTime(item.createdAt)}>{relativeNotificationTime(item.createdAt,clock)}</time></span>
      <Icon name="chevronRight" size={16}/><span className="visually-hidden">{read?'읽음':'읽지 않음'}{item.kind!=='member'?', 새 탭에서 열기':''}</span>
    </>)}
    {hover.card&&<ProfileTooltip id={id} {...hover.card} onMouseEnter={hover.keep} onMouseLeave={hover.leave}/>}
  </>;
}

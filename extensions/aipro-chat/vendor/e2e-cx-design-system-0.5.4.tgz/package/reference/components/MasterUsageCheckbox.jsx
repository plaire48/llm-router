import React from 'react';

export function MasterUsageCheckbox({ label, active, disabled, onChange }) {
  return <label className="master-usage-control" title={`${label}: ${active ? '사용' : '미사용'}`}>
    <input type="checkbox" className="cx-checkbox" aria-label={`${label} 사용`} checked={active} disabled={disabled} onChange={event => onChange(event.target.checked)}/>
  </label>;
}

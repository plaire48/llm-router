import { ActionButton } from './ActionButton';
import {useFeedback, ToastNotice} from './Toast';
import React, {useEffect, useRef, useState} from 'react';
import {DetailPanel} from './DetailPanel';
import {Icon} from './Icon';
import {MasterActionButton} from './MasterActionButton';
import {SettingsGrid, useSettingsGrid} from './SettingsGrid';
import {TableEditModeButton} from './TableEditModeButton';
import {confirmAction} from './confirmAction';
import {useBeforeUnload} from './useBeforeUnload';
import {useWorkList} from './WorkListState';
import {stableJson} from './agentFlowModel';
import {EFFECTIVENESS_RULE_ID, validateEnhancementAttributes} from './enhancementCriteria';

export function EnhancementAttributesSettings({onPendingChange}) {
  const state=useWorkList(),source=state.catalogs.decisionRules;
  const [draft,setDraft]=useState(()=>structuredClone(source)),[editing,setEditing]=useState(null),[editAll,setEditAll]=useState(false);
  const [loading,setLoading]=useState(state.canSettings);
  const current=useRef(state),panel=useRef(null),pending=useRef(false);current.current=state;
  const dirty=(()=>{try{return stableJson(validateEnhancementAttributes(draft).items)!==stableJson(source.items);}catch{return true;}})();
  const disabled=!state.canSettings||loading||state.loading||state.saving||state.loadError;
  useEffect(()=>{setDraft(structuredClone(source));setEditing(null);},[source]);
  useEffect(()=>{
    if(!state.canSettings)return;
    let active=true;setLoading(true);
    current.current.reloadEnhancementAttributes().catch(reason=>{if(active){notify(reason.message,true);}}).finally(()=>{if(active)setLoading(false);});
    return()=>{active=false;};
  },[state.canSettings]);
  useEffect(()=>{onPendingChange?.({dirty,saving:state.saving});},[dirty,state.saving,onPendingChange]);
  useEffect(()=>{if(editing||editAll)panel.current?.querySelector('input')?.focus();},[Boolean(editing),editAll]);
  useBeforeUnload(dirty);
  const [,notify]=useFeedback([{label:'최신 기준 불러오기',onClick:()=>reload()}]);
  const change=(id,key,value)=>setDraft(document=>({...document,items:document.items.map(item=>item.id===id?{...item,[key]:value}:item)}));
  const save=async()=>{
    if(disabled||pending.current)return false;
    pending.current=true;
    try {
      const document=validateEnhancementAttributes(draft);
      if(stableJson(document.items)===stableJson(source.items)){notify('변경 사항이 없습니다.');return true;}
      await state.saveEnhancementAttributes(document);setEditing(null);notify('저장했습니다.');return true;
    }catch(reason){notify(reason.message,true);return false;}
    finally{pending.current=false;}
  };
  const discard=()=>{setDraft(structuredClone(source));setEditing(null);};
  const reset=async()=>{if(disabled||dirty&&!await confirmAction({kind:'reset'}))return;discard();notify('마지막 저장 상태로 초기화했습니다.');};
  const reload=async()=>{
    if(state.saving||loading||dirty&&!await confirmAction({kind:'reload'}))return;
    setLoading(true);
    try {await state.reloadEnhancementAttributes();notify('');}
    catch(reason){notify(reason.message,true);}
    finally{setLoading(false);}
  };
  const rows=draft.items.filter(item=>item.id===EFFECTIVENESS_RULE_ID).map(item=>({...item,original:source.items.find(original=>original.id===item.id)}));
  const grid=useSettingsGrid({id:'settings.enhancementAttributes',label:'고도화 대상 속성',rows,columns:[
    {key:'label',label:'이름',width:300,filterValue:row=>row.original?.label},
    {key:'value',label:'시간',width:180,filterValue:row=>row.original?.value},
    {key:'unit',label:'단위',width:160},
  ]});
  return <DetailPanel embedded hideHeading busy={state.saving} title="고도화 대상 속성" className="work-options-modal enhancement-attributes-settings" footer={state.canSettings?<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" type="button" disabled={disabled||!dirty} onClick={reset}/><TableEditModeButton active={editAll} disabled={disabled} dirty={dirty} onSave={save} onDiscard={discard} onChange={value=>{setEditAll(value);setEditing(null);}}/><ActionButton action="save" busy={state.saving} type="button" disabled={disabled} onClick={save}/></>:null}>

    {state.structureErrors.decisionRules&&<ToastNotice error message={state.structureErrors.decisionRules} actions={[{label:'최신 기준 불러오기',onClick:reload}]}/>}
    <div ref={panel}><SettingsGrid grid={grid} showCount={false} nameHeading={{label:grid.label,count:rows.length}} className="work-options-table" renderCell={(row,key)=>{
      if(key==='unit')return row.unit;
      if(editAll||editing?.id===row.id)return <input className="text-input" type={key==='value'?'number':'text'} min={key==='value'?0:undefined} step={key==='value'?'any':undefined} inputMode={key==='value'?'decimal':undefined} aria-label={key==='value'?'효과성 최소 시간':'기준 이름'} value={row[key]??''} disabled={disabled} onChange={event=>change(row.id,key,event.target.value)}/>;
      return key==='value'?Number(row.value).toLocaleString('ko-KR',{maximumFractionDigits:15}):row.label;
    }} renderActions={row=>!state.canSettings||editAll?null:editing?.id===row.id?<><MasterActionButton action="complete" label={row.label} disabled={disabled} onClick={()=>{try{setDraft(validateEnhancementAttributes(draft));setEditing(null);notify('');}catch(reason){notify(reason.message,true);}}}/><MasterActionButton action="cancel" label={row.label} disabled={disabled} onClick={()=>{setDraft(document=>({...document,items:document.items.map(item=>item.id===row.id?editing:item)}));setEditing(null);notify('');}}/></>:<MasterActionButton action="edit" label={row.label} disabled={disabled} onClick={()=>{setEditing(structuredClone(draft.items.find(item=>item.id===row.id)));notify('');}}/>}/></div>
  </DetailPanel>;
}

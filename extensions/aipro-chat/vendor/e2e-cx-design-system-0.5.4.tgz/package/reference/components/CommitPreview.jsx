import React,{useEffect,useId,useLayoutEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {ActionButton} from './ActionButton';
import {shortCommit} from './historySearch';
import {commitPreviewChanges,commitPreviewValue} from './commitPreviewModel';
import {CommitId} from './CommitReference';
import './commit-preview.css';

export function CommitPreview({entry,history,catalogs}) {
  const id=useId(),trigger=useRef(null),panel=useRef(null),leaveTimer=useRef(null),restoringFocus=useRef(false);
  const [open,setOpen]=useState(false),[position,setPosition]=useState(null),[result,setResult]=useState(null),[attempt,setAttempt]=useState(0);
  const cancelLeave=()=>clearTimeout(leaveTimer.current);
  const leave=()=>{cancelLeave();leaveTimer.current=setTimeout(()=>{if(!panel.current?.contains(document.activeElement)&&document.activeElement!==trigger.current)setOpen(false);},180);};
  const close=()=>{setOpen(false);restoringFocus.current=document.activeElement!==trigger.current;trigger.current?.focus({preventScroll:true});};
  useEffect(()=>()=>cancelLeave(),[]);
  useEffect(()=>{
    if(!open)return;
    let current=true;setResult(null);
    history.revision(entry).then(revision=>{if(current)setResult({changes:commitPreviewChanges(revision)});}).catch(()=>{if(current)setResult({error:'변경 내용을 불러오지 못했습니다.'});});
    return()=>{current=false;};
  },[open,entry,history.revision,attempt]);
  useLayoutEffect(()=>{
    if(!open)return;
    const place=()=>{
      const box=trigger.current?.getBoundingClientRect();if(!box)return;
      const viewport=window.visualViewport,left=viewport?.offsetLeft||0,top=viewport?.offsetTop||0,width=viewport?.width||innerWidth,height=viewport?.height||innerHeight;
      const w=Math.min(400,width-16),h=Math.min(panel.current?.offsetHeight||280,height-16);
      const y=box.bottom+8+h<=top+height-8?box.bottom+8:Math.max(top+8,box.top-h-8);
      setPosition({left:Math.max(left+8,Math.min(box.right-w,left+width-w-8)),top:y,width:w,maxHeight:height-16});
    };
    const outside=event=>{if(!panel.current?.contains(event.target)&&!trigger.current?.contains(event.target))setOpen(false);};
    const escape=event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}};
    place();window.addEventListener('resize',place);window.addEventListener('scroll',place,true);window.visualViewport?.addEventListener('resize',place);document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return()=>{window.removeEventListener('resize',place);window.removeEventListener('scroll',place,true);window.visualViewport?.removeEventListener('resize',place);document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[open,result]);
  if(!shortCommit(entry.sha))return null;
  return <>
    <button ref={trigger} type="button" className="settings-commit" aria-label={`커밋 ${shortCommit(entry.sha)} 변경 요약`} aria-haspopup="dialog" aria-expanded={open} aria-controls={open?id:undefined} onMouseEnter={()=>{cancelLeave();setOpen(true);}} onMouseLeave={leave} onFocus={event=>{if(restoringFocus.current){restoringFocus.current=false;return;}if(event.currentTarget.matches(':focus-visible')){cancelLeave();setOpen(true);}}} onBlur={leave} onClick={()=>{cancelLeave();setOpen(true);}} onKeyDown={event=>{if(open&&event.key==='ArrowDown'){event.preventDefault();panel.current?.querySelector('button')?.focus();}}}><CommitId sha={entry.sha}/></button>
    {open&&createPortal(<section ref={panel} id={id} role="dialog" aria-label="커밋 변경 요약" className="commit-preview" style={position||{visibility:'hidden'}} onMouseEnter={cancelLeave} onMouseLeave={leave} onFocus={cancelLeave} onBlur={leave}>
      <header><h2>변경 요약 <CommitId sha={entry.sha}/></h2><ActionButton action="close" onClick={close}/></header>
      <div className="commit-preview-body">
        {entry.message&&<p className="commit-preview-title">{entry.message.replace(/[·•]/g,' ')}</p>}
        {!result?<p role="status">불러오는 중…</p>:result.error?<div className="commit-preview-error"><p role="status">{result.error}</p><ActionButton action="refresh" label="변경 요약 다시 조회" onClick={()=>setAttempt(value=>value+1)}/></div>:result.changes.length?<><ul>{result.changes.slice(0,4).map((change,index)=><li key={index}><strong>{[change.process,change.activity,change.task].filter(Boolean).join(' / ')||'기준 설정'}</strong><span className="commit-preview-field">{change.label}<small>{change.type}</small></span><div className="commit-preview-values"><span title={commitPreviewValue(change,change.before,catalogs)}>{commitPreviewValue(change,change.before,catalogs)}</span><span aria-hidden="true">→</span><span className="visually-hidden">변경 후</span><b title={commitPreviewValue(change,change.after,catalogs)}>{commitPreviewValue(change,change.after,catalogs)}</b></div></li>)}</ul>{result.changes.length>4&&<p className="commit-preview-more">외 {result.changes.length-4}개 변경</p>}</>:<p>표시 항목에 변경이 없습니다.</p>}
      </div>
    </section>,document.body)}
  </>;
}

import React from 'react';
import { shortCommit } from './historySearch';

export function CommitId({sha}) {
  return <code className="commit-reference" title={sha} aria-label={`커밋 ID ${sha}`}>{shortCommit(sha)||'—'}</code>;
}

export function CommitReference({sha,url}) {
  const label=shortCommit(sha);
  if(!label)return <span className="is-empty">—</span>;
  const value=<CommitId sha={sha}/>;
  return /^https?:\/\//i.test(url||'')?<a className="commit-reference-link" href={url} target="_blank" rel="noreferrer" title={`커밋 ${sha} 원본 보기`} aria-label={`커밋 ${label} 원본 보기`} onClick={event=>event.stopPropagation()}>{value}</a>:value;
}

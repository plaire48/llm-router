import React, { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Icon } from './Icon';

export function AutomationRateSource({entry, label = '', pending = false}) {
  const button = useRef(null), id = useId();
  const [position, setPosition] = useState(null);
  const source = entry?.rateSource === 'manual' ? 'manual' : entry?.sourceActivityId ? 'automatic' : 'unrecorded';
  const text = source === 'manual' ? '수동 입력' : source === 'automatic' ? 'YAML 자동 계산' : '입력 방식 미기록';
  const description = source === 'manual' ? pending?'직접 입력한 저장 전 값입니다.':'자동화율을 직접 입력해 저장한 값입니다.' : source === 'automatic' ? 'Action과 가중치로 계산한 값입니다.' : '입력 방식이 기록되지 않은 값입니다.';
  const show = () => {
    const rect = button.current.getBoundingClientRect();
    setPosition({left: Math.max(8, Math.min(rect.left, window.innerWidth - 228)), top: rect.top > 88 ? rect.top - 8 : rect.bottom + 8, above: rect.top > 88});
  };
  useEffect(() => {
    if(!position)return;
    const hide=()=>setPosition(null);
    window.addEventListener('scroll',hide,true);window.addEventListener('resize',hide);
    return()=>{window.removeEventListener('scroll',hide,true);window.removeEventListener('resize',hide);};
  }, [position]);
  if(entry?.rate == null)return null;
  return <>
    <button ref={button} type="button" className={`automation-rate-source is-${source}`} data-rate-source={source} aria-label={`${label ? `${label} 자동화율: ` : ''}${text}`} aria-describedby={position?id:undefined}
      onFocus={show} onBlur={()=>setPosition(null)} onMouseEnter={show} onMouseLeave={()=>{if(document.activeElement!==button.current)setPosition(null);}} onClick={show}
      onKeyDown={event=>{if(event.key==='Escape'&&position){event.preventDefault();event.stopPropagation();setPosition(null);}}}>
      <Icon name={source==='manual'?'user':source==='automatic'?'automation':'infoCircle'} size={16}/>
    </button>
    {position&&createPortal(<div id={id} role="tooltip" className="automation-rate-source-tooltip" style={{left:position.left,top:position.top,transform:position.above?'translateY(-100%)':undefined}}><strong>{text}</strong><span>{description}</span></div>,document.body)}
  </>;
}

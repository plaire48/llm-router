import {usesSingleBranchData} from './config.js';
import {loadPublicSnapshot} from './publicSnapshot';
import { getMasterDefinition } from './masterCatalog';
import {useBeforeUnload} from './useBeforeUnload';
import {useFeedback, ToastNotice} from './Toast';
import { confirmAction } from './confirmAction';
import {resolveEditConflict} from './resolveEditConflict';
import { defaultScoring } from './agentFlowModel';
import { persistFlowChanges } from './agentFlowPersistence';
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { loadGithubJson, loadGithubMaster, parseMaster, parseAutomationCriteria, parseAutomationScoring, saveGithubMaster, saveGithubAutomationMaster, saveGithubJson } from './master';
import { getGithubSession } from './session';
import { LIST_CATALOGS, WORK_FIELDS, workFieldValue, workFieldEnabled, applyWorkDraft, applySelectedWorkPatch, changedWorkFields } from './workListModel';
import { useRowRevisions } from './useRowRevisions';
import { useWorkHistory } from './useWorkHistory';
import { changedWorkCatalogs, validateWorkChoices, persistWorkChanges } from './workListPersistence';
import { persistCatalogChanges } from './catalogPersistence';
import { applyAutomationCriteria, changedAutomationCriteria, persistAutomationCriteria } from './automationCriteria';
import { STRUCTURE_DEFINITIONS, structureDefinition, resolveStandardRow, organizationAssignments, validateHierarchy } from './hierarchyModel';
import bundledAssignments from './data/masters/process-organizations.json';
import { PROCESS_ORGANIZATIONS, applyProcessOrganizations, seedProcessOrganizations, validateProcessOrganizations } from './processOrganizations';
import { persistProcessOrganizations } from './processOrganizationPersistence';
import { ENHANCEMENT_ATTRIBUTES, validateEnhancementAttributes } from './enhancementCriteria';
import { migrateFieldCatalog } from './fieldCatalogMigration';
import { validateOptionRows } from './optionModel';
import { includeStandardTasks } from './standardWorkRows';
import { loadWorkListCatalogs } from './workListCatalogs';

const State = createContext(null);
export function WorkListProvider({ isEditor, canSettings = isEditor, canRead = isEditor, user, children, initialRows, initialCatalogs, initialAutomationRates, initialAutomationScoring, loadMaster = loadGithubMaster, saveMaster = saveGithubMaster, saveAutomationMaster = saveMaster === saveGithubMaster ? saveGithubAutomationMaster : saveMaster, listHistory, loadPublishedMetadata, loadHistoryRevision, saveStructureJson = saveGithubJson, loadStructureJson = loadGithubJson }) {
  const [publicMetadata,setPublicMetadata]=useState(null);
  const storedHistory = useWorkHistory(canRead && !initialRows || Boolean(canRead && listHistory), listHistory, loadPublishedMetadata, loadHistoryRevision);
  const history=publicMetadata&&!canRead?{...storedHistory,published:publicMetadata}:storedHistory;
  const publicRefresh=useRef(null);
  const initial = () => (initialRows || parseMaster()).map(row=>resolveStandardRow(row,initialCatalogs?.standardProcesses||structureDefinition('standardProcesses').bundled));
  const [automationRates, setAutomationRates] = useState(() => initialAutomationRates || (initialRows ? {} : parseAutomationCriteria()));
  const [automationScoring, setAutomationScoring] = useState(() => initialAutomationScoring || (initialRows ? defaultScoring() : parseAutomationScoring()));
  const [storedRows, setRows] = useState(initial);
  const [storedSavedRows, setSavedRows] = useState(initial);
  const [sourceCatalogs, setCatalogs] = useState(() => {
    const catalogs={...Object.fromEntries([...LIST_CATALOGS,...STRUCTURE_DEFINITIONS,ENHANCEMENT_ATTRIBUTES].map((entry) => [entry.key, entry.bundled])),...initialCatalogs};
    return {...Object.fromEntries(Object.entries(catalogs).map(([key,document])=>[key,migrateFieldCatalog(key,document)])),processOrganizations:initialCatalogs?.processOrganizations||(initialRows?seedProcessOrganizations(initialRows,catalogs.standardProcesses,catalogs.organizations):bundledAssignments)};
  });
  const catalogs={...sourceCatalogs,responsibleGroups:organizationAssignments(sourceCatalogs.organizations)};
  const withRevision=useRowRevisions(storedSavedRows,history,canRead);
  const resolveRows = values => applyAutomationCriteria(applyProcessOrganizations(values,catalogs.standardProcesses,catalogs.organizations,catalogs.processOrganizations),catalogs.standardProcesses,automationRates).map(withRevision);
  const rows=resolveRows(includeStandardTasks(storedRows,catalogs.standardProcesses));
  const savedRows=resolveRows(includeStandardTasks(storedSavedRows,catalogs.standardProcesses));
  const [structureSha,setStructureSha]=useState({});
  const [structureLoading,setStructureLoading]=useState(Boolean(canRead&&!initialRows));
  const [structureErrors,setStructureErrors]=useState({});
  const structureError=Object.values(structureErrors).find(Boolean);
  const [sha, setSha] = useState(null);
  const [criteriaSha,setCriteriaSha]=useState(null);
  const [storedEditing, setEditing] = useState(null);
  const editing=storedEditing?{...storedEditing,draft:resolveRows([storedEditing.draft])[0]}:null;
  const [editAll,setEditAllValue]=useState(false),[storedBulkDrafts,setBulkDrafts]=useState({});
  const bulkDrafts=Object.fromEntries(Object.entries(storedBulkDrafts).map(([id,draft])=>[id,resolveRows([draft])[0]]));
  const setEditAll=value=>{setEditAllValue(value);if(!value)setBulkDrafts({});};
  const [status, setStatus] = useFeedback();
  const [loading, setLoading] = useState(Boolean(canRead && !initialRows));
  const [loadError, setLoadError] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [loginRequired, setLoginRequired] = useState(false);
  const pendingSave = useRef(false);
  const latestOperations = useRef({});
  const baseline = new Map(savedRows.map((row) => [row.id, row]));
  const dirtyRows = rows.filter((row) => changedWorkFields(bulkDrafts[row.id]||row, baseline.get(row.id)).length);
  const editedRow = rows.find((row) => row.id === editing?.id);
  const draftDirty = Boolean(editing && changedWorkFields(editing.draft, editedRow).length)||rows.some(row=>bulkDrafts[row.id]&&changedWorkFields(bulkDrafts[row.id],row).length);
  const catalogVersions = useRef({});
  const refreshCatalog = (key, document, nextSha) => {
    catalogVersions.current[key]=(catalogVersions.current[key]||0)+1;
    setCatalogs(current=>({...current,[key]:document}));
    if(nextSha!==undefined)setStructureSha(current=>({...current,[key]:nextSha}));
    setStructureErrors(current=>({...current,[key]:''}));
  };
  const acceptCatalogSnapshot = (snapshot, versions) => {
    // A slower initial request must not overwrite a newer settings read/save.
    const fresh=Object.fromEntries(Object.entries(snapshot.catalogs).filter(([key])=>(catalogVersions.current[key]||0)===(versions[key]||0)));
    setCatalogs(current=>({...current,...fresh}));
    setStructureSha(current=>({...current,...Object.fromEntries(Object.keys(fresh).map(key=>[key,snapshot.shas[key]]))}));
    setStructureErrors(current=>({...current,...Object.fromEntries(Object.keys(fresh).map(key=>[key,'']))}));
  };
  useEffect(() => {
    if (!canRead || initialRows) return;
    let active = true;
    const versions={...catalogVersions.current}, session=getGithubSession();
    setLoading(true);setStructureLoading(true);setLoadError(false);
    Promise.resolve().then(()=>loadMaster(session)).then(async remote=>{
      const latest=remote?.rows||parseMaster();
      const snapshot=await loadWorkListCatalogs({session:{...session,...(remote?.snapshotHead?{ref:remote.snapshotHead}:{})},rows:latest,loadDocument:loadStructureJson});
      if(!active)return;
      setRows(latest);setSavedRows(latest);setAutomationRates(remote?.automationRates||{});setAutomationScoring(remote?.automationScoring||defaultScoring());setSha(remote?.sha||null);setCriteriaSha(remote?.criteriaSha||remote?.sha||null);
      acceptCatalogSnapshot(snapshot,versions);setStatus('');
    }).catch(error=>{if(active){setLoadError(true);setStatus(error,true,[{label:'다시 불러오기',onClick:()=>latestOperations.current.reloadLatest()}]);}})
      .finally(()=>{if(active){setLoading(false);setStructureLoading(false);}});
    return()=>{active=false;};
  },[canRead, initialRows, loadMaster, loadStructureJson]);
  useEffect(()=>{
    if(canRead||initialRows)return;
    let active=true,running=null,timer,last=null;
    if(usesSingleBranchData())setLoading(true);
    const controller=new AbortController();
    const poll=async(manual=false)=>{
      if(!active||document.hidden&&!manual)return;
      if(running)return running;
      clearTimeout(timer);
      running=(async()=>{
        try{
          const snapshot=await loadPublicSnapshot({signal:controller.signal});
          if(!active)return;
          setLoadError(false);setLoading(false);
          if(!last||snapshot.revision!==last.revision&&Date.parse(snapshot.publishedAt)>=Date.parse(last.publishedAt)){
            setRows(snapshot.rows);setSavedRows(snapshot.rows);setCatalogs(snapshot.catalogs);setAutomationRates(snapshot.automationRates);setAutomationScoring(snapshot.automationScoring);setPublicMetadata(snapshot.metadata);last=snapshot;
          }
          if(manual)setStatus('게시된 최신 현황을 불러왔습니다.');
          return true;
        }catch(error){if(active){setLoading(false);if(!last&&usesSingleBranchData())setLoadError(true);if(manual||!last&&usesSingleBranchData())setStatus(error,true);}return false;}
        finally{running=null;if(active)timer=setTimeout(()=>poll(),60000);}
      })();
      return running;
    };
    publicRefresh.current=poll;
    const visible=()=>{if(document.hidden)clearTimeout(timer);else poll();};
    poll();document.addEventListener('visibilitychange',visible);
    return()=>{active=false;controller.abort();clearTimeout(timer);publicRefresh.current=null;document.removeEventListener('visibilitychange',visible);};
  },[canRead,initialRows]);
  useBeforeUnload(Boolean(dirtyRows.length||draftDirty));
  const begin = async (row) => {
    if(!isEditor){if(user?.login)setStatus('E2E 관리자 또는 시스템 관리자만 수정할 수 있습니다.',true);else setLoginRequired(true);return;}
    if(editAll||pendingSave.current||saving||loading||structureLoading||structureError||loadError)return;
    if(editing && editing.id!==row.id && draftDirty&&!await confirmAction({kind:'leave',message:'현재 행에서 수정한 내용이 사라집니다.'}))return;
    setEditing({id:row.id,draft:{...row}});setStatus('');
  };
  const cancel = async (options = {}) => {
    if(pendingSave.current)return false;
    if(editing&&changedWorkFields(editing.draft,editedRow).length&&!await confirmAction({kind:options.kind||'discard'}))return false;
    setEditing(null);setStatus('');return true;
  };
  const discard = () => {if(!pendingSave.current){setEditing(null);setStatus('');}};
  const discardChanges = () => {
    if(pendingSave.current)return false;
    setRows(storedSavedRows);setBulkDrafts({});setEditing(null);setEditAllValue(false);setSaveError('');setStatus('');
    return true;
  };
  const applyDraft = (row, draft) => applyWorkDraft(row, draft);
  const apply = () => {
    if(!isEditor||!editing||pendingSave.current||loading||structureLoading||structureError||loadError)return false;
    try {
      const next=applyDraft(editedRow,editing.draft);
      const submitted=rows.map(row=>row.id===next.id?next:row);
      setRows(submitted);setEditing(null);
      setSaveError('');
      setStatus(submitted.some(row=>changedWorkFields(row,baseline.get(row.id)).length) ? '수정 완료' : '변경 사항이 없습니다.');
      return true;
    } catch(error){setStatus(error.message,true);return false;}
  };
  const persist = async (submitted) => {
    if(!isEditor||pendingSave.current||loading||structureLoading||structureError||loadError)return;
    pendingSave.current=true;setSaving(true);setSaveError('');setStatus('변경 사항을 저장하는 중…');
    try {
      let snapshot=[];
      const definitions=[structureDefinition('standardProcesses'),...changedWorkCatalogs(savedRows,submitted)];
      const loadCurrent=async (session,comparison={baseline:savedRows,submitted})=>{
        const remote=await loadMaster(session);
        const loaded=await readCatalogs(definitions,{...session,...(remote?.snapshotHead?{ref:remote.snapshotHead}:{})});
        const current={...catalogs,...Object.fromEntries(loaded.map(entry=>[entry.key,entry.document]))};
        validateWorkChoices(comparison.baseline,comparison.submitted,current);
        snapshot=loaded;
        return remote?{...remote,referenceVersions:{automationCriteria:remote.criteriaSha||null,...Object.fromEntries(loaded.map(entry=>[entry.key,entry.sha]))},automationScoring:remote.automationScoring || automationScoring,rows:applyAutomationCriteria(includeStandardTasks(remote.rows,current.standardProcesses),current.standardProcesses,remote.automationRates || automationRates)}:null;
      };
      const result=await persistWorkChanges({baseline:savedRows,submitted,knownSha:sha,session:getGithubSession(),user,loadMaster:loadCurrent,saveMaster,resolveConflicts:conflicts=>resolveEditConflict(conflicts.map(item=>{
        const field=WORK_FIELDS.find(field=>field.key===item.key);
        const label=value=>field?workFieldValue({[item.key]:value},field,catalogs):value;
        return {...item,beforeLabel:label(item.before),currentLabel:label(item.current),proposedLabel:label(item.proposed)};
      }))});
      snapshot.forEach(entry=>acceptStructure(entry.key,entry.document,entry.sha));
      setRows(result.rows);setSavedRows(result.rows);setAutomationRates(result.automationRates || {});setAutomationScoring(result.automationScoring || automationScoring);setSha(result.sha);setStatus(result.commit ? '저장했습니다.' : '변경 사항이 없습니다.');
      if(result.commit) void history.recorded(result.commit,user,undefined,result.modifiedRows);
      else void history.refresh();
      return result;
    } catch(error){if(error.cancelled){setSaveError('');setStatus('수정값은 유지됩니다.');return false;}setSaveError(error.message);setStatus(`저장하지 못했습니다. 수정값은 유지됩니다.\n${error.message}`,true,[{label:'다시 저장',onClick:()=>latestOperations.current.save()},{label:'최신 값 불러오기',onClick:()=>latestOperations.current.reloadLatest()}]);return false;}
    finally{pendingSave.current=false;setSaving(false);}
  };
  const save = () => {
    if(!isEditor||pendingSave.current||loading||structureLoading||structureError||loadError)return;
    let submitted;
    try {submitted=rows.map(row=>bulkDrafts[row.id]?applyDraft(row,bulkDrafts[row.id]):row);}
    catch(error){setStatus(error.message,true);setSaveError(error.message);return false;}
    if(editing) {
      try { const next=applyDraft(editedRow,editing.draft); submitted=rows.map(row=>row.id===next.id?next:row); }
      catch(error){setStatus(error.message,true);return;}
      setRows(submitted);setEditing(null);
    }
    if(!submitted.some(row=>changedWorkFields(row,baseline.get(row.id)).length)) {
      setBulkDrafts({});setSaveError('');setStatus('변경 사항이 없습니다.');return true;
    }
    return persist(submitted).then(result=>{if(result)setBulkDrafts({});return result;});
  };
  const reset = async () => {
    if(pendingSave.current)return;
    if((dirtyRows.length||draftDirty)&&!await confirmAction({kind:'reset'}))return;
    setRows(storedSavedRows);setBulkDrafts({});setEditing(null);setSaveError('');setStatus('마지막 저장 상태로 초기화했습니다.');
  };
  const reloadLatest = async () => {
    if(!canRead)return publicRefresh.current?.(true);
    if(pendingSave.current||!await confirmAction({kind:'reload',title:'최신 현황을 불러올까요?',confirmLabel:'최신 값 불러오기'}))return;
    pendingSave.current=true;setSaving(true);
    try {
      const remote=await loadMaster(getGithubSession());
      if(!remote&&sha)throw new Error('현황 파일이 삭제됐습니다. 수정값은 유지됩니다.');
      const latest=remote?.rows||initial();
      const versions={...catalogVersions.current};
      const snapshot=await loadWorkListCatalogs({session:{...getGithubSession(),...(remote?.snapshotHead?{ref:remote.snapshotHead}:{})},rows:latest,loadDocument:loadStructureJson,knownShas:structureSha});
      acceptCatalogSnapshot(snapshot,versions);setLoadError(false);
      setRows(latest);setSavedRows(latest);setBulkDrafts({});setAutomationRates(remote?.automationRates || {});setAutomationScoring(remote?.automationScoring || defaultScoring());setSha(remote?.sha||null);setCriteriaSha(remote?.criteriaSha||remote?.sha||null);setEditing(null);setSaveError('');setStatus('최신 현황을 불러왔습니다.');void history.refresh();
    } catch(error){setSaveError(error.message);setStatus(error,true,[{label:'최신 값 불러오기',onClick:()=>latestOperations.current.reloadLatest()}]);}
    finally{pendingSave.current=false;setSaving(false);}
  };
  const acceptStructure=(key,next,sha)=>{
    catalogVersions.current[key]=(catalogVersions.current[key]||0)+1;
    setStructureSha(current=>({...current,[key]:sha}));
    // Bind existing literal rows before replacing renamed standard labels.
    if(key==='standardProcesses'){
      setRows(current=>current.map(row=>resolveStandardRow(row,catalogs.standardProcesses)));
      setSavedRows(current=>current.map(row=>resolveStandardRow(row,catalogs.standardProcesses)));
      setBulkDrafts(current=>Object.fromEntries(Object.entries(current).filter(([id,draft])=>changedWorkFields(draft,rows.find(row=>row.id===id)).length).map(([id,draft])=>[id,resolveStandardRow(draft,next)])));
      setEditing(current=>current?{...current,draft:resolveStandardRow(resolveStandardRow(current.draft,catalogs.standardProcesses),next)}:current);
    }
    setCatalogs(current=>({...current,[key]:next}));
    setStructureErrors(current=>({...current,[key]:''}));
    return next;
  };
  const readCatalogs = async (definitions, session=getGithubSession()) => Promise.all(definitions.map(async definition=>{
    const remote=await loadStructureJson({...session,path:definition.path});
    if(!remote&&structureSha[definition.key])throw new Error(`${definition.label} 파일이 삭제됐습니다. 수정 내용은 유지됩니다.`);
    let document=remote?.document||catalogs[definition.key];
    if(definition.levels)document=validateHierarchy(definition,document);
    else if(definition.key===PROCESS_ORGANIZATIONS.key)document=validateProcessOrganizations(document);
    else if(definition.key===ENHANCEMENT_ATTRIBUTES.key)document=validateEnhancementAttributes(document);
    else {document=migrateFieldCatalog(definition.key,document);document={...document,items:validateOptionRows(document.items)};}
    return {key:definition.key,document,sha:remote?.sha||null};
  }));
  const loadAutomationMaster = async session => {
    const remote=await loadMaster(session);
    const [standard]=await readCatalogs([structureDefinition('standardProcesses')],{...session,...(remote?.snapshotHead?{ref:remote.snapshotHead}:{})});
    return {...remote,rows:remote?.rows||savedRows,automationRates:remote?.automationRates||automationRates,automationScoring:remote?.automationScoring||automationScoring,sha:remote?.criteriaSha||remote?.sha||null,missing:!remote,standardDocument:standard.document,standardSha:standard.sha};
  };
  const reloadStructure=async key=>{
    if(!isEditor||pendingSave.current||saving)throw new Error('저장이 끝난 뒤 다시 불러오세요.');
    const definition=structureDefinition(key);
    const remote=await loadStructureJson({...getGithubSession(),path:definition.path});
    if(!remote&&structureSha[key])throw new Error('기준정보 파일을 찾을 수 없습니다. 수정 내용은 유지됩니다.');
    const next=remote?.document||catalogs[key];validateHierarchy(definition,next);
    return acceptStructure(key,next,remote?.sha||null);
  };
  const saveStructure=async(key,document)=>{
    if(!canSettings||loading||loadError||structureLoading||structureErrors[key]||pendingSave.current||saving)throw new Error('조회나 저장이 진행 중입니다. 완료 후 다시 저장하세요.');
    const definition=structureDefinition(key);validateHierarchy(definition,document);
    const submitted={...document,updatedBy:user?{id:user.id,login:user.login,name:user.name,avatar_url:user.avatar_url}:null};
    pendingSave.current=true;setSaving(true);
    try {
      const result=await persistCatalogChanges({baseline:catalogs[key],submitted,knownSha:structureSha[key],session:getGithubSession(),path:definition.path,message:`${definition.label} 기준정보 변경 @${user?.login}`,loadDocument:loadStructureJson,saveDocument:saveStructureJson,resolveConflicts:resolveEditConflict,validate:value=>validateHierarchy(definition,value)});
      if(result.commit)void history.recorded(result.commit,user,definition.path);
      else void history.refresh();
      return acceptStructure(key,result.document,result.sha);
    } finally {pendingSave.current=false;setSaving(false);}
  };
  const reloadEnhancementAttributes=async()=>{
    if(!isEditor||pendingSave.current)throw new Error('진행 중인 저장이 끝난 뒤 다시 불러오세요.');
    try {
      const remote=await loadStructureJson({...getGithubSession(),path:ENHANCEMENT_ATTRIBUTES.path});
      if(!remote&&structureSha.decisionRules)throw new Error('고도화 대상 속성 파일을 찾을 수 없습니다.');
      const document=validateEnhancementAttributes(remote?.document||catalogs.decisionRules);
      return acceptStructure('decisionRules',document,remote?.sha||null);
    }catch(error){setStructureErrors(current=>({...current,decisionRules:error.message}));throw error;}
  };
  const saveEnhancementAttributes=async draft=>{
    if(!canSettings||loading||loadError||structureLoading||structureErrors.decisionRules||pendingSave.current)throw new Error('조회나 저장이 진행 중입니다. 완료 후 다시 저장하세요.');
    const submitted={...validateEnhancementAttributes(draft),updatedBy:user?{id:user.id,login:user.login,name:user.name,avatar_url:user.avatar_url}:null};
    pendingSave.current=true;setSaving(true);
    try {
      const result=await persistCatalogChanges({baseline:catalogs.decisionRules,submitted,knownSha:structureSha.decisionRules,session:getGithubSession(),path:ENHANCEMENT_ATTRIBUTES.path,message:`고도화 대상 속성 변경 @${user?.login||'user'}`,loadDocument:loadStructureJson,saveDocument:saveStructureJson,resolveConflicts:resolveEditConflict,validate:validateEnhancementAttributes});
      acceptStructure('decisionRules',result.document,result.sha);
      if(result.commit)void history.recorded(result.commit,user,ENHANCEMENT_ATTRIBUTES.path);else void history.refresh();
      return result;
    }finally{pendingSave.current=false;setSaving(false);}
  };
  const canEditField=field=>WORK_FIELDS.some(item=>item.key===field&&!item.readOnly);
  const update=(field,value)=>{if(!canEditField(field)||pendingSave.current)return;setEditing(current=>current&&workFieldEnabled(current.draft,WORK_FIELDS.find(item=>item.key===field))?{...current,draft:{...current.draft,[field]:value}}:current);};
  const beginAll=()=>{if(editing&&!apply())return false;return true;};
  const updateBulk=(id,field,value)=>{
    if(!isEditor||!editAll||saving||loading||loadError||structureLoading||structureError||!canEditField(field))return;
    setBulkDrafts(current=>{
      const before=current[id]||rows.find(row=>row.id===id);
      if(!workFieldEnabled(before,WORK_FIELDS.find(item=>item.key===field)))return current;
      const next={...before,[field]:value};
      return {...current,[id]:next};
    });setStatus('');setSaveError('');
  };
  const applySelection=(ids,patch)=>{
    if(!isEditor||pendingSave.current||saving||loading||loadError||structureLoading||structureError)throw new Error('현황을 불러오거나 저장하는 중입니다. 잠시 후 다시 적용하세요.');
    // Keep unfinished row edits and other bulk drafts. Applying is not a repository save.
    const current=rows.map(row=>editing?.id===row.id?editing.draft:bulkDrafts[row.id]||row);
    const result=applySelectedWorkPatch(current,ids,patch,catalogs);
    if(result.changedCount){
      const updates=new Map(result.rows.filter((row,index)=>row!==current[index]).map(row=>[row.id,row]));
      if(editAll)setBulkDrafts(drafts=>({...drafts,...Object.fromEntries(updates)}));
      else {
        setRows(values=>values.map(row=>row.id!==editing?.id&&updates.has(row.id)?updates.get(row.id):row));
        if(editing&&updates.has(editing.id))setEditing({...editing,draft:updates.get(editing.id)});
      }
    }
    setSaveError('');
    const unsaved=result.rows.some(row=>ids.includes(row.id)&&changedWorkFields(row,baseline.get(row.id)).length);
    setStatus(unsaved?`선택한 ${ids.length}건에 적용했습니다. 저장을 눌러 반영하세요.`:'변경 사항이 없습니다.');
    return result;
  };
  const saveAssignments = async drafts => {
    if(!canSettings||pendingSave.current||loading||structureLoading||structureError||loadError)return false;
    pendingSave.current=true;setSaving(true);
    try {
      let loaded=[];
      const loadDependencies=async ref=>{loaded=await readCatalogs(STRUCTURE_DEFINITIONS,{...getGithubSession(),...(ref?{ref}:{})});return Object.fromEntries(loaded.map(entry=>[entry.key,entry.document]));};
      const result=await persistProcessOrganizations({baseline:catalogs.processOrganizations,drafts,standard:catalogs.standardProcesses,organizations:catalogs.organizations,knownSha:structureSha.processOrganizations,session:getGithubSession(),user,loadDocument:loadStructureJson,saveDocument:saveStructureJson,loadDependencies});
      loaded.forEach(entry=>acceptStructure(entry.key,entry.document,entry.sha));
      acceptStructure('processOrganizations',result.document,result.sha);
      if(result.commit)void history.recorded(result.commit,user,PROCESS_ORGANIZATIONS.path);else void history.refresh();
      return result;
    } finally {pendingSave.current=false;setSaving(false);}
  };
  const reloadAssignments = async () => {
    if(!isEditor||pendingSave.current)return false;
    pendingSave.current=true;setSaving(true);
    try {
      const loaded=await readCatalogs([...STRUCTURE_DEFINITIONS,PROCESS_ORGANIZATIONS]);
      loaded.forEach(entry=>acceptStructure(entry.key,entry.document,entry.sha));
      return true;
    } finally {pendingSave.current=false;setSaving(false);}
  };
  const acceptAutomationSave = result => {
    if(result.standardDocument)acceptStructure('standardProcesses',result.standardDocument,result.standardSha);
    if (!editing && !dirtyRows.length && !draftDirty) {
      setRows(result.rows);setSavedRows(result.rows);setBulkDrafts({});
    } else {
      // Settings save only persisted rows. Keep list edits and their original
      // comparison baseline so later saves still detect concurrent field edits.
      // Refresh derived rates inside open editors without committing their inputs.
      const refreshDraft = draft => applyAutomationCriteria([draft],result.standardDocument||catalogs.standardProcesses,result.automationRates)[0];
      setEditing(current=>current?{...current,draft:refreshDraft(current.draft)}:current);
      setBulkDrafts(current=>Object.fromEntries(Object.entries(current).map(([id,draft])=>[id,refreshDraft(draft)])));
    }
    setAutomationRates(result.automationRates);setAutomationScoring(result.automationScoring || automationScoring);setCriteriaSha(result.sha);if(saveAutomationMaster===saveMaster)setSha(result.sha);
  };
  const saveRateCriteria = async drafts => {
    if (!canSettings || pendingSave.current || loading || structureLoading || structureError || loadError) return false;
    if (!changedAutomationCriteria(catalogs.standardProcesses, savedRows, automationRates, drafts).length) return {rows, automationRates, commit: null};
    pendingSave.current=true;setSaving(true);
    try {
      const result = await persistAutomationCriteria({document:catalogs.standardProcesses,baselineRows:savedRows,baselineCriteria:automationRates,drafts,knownSha:criteriaSha,session:getGithubSession(),user,loadMaster:loadAutomationMaster,saveMaster:saveAutomationMaster});
      acceptAutomationSave(result);
      if(result.commit)void history.recorded(result.commit,user);
      else void history.refresh();
      return result;
    } finally{pendingSave.current=false;setSaving(false);}
  };
  const saveFlow = async change => {
    if(!canSettings||pendingSave.current||loading||structureLoading||structureError||loadError)return false;
    pendingSave.current=true;setSaving(true);
    try {
      const result=await persistFlowChanges({document:catalogs.standardProcesses,baselineCriteria:automationRates,baselineScoring:automationScoring,baselineRows:savedRows,knownSha:criteriaSha,session:getGithubSession(),user,loadMaster:loadAutomationMaster,saveMaster:saveAutomationMaster,...change});
      acceptAutomationSave(result);
      if(result.commit)void history.recorded(result.commit,user);
      return result;
    } finally{pendingSave.current=false;setSaving(false);}
  };
  const saveRates = drafts => saveRateCriteria(Object.fromEntries(Object.entries(drafts).map(([rowId,value])=>[resolveStandardRow(rows.find(row=>row.id===rowId),catalogs.standardProcesses).standardTaskId,value])));
  latestOperations.current = {save, reloadLatest};
  return <State.Provider value={{rows,savedRows,catalogs,catalogShas:structureSha,editAll,setEditAll,bulkDrafts,beginAll,updateBulk,automationRates,automationScoring,saveFlow,editing,editedRow,draftDirty,dirtyRows,baseline,status:structureError?`기준정보를 확인하지 못해 저장할 수 없습니다. ${structureError}`:status,setStatus,loading:loading||structureLoading,loadError:loadError||Boolean(structureError),saving,saveError,loginRequired,isEditor,canSettings,canRead,user,history,structureLoading,structureErrors,saveStructure,reloadStructure,saveEnhancementAttributes,reloadEnhancementAttributes,saveAssignments,reloadAssignments,saveRates,saveRateCriteria,begin,cancel,discard,discardChanges,apply,applySelection,save,reset,reloadLatest,refreshCatalog,updateCatalog:(key,document,commit,nextSha)=>{refreshCatalog(key,document,nextSha);if(commit)void history.recorded(commit,user,getMasterDefinition(key)?.path);else void history.refresh();},update}}><ToastNotice message={structureError?`기준정보를 불러오지 못했습니다. ${structureError}`:''} error/>{children}</State.Provider>;
}
export const useWorkList = () => useContext(State);

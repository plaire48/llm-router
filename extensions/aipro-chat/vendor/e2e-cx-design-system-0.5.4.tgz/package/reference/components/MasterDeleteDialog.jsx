import React from 'react';
import { CxConfirmation } from './CxConfirmation';

export function MasterDeleteDialog({ label, field, references = [], descendants = [], showUsageCount = true, onCancel, onConfirm }) {
  const count = new Set(references.map(item => item.rowId)).size;
  return <CxConfirmation title="항목을 삭제할까요?" className="master-delete-dialog" cancelLabel="취소" confirmLabel="삭제" onCancel={onCancel} onConfirm={onConfirm} message={<><p><strong>{label || '새 항목'}</strong></p><p>{count ? <>{showUsageCount ? <><strong>{count}개 Agent</strong>에서 </> : '기존 Agent에서 '}{field} 값으로 사용 중입니다.</> : `${field}에서 삭제됩니다.`}</p></>}>
    {references.length > 0 && <div className="master-delete-references" tabIndex={0} aria-label="사용 중인 Agent"><table><thead><tr><th scope="col">Agent</th><th scope="col">사용 중인 속성</th></tr></thead><tbody>{references.map((row, index) => <tr key={`${row.rowId}/${index}`}><td><strong>{row.task}</strong><span>{[row.process, row.activity].filter(Boolean).join(' / ')}</span></td><td><span>{row.field}</span><strong>{row.value}</strong></td></tr>)}</tbody></table></div>}
    {descendants.length > 0 && <details className="master-delete-descendants"><summary>함께 삭제되는 하위 항목 {descendants.length}개</summary><ul>{descendants.map(item => <li key={item.id}>{item.path}</li>)}</ul></details>}
    <p className="master-delete-note">저장하면 삭제됩니다.<br/>기존 Agent의 값은 유지되며 새로 선택할 수 없습니다.</p>
  </CxConfirmation>;
}

import React from 'react';
import {SelectionApplyDialog} from './SelectionApplyDialog';
import {useFeedback} from './Toast';
import {useWorkList} from './WorkListState';
import {workFieldValue} from './workListModel';

export function SelectionApplyConfirmation({change, onClose}) {
  const state = useWorkList();
  const [,notify] = useFeedback();
  const {ids, field, value, skipped=0} = change;
  const displayed = workFieldValue({[field.key]:value}, field, state.catalogs);
  const apply = () => {
    try { state.applySelection(ids, {[field.key]:value}); onClose(); }
    catch (error) { notify(error.message,true); }
  };
  return <SelectionApplyDialog count={ids.length} field={field.label} value={displayed}
    multiline={field.multiline} skipped={skipped} busy={state.saving} onCancel={onClose} onConfirm={apply}/>;
}

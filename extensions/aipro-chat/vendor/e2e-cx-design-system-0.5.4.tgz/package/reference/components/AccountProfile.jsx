import {ProfileTooltip,usePublicProfileHover} from './ProfileTooltip';
import React, { createContext, useContext, useEffect, useMemo, useState, useId } from 'react';
import { DetailPanel } from './DetailPanel';
import { Icon } from './Icon';
import { githubDisplayIdentity, githubIdentityLabel } from './githubIdentity';
import {createProfileClient} from './profileClient';
import {ActionButton,ActionLink} from './ActionButton';
import {E2E_ROLES} from './adminClient';
import './account-profile.css';

const Account = createContext(null);
export const useAccount = () => useContext(Account);
export function GithubAvatar({ user, size = 'md' }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [user?.avatar_url]);
  const name = user?.name || user?.login || '사용자';
  return user?.avatar_url && !failed ? <img className={`github-avatar github-avatar--${size}`} src={user.avatar_url} alt={`${name} GitHub 프로필`} onError={() => setFailed(true)} referrerPolicy="no-referrer" /> : <span className={`github-avatar github-avatar--${size} github-avatar--fallback`} aria-label={`${name} GitHub 프로필`}><Icon name="user" size={size === 'lg' ? 24 : 16}/></span>;
}

// Identity comes from GHES login. There is no separate personal profile store.
export function AccountProvider({ user, children }) {
  return <Account.Provider value={{user:githubDisplayIdentity(user)}}>{children}</Account.Provider>;
}

export function AccountProfile({ onClose, client }) {
  const {user} = useAccount();
  return <GithubProfilePanel account={user} title="내 프로필" onClose={onClose} client={client}/>;
}

export function ProfileIdentity({user,size='sm'}) {
  const [open,setOpen]=useState(false),id=useId(),hover=usePublicProfileHover(user);
  return <><button type="button" className="profile-identity-button" {...hover.handlers} aria-describedby={hover.card?id:undefined} disabled={!user?.login} aria-label={`${githubIdentityLabel(user)} 프로필 보기`} onClick={event=>{event.currentTarget.focus();hover.close();setOpen(true);}}><GithubAvatar user={user} size={size}/><strong>{githubIdentityLabel(user)}</strong></button>{hover.card&&<ProfileTooltip id={id} {...hover.card} onMouseEnter={hover.keep} onMouseLeave={hover.leave}/>} {open&&<GithubProfilePanel account={user} onClose={()=>setOpen(false)}/>}</>;
}

export function GithubProfilePanel({account,title='프로필',onClose,client:providedClient}) {
  const [profile,setProfile]=useState(null),[error,setError]=useState(''),[loading,setLoading]=useState(true),[revision,setRevision]=useState(0);
  const client=useMemo(()=>providedClient||createProfileClient(),[providedClient,account?.id,account?.login,revision]);
  useEffect(()=>{
    const controller=new AbortController();setLoading(true);setError('');setProfile(null);
    client.load(account,{signal:controller.signal}).then(value=>{if(!controller.signal.aborted)setProfile(value);}).catch(reason=>{if(!controller.signal.aborted)setError(reason.message);}).finally(()=>{if(!controller.signal.aborted)setLoading(false);});
    return()=>controller.abort();
  },[client,account?.id,account?.login,revision]);
  const identity=profile||account,role=E2E_ROLES.find(item=>item.key===profile?.role)?.label;
  return <DetailPanel helpTopic="account" title={title} onClose={onClose} className="account-profile-panel">
    <div className="profile-hero"><GithubAvatar user={identity} size="lg"/><div className="profile-heading"><h3>{identity?.name||identity?.login}</h3><span className="profile-login">@{identity?.login}</span>{role&&<span className="profile-role">{role}</span>}</div></div>
    {loading?<div className="profile-feedback" role="status"><span className="status-spinner" aria-hidden="true"/>프로필을 불러오는 중…</div>:error?<div className="profile-feedback is-error" role="alert"><p>{error}</p><ActionButton action="refresh" label="프로필 다시 불러오기" onClick={()=>setRevision(value=>value+1)}/></div>:profile&&<>
      {profile.bio&&<p className="account-bio">{profile.bio}</p>}
      {profile.company&&<section className="profile-section"><div className="profile-section-heading"><h3>소속</h3></div><dl className="profile-facts"><div><dt>부서</dt><dd>{profile.company}</dd></div></dl></section>}
      <section className="profile-section"><div className="profile-section-heading"><h3>기본 정보</h3><div className="profile-section-actions"><ActionButton action="refresh" label="프로필 새로고침" onClick={()=>setRevision(value=>value+1)}/><ActionLink action={profile.own?"edit":"openExternal"} label={profile.own?"GitHub 프로필 수정":"GitHub에서 보기"} className="profile-github-link" href={profile.own?`https://${new URL(profile.html_url).host}/settings/profile`:profile.html_url} target="_blank" rel="noopener noreferrer"/></div></div><dl className="profile-facts">
        <div><dt>이메일</dt><dd>{profile.email?<a href={`mailto:${encodeURIComponent(profile.email)}`}>{profile.email}</a>:profile.unavailable.includes('email')?'조회 권한 확인 필요':'비공개 또는 미등록'}</dd></div>
        {!role&&<div><dt>권한</dt><dd>확인할 수 없음</dd></div>}
        {profile.location&&<div><dt>위치</dt><dd>{profile.location}</dd></div>}
        {profile.blog&&<div><dt>웹사이트</dt><dd><a href={profile.blog} target="_blank" rel="noopener noreferrer">{profile.blog.replace(/^https?:\/\//,'')}</a></dd></div>}
      </dl></section>
      {(profile.socials.length>0||profile.unavailable.includes('socials'))&&<section className="profile-section"><div className="profile-section-heading"><h3>소셜 계정</h3></div>{profile.socials.length>0?<ul className="profile-social-list">{profile.socials.map(item=><li key={item.url}><a href={item.url} target="_blank" rel="noopener noreferrer"><Icon name="link" size={16}/><span>{item.provider||new URL(item.url).hostname}<small>{item.url.replace(/^https?:\/\//,'')}</small></span><Icon name="linkExternal" size={16}/></a></li>)}</ul>:<p className="profile-note">소셜 계정을 불러오지 못했습니다.</p>}</section>}
    </>}
  </DetailPanel>;
}

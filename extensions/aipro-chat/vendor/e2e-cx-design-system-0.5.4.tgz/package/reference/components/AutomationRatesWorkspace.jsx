import { ActionButton } from './ActionButton';
import {useFeedback} from './Toast';
import {SettingsGrid, SettingsCommitInput, useSettingsGrid, useSettingsApply} from './SettingsGrid';
import {useBeforeUnload} from './useBeforeUnload';
import { CxConfirmation } from './CxConfirmation';
import { confirmationCopy } from './confirmationCopy';
import { TableEditModeButton } from './TableEditModeButton';
import React, { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { DetailPanel } from './DetailPanel';
import { MasterActionButton } from './MasterActionButton';
import { useWorkList } from './WorkListState';
import { automationCriterionRows, changedAutomationCriteria } from './automationCriteria';
import { decimalValue } from './operatingMetrics';
import { formatAutomationRate } from './automationRate';
import { hierarchySelection, nodePath, orderedNodes, structureDefinition } from './hierarchyModel';
import { AutomationRateSource } from './AutomationRateSource';

const FlowAssessmentEditor = lazy(() => import('./FlowAssessmentEditor'));
const definition = structureDefinition('standardProcesses');
function RateLevelTable({level,label,nodes,parentId,selection,editAll,editors,changed,rates,valueFor,state,unavailable,invalid,focus,onChoose,onChange,onBegin,onEnd,onFlow,onBatch}) {
  const task=level==='task';
  const grid=useSettingsGrid({id:`settings.automationRates.${level}`,label:`자동화율 ${label}`,scope:parentId,rows:nodes.map(node=>({...node,selectionLabel:`${label} ${node.label}`})),columns:[
    {key:'label',label:'이름',width:220},
    ...(task?[{key:'rate',label:'자동화율 (%)',width:190,value:node=>valueFor(node.id)===''?null:Number(valueFor(node.id)),filterValue:node=>rates.get(node.id)}]:[]),
  ]});
  const batch=useSettingsApply(grid,{disabled:unavailable});
  return <><SettingsGrid grid={grid} compact nameHeading={{label,count:nodes.length}} focusId={focus?.edit?focus.id:null} rowProps={node=>({'data-rate-task-id':node.id,className:`${selection===node.id?'is-current':''} ${changed.includes(node.id)?'has-changes':''}`})} renderCell={(node,field)=>{
    if(field==='label')return <button type="button" className="hierarchy-select" aria-pressed={selection===node.id} onClick={()=>onChoose(node)}><span>{node.label}</span></button>;
    const editing=editAll||Boolean(editors[node.id]);
    return editing?<label className="automation-rate-input"><SettingsCommitInput type="number" className="text-input" data-rate-id={node.id} aria-label={`${node.label} 자동화율`} aria-invalid={invalid===node.id||undefined} value={valueFor(node.id)} min="0" max="100" step="any" inputMode="decimal" disabled={unavailable} onChange={event=>onChange(node.id,event.target.value)} onCommit={value=>batch.offer({rowId:node.id,field:'자동화율 (%)',value,apply:targets=>onBatch(targets,value)})} onKeyDown={event=>{if(!editAll&&event.key==='Escape'){event.preventDefault();event.stopPropagation();onEnd(node.id,true);}}}/><span>%</span></label>:<div className="rate-criterion-controls"><span className="rate-criterion-value">{valueFor(node.id)===''?'—':formatAutomationRate(valueFor(node.id))}</span><AutomationRateSource pending={changed.includes(node.id)} entry={changed.includes(node.id)?{rate:valueFor(node.id)===''?null:Number(valueFor(node.id)),rateSource:'manual'}:state.automationRates[node.id]||{rate:rates.get(node.id)}} label={node.label}/></div>;
  }} renderActions={level==='process'?undefined:node=>{
    if(level==='activity')return <ActionButton action={state.canSettings?'upload':'view'} className="master-action" aria-label={`${node.label} YAML ${state.canSettings?'업로드':'보기'}`} title={state.canSettings?'YAML 업로드':'YAML 보기'} disabled={state.loading||state.saving||Boolean(state.loadError)} onClick={()=>onFlow({activityId:node.id})}/>;
    return !editAll&&editors[node.id]?<><MasterActionButton action="complete" label={node.label} disabled={unavailable} onClick={()=>onEnd(node.id)}/><MasterActionButton action="cancel" label={node.label} disabled={unavailable} onClick={()=>onEnd(node.id,true)}/></>:<><ActionButton action="workflow" type="button" className="master-action" aria-label={`${node.label} 워크플로우 ${state.canSettings?'수정':'보기'}`} title="워크플로우" disabled={state.loading||state.saving||Boolean(state.loadError)} onClick={()=>onFlow({activityId:node.parentId,taskId:node.id})}/>{state.canSettings&&!editAll&&<MasterActionButton action="edit" label={`${node.label} 자동화율`} disabled={unavailable} onClick={()=>onBegin(node.id)}/>}</>;
  }}/>{batch.dialog}</>;
}

export function AutomationRatesWorkspace({ onBack, onPendingChange, embedded = false }) {
  const state = useWorkList(), source = state.catalogs.standardProcesses;
  const criteria = automationCriterionRows(source, state.savedRows, state.automationRates);
  const rates = new Map(criteria.map(item => [item.id, item.rate]));
  const [editAll,setEditAll]=useState(false);
  const [drafts, setDrafts] = useState({}), [editors, setEditors] = useState({});
  const [selected, setSelected] = useState(() => hierarchySelection(definition, source.items));
  const [invalid, setInvalid] = useState(null), [focus, setFocus] = useState(null);
  const [opened, setOpened] = useState(null), [flowPending, setFlowPending] = useState({dirty:false,saving:false}), [confirmation, setConfirmation] = useState(null);
  const panel = useRef(null), pending = useRef(false);
  const changed = Object.keys(drafts).filter(id => {
    try { return !rates.has(id) || decimalValue(drafts[id], {label:'자동화율',max:100,optional:true}) !== rates.get(id); }
    catch { return true; }
  });
  const dirty = changed.length > 0;
  const unavailable = !state.canSettings || state.loading || state.saving || state.loadError;
  const [,notify]=useFeedback();
  const valueFor = id => Object.hasOwn(drafts,id) ? drafts[id] : rates.get(id) ?? '';
  useEffect(() => {setSelected(current => hierarchySelection(definition, source.items, current));}, [source]);
  useEffect(() => {onPendingChange?.({dirty:dirty||flowPending.dirty,saving:state.saving||flowPending.saving});}, [dirty,flowPending,state.saving,onPendingChange]);
  useBeforeUnload(dirty);
  useEffect(() => {
    if (!focus) return;
    const row = panel.current?.querySelector(`[data-rate-task-id="${CSS.escape(focus.id)}"]`);
    row?.querySelector(focus.edit ? 'input[type=number]' : '[data-master-action="edit"]')?.focus();
  }, [focus]);
  const choose = (node,index) => setSelected(hierarchySelection(definition,source.items,[...visibleSelection.slice(0,index),node.id]));
  const begin = id => {
    if (unavailable) return;
    setEditors(current=>({...current,[id]:{value:valueFor(id),hadDraft:Object.hasOwn(drafts,id)}}));
    setSelected(nodePath(source.items,id).map(item=>item.id));setFocus({id,edit:true});setInvalid(null);notify('');
  };
  const end = (id,cancel=false) => {
    if (unavailable) return;
    if (!cancel) {
      try {decimalValue(valueFor(id),{label:'자동화율',max:100,optional:true});}
      catch(reason){setInvalid(id);setFocus({id,edit:true});notify(reason.message,true);return;}
    } else {
      const original=editors[id];
      setDrafts(current=>{const next={...current};if(original.hadDraft)next[id]=original.value;else delete next[id];return next;});
    }
    setEditors(current=>{const next={...current};delete next[id];return next;});setInvalid(null);setFocus({id,edit:false});notify('');
  };
  const discard=()=>{setDrafts({});setEditors({});setInvalid(null);setFocus(null);setConfirmation(null);};
  const reset = () => {
    if (unavailable) return;
    discard();notify('마지막 저장 상태로 초기화했습니다.');
  };
  const save = async () => {
    if (unavailable || pending.current) return;
    try {changedAutomationCriteria(source,state.savedRows,state.automationRates,drafts);}
    catch(reason){setInvalid(reason.taskId);setSelected(nodePath(source.items,reason.taskId).map(item=>item.id));setEditors(current=>({...current,[reason.taskId]:current[reason.taskId]||{value:rates.get(reason.taskId)??'',hadDraft:false}}));setFocus({id:reason.taskId,edit:true});notify(reason.message,true);return;}
    if (!dirty) {setDrafts({});setEditors({});notify('변경 사항이 없습니다.');return true;}
    pending.current=true;
    try {
      const result=await state.saveRateCriteria(drafts);
      if (!result) {notify('저장하지 못했습니다. 수정값은 유지됩니다.',true);return;}
      setDrafts({});setEditors({});setInvalid(null);notify(result.commit?'저장했습니다.':'변경 사항이 없습니다.');return true;
    } catch(reason){notify(reason.message,true);}
    finally {pending.current=false;}
  };
  const close=()=>{if(state.saving)return;if(dirty){setConfirmation({type:'close'});return;}onBack?.();};
  const openFlow=next=>{if(state.saving||state.loading||state.loadError)return;if(dirty){setConfirmation({type:'workflow',next});return;}setEditors({});setDrafts({});setOpened(next);};
  const confirm=()=>{const next=confirmation;reset();if(next.type==='workflow')setOpened(next.next);if(next.type==='close')onBack?.();};
  const visibleItems=source.items;
  const visibleSelection=hierarchySelection(definition,visibleItems,selected);
  return <DetailPanel helpTopic="automation" busy={state.saving} title="자동화율 산정" embedded={embedded} hideHeading={embedded} className="hierarchy-panel automation-criteria-panel flow-criteria-workspace" onClose={close} footer={state.canSettings?<><span className="list-panel-mode">{dirty?'저장 전':''}</span><ActionButton action="reset" type="button" onClick={()=>dirty?setConfirmation({type:'reset'}):reset()} disabled={unavailable || !dirty&&!Object.keys(editors).length}/><TableEditModeButton active={editAll} onChange={value=>{setEditAll(value);setEditors({});}} dirty={dirty} onSave={save} onDiscard={discard} disabled={unavailable}/><ActionButton action="save" busy={state.saving} type="button" onClick={save} disabled={unavailable}/></>:null}>

    <div ref={panel} className="hierarchy-columns automation-criteria-columns">{definition.levels.map(([level,label],index)=>{
      const parentId=index?visibleSelection[index-1]:null;
      const nodes=orderedNodes(visibleItems.filter(item=>item.level===level&&(!index||parentId&&item.parentId===parentId)));
      return <section className={`hierarchy-column ${level==='task'?'automation-criteria-tasks':''}`} key={level} aria-label={`자동화율 ${label} 목록`}>
        <RateLevelTable level={level} label={label} nodes={nodes} parentId={parentId} selection={visibleSelection[index]} editAll={editAll} editors={editors} changed={changed} rates={rates} valueFor={valueFor} state={state} unavailable={unavailable} invalid={invalid} focus={focus} onChoose={node=>choose(node,index)} onChange={(id,value)=>{setDrafts(current=>({...current,[id]:value}));setInvalid(null);notify('');}} onBegin={begin} onEnd={end} onFlow={openFlow} onBatch={(targets,value)=>{setDrafts(current=>({...current,...Object.fromEntries(targets.map(node=>[node.id,value]))}));setInvalid(null);notify('');}}/>
      </section>;
    })}</div>
    {opened&&<Suspense fallback={<p className="visually-hidden" role="status">워크플로우를 불러오는 중…</p>}><FlowAssessmentEditor activityId={opened.activityId} initialTaskId={opened.taskId} onClose={()=>setOpened(null)} onPendingChange={setFlowPending}/></Suspense>}
    {confirmation&&<CxConfirmation {...confirmationCopy(confirmation.type)} className="flow-confirm-dialog" busy={state.saving} onCancel={()=>setConfirmation(null)} onConfirm={confirm}/>}
  </DetailPanel>;
}

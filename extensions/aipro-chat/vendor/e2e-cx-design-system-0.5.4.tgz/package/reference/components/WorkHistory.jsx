import { DateRangeFilter } from './DateRangeFilter';
import {SearchField} from './SearchField';
import { searchHistory, shortCommit } from './historySearch';
import { ActionButton } from './ActionButton';
import {ToastNotice} from './Toast';
import React, { useEffect, useId, useRef, useState } from 'react';
import { CxTabs } from './CxTabs';
import { PageSizeSelect, TablePagination, usePagination } from './TableControls';
import { HISTORY_FILTERS, historyCategories, historyEntryKey } from './changeHistory';
import { EmptyState } from './EmptyState';
import { DetailPanel } from './DetailPanel';
import { Icon } from './Icon';
import { GithubAvatar } from './AccountProfile';
import { githubIdentityLabel } from './githubIdentity';
import { getGithubSession } from './session';
import { workFieldValue } from './workListModel';
import { useWorkList } from './WorkListState';
import { commitPreviewChanges } from './commitPreviewModel';
import { CommitId } from './CommitReference';

export const historyDate = value => {
  const date = value && new Date(value);
  return date && !Number.isNaN(date.getTime()) ? new Intl.DateTimeFormat('ko-KR', { dateStyle:'medium',timeStyle:'short' }).format(date) : '시각 확인 안 됨';
};

function HistoryValue({change, value, catalogs}) {
  if (value == null || value === '') return <span className="history-value-empty" aria-label="값 없음">—</span>;
  if (change.field.kind === 'github-profile') return <span className="history-person"><GithubAvatar user={value}/><span>{githubIdentityLabel(value)}</span></span>;
  if (change.field.kind === 'datetime') return <time dateTime={value}>{historyDate(value)}</time>;
  if (change.field.kind === 'catalog') return String(value);
  if (change.field.multiline) return <span className="history-value-multiline">{String(value)}</span>;
  return workFieldValue({[change.field.key]:value},change.field,catalogs) || <span className="history-value-empty" aria-label="값 없음">—</span>;
}

function HistoryComparison({changes, catalogs}) {
  const groups = new Map();
  changes.forEach(change=>{
    const key=JSON.stringify([change.rowId,change.task]);
    if(!groups.has(key))groups.set(key,{target:[change.process,change.activity,change.task].filter(Boolean).join(' / '),changes:[]});
    groups.get(key).changes.push(change);
  });
  return <div className="history-groups">{[...groups].map(([key,group])=>{
    const path=group.target?.split(' / ')||[],name=path.pop();
    return <section className="history-group" key={key}>
      <table className="work-history-comparison">
        <caption>{path.length>0&&<span className="history-target-path">{path.join(' / ')}</span>}<strong>{name||'E2E Agent'}</strong></caption>
        <thead><tr><th scope="col">항목</th><th scope="col">변경 전</th><th scope="col">변경 후</th></tr></thead>
        <tbody>{group.changes.map((change,index)=><tr key={`${change.field.key}:${index}`}>
          <th scope="row" className="history-field">{change.label}<small>{change.type}</small></th>
          <td className="history-before" data-label="변경 전"><HistoryValue change={change} value={change.before} catalogs={catalogs}/></td>
          <td className="history-after" data-label="변경 후"><HistoryValue change={change} value={change.after} catalogs={catalogs}/></td>
        </tr>)}</tbody>
      </table>
    </section>;
  })}</div>;
}

export function WorkHistoryMenu({ loadRevision }) {
  const { canRead: isEditor, history, catalogs, setStatus } = useWorkList();
  const copyCommit=async sha=>{
    try {await navigator.clipboard.writeText(sha);setStatus('커밋 ID를 복사했습니다.');}
    catch {setStatus('커밋 ID를 복사하지 못했습니다. 원본에서 확인하세요.',true);}
  };
  const panelId = useId();
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [revisions, setRevisions] = useState({});
  const sessionVersion=useRef(0);
  const [category,setCategory]=useState('all');
  const [query,setQuery]=useState(''),[from,setFrom]=useState(''),[to,setTo]=useState('');
  const filtered=Boolean(query.trim()||from||to);
  const items=searchHistory(history.items.filter(item=>category==='all'||historyCategories(item).includes(category)),{query,from,to});
  const filterKey=JSON.stringify([category,query,from,to]);
  const pagination=usePagination('change-history',items,filterKey);
  const clearFilters=()=>{setQuery('');setFrom('');setTo('');};
  useEffect(()=>{setExpanded(null);document.querySelector('.work-history-scroll')?.scrollTo(0,0);},[filterKey,pagination.page,pagination.size]);
  useEffect(()=>{if(!isEditor){setRevisions({});setExpanded(null);setCategory('all');clearFilters();}return()=>{sessionVersion.current++;};},[isEditor]);
  const expand = async (key, retry = false) => {
    const entry=history.items.find(item=>historyEntryKey(item)===key),sha=entry?.sha;
    if(!entry)return;
    if(expanded===key && !retry){setExpanded(null);return;}
    setExpanded(key);
    if(revisions[key]?.changes || revisions[key]?.loading) return;
    setRevisions(current=>({...current,[key]:{loading:true}}));
    const version=sessionVersion.current;
    try {
      const revision = await (loadRevision?loadRevision({...getGithubSession(),sha,paths:entry?.paths,repositoryScope:entry?.repositoryScope}):history.revision(entry));
      if(version!==sessionVersion.current)return;
      setRevisions(current=>({...current,[key]:{changes:commitPreviewChanges(revision),editor:revision.editor}}));
    } catch(e) {if(version===sessionVersion.current)setRevisions(current=>({...current,[key]:{error:e.message}}));}
  };
  return <>
    <ActionButton action="history" type="button" className="topbar-history-button" aria-label="변경 이력" onClick={()=>setOpen(true)}/>
    {open&&<DetailPanel helpTopic="history" title="변경 이력" className="work-history-panel" onClose={()=>setOpen(false)} footer={isEditor?<TablePagination as="div" pagination={pagination}/>:null}>
      {!isEditor?<EmptyState icon="clockRewind" title="로그인 후 이력을 확인하세요"><a className="cx-button cx-button--primary" href="#login"><Icon name="logIn" size={18}/>로그인</a></EmptyState>:<>
        <CxTabs items={HISTORY_FILTERS} active={category} onChange={setCategory} label="변경 이력 구분" idPrefix={`${panelId}-tab`} panelId={`${panelId}-history`} className="work-history-tabs"/>
        <div className="history-search-controls" role="search" aria-label="변경 이력 검색">
          <DateRangeFilter from={from} to={to} onChange={value=>{setFrom(value.from);setTo(value.to);}}/>
          <div className="history-search-field"><span className="history-filter-label" aria-hidden="true">검색</span><SearchField className="history-search" label="커밋 ID, 수정자, 변경 제목 검색" placeholder="커밋 ID, 수정자, 변경 제목" value={query} onChange={setQuery}/></div>
          <ActionButton action="reset" type="button" aria-label="이력 검색 초기화" disabled={!filtered} onClick={clearFilters}/>
        </div>
        <div className="work-history-toolbar"><div className="work-history-count"><span>{filtered?'검색 결과':'전체'} <strong>{items.length.toLocaleString()}</strong>건</span><PageSizeSelect pagination={pagination}/></div><ActionButton action="refresh" type="button" aria-label="변경 이력 새로고침" title="새로고침" disabled={history.loading} onClick={history.refresh}/></div>
        <div id={`${panelId}-history`} role="tabpanel" aria-labelledby={`${panelId}-tab-${category}`} className="work-history-scroll" aria-busy={history.loading}>
        {history.error&&<ToastNotice error message={history.error} actions={[{label:'다시 조회',onClick:history.refresh}]}/>}
        <ol className="work-history-list" start={pagination.start+1}>{pagination.rows.map(item=>{
          const key=historyEntryKey(item),detail=revisions[key], detailId=`${panelId}-${item.sha}`;
          return <li key={key}>
            <button type="button" className="work-history-entry" onClick={()=>expand(key)} aria-expanded={expanded===key} aria-controls={expanded===key?detailId:undefined}>
              <GithubAvatar user={item.author} size="md"/>
              <span className="work-history-entry-copy"><strong>{githubIdentityLabel(item.author)}</strong><span>{item.message.replace(/\s*(?:·\s*)?@[\w-]+\s*$/,'').replace(/[·•]/g,' ')}</span></span>
              <span className="history-entry-meta"><time dateTime={item.date}>{historyDate(item.date)}</time><CommitId sha={item.sha}/></span><Icon name={expanded===key?'chevronUp':'chevronDown'} size={18}/>
            </button>
            {expanded===key&&<div id={detailId} className="work-history-diff">
              {detail?.loading?<p role="status" className="work-history-state"><span className="status-spinner" aria-hidden="true"/>변경 내용을 불러오는 중…</p>:detail?.error?<ToastNotice error message={detail.error} actions={[{label:'다시 조회',onClick:()=>expand(key,true)}]}/>:<>
                {detail?.changes?.length?<HistoryComparison changes={detail.changes} catalogs={catalogs}/>:<p className="work-history-state">표시 항목에 변경이 없습니다.</p>}
              </>}
              {shortCommit(item.sha)&&<div className="work-history-reference">
                <ActionButton action="copy" type="button" aria-label="전체 커밋 ID 복사" title="전체 커밋 ID 복사" onClick={()=>copyCommit(item.sha)}/>
                {item.htmlUrl&&<a href={item.htmlUrl} target="_blank" rel="noreferrer">원본 보기 <Icon name="linkExternal" size={16}/></a>}
              </div>}
            </div>}
          </li>;
        })}</ol>
        {history.loading?<p role="status" className="work-history-state"><span className="status-spinner" aria-hidden="true"/>이력을 불러오는 중…</p>:!items.length&&!history.error?<EmptyState icon="clockRewind" title={filtered?'검색 결과가 없습니다.':'아직 반영된 변경이 없습니다.'} description={filtered?'날짜나 검색어를 바꿔 확인하세요.':'저장한 변경만 표시됩니다.'}/>:null}
        </div>
      </>}
    </DetailPanel>}
  </>;
}

export function WorkLastModified() {
  const {history} = useWorkList();
  const latest = history.latest || (history.published?.date ? history.published : null);
  return <div className="topbar-last-modified" title={history.error&&latest?'최근 저장 시각입니다. 최신 이력 조회에 실패했습니다.':undefined}>
    <span>최종 변경일</span><strong>{latest?<time dateTime={latest.date}>{historyDate(latest.date)}</time>:history.loading?'조회 중…':history.error?'조회 실패':'기록 없음'}</strong>
  </div>;
}

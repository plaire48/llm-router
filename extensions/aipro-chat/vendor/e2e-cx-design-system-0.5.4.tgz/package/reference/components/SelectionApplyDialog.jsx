import React from 'react';
import {CxConfirmation} from './CxConfirmation';
import './selection-apply.css';

export function SelectionApplyDialog({count,field,value,multiline=false,skipped=0,busy,onCancel,onConfirm,className=''}) {
  return <CxConfirmation title={`선택한 ${count.toLocaleString('ko-KR')}건에 같은 값을 적용할까요?`}
    message="아래 항목만 변경합니다." icon="copy01"
    cancelLabel="현재 행만 수정" confirmLabel="선택 항목에 적용"
    onCancel={onCancel} onConfirm={onConfirm} busy={busy} className={`selection-apply-confirm ${className}`}>
    <dl className={`selection-apply-value ${multiline?'is-multiline':''}`}><dt>{field}</dt><dd>{value || '값 지우기'}</dd></dl>
    {skipped>0&&<p className="selection-apply-hint">수정할 수 없는 {skipped}건은 제외됩니다.</p>}
    <p className="selection-apply-hint">다른 페이지에서 선택한 행도 포함됩니다.<br/>저장을 눌러야 반영됩니다.</p>
  </CxConfirmation>;
}

# YAML upload metadata and CX review

Verified locally on 2026-09-10 in `/Users/ganadi/Downloads/e2e-report`.

## Final layout

- Modal heading identifies the Activity. The Process is secondary text; Task is selected once in the workflow toolbar.
- Agent Flow (16px) and YAML 업로드 occupy the first row.
- Upload information has its own pale surface, 1px border and 6px radius below that row. Order: GitHub avatar, uploader name, filename, upload time. Names and filenames use 14px; time uses 13px. On narrow screens, filenames wrap instead of being clipped.
- Task selection and quiet canvas controls precede the workflow. Action count and Task automation rate share the table action bar. Action table content uses 14px; mobile inputs retain 16px and 44px height.
- Calculation paragraphs and repeated guidance were removed from the modal and retained in Help. The manual effective rate remains distinguishable from the calculated rate.
- Empty, invalid YAML, file selection, replacement confirmation, unsaved, saved, failed-save and no-change states retain their relevant controls and feedback. Empty-state guidance is hidden while selecting an imported Activity.
- The shared opaque panel, header Help/Close controls and fixed Reset/Save footer remain in use.

The component-spec skill's anatomy, states, responsive behavior and accessibility checks informed the review. Reference styling follows the user's supplied CX table, action bar, card and dialog examples with the existing signature blue.

## Upload attribution and saved revisions

`automationRates[activityId].assessment.upload` stores `at` and `by`. The latter contains only GitHub public identity fields: id, login, name, avatar_url and html_url. Attribution comes from the signed-in user, not from YAML contents.

The metadata is captured when the import is applied and persists with the workflow on successful Save. Action-only and scoring-only edits retain the existing uploader and upload date. Legacy files without recorded attribution show their filename without invented metadata.

An identical final assessment retains its previous upload metadata. Re-uploading the same content, including reverting A to B to A, therefore does not generate a timestamp-only commit. Save failure retains the draft. Retrying after an uncertain response detects the already committed assessment.

History groups changes by target rather than repeating long target paths in every row. Each group has labelled before/after columns, pale blue saved values and a visible target caption. GitHub upload attribution and timestamps are displayed from the particular saved revision. Changes to subsequent files do not rewrite older revisions. Mobile comparison values remain side by side beneath the field label.

## Verification

- `npm test`: **115 passed, 0 failed**. Includes upload metadata round-trip, profile field filtering, preserved metadata on Action/weight changes, no-op and legacy handling, and uncertain-save retry behavior.
- `npm run build`: passed. The existing bundle-size warning remains.
- `scripts/yaml-upload-history-smoke.js`: **16 checks passed** at 1440px, 390px and 320px. Uses `scripts/agent-flow-fixture.js` with local persistence and revision loaders.
- `scripts/cx-layout-history-smoke.js`: **30 checks passed** at 1440px, covering opaque surfaces, typography, exact revision values, loading/error/retry, pagination, refresh failure retention, keyboard close/focus restoration and public last-modified behavior.
- Visual inspection of desktop and mobile modal and history. At 320px and 390px there was no horizontal overflow outside the intentionally scrollable Action table/canvas. A long Korean filename wrapped inside the metadata box.
- Additional 320px checks: empty-state Save disabled, invalid YAML error retained, Activity select 44px high, import card contained within the viewport, and Help closes back to the editor.
- Final computed desktop styles: section title 16px, table and upload information 14px, metadata below title, 1px box border, background rgb(247, 248, 251). One shared Help control; no calculation paragraph. No browser console warnings/errors on the inspected dev page.

Logs: `yaml-upload-history-tests.log`, `yaml-upload-history-build.log`.

All edits and persistence tests used isolated local data. No actual GHES writes or production authentication verification were performed.

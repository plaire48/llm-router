# CX 탭과 조회 조건 수정

2026-09-10, `/Users/ganadi/Downloads/e2e-report`

## 변경

- 제공된 CX 헤더/탭 이미지에 맞춰 데스크톱 상단 메뉴의 채워진 배경, 둥근 모서리, 그림자를 제거했다. 현재 메뉴는 파란 글자와 2px 하단 선으로 표시한다. 호버도 투명 배경을 유지하며 키보드 포커스 테두리는 헤더 안에 표시한다.
- 조회 조건 순서는 Process → Activity → 담당그룹이다. Process를 선택하면 그 Process에 속한 Activity를 표시하고 이전 Activity 선택을 해제한다. Process를 선택하지 않고 Activity만 조회할 수도 있다.
- Activity 조건을 목록, 개수, 검색, 담당그룹, CSV 내보내기, 페이지 초기화 및 행 선택 해제에 연결했다. 기준 설정으로 이동했다 돌아오면 조건을 보존한다. 필터 해제는 세 조건 모두 지운다.
- 모바일은 긴 Process/Activity 이름을 읽을 수 있도록 세로 배치한다. 태블릿은 세 열과 별도 초기화 행, 데스크톱은 세 열과 초기화 버튼을 같은 줄에 배치한다.

## 검증

- `npm run build`: exit 0, `✓ built in 567ms`. `cx-tabs-filters-build.log`에 출력 보관.
- `scripts/cx-tabs-filters-smoke.js`: 20개 통과. 실제 158개 복원 데이터로 조건 연동, 17개 Process 결과에서 4개 Activity 결과로 전환, 페이지 및 선택 초기화, 담당그룹/검색 교집합, CSV, 빈 결과, 화면 이동 후 조건 유지, 리셋 및 탭 키보드 이동 확인. 실제 다운로드/GHES 쓰기 0회.
- `scripts/cx-refinement-public-smoke.js`: 기존 화면 검증 25개 통과.
- 1440px 데스크톱과 390px 모바일 화면을 스크린샷으로 확인했다. 모바일의 세 입력은 각각 332px × 44px이며 Activity 결과 4개와 페이지 넘침 없음을 확인했다.
- 901px 및 768px 너비에서도 조회 조건이 페이지 밖으로 넘치지 않음을 확인했다.
- 개발/preview 페이지 콘솔 오류 및 경고 없음.

## 파일

제품 소스 변경: `src/WorkList.jsx`, `src/cx-system.css`.
변경 전 복사본: `cx-tabs-filters-before/`. 이번 수정 비교: `cx-tabs-filters.diff`.
Git 저장소가 아니므로 HEAD/브랜치는 없고 `git status`는 exit 128이다. 이전 변경은 유지했다.

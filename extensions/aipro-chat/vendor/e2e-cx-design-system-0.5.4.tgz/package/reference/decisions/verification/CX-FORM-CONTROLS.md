# CX text and selection controls

2026-09-10, local verification in `/Users/ganadi/Downloads/e2e-report`.

## Shared rules

- Text, numeric, native single-select and implementation-method multi-select fields use the same CX font, border, radius, height and state treatment.
- Desktop values: Noto Sans KR, 14px, 36px control height, 12px horizontal content inset, 5px radius.
- Narrow/touch values: 16px, 44px height. Readable content and field labels keep their own hierarchy instead of inheriting the larger input size.
- Native selects and multi-select triggers reserve 40px on the right. Both chevrons use the same 16px glyph and sit 12px from the right edge.
- Labels sit above the standard-process parent dropdown and name input with an 8px gap. Desktop fields share a baseline and equal width; narrow layouts stack them.
- Focus/open, disabled, empty and invalid states share colors. Search fields keep their leading icon inset. Compact pagination metadata remains compact.
- Native selects retain native selection and keyboard behavior; their expanded picker remains browser/OS-managed. The app-rendered implementation-method popup uses the shared 14px/16px typography and 44px option rows.

## Browser checks

Used isolated local fixtures, with no actual GHES writes.

- `scripts/agent-flow-multimethod-smoke.js`: 15 checks passed at 1440px and 390px. Covers multiple selections, highest-weight calculation, keyboard focus, Escape/Tab, Save/Reset, failed-save retry and retained disabled state.
- Computed styles for every workflow select and multi-select: desktop 14px/36px, mobile 16px/44px, left padding 12px and right padding 40px.
- Standard-process Activity editor: parent select and name input both 36px high with identical top positions and widths; 12px labels with 8px gaps. Visually inspected.
- Focused text field: 2px outline and blue border. Marking it invalid preserves the red error border.
- All three Agent filters and the editable Agent row were checked in desktop and mobile layouts. Input values and dropdown values match font and height; dropdown arrows are present and have reserved space. No mobile page overflow.
- The popup was visually inspected for option spacing, type size, selected state and trigger alignment.

Build and test output: `cx-controls-build.log`, `cx-controls-tests.log`.

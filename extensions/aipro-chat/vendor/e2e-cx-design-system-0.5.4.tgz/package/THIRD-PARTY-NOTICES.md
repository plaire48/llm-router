# 포함된 자산

Noto Sans KR 가변 WOFF2 원본은 SIL Open Font License 1.1로 배포됩니다. 라이선스 전문은 fonts/OFL.txt와 dist/fonts/OFL.txt에 있습니다. fonts/README.md에 원본 경로와 포맷을 기록했습니다.

카탈로그의 브라우저 예제에는 React와 React DOM 코드가 포함됩니다. MIT 라이선스 전문은 catalog/REACT-LICENSE.txt와 catalog/REACT-DOM-LICENSE.txt에 함께 배포합니다. 설치용 라이브러리는 React를 번들에 넣지 않고 peer dependency로 사용합니다.

기존 E2E Report 코드·스타일의 소유권이나 공개 라이선스를 새로 부여하지 않습니다. 패키지의 UNLICENSED는 공용 오픈소스 라이선스를 선언하지 않았다는 의미입니다.

import React,{useState,useRef} from 'react';
import {CxAppShell,CxPageHeader,CxCard,CxField,CxInput,CxSelect,CxTextarea,CxCheckbox,CxStatus,CxNotice,CxTable,CxButton,ActionButton,CxTabs,DetailPanel,CxConfirmation,notifyToast,confirmationCopy} from '@e2e/cx-design-system';

const initialRows=[{id:'example-1',name:'고객 문의 분류',status:'사용 중',description:'문의 내용을 확인하고 담당 업무로 연결합니다.'},{id:'example-2',name:'주간 현황 정리',status:'검토 중',description:'주간 변경 사항을 모아 검토합니다.'},{id:'example-3',name:'문서 내용 확인',status:'사용 중',description:'필요한 항목이 빠짐없이 작성되었는지 확인합니다.'}];
export default function App({embedded=false,initialItems=initialRows,onSave}) {
  const [rows,setRows]=useState(initialItems),[search,setSearch]=useState(''),[tab,setTab]=useState('all');
  const [draft,setDraft]=useState(null),[saved,setSaved]=useState(null),[confirm,setConfirm]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[fail,setFail]=useState(false);
  const pending=useRef(false),dirty=!!draft&&JSON.stringify(draft)!==JSON.stringify(saved);
  const filtered=rows.filter(row=>(tab==='all'||row.status==='사용 중')&&row.name.toLowerCase().includes(search.toLowerCase()));
  const open=row=>{setSaved(row);setDraft({...row});setError('');};
  const close=()=>{if(pending.current)return;if(dirty)setConfirm(true);else setDraft(null);};
  async function save() {
    if(pending.current)return;
    if(!draft.name.trim()){setError('이름을 입력하세요.');return;}
    if(!dirty){notifyToast('변경 사항이 없습니다.');return;}
    pending.current=true;setBusy(true);setError('');
    try {
      let result;
      if(onSave)result=await onSave({...draft});
      else { // Memory-only demo; connect the host's persistence through onSave.
        await new Promise(resolve=>setTimeout(resolve,250));
        if(fail)throw new Error('저장하지 못했습니다. 입력 내용은 유지됩니다. 다시 시도하세요.');
        result={...draft};
      }
      if(!result||result.id!==draft.id||typeof result.name!=='string'||typeof result.status!=='string'||typeof result.description!=='string')throw new Error('저장 결과를 확인하지 못했습니다. 다시 시도하세요.');
      setRows(current=>current.map(row=>row.id===draft.id?{...result}:row));
      setSaved({...result});setDraft(null);notifyToast('저장했습니다.');
    } catch(reason){setError(reason?.message||'저장하지 못했습니다. 입력 내용은 유지됩니다. 다시 시도하세요.');}
    finally{pending.current=false;setBusy(false);}
  }
  const content=<>
    <CxPageHeader title="업무 목록" description="조회하고 수정한 뒤 저장합니다." actions={!onSave&&<ActionButton action="refresh" label="예제 초기화" onClick={()=>{setRows(initialItems);setSearch('');setTab('all');}}/>}/>
    <CxCard>
      <div className="sample-toolbar"><CxField label="업무 검색"><CxInput type="search" value={search} placeholder="업무 이름 검색" onChange={e=>setSearch(e.target.value)}/></CxField><span className="sample-count">조회 결과 {filtered.length}개</span></div>
      <CxTabs items={[{key:'all',label:'전체'},{key:'active',label:'사용 중'}]} active={tab} onChange={setTab} label="업무 보기" idPrefix="sample-tab" panelId="sample-panel"/>
      <div role="tabpanel" id="sample-panel" aria-labelledby={`sample-tab-${tab}`} className="sample-results"><CxTable caption="업무별 사용 현황" rows={filtered} columns={[
        {key:'name',label:'업무 이름'},
        {key:'status',label:'상태',render:value=><CxStatus tone={value==='사용 중'?'success':'warning'}>{value}</CxStatus>},
        {key:'id',label:'수정',render:(_,row)=><ActionButton action="edit" label={`${row.name} 수정`} onClick={()=>open(row)}/>}
      ]}/></div>
    </CxCard>
    {!onSave&&<p className="sample-note">예제 데이터는 메모리에서만 변경됩니다. 새로고침하면 초기화됩니다.</p>}
    {draft&&<DetailPanel title="업무 수정" variant="modal" busy={busy} onClose={close} footer={<><CxButton disabled={busy} onClick={close}>취소</CxButton><ActionButton action="save" busy={busy} disabled={!dirty} onClick={save}/></>}>
      <div className="sample-form">{error&&<CxNotice tone="danger">{error}</CxNotice>}
        <CxField label="이름" required error={!draft.name.trim()&&error?'이름을 입력하세요.':undefined}><CxInput value={draft.name} disabled={busy} onChange={e=>setDraft({...draft,name:e.target.value})}/></CxField>
        <CxField label="상태"><CxSelect value={draft.status} disabled={busy} onChange={e=>setDraft({...draft,status:e.target.value})}><option>사용 중</option><option>검토 중</option></CxSelect></CxField>
        <CxField label="설명"><CxTextarea value={draft.description} disabled={busy} onChange={e=>setDraft({...draft,description:e.target.value})}/></CxField>
        {!onSave&&<CxCheckbox label="저장 실패 상태 체험" checked={fail} disabled={busy} onChange={e=>setFail(e.target.checked)}/> }
      </div>
    </DetailPanel>}
    {confirm&&<CxConfirmation {...confirmationCopy('close')} onCancel={()=>setConfirm(false)} onConfirm={()=>{setConfirm(false);setDraft(null);}}/>}
  </>;
  return embedded?<div className="sample-app">{content}</div>:<CxAppShell brand="우리 서비스" footer={<span>우리 서비스 · CX Design System</span>}>{content}</CxAppShell>;
}

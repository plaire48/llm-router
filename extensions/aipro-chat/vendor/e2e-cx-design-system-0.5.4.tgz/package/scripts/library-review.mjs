import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const registry=JSON.parse(await readFile(resolve(root,'templates/registry.json'),'utf8'));
const results=[];
const server=await servePages(root,'/Manufacturing-IT/CX/');
const geometry=async page=>{const result=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth+1,width:innerWidth,offenders:[...document.querySelectorAll('body *')].filter(el=>el.getBoundingClientRect().right>innerWidth+1).slice(0,12).map(el=>({tag:el.tagName,cls:el.className,right:el.getBoundingClientRect().right,text:el.textContent.slice(0,80)}))}));assert.equal(result.overflow,false,JSON.stringify(result));};
await mkdir(resolve(root,'verification'),{recursive:true});
await writeFile(resolve(root,'verification/tokens-only.html'),'<meta charset="utf-8"><link rel="stylesheet" href="../dist/tokens.css"><link rel="stylesheet" href="../fonts/font.css"><style>body{font-family:var(--cx-font-family)}button{height:var(--cx-control)}input{font-size:var(--cx-field-font)}</style><p>한글 토큰 미리보기</p><button>저장</button><input aria-label="입력">');
try{
  for(const engine of ['chromium','firefox','webkit']){
    const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
    try{
      for(const width of [390,1440]){
        const page=await browser.newPage({viewport:{width,height:900}});page.setDefaultTimeout(7000);
        const errors=[];page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400&&!response.url().endsWith('favicon.ico'))errors.push(response.url());});
        try{
          // The catalog renders the very same source that the CLI copies.
          await page.goto(server.url+'catalog/index.html');
          await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/화면 템플릿/}).click();
          for(const template of registry.templates){
            await page.getByRole('combobox',{name:'화면 템플릿 선택'}).selectOption(template.id);
            await page.getByRole('tab',{name:'미리보기',exact:true}).click();await geometry(page);
            await page.getByRole('tab',{name:'사용 방법',exact:true}).click();
            assert.ok((await page.getByRole('tabpanel',{name:'사용 방법'}).textContent()).includes('--template '+template.id));await geometry(page);
            await page.getByRole('tab',{name:'소스 코드',exact:true}).click();
            assert.ok((await page.getByRole('tabpanel',{name:'소스 코드'}).textContent()).includes('export default function App'));await geometry(page);
          }
          await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/토큰 라이브러리/}).click();
          await page.getByRole('searchbox',{name:'토큰 검색'}).fill('--cx-control');
          const token=page.locator('.catalog-token-entry').filter({has:page.locator(':scope > code').filter({hasText:/^var\(--cx-control\)$/})});
          await token.getByText('정의·조건·관련 조합',{exact:true}).click();
          assert.ok((await token.textContent()).includes('(pointer: coarse)'));
          await token.getByRole('button',{name:'로그인 템플릿',exact:true}).click();
          assert.equal(await page.getByRole('combobox',{name:'화면 템플릿 선택'}).inputValue(),'login');
          await page.getByRole('button',{name:'로그인',exact:true}).click();
          await page.getByRole('alert').filter({hasText:'로그인하지 못했습니다.'}).waitFor();
          await page.screenshot({path:resolve(root,`verification/library-${engine}-${width}.png`)});
          // Each distributed template is an independently built Vite entry.
          for(const template of registry.templates){await page.goto(server.url+'verification/templates/'+template.id+'/');await page.getByRole('main').waitFor();await geometry(page);assert.equal(await page.locator('h1').count(),1);}
          await page.goto(server.url+'verification/consumer-library/');
          const field=page.getByRole('textbox',{name:'서비스 이름',exact:true}),save=page.getByRole('button',{name:'저장',exact:true}),mode=page.getByRole('combobox',{name:'콜백 결과'});
          assert.ok(await save.isDisabled());await field.fill('수정');await field.fill('서버 설정');assert.ok(await save.isDisabled());
          await field.fill('보존할 초안');await mode.selectOption('error');await save.click();assert.ok(await field.isDisabled());
          await page.getByRole('alert').filter({hasText:'저장하지 못했습니다.'}).waitFor();assert.equal(await field.inputValue(),'보존할 초안');assert.equal(await page.getByLabel('호출 수').textContent(),'1');
          await mode.selectOption('invalid');await save.click();await page.getByRole('alert').filter({hasText:'저장 결과를 확인하지 못했습니다.'}).waitFor();assert.equal(await field.inputValue(),'보존할 초안');
          await mode.selectOption('success');await save.click();await page.waitForFunction(()=>document.querySelector('input')?.value==='보존할 초안 완료');assert.ok(await save.isDisabled());
          await field.fill('버릴 초안');const cancel=page.getByRole('button',{name:'변경 취소',exact:true});await cancel.click();
          let confirm=page.getByRole('alertdialog',{name:'변경을 취소할까요?'});await confirm.getByRole('button',{name:'계속 수정',exact:true}).click();assert.equal(await field.inputValue(),'버릴 초안');
          await cancel.click();confirm=page.getByRole('alertdialog');await confirm.getByRole('button',{name:'변경 취소',exact:true}).click();assert.equal(await field.inputValue(),'보존할 초안 완료');await geometry(page);
          const computed=await page.evaluate(()=>({control:getComputedStyle(document.documentElement).getPropertyValue('--cx-control').trim(),field: getComputedStyle(document.querySelector('input')).fontSize,columns:getComputedStyle(document.querySelector('.cx-layout-grid')).gridTemplateColumns.split(' ').length}));
          assert.equal(computed.control,'32px');assert.equal(computed.field,width<=700?'16px':'14px');assert.equal(computed.columns,width<=700?1:2);
          // A stale slow response must not replace a more recent query.
          await page.getByRole('combobox',{name:'검증 화면'}).selectOption('history');await page.getByRole('cell',{name:'서버 이력',exact:true}).waitFor();
          const query=page.getByRole('searchbox',{name:'변경 이력 검색',exact:true});await query.fill('slow');await query.fill('fast');await page.getByRole('cell',{name:'fast',exact:true}).waitFor();await page.waitForTimeout(600);assert.equal(await page.getByRole('cell',{name:'slow',exact:true}).count(),0);
          await mode.selectOption('error');await page.getByRole('alert').filter({hasText:'불러오지 못했습니다.'}).waitFor();
          await mode.selectOption('success');await page.getByRole('cell',{name:'fast',exact:true}).waitFor();
          await mode.selectOption('empty');await page.getByRole('table').waitFor();assert.equal(await page.getByRole('cell',{name:'fast',exact:true}).count(),0);
          await mode.selectOption('success');await page.getByRole('cell',{name:'fast',exact:true}).waitFor();const detail=page.getByRole('button',{name:'fast 변경 내용'});await detail.click();await page.getByRole('dialog',{name:'변경 내용'}).waitFor();await page.keyboard.press('Escape');assert.ok(await detail.evaluate(el=>el===document.activeElement));
          await page.getByRole('combobox',{name:'검증 화면'}).selectOption('list');await mode.selectOption('error');await page.getByRole('button',{name:'고객 문의 분류 수정'}).click();const panel=page.getByRole('dialog',{name:'업무 수정'});await panel.getByRole('textbox',{name:'이름',exact:true}).fill('서버 업무');await panel.getByRole('button',{name:'저장',exact:true}).click();await panel.getByRole('alert').waitFor();assert.equal(await panel.getByRole('textbox',{name:'이름',exact:true}).inputValue(),'서버 업무');await panel.getByRole('button',{name:'취소',exact:true}).click();await page.getByRole('alertdialog').getByRole('button',{name:'저장하지 않고 닫기',exact:true}).click();await mode.selectOption('success');await page.getByRole('button',{name:'고객 문의 분류 수정'}).click();await panel.getByRole('textbox',{name:'이름',exact:true}).fill('서버 업무');await panel.getByRole('button',{name:'저장',exact:true}).click();await panel.waitFor({state:'detached'});await page.getByRole('cell',{name:'서버 업무 완료',exact:true}).waitFor();
          await page.getByRole('combobox',{name:'검증 화면'}).selectOption('login');await mode.selectOption('absent');let login=page.getByRole('button',{name:'로그인',exact:true});assert.ok(await login.isDisabled());
          await mode.selectOption('error');await login.click();assert.ok(await page.getByRole('button',{name:'로그인',exact:true}).isDisabled());await page.getByRole('alert').filter({hasText:'로그인하지 못했습니다.'}).waitFor();
          await mode.selectOption('invalid');await login.click();await page.getByRole('alert').filter({hasText:'로그인하지 못했습니다.'}).waitFor();assert.equal(await page.getByLabel('인증 연결 결과').textContent(),'대기');
          await mode.selectOption('success');await login.click();await page.getByLabel('인증 연결 결과').filter({hasText:'세션 연결 확인'}).waitFor();await geometry(page);
          assert.deepEqual(errors,[]);
          results.push({engine,version:browser.version(),width,catalog:true,independentTemplates:5,settingsCallbacks:true,listCallbacks:true,historyStaleResponse:true,loginCallbacks:true,responsiveTokens:true,pass:true});
          console.log(`${engine} ${width}: catalog, 5 templates, host callbacks and responsive tokens passed`);
        }finally{await page.close();}
      }
      const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true});
      await page.goto(server.url+'verification/tokens-only.html');await page.evaluate(()=>document.fonts.ready);assert.ok(await page.evaluate(()=>[...document.fonts].some(font=>font.family.includes('Noto Sans KR')&&font.status==='loaded')));
      assert.equal(await page.locator('button').evaluate(el=>getComputedStyle(el).height),'44px');assert.equal(await page.locator('input').evaluate(el=>getComputedStyle(el).fontSize),'16px');
      await page.goto(server.url+'verification/consumer-library/');assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--cx-control').trim()),'44px');
      results.push({engine,tokensOnlyTouch:true,tokensAfterStylesTouch:true,pass:true});await page.close();
    }finally{await browser.close();}
  }
}finally{await server.close();}
await writeFile(resolve(root,'verification/library-browser-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({scenarios:results.length,passed:results.length}));

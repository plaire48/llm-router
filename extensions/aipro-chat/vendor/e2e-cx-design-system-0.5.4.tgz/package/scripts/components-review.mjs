import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {servePages} from './verify-pages.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const out=resolve(root,'.build/components');
await mkdir(out,{recursive:true});await mkdir(resolve(root,'verification'),{recursive:true});
await build({entryPoints:[resolve(root,'scripts/fixtures/components.jsx')],outfile:resolve(out,'app.js'),bundle:true,format:'esm',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'}});
await writeFile(resolve(out,'index.html'),'<!doctype html><html lang="ko"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CX 컴포넌트 검증</title><link rel="stylesheet" href="../../dist/styles.css"><style>[data-state]{display:none}section,form{margin-block:16px}fieldset{min-width:0}</style><div id="root"></div><script type="module" src="app.js"></script></html>');
const server=await servePages(root),results=[];
try{
for(const engine of ['chromium','firefox','webkit']){
  const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
  try{for(const width of [390,1440]){
    const page=await browser.newPage({viewport:{width,height:900}});page.setDefaultTimeout(5000);
    const errors=[],checks=[];page.on('pageerror',error=>errors.push(error.message));
    const check=label=>checks.push(label),state=()=>page.locator('[data-state]').textContent().then(JSON.parse);
    await page.goto(server.url+'.build/components/');
    const mode=page.getByLabel('콜백 결과');
    const enter=page.getByRole('button',{name:'전체 수정',exact:true});
    // Errors may be null or non-Error values from a host callback.
    await enter.click();await page.getByRole('button',{name:'읽기 모드',exact:true}).waitFor();
    await page.getByRole('button',{name:'초안 변경',exact:true}).click();
    await mode.selectOption('null-error');
    await page.getByRole('button',{name:'읽기 모드',exact:true}).click();
    const dialog=page.getByRole('alertdialog',{name:'변경 사항을 저장할까요?'});
    await dialog.getByRole('button',{name:'저장 후 보기',exact:true}).click();
    await page.waitForTimeout(350);
    assert.deepEqual(errors,[],'host save rejection must not escape the component');
    assert.equal((await state()).dirty,true);assert.equal((await state()).active,true);
    await page.getByRole('alert').filter({hasText:'저장하지 못했습니다.'}).waitFor();check('failed save keeps draft and edit mode with actionable feedback');
    await dialog.getByRole('button',{name:'반영 안 함',exact:true}).click();
    assert.deepEqual(errors,[]);await page.getByRole('alert').filter({hasText:'읽기 모드로 전환하지 못했습니다.'}).waitFor();
    assert.equal((await state()).dirty,true);check('failed discard keeps draft and dialog');
    await dialog.getByRole('button',{name:'계속 수정',exact:true}).click();
    await mode.selectOption('success');await page.getByRole('button',{name:'읽기 모드',exact:true}).click();
    await dialog.getByRole('button',{name:'저장 후 보기',exact:true}).click();
    await page.keyboard.press('Escape');assert.equal(await dialog.count(),1);check('saving locks confirmation against Escape');
    await enter.waitFor();assert.equal((await state()).dirty,false);assert.equal((await state()).calls.save,2);check('successful retry saves once and exits edit mode');

    await mode.selectOption('null-error');await enter.click();await page.waitForTimeout(350);
    assert.deepEqual(errors,[],'host enter rejection must not escape the component');assert.equal((await state()).active,false);
    await page.getByRole('alert').filter({hasText:'수정 모드로 전환하지 못했습니다.'}).waitFor();check('failed mode entry is recoverable');
    await mode.selectOption('success');
    const before=(await state()).calls.enter;
    await enter.evaluate(button=>{button.click();button.click();});
    await page.getByRole('button',{name:'읽기 모드',exact:true}).waitFor();
    assert.equal((await state()).calls.enter,before+1);check('pending mode entry blocks duplicate host callbacks');
    await page.getByRole('button',{name:'읽기 모드',exact:true}).click();
    assert.equal((await state()).active,false);check('clean mode exit needs no confirmation');
    await mode.selectOption('reject');await enter.click();
    await page.waitForFunction(()=>!document.querySelector('[data-action="editAll"]')?.disabled);
    assert.equal((await state()).active,false);check('host can reject mode entry without changing state');
    await mode.selectOption('success');await enter.click();await page.getByRole('button',{name:'읽기 모드',exact:true}).waitFor();
    await page.getByRole('button',{name:'초안 변경',exact:true}).click();
    await mode.selectOption('reject');await page.getByRole('button',{name:'읽기 모드',exact:true}).click();
    await dialog.getByRole('button',{name:'반영 안 함',exact:true}).click();
    assert.equal(await dialog.count(),1);assert.equal((await state()).dirty,true);check('host can reject discard without losing draft');
    await dialog.getByRole('button',{name:'저장 후 보기',exact:true}).click();await dialog.waitFor({state:'detached'});
    assert.equal((await state()).active,true);assert.equal((await state()).dirty,true);check('false save result keeps edit mode and unsaved data');
    await mode.selectOption('success');await page.getByRole('button',{name:'읽기 모드',exact:true}).click();
    await dialog.getByRole('button',{name:'반영 안 함',exact:true}).click();
    assert.equal((await state()).dirty,false);assert.equal((await state()).active,false);check('explicit discard restores read mode');

    const link=page.getByRole('link',{name:'세부 페이지',exact:true});
    assert.equal(await link.getAttribute('href'),null);assert.equal(await link.getAttribute('tabindex'),'-1');
    await link.evaluate(node=>node.click());assert.equal((await state()).calls.link,0);check('disabled link has no navigation or callback');
    await page.getByRole('button',{name:'링크 잠금 전환'}).click();await link.click();
    assert.equal((await state()).calls.link,1);assert.equal(new URL(page.url()).hash,'#details');check('enabled link navigates and calls host');

    const select=page.getByRole('combobox',{name:'항목',exact:true});
    await select.press('ArrowDown');await select.press('ArrowDown');await select.press('Enter');
    assert.equal((await state()).choice,'two');
    assert.equal(await page.getByRole('form',{name:'선택 폼'}).evaluate(form=>new FormData(form).get('item')),'two');check('select skips disabled options and retains native form value');
    await select.press('ArrowDown');await select.press('Home');await select.press('Escape');assert.equal((await state()).choice,'two');check('select Escape cancels pending choice');
    await select.press('ArrowDown');await page.getByRole('button',{name:'선택 항목 제거'}).evaluate(button=>button.click());
    await page.getByRole('listbox').waitFor({state:'detached'});check('removed options invalidate open menu');
    await select.press('ArrowDown');await page.getByRole('button',{name:'폼 잠금 전환'}).evaluate(button=>button.click());
    await page.getByRole('listbox').waitFor({state:'detached'});assert.equal(await select.isDisabled(),true);check('fieldset lock closes menu and disables selection');
    const checkbox=page.getByRole('checkbox',{name:'혼합 선택'});assert.equal(await checkbox.evaluate(node=>node.indeterminate),true);
    await checkbox.click();assert.equal((await state()).checked,true);assert.equal(await checkbox.evaluate(node=>node.indeterminate),false);check('mixed checkbox transitions to checked');
    await mode.selectOption('reject');await page.getByRole('tab',{name:'첫 화면'}).press('ArrowRight');
    assert.equal((await state()).tab,'first');check('tab host can reject navigation');
    await mode.selectOption('success');await page.getByRole('tab',{name:'첫 화면'}).press('End');
    await page.waitForFunction(()=>document.querySelector('[data-tab-key="second"]')===document.activeElement);
    assert.equal((await state()).tab,'second');check('tab End moves selection and focus');
    assert.equal(await page.locator('#details a').count(),1);assert.equal(await page.locator('#details a').getAttribute('rel'),'noreferrer');check('commit reference links only valid HTTP URLs and hashes');
    await page.getByRole('status').filter({hasText:'목록을 불러오는 중…'}).waitFor();
    assert.deepEqual(errors,[]);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
    results.push({engine,version:browser.version(),width,checks,errors});console.log(`${engine} ${width}: ${checks.length} component checks passed`);
    await page.close();
  }}finally{await browser.close();}
}
}finally{await server.close();}
await writeFile(resolve(root,'verification/components-results.json'),JSON.stringify(results,null,2)+'\n');

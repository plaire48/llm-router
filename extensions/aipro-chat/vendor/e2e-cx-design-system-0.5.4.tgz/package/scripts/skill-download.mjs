import {mkdir,readFile,readdir,writeFile} from 'node:fs/promises';
import {resolve,posix} from 'node:path';
import {createHash} from 'node:crypto';

// Store-only ZIP with fixed DOS timestamps and UTF-8 names. No host zip binary,
// file mtimes or compression version can change the committed download bytes.
function crc32(bytes) {
  let crc=0xffffffff;
  for(const byte of bytes){crc^=byte;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}
  return (crc^0xffffffff)>>>0;
}
function storedZip(files) {
  const local=[],central=[];let offset=0;
  for(const {path,bytes} of files){
    const name=Buffer.from(path),crc=crc32(bytes),header=Buffer.alloc(30),entry=Buffer.alloc(46);
    header.writeUInt32LE(0x04034b50);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);
    header.writeUInt16LE(33,12);header.writeUInt32LE(crc,14);header.writeUInt32LE(bytes.length,18);header.writeUInt32LE(bytes.length,22);header.writeUInt16LE(name.length,26);
    entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);
    entry.writeUInt16LE(33,14);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(bytes.length,20);entry.writeUInt32LE(bytes.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE(offset,42);
    local.push(header,name,bytes);central.push(entry,name);offset+=header.length+name.length+bytes.length;
  }
  const directory=Buffer.concat(central),end=Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
  return Buffer.concat([...local,directory,end]);
}

export async function buildSkillDownload(root) {
  const source=resolve(root,'skills/cx-ui'),files=[];
  async function collect(path=''){
    const entries=await readdir(resolve(source,path),{withFileTypes:true});
    for(const entry of entries.sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0)){
      if(entry.name.startsWith('.')||entry.name.includes('\\'))throw new Error('Unexpected skill resource: '+entry.name);
      const relative=posix.join(path,entry.name);
      if(entry.isDirectory())await collect(relative);
      else if(entry.isFile())files.push({path:'cx-ui/'+relative,bytes:await readFile(resolve(source,relative))});
      else throw new Error('Skill resources must be regular files: '+relative);
    }
  }
  await collect();
  if(!files.some(file=>file.path==='cx-ui/SKILL.md'))throw new Error('Missing skill entrypoint');
  const archive=storedZip(files),hash=bytes=>createHash('sha256').update(bytes).digest('hex');
  const {version}=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
  const metadata={format:'cx-skill-download/1',name:'cx-ui',version,archive:'cx-ui-skill.zip',root:'cx-ui',bytes:archive.length,sha256:hash(archive),files:files.map(file=>({path:file.path,bytes:file.bytes.length,sha256:hash(file.bytes)}))};
  await mkdir(resolve(root,'downloads'),{recursive:true});
  await writeFile(resolve(root,'downloads/cx-ui-skill.zip'),archive);
  await writeFile(resolve(root,'downloads/cx-ui-skill.json'),JSON.stringify(metadata,null,2)+'\n');
  return metadata;
}

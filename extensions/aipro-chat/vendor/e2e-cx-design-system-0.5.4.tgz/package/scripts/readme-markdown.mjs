import {Marked,Renderer} from 'marked';
import {posix} from 'node:path';

const escape=text=>text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function usageLink(href,{source='README.md',targetPage='docs/USAGE.html'}={}) {
  if(href.startsWith('#')||/^(?:https?:|mailto:)/.test(href))return href;
  const [path,fragment]=href.split('#'),file=posix.normalize(posix.join(posix.dirname(source),path));
  const target=file==='README.md'?'docs/USAGE.html':file==='docs/TEMPLATES.txt'?'docs/TEMPLATES.html':file==='docs/TABLES.txt'?'docs/TABLES.html':file==='docs/FEEDBACK.md'?'docs/FEEDBACK.html':file==='docs/SKILLS.md'?'docs/SKILLS.html':/\.(?:md|txt|json|jsx|js|mjs|css|yaml)$/.test(file)?'docs/read/'+file+'.html':file;
  return posix.relative(posix.dirname(targetPage),target)+(fragment?'#'+fragment:'');
}

export function renderReadme(markdown,options={}) {
  const headings=new Map();
  const parser=new Marked({gfm:true,renderer:{
    heading({text,tokens,depth}) {
      const base=text.toLowerCase().replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/\s/g,'-');
      const count=headings.get(base)||0;headings.set(base,count+1);
      return `<h${depth} id="${escape(base+(count?'-'+count:''))}">${this.parser.parseInline(tokens)}</h${depth}>\n`;
    },
    link({href,title,tokens}) {
      return `<a href="${escape(usageLink(href,options))}"${title?' title="'+escape(title)+'"':''}>${this.parser.parseInline(tokens)}</a>`;
    },
    // README prose is Markdown; HTML examples belong in fenced code blocks.
    html({text}) {return escape(text);},
    table(token) {return '<div class="usage-table-scroll" role="region" aria-label="안내 표" tabindex="0">'+Renderer.prototype.table.call(this,token)+'</div>\n';},
  }});
  const tokens=parser.lexer(markdown.replace(/^\uFEFF/,''));
  if(tokens[0]?.type!=='heading'||tokens[0].depth!==1)throw new Error('README.md must begin with a level-one title.');
  return {title:tokens[0].text,html:parser.parser(tokens)};
}

import {readFile, writeFile} from 'node:fs/promises';
import {resolve, dirname, basename} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import postcss from 'postcss';
import {parse} from '@babel/parser';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(resolve(root, path), 'utf8');
const json = async path => JSON.parse(await read(path));
const save = (path, data) => writeFile(resolve(root, path), JSON.stringify(data, null, 2) + '\n');
const inventory = await json('reference/inventory.json');
const manifest = await json('agent/manifest.json');
const {values} = await json('tokens/css-variables.json');
const hash = content => createHash('sha256').update(content).digest('hex');

const categories = [
  ['color','색상·강조·투명도'], ['type','폰트·글자·줄바꿈'], ['geometry','크기·간격·레이아웃'],
  ['shape','테두리·모서리·그림자'], ['layer','모달·레이어·스크롤'], ['motion','모션·피드백'], ['other','기타 표현'],
];
function category(property) {
  if (/color|background|opacity|fill|stroke(?!-width)|brand-|surface|muted|danger|success|warning/.test(property)) return 'color';
  if (/font|line-height|letter|text-|word-|white-space|type-|weight|line-/.test(property)) return 'type';
  if (/z-index|overflow|overscroll|position|inset|^top$|^bottom$|^left$|^right$/.test(property)) return 'layer';
  if (/border|radius|shadow|outline/.test(property)) return 'shape';
  if (/animation|transition|transform|motion|scroll-behavior/.test(property)) return 'motion';
  if (/width|height|size|padding|margin|gap|space|display|flex|grid|align|justify|control|cell|row|inset|gutter/.test(property)) return 'geometry';
  return 'other';
}
const declarations = [], fontFaces = [];
const styleFiles = [...inventory.cssOrder, 'fonts/font.css', 'src/portable.css', 'src/layouts.css'];
for (const file of styleFiles) {
  const css = postcss.parse(await read(file), {from:file});
  css.walkDecls(decl => {
    const context = [];
    for (let node = decl.parent; node && node.type !== 'root'; node = node.parent) {
      context.unshift(node.type === 'rule' ? node.selector : '@' + node.name + (node.params ? ' ' + node.params : ''));
    }
    const selector = context.filter(value => !value.startsWith('@')).join(' / ');
    const conditions = context.filter(value => value.startsWith('@'));
    const states = [...new Set((selector.match(/:(?:hover|focus-visible|focus-within|focus|active|disabled|checked|invalid)|\[aria-[^\]]+\]|\.is-[\w-]+/g) || []))];
    declarations.push({file, line:decl.source.start.line, property:decl.prop, value:decl.value,
      important:Boolean(decl.important), selector, conditions, states, category:category(decl.prop),
      layer:file.startsWith('src/') ? 'portable' : file.startsWith('fonts/') ? 'font' : 'source',
      legacyDark:/data-theme[^\]]*dark/.test(selector.replace(/:not\(\[data-theme[^\]]*dark[^\]]*\]\)/g, ''))});
  });
  css.walkAtRules('font-face', rule => {
    const face = {file, line:rule.source.start.line};
    rule.walkDecls(decl => face[decl.prop] = decl.value);
    fontFaces.push(face);
  });
}

const groups = [
  ['shell','앱 프레임·레이아웃','main reportWorkspace AppChrome AppFooter WorkspaceLayout WorkspaceMemory'],
  ['actions','버튼·아이콘·탭','ActionButton Icon CxTabs HelpTrigger MasterActionButton'],
  ['fields','검색·입력·선택·필터','SearchField CxSelect DateRangeFilter ImplementationMethodsSelect MasterUsageCheckbox'],
  ['tables','표·열·편집·계층','WorkList WorkListState WorkLongText SettingsGrid GroupedSettingsGrid TableControls TableEditModeButton ColumnVisibilityMenu HierarchyManager OptionManager'],
  ['dialogs','모달·확인·충돌','DetailPanel CxConfirmation MasterDeleteDialog SelectionApplyDialog SelectionApplyConfirmation resolveEditConflict confirmAction'],
  ['feedback','로딩·빈 결과·오류·알림','EmptyState Toast CommunityStatus GithubRequestError NotificationMenu'],
  ['identity','로그인·프로필·사용자','LoginScreen AccountProfile ProfileTooltip UserIdentity TeamAssignment'],
  ['history','변경 이력·커밋','WorkHistory CommitPreview CommitReference SettingsLastModified'],
  ['settings','설정·마스터','AdminSettings MasterSettings ScoringSettings EnhancementAttributesSettings BrandPalette'],
  ['workspaces','업무·Agent Flow','AutomationRateSource AutomationRatesWorkspace ProcessOrganizationsWorkspace FlowAssessmentEditor AgentFlowPreview'],
  ['support','도움말·문의','HelpButton HelpPanel ServiceDesk InquiryWorkspace InquiryAssignees InquiryRecipients'],
  ['talk','게시판·댓글·첨부·멘션','E2ETalk CommentComposer CommentThreadList MentionMenu MentionTextInput NativeAttachmentLink TalkContent TalkEditor TalkMentions TalkTeamNotice'],
];
const nameOf = node => node?.type === 'JSXIdentifier' ? node.name : node?.type === 'JSXMemberExpression' ? nameOf(node.object) + '.' + nameOf(node.property) : '';
function visit(node, callback) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {for (const child of node) visit(child, callback); return;}
  if (node.type) callback(node);
  for (const [key, child] of Object.entries(node)) if (!['loc','start','end','extra','comments','tokens'].includes(key)) visit(child, callback);
}
const components = [], surfaces = [], inlineStyles = [], scriptDesignValues = [];
const styleKeys = /^(?:font(?:Size|Family|Weight|Style|Variant)?|lineHeight|letterSpacing|color|background(?:Color)?|border(?:Color|Width|Style|Radius)?|boxShadow|opacity|stroke(?:Width)?|fill|zIndex|padding(?:Top|Right|Bottom|Left|Inline|Block)?|margin(?:Top|Right|Bottom|Left)?|(?:min|max)?(?:Width|Height)|width|height|top|left|right|bottom|gap|rowGap|columnGap|transform|position|overflow|display|alignItems|justifyContent)$/;
function scriptValues(ast, source, file) {
  visit(ast, node => {
    if (node.type === 'StringLiteral' && /^(?:#[a-f\d]{3,8}|(?:rgb|hsl)a?\([^\n]+\))$/i.test(node.value)) {
      scriptDesignValues.push({file,line:node.loc.start.line,kind:'color-literal',property:'color',category:'color',expression:node.value});
    }
    if (node.type === 'ObjectProperty') {
      const property = node.key.name || node.key.value;
      if (typeof property === 'string' && (styleKeys.test(property) || property.startsWith('--'))) {
        scriptDesignValues.push({file,line:node.loc.start.line,kind:'style-property',property,category:category(property.replace(/[A-Z]/g, match=>'-'+match.toLowerCase())),expression:source.slice(node.value.start,node.value.end)});
      }
    }
    if (node.type === 'VariableDeclarator' && /(?:colors|palette|widths|heights|sizes|fitViewOptions)$/i.test(node.id.name || '') && node.init) {
      scriptDesignValues.push({file,line:node.loc.start.line,kind:'design-constant',property:node.id.name,category:/color|palette/i.test(node.id.name)?'color':'geometry',expression:source.slice(node.init.start,node.init.end)});
    }
  });
}
for (const entry of inventory.components) {
  const source = await read(entry.file);
  const ast = parse(source, {sourceType:'module', plugins:['jsx']});
  scriptValues(ast, source, entry.file);
  const group = groups.find(([, , names]) => names.split(' ').includes(basename(entry.file, '.jsx')));
  if (!group) throw new Error('Classify the new UI module: ' + entry.file);
  const definitions = [], classes = new Set();
  visit(ast, node => {
    if (node.type === 'FunctionDeclaration' && /^[A-Z]/.test(node.id?.name || '')) definitions.push({name:node.id.name, line:node.loc.start.line});
    if (node.type !== 'JSXOpeningElement') return;
    const element = nameOf(node.name), attrs = {};
    for (const attr of node.attributes) {
      if (attr.type !== 'JSXAttribute') continue;
      const name = attr.name.name;
      const value = attr.value?.type === 'StringLiteral' ? attr.value.value : attr.value ? source.slice(attr.value.start, attr.value.end) : true;
      attrs[name] = value;
      if (name === 'className' && typeof value === 'string') {
        for (const match of value.matchAll(/\b[a-z][a-z\d]*-[a-z\d-]+\b/g)) classes.add(match[0]);
      }
      if (name === 'style') inlineStyles.push({file:entry.file, line:attr.loc.start.line, element, expression:value});
    }
    if (/DetailPanel|Confirmation|Dialog$/.test(element) || element === 'dialog' || ['dialog','alertdialog','listbox','menu','tooltip'].includes(attrs.role)) {
      surfaces.push({file:entry.file, line:node.loc.start.line, element, attributes:attrs,
        kind:['listbox','menu','tooltip'].includes(attrs.role) ? 'popup' : 'dialog-or-panel'});
    }
  });
  const api = manifest.portable.filter(item => entry.exports.some(exp => exp.name === item.name)).map(item => item.name);
  const styleImports = entry.imports.filter(path => path.endsWith('.css'));
  components.push({file:entry.file, group:group[0], label:group[1], exports:entry.exports, definitions,
    portable:api, status:api.length ? 'portable-adaptation-available' : 'reference-only',
    classes:[...classes].sort(), styleImports,
    dependencies:entry.imports.filter(path => !path.endsWith('.css')),
    surfaces:surfaces.filter(item => item.file === entry.file).map(({line,element,kind}) => ({line,element,kind})),
  });
}
for (const entry of inventory.modules) {
  const source=await read(entry.file);
  scriptValues(parse(source,{sourceType:'module',plugins:['jsx']}),source,entry.file);
}
function resolveAlias(value, seen = []) {
  return value.replace(/var\((--[\w-]+)\)/g, (match, token) => values[token] && !seen.includes(token) ? resolveAlias(values[token], [...seen, token]) : match);
}
const foundationGroups = [
  ['브랜드와 강조','color',[
    ['주요 동작','--brand-action'],['강조 글자','--brand-ink'],['아주 옅은 배경·hover','--brand-surface'],['약한 강조','--brand-soft'],['선택 배경','--brand-selected'],['브랜드 테두리','--brand-border'],
  ]],
  ['중립색과 상태','color',[
    ['페이지 배경','--layout-soft'],['표면','--layout-surface'],['본문','--layout-text'],['보조 글자','--layout-muted'],['비활성 글자','--cx-disabled'],['테두리','--layout-border'],['행 구분','--layout-row-border'],['표 헤더','--layout-table-head'],['입력 테두리','--cx-input-border'],['성공','--cx-success'],['주의','--cx-warning'],['오류','--cx-danger'],['오류 배경','--cx-error-surface'],['모달 배경막','--cx-overlay'],
  ]],
  ['폰트와 위계','type',[
    ['글꼴','--cx-font-family'],['코드 글꼴','--font-family-code'],['본문','--cx-type-body'],['보조 정보','--cx-type-caption'],['구획 제목','--cx-type-section'],['페이지 제목','--cx-type-title'],['모달 제목','--cx-type-panel-title'],['본문 굵기','--cx-weight-regular'],['중간 강조','--cx-weight-medium'],['제목 굵기','--cx-weight-bold'],['본문 줄 높이','--cx-line-body'],['보조 줄 높이','--cx-line-caption'],
  ]],
  ['버튼·입력·표','geometry',[
    ['기본 조작','--cx-control'],['작은 조작','--cx-control-small'],['주 터치 조작','--cx-touch'],['입력 높이','--cx-field-height'],['입력 글자','--cx-field-font'],['탭 높이','--cx-tab-height'],['표 행 높이','--cx-row-height'],['표 헤더 높이','--cx-table-head-height'],['셀 상하 여백','--cx-cell-block'],['셀 좌우 여백','--cx-cell-inline'],['긴 입력 최소 높이','--cx-long-input-min'],
  ]],
  ['간격과 모달','geometry',[
    ['간격 1','--cx-space-1'],['간격 2','--cx-space-2'],['간격 3','--cx-space-3'],['간격 4','--cx-space-4'],['간격 6','--cx-space-6'],['간격 8','--cx-space-8'],['중간 큰 간격','--cx-gap-lg'],['워크스페이스 여백','--cx-workspace-gutter'],['모달 좌우 여백','--cx-panel-inset'],['모달 상하 여백','--cx-panel-block'],
  ]],
  ['모서리·그림자·모션','shape',[
    ['조작 모서리','--cx-radius-control'],['카드 모서리','--cx-radius-card'],['팝업 모서리','--cx-popup-radius'],['카드 그림자','--cx-shadow-card'],['팝업 그림자','--cx-shadow-overlay'],['기본 모션','--cx-motion'],
  ]],
];
const foundations = foundationGroups.flatMap(([group, category, entries]) => entries.map(([label, token]) => {
  if (!values[token]) throw new Error('Foundation token missing: ' + token);
  return {group, category, label, token, value:values[token], resolved:resolveAlias(values[token]),
    declarations:declarations.filter(decl => decl.property === token).map(({file,line,value,selector,conditions,legacyDark}) => ({file,line,value,selector,conditions,legacyDark})),
    origin:token.startsWith('--brand-') ? 'reference/modules/brandTheme.js: brandTokens(#1826ad, light)' : token === '--font-family-code' ? 'scripts/capture.mjs: system code font adaptation' : 'CSS declarations (context matters)',
  };
}));
const fontSupport = await Promise.all(['fonts/font.css','fonts/OFL.txt'].map(async file => ({file,sha256:hash(await read(file))})));
const coverage = {
  styles:inventory.styles.length, uiModules:components.length, helperModules:inventory.modules.length,
  fontFiles:inventory.fonts.length, fontFaces:fontFaces.length,
  rootVariables:Object.keys(values).length, sourceDeclarations:declarations.filter(item => item.layer === 'source').length,
  portableDeclarations:declarations.filter(item => item.layer === 'portable').length,
  conditionalTokenDeclarations:declarations.filter(item => item.layer === 'source' && item.property.startsWith('--')).length,
  dialogAndPopupSites:surfaces.length, inlineStyleSites:inlineStyles.length, scriptDesignValues:scriptDesignValues.length, portableApis:manifest.portable.length,
};
const notes = [
  '현행 E2E src의 모든 비폰트 CSS·JSX, 지정한 UI 보조 모듈, 로컬 글꼴을 수집했습니다. 제품 데이터·인증 클라이언트를 공통 실행 코드로 복제하지 않습니다.',
  '스크립트 디자인 값은 수집한 JSX와 UI 보조 모듈에서 색상 리터럴·스타일 속성·팔레트와 크기 상수를 추적합니다. 동적 표현은 실행하지 않습니다. 외부 UI 라이브러리의 CSS는 각 모듈의 styleImports에 의존성으로 표시하며 공통 스타일의 원본으로 복제하지 않습니다.',
  'CSS 선언과 인라인 JSX 식은 원문 근거입니다. 나열 순서나 토큰 별칭 해석은 특정 DOM의 최종 계산 스타일을 보장하지 않습니다. 선택자 우선순위·조건·인라인 값·실행 시 상태를 함께 확인하세요.',
  '현행 테마는 light 하나입니다. data-theme=dark 선언과 recovered.css의 과거 컴포넌트는 원본 추적을 위해 남겼으며 신규 권장 테마·공개 API가 아닙니다.',
  '참고 JSX에서 일부 export의 공통 어댑터를 제공하더라도 참고 파일 전체를 그대로 import하지 않습니다. 사용할 수 있는 이름은 agent/manifest.json의 portable에 한정합니다.',
  '주 입력 장치가 (pointer: coarse)일 때 조작 44px, 행 52px, 표 헤더 48px로 바뀝니다. 화면 너비 700px 이하는 입력 글자 16px와 줄 높이 24px만 바꿉니다.',
];
const index = {format:'cx-design-index/1', version:manifest.version, sourceRevision:inventory.sourceRevision,
  includesWorkingTree:inventory.includesWorkingTree, coverage, categories:categories.map(([id,label])=>({id,label})),
  groups:groups.map(([id,label])=>({id,label,count:components.filter(item=>item.group===id).length})),
  foundations, components, notes,
  details:'reference/design-details.json', guide:'docs/DESIGN-INVENTORY.html', changes:'reference/updates.json', fontSupport,
};
await save('agent/design-index.json', index);
const details = {format:'cx-design-details/1', version:manifest.version, sourceRevision:inventory.sourceRevision, coverage, notes, declarations, surfaces, inlineStyles, scriptDesignValues, fontFaces};
await save('reference/design-details.json', details);
const template = await read('scripts/design-inventory.html');
// Embedded data keeps the reference viewer usable on an offline file:// copy, with no fetch or CDN.
const payload = JSON.stringify({index, details}).replaceAll('<', '\\u003c');
await writeFile(resolve(root,'docs/DESIGN-INVENTORY.html'), template.replace('/*__CX_DATA__*/null', payload));
console.log('Indexed complete CX design details:', JSON.stringify(coverage));

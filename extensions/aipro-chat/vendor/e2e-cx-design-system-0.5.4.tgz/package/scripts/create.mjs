#!/usr/bin/env node
import {access,cp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname,basename} from 'node:path';
import {fileURLToPath} from 'node:url';
import {installSkill} from './install-skill.mjs';
import {templateRegistry,templateFiles,ensureEmpty} from './template-files.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const [destination,...args]=process.argv.slice(2),packageIndex=args.indexOf('--package');
const registry=await templateRegistry();
if(destination==='--list'&&!args.length){console.log(JSON.stringify({default:registry.default,templates:registry.templates.map(({id,label,description})=>({id,label,description}))},null,2));process.exit(0);}
if(!destination||packageIndex<0||!args[packageIndex+1])throw new Error('Usage: cx-create ./new-app --template <id> [--skill-target codex|claude|all|none] --package /path/to/e2e-cx-design-system-<version>.tgz | cx-create --list');
const options=new Map();
for(let i=0;i<args.length;i+=2){if(!['--package','--template','--skill-target'].includes(args[i])||!args[i+1]||args[i+1].startsWith('--')||options.has(args[i]))throw new Error('Invalid or duplicate create option.');options.set(args[i],args[i+1]);}
const skillTarget=options.get('--skill-target')||'none';
if(!['codex','claude','all','none'].includes(skillTarget))throw new Error('Skill target must be codex, claude, all, or none.');
const selected=options.get('--template')||registry.default;
const {template,files}=await templateFiles(selected);
const target=resolve(destination),archive=resolve(args[packageIndex+1]);
await access(archive);
await ensureEmpty(target);
await mkdir(target,{recursive:true});
await cp(resolve(root,'starter'),target,{recursive:true});
for(const file of files)await writeFile(resolve(target,'src',file.target),file.content);
await mkdir(resolve(target,'vendor'),{recursive:true});
await cp(archive,resolve(target,'vendor',basename(archive)));
const pkg=JSON.parse(await readFile(resolve(target,'package.json'),'utf8'));
pkg.dependencies['@e2e/cx-design-system']='file:vendor/'+basename(archive);
await writeFile(resolve(target,'package.json'),JSON.stringify(pkg,null,2)+'\n');
if(skillTarget!=='none')await installSkill(target,{target:skillTarget});
await cp(resolve(root,'agent/INSTRUCTIONS.md'),resolve(target,'DESIGN-SYSTEM.md'));
if(['codex','all'].includes(skillTarget))await writeFile(resolve(target,'AGENTS.md'),'# 개발 기준\n\nUI 작업에는 .agents/skills/cx-ui/SKILL.md의 CX UI 스킬을 적용한다. DESIGN-SYSTEM.md를 읽고 설치된 @e2e/cx-design-system의 manifest와 문서를 확인한다.\n\n검증: npm run design:check, npm run build. 변경 화면의 반응형과 동작도 브라우저에서 확인한다.\n');
if(['claude','all'].includes(skillTarget))await writeFile(resolve(target,'CLAUDE.md'),'# 개발 기준\n\nUI 작업에는 /cx-ui 스킬을 사용한다. .claude/skills/cx-ui/SKILL.md와 DESIGN-SYSTEM.md를 읽고 설치된 @e2e/cx-design-system의 manifest와 문서를 확인한다.\n\n검증: npm run design:check, npm run build. 변경 화면의 반응형과 동작도 브라우저에서 확인한다.\n');
await writeFile(resolve(target,'.gitignore'),'node_modules/\ndist/\n.DS_Store\n');
await writeFile(resolve(target,'CX-TEMPLATE.json'),JSON.stringify({template:selected,version:JSON.parse(await readFile(resolve(root,'package.json'),'utf8')).version,source:template.entry,integration:template.integration},null,2)+'\n');
console.log(`Created ${target}\nTemplate: ${selected}\nNext: npm install, npm run dev\nSkill target: ${skillTarget}`);
if(skillTarget==='none')console.log('스킬은 설치하지 않았습니다. npm install 후 프로젝트에서 node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs . 을 실행해 도구를 선택하거나 --skill-target을 지정해 새 프로젝트를 만드세요.');

import { readFile, writeFile, mkdir, readdir, cp, rm } from 'node:fs/promises';
import { resolve, dirname, relative, extname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import postcss from 'postcss';
import { parse } from '@babel/parser';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = process.argv[2] && resolve(process.argv[2]);
if (!source) throw new Error('Usage: npm run capture -- /absolute/path/to/e2e-report');
if(process.argv[3]==='--styles'){
  const {captureStyles}=await import('./capture-styles.mjs');
  await captureStyles(root,source,process.argv.slice(4));
  process.exit(0);
}
const hash = text => createHash('sha256').update(text).digest('hex');
async function write(path, value) { const out=resolve(root,path); await mkdir(dirname(out),{recursive:true}); await writeFile(out,typeof value==='string'?value:JSON.stringify(value,null,2)+'\n'); }
async function walk(dir) { const out=[]; for(const e of await readdir(dir,{withFileTypes:true})) { const path=resolve(dir,e.name); if(e.isDirectory())out.push(...await walk(path)); else out.push(path); } return out.sort(); }
const files = await walk(resolve(source,'src'));
const previous = JSON.parse(await readFile(resolve(root,'reference/inventory.json'),'utf8'));
const sourceRevision=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim();
const dirtySource=execFileSync('git',['status','--porcelain','--','src'],{cwd:source,encoding:'utf8'}).trim();
// These directories are capture-owned. Removed source files must not linger as active references.
for(const folder of ['reference/styles','reference/components','reference/modules'])await rm(resolve(root,folder),{recursive:true,force:true});
const cssFiles = files.filter(path=>path.endsWith('.css')&&!path.includes('/assets/'));
// Baseline -> shared layout -> specialised surfaces -> current CX decisions -> common action geometry.
const first=['styles/recovered.css','app.css','cx.css','table.css','agent.css','work-list.css'];
const last=['cx-system.css','cx-density.css','action-buttons.css'].filter(name=>cssFiles.some(path=>path===resolve(source,'src',name)));
const rel=path=>relative(resolve(source,'src'),path);
const cssOrder=[...first,...cssFiles.map(rel).filter(p=>!first.includes(p)&&!last.includes(p)),...last];
const cssInventory=[], declarations=[], roots={};
for(const name of cssOrder) {
  const text=await readFile(resolve(source,'src',name),'utf8');
  await write('reference/styles/'+name,text);
  const ast=postcss.parse(text), selectors=new Set(), queries=new Set();
  ast.walkRules(rule=>selectors.add(rule.selector));
  ast.walkAtRules('media',rule=>queries.add(rule.params));
  ast.walkDecls(decl=>{
    if(!decl.prop.startsWith('--'))return;
    const context=[]; for(let n=decl.parent;n&&n.type!=='root';n=n.parent)context.unshift(n.selector||`@${n.name} ${n.params}`);
    declarations.push({name:decl.prop,value:decl.value,source:'reference/styles/'+name,line:decl.source.start.line,context});
    if(decl.parent.type==='rule'&&decl.parent.selector===':root'&&decl.parent.parent.type==='root') roots[decl.prop]=decl.value;
  });
  cssInventory.push({file:'reference/styles/'+name,sha256:hash(text),bytes:Buffer.byteLength(text),selectors:[...selectors],media:[...queries]});
}
const {brandTokens}=await import(pathToFileURL(resolve(source,'src/brandTheme.js')));
Object.assign(roots,brandTokens('#1826ad','light'));
roots['--font-family-code']='ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
const portable=['ActionButton.jsx','Icon.jsx','CxTabs.jsx','EmptyState.jsx','CxConfirmation.jsx','HelpTrigger.jsx','TableEditModeButton.jsx','Toast.jsx','toastStore.js','modalFocus.js','confirmationCopy.js','CxSelect.jsx','SearchField.jsx','DateRangeFilter.jsx','calendarRange.js','CommunityStatus.jsx','CommitReference.jsx'];
const uiFiles=files.filter(p=>extname(p)==='.jsx');
const uiInventory=[];
for(const path of uiFiles) {
  const name=rel(path),text=await readFile(path,'utf8');
  const ast=parse(text,{sourceType:'module',plugins:['jsx']}), exports=[], imports=[];
  for(const node of ast.program.body) {
    if(node.type==='ImportDeclaration')imports.push(node.source.value);
    if(node.type==='ExportNamedDeclaration'&&node.declaration) {
      const d=node.declaration;
      if(d.id)exports.push({name:d.id.name,props:d.params?.[0]?.type==='ObjectPattern'?d.params[0].properties.map(p=>p.key?.name||'...props'):[]});
      for(const item of d.declarations||[])if(item.id.name)exports.push({name:item.id.name,props:[]});
    }
    if(node.type==='ExportDefaultDeclaration')exports.push({name:node.declaration.id?.name||'default',props:[]});
  }
  await write('reference/components/'+name,text);
  uiInventory.push({file:'reference/components/'+name,sha256:hash(text),exports,imports,availability:portable.includes(name)?'portable':'reference-only'});
}
for(const name of portable) {
  const text=await readFile(resolve(source,'src',name),'utf8');
  await write('src/'+name,text.replace(/^import ['"]\.\/[^'"]+\.css['"];?\s*$/gm,''));
}
// Detach the shared commit label from the product history module.
const historySource=await readFile(resolve(source,'src/historySearch.js'),'utf8');
const shortCommit=historySource.match(/export const shortCommit = [^\n]+/);
if(!shortCommit)throw new Error('Review shortCommit adaptation.');
const commitPath=resolve(root,'src/CommitReference.jsx');
await write('src/CommitReference.jsx',(await readFile(commitPath,'utf8')).replace("import { shortCommit } from './historySearch';",shortCommit[0].replace('export ','')));
// Keep closed selects renderable without a browser document.
const selectPath=resolve(root,'src/CxSelect.jsx');
await write('src/CxSelect.jsx',(await readFile(selectPath,'utf8')).replace('||document.body;',"||(typeof document==='undefined'?null:document.body);"));
// WebKit does not focus a button on pointer click by default. Give dialogs a consistent return target.
const actionPath=resolve(root,'src/ActionButton.jsx');
let actionSource=await readFile(actionPath,'utf8');
// Keep the portable login action alongside the captured logout action.
if (!/login\s*:/.test(actionSource)) {
  if (!actionSource.includes("logout: ['logOut','로그아웃']")) throw new Error('Review the portable login mapping before capture.');
  actionSource = actionSource.replace("logout: ['logOut','로그아웃']", "login: ['logIn','로그인'], logout: ['logOut','로그아웃']");
}
const originalClick="onClick={event=>{if(blocked){event.preventDefault();return;}setHint(false);onClick?.(event);}}";
if(!actionSource.includes(originalClick))throw new Error('ActionButton changed: review the portable pointer-focus adaptation before capture.');
await write('src/ActionButton.jsx',actionSource.replace(originalClick,"onClick={event=>{if(blocked){event.preventDefault();return;}event.currentTarget.focus({preventScroll:true});setHint(false);onClick?.(event);}}"));
// The catalogue can enumerate exactly the same icon paths as production.
await write('src/Icon.jsx',(await readFile(resolve(root,'src/Icon.jsx'),'utf8'))+'\nexport const ICON_NAMES = Object.freeze(Object.keys(GLYPHS));\n');
const modules=[];
for(const name of ['brandTheme.js','calendarRange.js','modalFocus.js','toastStore.js','confirmationCopy.js','IdentityMention.js','historySearch.js','reportInteractions.js','automationRate.js']) {
  const text=await readFile(resolve(source,'src',name),'utf8'),file='reference/modules/'+name;
  await write(file,text);modules.push({file,source:'src/'+name,sha256:hash(text),availability:'reference-only'});
}
await mkdir(resolve(root,'fonts'),{recursive:true});
await cp(resolve(source,'src/assets/fonts/noto-sans-kr'),resolve(root,'fonts'),{recursive:true});
const fontFiles=(await readdir(resolve(root,'fonts'))).filter(n=>n.endsWith('.woff2'));
const fonts=await Promise.all(fontFiles.map(async name=>({file:'fonts/'+name,sha256:hash(await readFile(resolve(root,'fonts',name)))})));
const decisionPaths=['docs/cx-design-review.md',...(await readdir(resolve(source,'docs'))).filter(n=>n.startsWith('CX-')&&n.endsWith('.md')).map(n=>'docs/'+n),...(await readdir(resolve(source,'verification'))).filter(n=>n.includes('CX')&&n.endsWith('.md')).map(n=>'verification/'+n)];
const decisions=[];
for(const name of decisionPaths){const text=await readFile(resolve(source,name),'utf8');await write('reference/decisions/'+name,text);decisions.push({source:name,file:'reference/decisions/'+name,sha256:hash(text),status:'historical-reference'});}
await write('tokens/css-variables.json',{description:'Unconditional light-mode root values, including the fixed product brand. Responsive and contextual overrides remain in declarations.json.',values:roots});
await write('tokens/declarations.json',declarations);
await write('reference/inventory.json',{capturedAt:new Date().toISOString(),sourceRevision,includesWorkingTree:Boolean(dirtySource),cssOrder:cssInventory.map(s=>s.file),styles:cssInventory,components:uiInventory,modules,fonts,decisions,scope:'All src non-font CSS and UI JSX including the application entry for reference, plus selected UI helpers and bundled font files. Business data, authentication clients, credentials and deployment assets are not part of the runtime package. Reference JSX may import application modules and is not a standalone API.'});
const updates={sourceRevision,previousSourceRevision:previous.sourceRevision,styles:{},components:{}};
for(const [key,current] of [['styles',cssInventory],['components',uiInventory]]) {
  const old=new Map(previous[key].map(entry=>[entry.file,entry.sha256])),now=new Map(current.map(entry=>[entry.file,entry.sha256]));
  updates[key]={added:[...now.keys()].filter(file=>!old.has(file)),updated:[...now.keys()].filter(file=>old.has(file)&&old.get(file)!==now.get(file)),removed:[...old.keys()].filter(file=>!now.has(file))};
}
if(Object.values(updates.styles).some(items=>items.length)||Object.values(updates.components).some(items=>items.length))await write('reference/updates.json',updates);
await write('reference/styles-entry.css',cssInventory.map(s=>`@import './${s.file.replace('reference/','')}';`).join('\n')+'\n');
console.log(JSON.stringify({styles:cssInventory.length,uiModules:uiInventory.length,fontFiles:fonts.length,rootVariables:Object.keys(roots).length,tokenDeclarations:declarations.length},null,2));

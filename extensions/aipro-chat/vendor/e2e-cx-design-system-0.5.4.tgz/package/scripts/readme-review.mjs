import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
// test:distribution builds these files from the exact JSX and CSS in README.md.
const server=await servePages(resolve(root,'verification/consumer-readme'),'/Manufacturing-IT/CX/'),results=[];
try{
  for(const engine of ['chromium','firefox','webkit']){
    const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
    try{
      for(const width of [390,1440]){
        const page=await browser.newPage({viewport:{width,height:900}});page.setDefaultTimeout(6000);
        const errors=[];page.on('pageerror',error=>errors.push(error.message));
        await page.goto(server.url);await page.getByRole('heading',{name:'업무 관리'}).waitFor();
        await page.getByRole('button',{name:'추가',exact:true}).click();
        await page.getByText('업무 이름을 입력하세요.',{exact:true}).waitFor();
        await page.getByRole('textbox',{name:'업무 이름'}).fill('한글 업무 테스트');
        await page.getByRole('button',{name:'추가',exact:true}).click();
        await page.getByRole('cell',{name:'한글 업무 테스트',exact:true}).waitFor();
        assert.equal(await page.getByRole('textbox',{name:'업무 이름'}).inputValue(),'');
        assert.equal(await page.getByText('업무 이름을 입력하세요.',{exact:true}).count(),0);
        assert.deepEqual(errors,[]);
        await page.evaluate(()=>document.fonts.ready);
        assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
        results.push({engine,width,validation:true,addRow:true,korean:true});
        await page.close();
      }
    }finally{await browser.close();}
  }
}finally{await server.close();}
await writeFile(resolve(root,'verification/readme-browser-results.json'),JSON.stringify(results,null,2));
console.log(JSON.stringify({readmeExampleScenarios:results.length,passed:results.length}));

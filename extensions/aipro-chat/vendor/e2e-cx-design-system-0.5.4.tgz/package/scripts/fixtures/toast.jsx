import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {CxAppShell,CxButton,notifyToast,useFeedback,ToastNotice} from '../../dist/index.js';
import {ToastExamples} from '../../catalog/ToastExamples.jsx';
// Public API bridge belongs only to this isolated synthetic-data regression fixture.
window.toastReview={notifyToast};
function OwnedFeedback(){const [message,notify,error]=useFeedback();return <section><CxButton onClick={()=>notify('폼 오류입니다.',true)}>폼 오류</CxButton><CxButton onClick={()=>notify('저장했습니다.')}>폼 완료</CxButton><p data-local-error>{error?message:''}</p></section>;}
function Fixture(){const [show,setShow]=useState(true),[notice,setNotice]=useState('');return <CxAppShell brand="CX 알림 검증"><ToastExamples/><button id="toast-review-outside">다른 항목</button><CxButton onClick={()=>setShow(v=>!v)}>폼 표시 전환</CxButton>{show&&<OwnedFeedback/>}<CxButton onClick={()=>setNotice('선언형 오류입니다.')}>선언형 오류</CxButton><CxButton onClick={()=>setNotice('')}>선언형 해제</CxButton>{notice&&<ToastNotice message={notice} error/>}</CxAppShell>;}
createRoot(document.getElementById('root')).render(<Fixture/>);

// Synthetic data only. Import the original product implementation for an isolated audit.
import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {WorkspaceMemory} from 'e2e-source/WorkspaceMemory.jsx';
import {SettingsGrid,useSettingsGrid} from 'e2e-source/SettingsGrid.jsx';
import {GroupedSettingsGrid} from 'e2e-source/GroupedSettingsGrid.jsx';
import {ColumnVisibilityMenu} from 'e2e-source/ColumnVisibilityMenu.jsx';
import {DetailPanel} from 'e2e-source/DetailPanel.jsx';

const columns=[{key:'label',label:'이름',width:180,group:'basic'},{key:'team',label:'부서',width:180,group:'basic'},{key:'rate',label:'수치',width:180,group:'basic'},{key:'memo',label:'설명',width:180,group:'basic'}];
const rows=Array.from({length:23},(_,i)=>({id:String(i),label:`항목 ${i+1}`,team:i%2?'개발':'운영',rate:i===0?0:i===1?null:i,memo:'긴 내용 확인',group:'one'}));
function Grid({grouped=false}) {
  const grid=useSettingsGrid({id:grouped?'audit.groups':'audit.table',rows,columns,label:'검토 목록',interactive:true,paginate:!grouped});
  const cell=(row,key)=>row[key]??'—';
  return <section aria-label="표 검토"><output data-audit-state>{JSON.stringify({sort:grid.sort,filters:grid.controls.filters,widths:grid.controls.widths,selected:[...grid.selection.ids],pinned:grid.pinned,page:grid.pagination.page,total:grid.pagination.total})}</output>{grouped?<GroupedSettingsGrid grid={grid} groups={[{key:'one',label:'검토 그룹',columns:columns.map(c=>c.key)}]} groupKey={r=>r.group} jumpLabel="그룹 이동" onAdd={()=>{}} renderCell={cell}/>:<SettingsGrid grid={grid} renderCell={cell}/>}</section>;
}
function Visibility({custom=false}) {
  const [hidden,setHidden]=useState([]);
  return <ColumnVisibilityMenu fields={custom?[{key:'customName',label:'사용자 이름'}]:columns} hidden={hidden} onChange={setHidden} view="audit"/>;
}
function Audit() {
  const mode=new URLSearchParams(location.search).get('case')||'table';
  const [open,setOpen]=useState(false),[mounted,setMounted]=useState(true);
  return <WorkspaceMemory><main className="app-shell" style={{display:'block',padding:16,maxWidth:'100%'}}><h1>표 원본 동작 검토</h1>{mode==='visibility-modal'?<><button onClick={()=>setOpen(true)}>검토 모달 열기</button>{open&&<DetailPanel title="검토 모달" hideHelp variant="modal" onClose={()=>setOpen(false)}><Visibility/></DetailPanel>}</>:mode==='custom-columns'?<Visibility custom/>:mode==='filter-modal'?<><button onClick={()=>setOpen(true)}>검토 모달 열기</button>{open&&<DetailPanel title="검토 모달" hideHelp variant="modal" onClose={()=>setOpen(false)}><Grid/></DetailPanel>}</>:<><button onClick={()=>setMounted(v=>!v)}>표 표시 전환</button>{mounted&&<Grid grouped={mode==='grouped'}/>}</>}</main></WorkspaceMemory>;
}
createRoot(document.getElementById('root')).render(<Audit/>);

import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {
  CxAppShell, CxButton, CxField, CxSelect, CxCheckbox, CxTabs,
  ActionLink, TableEditModeButton, CommitReference, CommunityStatus,
} from '../../dist/index.js';

// Synthetic host callbacks; no application data, network, or authentication.
function Fixture() {
  const [mode, setMode] = useState('success');
  const [active, setActive] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [calls, setCalls] = useState({enter:0, save:0, discard:0, link:0});
  const [blocked, setBlocked] = useState(true);
  const [choice, setChoice] = useState('one');
  const [removed, setRemoved] = useState(false);
  const [locked, setLocked] = useState(false);
  const [tab, setTab] = useState('first');
  const [checked, setChecked] = useState(false);
  const increment = key => setCalls(value => ({...value, [key]:value[key]+1}));
  async function callback(key) {
    increment(key);
    await new Promise(resolve => setTimeout(resolve, 250));
    if (mode === 'null-error') throw null;
    if (mode === 'error') throw new Error('작업을 완료하지 못했습니다.');
    return mode !== 'reject';
  }
  return <CxAppShell brand="CX 컴포넌트 검증">
    <h1>공개 컴포넌트 동작</h1>
    <label>콜백 결과<select value={mode} onChange={event=>setMode(event.target.value)}>
      {['success','reject','error','null-error'].map(value=><option key={value}>{value}</option>)}
    </select></label>
    <output data-state>{JSON.stringify({active,dirty,calls,choice,tab,checked})}</output>
    <section aria-label="수정 모드">
      <TableEditModeButton active={active} dirty={dirty} onChange={setActive}
        onEnter={()=>callback('enter')}
        onSave={async()=>{const saved=await callback('save');if(saved)setDirty(false);return saved;}}
        onDiscard={()=>{increment('discard');if(mode==='null-error')throw null;if(mode==='reject')return false;setDirty(false);return true;}}/>
      <CxButton onClick={()=>setDirty(true)}>초안 변경</CxButton>
    </section>
    <section aria-label="링크">
      <CxButton onClick={()=>setBlocked(value=>!value)}>링크 잠금 전환</CxButton>
      <ActionLink action="openExternal" label="세부 페이지" href="#details" disabled={blocked}
        onClick={()=>increment('link')}/>
    </section>
    <form aria-label="선택 폼">
      <fieldset disabled={locked}><CxField label="항목">
        <CxSelect name="item" value={choice} onChange={event=>setChoice(event.target.value)}>
          <option value="one">첫 항목</option><option value="blocked" disabled>선택 불가</option>
          {!removed&&<option value="two">둘째 항목</option>}
          <optgroup label="닫힌 그룹" disabled><option value="group">그룹 항목</option></optgroup>
        </CxSelect>
      </CxField></fieldset>
      <CxButton onClick={()=>setRemoved(value=>!value)}>선택 항목 제거</CxButton>
      <CxButton onClick={()=>setLocked(value=>!value)}>폼 잠금 전환</CxButton>
      <CxCheckbox label="혼합 선택" checked={checked} mixed={!checked} onChange={event=>setChecked(event.target.checked)}/>
    </form>
    <CxTabs label="검증 탭" idPrefix="review" panelId="review-panel" active={tab}
      items={[{key:'first',label:'첫 화면'},{key:'second',label:'둘째 화면'}]}
      onChange={key=>{if(mode==='reject')return false;setTab(key);}}/>
    <div role="tabpanel" id="review-panel" aria-labelledby={`review-${tab}`}>{tab}</div>
    <div id="details"><CommitReference sha={'a'.repeat(40)} url="https://example.invalid/commit"/>
      <CommitReference sha={'b'.repeat(40)} url="javascript:alert(1)"/>
      <CommitReference sha="invalid" url="https://example.invalid/commit"/></div>
    <CommunityStatus loading label="목록을 불러오는 중…"/>
  </CxAppShell>;
}
createRoot(document.getElementById('root')).render(<Fixture/>);

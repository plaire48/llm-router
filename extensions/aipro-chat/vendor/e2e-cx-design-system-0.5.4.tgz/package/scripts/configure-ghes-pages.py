"""Configure committed main/root files as GHES Pages; Python 3 standard library only."""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

SERVER = "https://code.sdsdev.co.kr"
REPOSITORY = "Manufacturing-IT/CX"
RESOURCE = "/repos/" + REPOSITORY
SOURCE = {"branch": "main", "path": "/"}


class PagesError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Client:
    def __init__(self, token):
        self.token = token
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, method, path, body=None):
        request = urllib.request.Request(
            SERVER + "/api/v3" + path,
            data=None if body is None else json.dumps(body).encode(), method=method,
            headers={"Authorization": "Bearer " + self.token,
                     "Accept": "application/vnd.github+json",
                     "Content-Type": "application/json",
                     "X-GitHub-Api-Version": "2022-11-28"},
        )
        try:
            response = self.opener.open(request, timeout=30)
        except urllib.error.HTTPError as error:
            response = error
        except (urllib.error.URLError, TimeoutError) as error:
            raise PagesError("사내 GHES에 연결할 수 없습니다. 실행기의 DNS·네트워크·인증서를 확인하세요.") from error
        with response:
            raw = response.read()
            try:
                data = json.loads(raw) if raw else {}
            except ValueError:
                raise PagesError("GHES API가 JSON 대신 다른 응답을 반환했습니다. API 접근·SSO 설정을 확인하세요.")
            return response.code, data


def require(status, allowed, action):
    if status not in allowed:
        hint = ""
        if status in (401, 403, 404):
            hint = (" 저장소 접근 권한과 Pages 활성화를 확인하세요. 최초 생성·원본 변경에는"
                    " 관리자 또는 Pages 관리 권한의 CX_PAGES_TOKEN이 필요할 수 있습니다.")
        raise PagesError("{}: HTTP {}.{}".format(action, status, hint))


def configure(client, expected_sha=None, attempts=60, pause=time.sleep):
    status, repository = client.request("GET", RESOURCE)
    require(status, (200,), "저장소 조회")
    if repository.get("full_name", "").lower() != REPOSITORY.lower():
        raise PagesError("응답의 저장소가 배포 대상과 다릅니다.")
    if repository.get("default_branch") != "main":
        raise PagesError("이 자동화는 기본 브랜치 main을 게시합니다. 저장소 기본 브랜치를 main으로 설정하세요.")
    status, branch = client.request("GET", RESOURCE + "/branches/main")
    require(status, (200,), "main 조회")
    head = branch.get("commit", {}).get("sha")
    if not head:
        raise PagesError("main 커밋을 확인하지 못했습니다.")
    if expected_sha and head != expected_sha:
        return {"status": "superseded", "message": "더 최근 main 커밋의 실행이 배포를 이어갑니다."}

    # Confirm the uploaded main contains actual runtime files before changing server settings.
    for path in ("index.html", ".nojekyll", "catalog/index.html", "catalog/site.js",
                 "catalog/catalog.css", "dist/styles.css", "starter/src/app.css", "dist/fonts"):
        status, _ = client.request("GET", RESOURCE + "/contents/" + path + "?ref=" + head)
        require(status, (200,), "배포 파일 " + path)

    status, site = client.request("GET", RESOURCE + "/pages")
    if status == 404:
        status, _ = client.request("POST", RESOURCE + "/pages", {"build_type": "legacy", "source": SOURCE})
        require(status, (201,), "Pages 최초 생성")
    else:
        require(status, (200,), "Pages 조회")
        if site.get("source") != SOURCE or site.get("build_type", "legacy") != "legacy":
            status, _ = client.request("PUT", RESOURCE + "/pages", {"build_type": "legacy", "source": SOURCE})
            require(status, (204,), "Pages main/root 설정")
    status, site = client.request("GET", RESOURCE + "/pages")
    require(status, (200,), "Pages 설정 확인")
    if site.get("source") != SOURCE or site.get("build_type", "legacy") != "legacy":
        raise PagesError("Pages 게시 원본이 main/root로 적용되지 않았습니다.")
    status, _ = client.request("POST", RESOURCE + "/pages/builds", {})
    require(status, (201,), "Pages 빌드 요청")
    for _ in range(attempts):
        status, build = client.request("GET", RESOURCE + "/pages/builds/latest")
        require(status, (200, 404), "Pages 빌드 상태 조회")
        if status == 200 and build.get("commit") == head:
            if build.get("status") == "errored":
                raise PagesError("Pages 서버 빌드가 실패했습니다. 저장소 Settings → Pages에서 빌드 오류를 확인하세요.")
            if build.get("status") == "built":
                return {"status": "built", "commit": head, "source": SOURCE,
                        "url": site.get("html_url"), "repository": SERVER + "/" + REPOSITORY}
        # A queued older run must not report another commit's deployment as its own success.
        pause(5)
    raise PagesError("Pages 설정과 빌드 요청은 완료했지만, 해당 커밋의 게시 완료를 제한 시간 안에 확인하지 못했습니다.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="네트워크 요청 없이 적용 대상을 표시")
    args = parser.parse_args()
    if args.dry_run:
        print(json.dumps({"repository": SERVER + "/" + REPOSITORY, "build_type": "legacy", "source": SOURCE}, indent=2))
        return
    for key, expected in (("GITHUB_SERVER_URL", SERVER), ("GITHUB_REPOSITORY", REPOSITORY), ("GITHUB_REF", "refs/heads/main")):
        if os.environ.get(key, expected) != expected:
            raise PagesError("{}가 사내 CX main 대상과 다릅니다. 설정을 변경하지 않았습니다.".format(key))
    token = os.environ.get("CX_PAGES_TOKEN") or os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_ENTERPRISE_TOKEN")
    if not token:
        raise PagesError("CX_PAGES_TOKEN 환경변수 또는 Actions GITHUB_TOKEN이 필요합니다. 토큰을 저장소 파일에 넣지 마세요.")
    result = configure(Client(token), expected_sha=os.environ.get("GITHUB_SHA"))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as output:
            if result["status"] == "built":
                output.write("CX main/root Pages 게시 완료\n\n커밋: `{}`\n\n주소: {}\n".format(result["commit"], result["url"]))
            else:
                output.write(result["message"] + "\n")


if __name__ == "__main__":
    try:
        main()
    except PagesError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)

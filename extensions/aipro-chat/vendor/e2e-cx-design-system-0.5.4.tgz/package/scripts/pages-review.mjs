import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const results=[];
await mkdir(resolve(root,'verification'),{recursive:true});
for(const engine of ['chromium','firefox','webkit']){
  const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
  try{
    for(const base of ['/','/CX/','/Manufacturing-IT/CX/','/pages/Manufacturing-IT/CX/']){
      const server=await servePages(resolve(process.env.CX_PAGES_DIRECTORY||root),base);
      try{
        for(const settings of [{width:390,height:844},{width:700,height:900},{width:701,height:900},{width:1440,height:900},{width:1440,height:900,touch:true}]){
          const {touch=false,...viewport}=settings;
          const expectedSize=touch?44:32;
          const page=await browser.newPage({viewport,hasTouch:touch});page.setDefaultTimeout(6000);
          const failures=[];
          page.on('pageerror',error=>failures.push(error.message));
          page.on('requestfailed',request=>failures.push(request.url()));
          page.on('response',response=>{if(response.status()>=400&&!response.url().endsWith('/favicon.ico'))failures.push(`${response.status()} ${response.url()}`);});
          try{
            await page.goto(server.url+'?test=pages#entry');
            await page.getByRole('heading',{name:/하나의 기준으로/}).waitFor();
            assert.equal(page.url(),server.url+'catalog/index.html?test=pages#entry');
            await page.evaluate(()=>document.fonts.ready);
            const layout=await page.evaluate(()=>({
              font:getComputedStyle(document.body).fontFamily,
              loaded:[...document.fonts].some(font=>font.family==='Noto Sans KR'&&font.status==='loaded'),
              overflow:document.documentElement.scrollWidth>innerWidth+1,
            }));
            assert.ok(layout.font.includes('Noto Sans KR')&&layout.loaded);assert.equal(layout.overflow,false);
            await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/컴포넌트/}).click();
            if(touch)assert.ok(await page.evaluate(()=>matchMedia('(pointer: coarse)').matches));
            const action=await page.getByRole('button',{name:'추가',exact:true}).boundingBox();
            assert.equal(action.width,expectedSize);assert.equal(action.height,expectedSize);
            for(const name of ['적용','취소','비활성','처리 중…'])assert.equal((await page.getByRole('button',{name,exact:true}).boundingBox()).height,expectedSize,name);
            assert.equal((await page.getByRole('textbox',{name:'기본 입력',exact:true}).boundingBox()).height,expectedSize);
            assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--cx-control-small').trim()),expectedSize===44?'44px':'28px');
            assert.equal(await page.getByRole('button',{name:'적용',exact:true}).evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(24, 38, 173)');
            const trigger=page.getByRole('button',{name:'모달 열기',exact:true});
            await trigger.click();await page.getByRole('dialog',{name:'내용을 확인하세요'}).waitFor();
            assert.equal((await page.getByRole('dialog').getByRole('button',{name:'닫기',exact:true}).boundingBox()).height,expectedSize);
            await page.keyboard.press('Escape');
            await page.getByRole('dialog',{name:'내용을 확인하세요'}).waitFor({state:'detached'});
            assert.ok(await trigger.evaluate(el=>el===document.activeElement));
            await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/전체 참조/}).click();
            for(const href of await page.locator('a[href]').evaluateAll(links=>links.map(a=>a.href))){
              assert.ok(href.startsWith(server.url),href);
              assert.equal((await page.request.get(href)).status(),200,href);
            }
            await page.getByRole('link',{name:'사용 설명서'}).click();
            await page.getByRole('heading',{name:'CX Design System 사용 방법',exact:true}).waitFor();
            await page.evaluate(()=>document.fonts.ready);
            const guide=await page.evaluate(()=>({encoding:document.characterSet,text:document.body.textContent,overflow:document.documentElement.scrollWidth>innerWidth+1,fontLoaded:[...document.fonts].some(font=>font.family==='Noto Sans KR'&&font.status==='loaded')}));
            assert.equal(guide.encoding,'UTF-8');assert.ok(guide.text.includes('업무 이름을 입력하세요.'));assert.ok(!guide.text.includes('\uFFFD'));assert.ok(guide.fontLoaded);assert.equal(guide.overflow,false);
            if(base==='/Manufacturing-IT/CX/'&&!touch&&[390,1440].includes(viewport.width))await page.screenshot({path:resolve(root,`verification/usage-${engine}-${viewport.width}.png`),fullPage:true});
            assert.deepEqual(failures,[]);
            results.push({engine,version:browser.version(),base,width:viewport.width,touch,controlSize:expectedSize,koreanGuide:true,pass:true});
          }finally{await page.close();}
        }
      }finally{await server.close();}
    }
  }finally{await browser.close();}
}
await writeFile(resolve(root,'verification/pages-browser-results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({scenarios:results.length,passed:results.filter(r=>r.pass).length,results},null,2));

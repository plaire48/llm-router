import {execFileSync} from 'node:child_process';
import {cp,mkdir,readFile,rm,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
export const pagesDirectory=resolve(root,'.build/pages');
export const pagesArchive=resolve(root,`releases/cx-pages-${pkg.version}.zip`);
await rm(pagesDirectory,{recursive:true,force:true});
await mkdir(pagesDirectory,{recursive:true});
for(const path of [
  'index.html','.nojekyll','README.md','THIRD-PARTY-NOTICES.md','AGENTS.md','CHANGELOG.md',
  'dist','src','docs','tokens','agent','skills','reference','fonts','templates','recipes','downloads',
  'catalog/index.html','catalog/site.js','catalog/catalog.css','catalog/templates.css',
  'catalog/ToastExamples.jsx','scripts/toast-review.mjs','catalog/REACT-LICENSE.txt','catalog/REACT-DOM-LICENSE.txt','starter/src/app.css',
]){
  const destination=resolve(pagesDirectory,path);
  await mkdir(dirname(destination),{recursive:true});
  await cp(resolve(root,path),destination,{recursive:true});
}
await writeFile(resolve(pagesDirectory,'DEPLOY.txt'),
  '\uFEFF이 ZIP의 내용 전체를 Pages 게시 폴더에 올리세요.\n'+
  'index.html과 catalog/, dist/, starter/ 등의 상대 위치를 유지해야 CSS, JS, 폰트가 로드됩니다.\n'+
  'catalog/index.html만 옮기거나 파일을 한 폴더로 합치지 마세요.\n'+
  '루트 index.html은 catalog/index.html로 이동합니다. 별도 서버 빌드는 필요 없습니다.\n');
await mkdir(dirname(pagesArchive),{recursive:true});
await rm(pagesArchive,{force:true});
execFileSync('zip',['-qr',pagesArchive,'.'],{cwd:pagesDirectory});
console.log(JSON.stringify({pagesDirectory,pagesArchive}));

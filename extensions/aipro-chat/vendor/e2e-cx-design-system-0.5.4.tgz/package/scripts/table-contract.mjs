import {readFile,writeFile,access} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const json=async path=>JSON.parse(await readFile(resolve(root,path),'utf8'));
const contract=await json('recipes/table-contract.json'),inventory=await json('reference/inventory.json'),pkg=await json('package.json'),manifest=await json('agent/manifest.json');
const evidence=await json(contract.verification.evidence);
if(evidence.sourceRevision!==inventory.sourceRevision)throw new Error('Table audit is stale: review the newly captured product revision.');
if(new Set(contract.features.map(item=>item.id)).size!==contract.features.length)throw new Error('Duplicate table feature ID');
const publicNames=new Set(manifest.portable.map(item=>item.name));
if(!publicNames.has(contract.publicComponent))throw new Error('Unknown public table component');
const referenceFiles=new Set([...inventory.components,...inventory.modules,...inventory.styles].map(item=>item.file));
for(const file of new Set([...contract.features.flatMap(item=>item.sources),...contract.knownGaps.flatMap(item=>item.sources),...contract.variants.map(item=>item.source)])){
  if(!file.startsWith('src/')&&!referenceFiles.has(file))throw new Error('Uncaptured table reference: '+file);
  await access(resolve(root,file));
}
await access(resolve(root,contract.guide));
await writeFile(resolve(root,'agent/table-contract.json'),JSON.stringify({...contract,version:pkg.version,sourceRevision:inventory.sourceRevision},null,2)+'\n');
console.log(`Built table contract: ${contract.features.length} features, ${contract.knownGaps.length} open reference findings`);

import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const catalogue=process.env.CX_CATALOG_URL||'http://127.0.0.1:5188/catalog/index.html';
const consumer=process.env.CX_CONSUMER_URL||'http://127.0.0.1:5191/';
const report={catalogue,consumer,engines:[],checks:0};
const verify=(condition,message)=>{assert.ok(condition,message);report.checks++;};
await mkdir(resolve(root,'verification'),{recursive:true});
const sections=['시작하기','기본 규격','토큰','템플릿','컴포넌트','화면 패턴','아이콘','전체 참조','에이전트 사용'];
async function geometry(page,label){const result=await page.evaluate(()=>{const main=document.querySelector('main'),footer=document.querySelector('.cx-kit-footer');return {overflow:document.documentElement.scrollWidth>innerWidth+1,footerOverlap:footer&&main&&footer.getBoundingClientRect().top<main.getBoundingClientRect().bottom-1,font:getComputedStyle(document.body).fontFamily,loaded:[...document.fonts].filter(font=>font.family==='Noto Sans KR'&&font.status==='loaded').length};});verify(!result.overflow,label+' page overflow');verify(!result.footerOverlap,label+' footer covers content');verify(result.font.includes('Noto Sans KR')&&result.loaded>0,label+' bundled font loaded');}
async function workflow(page,label){
  await page.goto(consumer);await page.getByRole('heading',{name:'업무 목록',exact:true}).waitFor();await page.evaluate(()=>document.fonts.ready);await geometry(page,label);
  await page.getByRole('searchbox',{name:'업무 검색'}).fill('no-match');verify(await page.getByText('조회 결과가 없습니다.',{exact:true}).isVisible(),label+' empty state');
  await page.getByRole('searchbox',{name:'업무 검색'}).fill('');
  await page.getByRole('tab',{name:'전체',exact:true}).focus();await page.keyboard.press('ArrowRight');verify(await page.getByRole('tab',{name:'사용 중',exact:true}).getAttribute('aria-selected')==='true',label+' keyboard tab navigation');
  await page.getByRole('tab',{name:'전체',exact:true}).click();
  const trigger=page.getByRole('button',{name:'고객 문의 분류 수정',exact:true});await trigger.click();
  const panel=page.getByRole('dialog',{name:'업무 수정'});await panel.waitFor();
  verify(await page.locator('#root').evaluate(el=>el.inert),label+' background inert');
  verify(await panel.getByRole('button',{name:'저장',exact:true}).isDisabled(),label+' unchanged save disabled');
  const name=panel.getByRole('textbox',{name:'이름',exact:true});await name.fill('새 이름');await name.fill('고객 문의 분류');verify(await panel.getByRole('button',{name:'저장',exact:true}).isDisabled(),label+' A-B-A clean');await name.fill('수정한 업무');
  await panel.getByRole('checkbox',{name:'저장 실패 상태 체험'}).check();await panel.getByRole('button',{name:'저장',exact:true}).click();
  await panel.getByRole('alert').waitFor();verify(await name.inputValue()==='수정한 업무',label+' failed save retains draft');
  await panel.getByRole('button',{name:'취소',exact:true}).click();const confirmation=page.getByRole('alertdialog');await confirmation.waitFor();
  verify(await confirmation.getByRole('button',{name:'계속 수정',exact:true}).evaluate(el=>el===document.activeElement),label+' safe initial focus');
  await page.keyboard.press('Escape');await confirmation.waitFor({state:'detached'});verify(await panel.isVisible(),label+' nested Esc only closes top');
  await panel.getByRole('checkbox',{name:'저장 실패 상태 체험'}).uncheck();await panel.getByRole('button',{name:'저장',exact:true}).click();await panel.waitFor({state:'detached'});
  verify(await page.getByRole('cell',{name:'수정한 업무',exact:true}).isVisible(),label+' retry saves');verify(!await page.locator('#root').evaluate(el=>el.inert),label+' background restored');
  const updatedTrigger=page.getByRole('button',{name:'수정한 업무 수정',exact:true});verify(await updatedTrigger.evaluate(el=>el===document.activeElement),label+' focus restored');
  await updatedTrigger.click();const reopened=page.getByRole('dialog',{name:'업무 수정'});await reopened.getByRole('textbox',{name:'이름',exact:true}).fill('버릴 초안');await reopened.getByRole('button',{name:'취소',exact:true}).click();await page.getByRole('alertdialog').getByRole('button',{name:'저장하지 않고 닫기',exact:true}).click();verify(await page.getByRole('cell',{name:'수정한 업무',exact:true}).isVisible(),label+' discarded draft leaves saved data');
}
for(const engineName of ['chromium','firefox','webkit']){
  const browser=await playwright[engineName].launch({headless:true,...(engineName==='chromium'?{channel:'chrome'}:{})});
  const page=await browser.newPage();page.setDefaultTimeout(6000);
  const errors=[],badResponses=[],external=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('favicon.ico'))badResponses.push(`${r.status()} ${r.url()}`);});
  await page.route('**/*',route=>{const url=route.request().url();if(url.startsWith('http')&&!['127.0.0.1','localhost'].includes(new URL(url).hostname)){external.push(url);return route.abort();}return route.continue();});
  try{
    await page.goto(catalogue);await page.getByRole('heading',{name:/하나의 기준으로/}).waitFor();
    for(const [width,height] of [[320,568],[390,844],[768,1024],[1440,900]]){
      await page.setViewportSize({width,height});
      for(const section of sections){await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:new RegExp(section)}).click();await page.evaluate(()=>document.fonts.ready);await geometry(page,`${engineName} ${width} ${section}`);}
      if(width===320||width===1440){await workflow(page,`${engineName} consumer ${width}`);await page.screenshot({path:resolve(root,`verification/consumer-${engineName}-${width}.png`),fullPage:true});await page.goto(catalogue);await page.getByRole('heading',{name:/하나의 기준으로/}).waitFor();}
      console.log(`${engineName} ${width}x${height}: layouts and applicable workflows passed`);
    }
    await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/컴포넌트/}).click();
    const primary=page.getByRole('button',{name:'적용',exact:true});verify(await primary.evaluate(el=>getComputedStyle(el).backgroundColor)==='rgb(24, 38, 173)',engineName+' fixed brand');
    const action=page.getByRole('button',{name:'추가',exact:true});const box=await action.boundingBox();verify(box.width===32&&box.height===32,engineName+' desktop action target');
    await page.getByRole('button',{name:'모달 열기',exact:true}).click();const parent=page.getByRole('dialog',{name:'내용을 확인하세요'});await parent.getByRole('button',{name:'도움말 열기',exact:true}).click();await page.getByRole('dialog',{name:'도움말',exact:true}).waitFor();await page.keyboard.press('Escape');verify(await parent.isVisible(),engineName+' help layer');await page.keyboard.press('Escape');verify(await page.getByRole('button',{name:'모달 열기',exact:true}).evaluate(el=>el===document.activeElement),engineName+' catalogue modal focus');
    await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/시작하기/}).click();await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:resolve(root,`verification/catalog-${engineName}-desktop.png`),fullPage:true});
    await page.setViewportSize({width:390,height:844});await page.screenshot({path:resolve(root,`verification/catalog-${engineName}-mobile.png`),fullPage:true});
    verify(errors.length===0,engineName+' JS errors '+errors.join(';'));verify(badResponses.length===0,engineName+' missing assets '+badResponses.join(';'));verify(external.length===0,engineName+' unexpected external requests');
    report.engines.push({name:engineName,version:browser.version(),sizes:4,sections:sections.length,jsErrors:errors,missingAssets:badResponses,externalRequests:external});
  }finally{await browser.close();}
}
const offline=await playwright.chromium.launch({headless:true,channel:'chrome'});try{const page=await offline.newPage();await page.goto(pathToFileURL(resolve(root,'catalog/index.html')).href);await page.getByRole('heading',{name:/하나의 기준으로/}).waitFor();await page.evaluate(()=>document.fonts.ready);await geometry(page,'offline file catalogue');verify(await page.getByRole('button',{name:'개발 시작하기',exact:true}).isVisible(),'offline catalogue functional');}finally{await offline.close();}
await writeFile(resolve(root,'verification/browser-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));

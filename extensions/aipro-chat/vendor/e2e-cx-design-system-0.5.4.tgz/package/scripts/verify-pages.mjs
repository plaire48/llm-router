import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {access,readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {createHash} from 'node:crypto';

// Plain static hosting: directory indexes only, without the preview server's routing.
export async function servePages(directory,base='/',{charset}={}){
  const mime={'.zip':'application/zip','.html':'text/html','.css':'text/css','.js':'text/javascript','.woff2':'font/woff2','.txt':'text/plain','.md':'text/plain','.jsx':'text/plain','.mjs':'text/plain','.json':'application/json'};
  const server=createServer(async(req,res)=>{
    try{
      const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
      if(!pathname.startsWith(base))throw new Error('Outside publishing base');
      let path=resolve(directory,pathname.slice(base.length));
      if(path!==directory&&!path.startsWith(directory+sep))throw new Error('Outside publishing root');
      if((await stat(path)).isDirectory())path=resolve(path,'index.html');
      const bytes=await readFile(path);
      const type=mime[extname(path)]||'application/octet-stream';
      res.writeHead(200,{'Content-Type':type+(charset&&/^(text\/|application\/json)/.test(type)?'; charset='+charset:'')});res.end(bytes);
    }catch{res.writeHead(404);res.end('Not found');}
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  return {url:`http://127.0.0.1:${server.address().port}${base}`,close:()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();})};
}

export async function verifyPages(directory){
  await access(resolve(directory,'.nojekyll'));
  const results=[];
  const documents=JSON.parse(await readFile(resolve(directory,'docs/text-pages.json'),'utf8')).pages;
  for(const {source,page} of documents){await access(resolve(directory,source));const bytes=await readFile(resolve(directory,page));assert.equal(bytes.subarray(0,3).toString('hex'),'efbbbf',page);}
  for(const base of ['/','/CX/','/Manufacturing-IT/CX/','/pages/Manufacturing-IT/CX/']){
    const server=await servePages(directory,base);
    try{
      const entry=await fetch(server.url);assert.equal(entry.status,200);
      assert.match(await entry.text(),/url=\.\/catalog\/index\.html/);
      const catalog=new URL('catalog/index.html',server.url);
      const response=await fetch(catalog);assert.equal(response.status,200);
      const html=await response.text();
      const download=await fetch(new URL('../downloads/cx-ui-skill.zip',catalog));
      assert.equal(download.status,200);
      const skillMetadata=JSON.parse(await readFile(resolve(directory,'downloads/cx-ui-skill.json'),'utf8'));
      assert.equal(createHash('sha256').update(Buffer.from(await download.arrayBuffer())).digest('hex'),skillMetadata.sha256);
      const queue=[...html.matchAll(/(?:href|src)="([^"]+)"/g)].map(m=>new URL(m[1],catalog));
      const visited=new Set();let stylesheets=0,fonts=0,scripts=0;
      while(queue.length){
        const url=queue.shift();if(visited.has(url.href))continue;visited.add(url.href);
        assert.ok(url.href.startsWith(server.url),`Asset escaped publishing base: ${url}`);
        const asset=await fetch(url);assert.equal(asset.status,200,url.href);
        const bytes=Buffer.from(await asset.arrayBuffer());assert.ok(bytes.length,url.href);
        if(url.pathname.endsWith('.css')){
          for(const match of bytes.toString().matchAll(/@import\s+["']([^"']+)["']/g))queue.push(new URL(match[1],url));
          stylesheets++;assert.match(asset.headers.get('content-type'),/^text\/css/);
          for(const match of bytes.toString().matchAll(/url\(["']?([^)'"\s]+)["']?\)/g)){
            if(!match[1].startsWith('data:'))queue.push(new URL(match[1],url));
          }
        }else if(url.pathname.endsWith('.woff2')){fonts++;assert.equal(bytes.subarray(0,4).toString(),'wOF2');}
        else if(url.pathname.endsWith('.js')){scripts++;assert.match(asset.headers.get('content-type'),/^text\/javascript/);}
      }
      assert.equal(stylesheets,3+JSON.parse(await readFile(resolve(directory,'templates/registry.json'),'utf8')).templates.length);assert.equal(scripts,1);assert.equal(fonts,124);
      results.push({base,stylesheets,scripts,fonts,documentViews:documents.length,skillDownload:true,missingAssets:0});
    }finally{await server.close();}
  }
  return results;
}

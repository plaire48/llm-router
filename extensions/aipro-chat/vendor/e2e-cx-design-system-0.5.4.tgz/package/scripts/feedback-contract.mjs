import {readFile,writeFile,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const json=async file=>JSON.parse(await readFile(resolve(root,file),'utf8'));
const contract=await json('recipes/feedback-contract.json'),manifest=await json('agent/manifest.json'),pkg=await json('package.json');
const names=new Set(manifest.portable.map(item=>item.name));
const {values:tokens}=await json('tokens/css-variables.json');
for(const api of contract.apis)if(!names.has(api.name))throw new Error('Unknown feedback API: '+api.name);
for(const token of contract.tokens)if(!Object.hasOwn(tokens,token))throw new Error('Unknown feedback token: '+token);
if(new Set(contract.features.map(item=>item.id)).size!==contract.features.length)throw new Error('Duplicate feedback feature');
const sources=[];
for(const file of new Set(contract.features.flatMap(item=>item.sources))){
  const bytes=await readFile(resolve(root,file));sources.push({file,sha256:createHash('sha256').update(bytes).digest('hex')});
}
for(const file of [contract.guide,contract.examples,contract.verification])await access(resolve(root,file));
if(contract.timing.fillMs+contract.timing.completionHoldMs!==contract.timing.durationMs)throw new Error('Feedback fill and hold must match total duration.');
// Surface a timing change for review instead of silently publishing an obsolete contract.
const toast=await readFile(resolve(root,'src/Toast.jsx'),'utf8');
if(!toast.includes(`duration = ${contract.timing.durationMs}, completionHold = ${contract.timing.completionHoldMs}`))throw new Error('Review feedback timing contract after changing Toast.jsx.');
await writeFile(resolve(root,'agent/feedback-contract.json'),JSON.stringify({...contract,version:pkg.version,sources},null,2)+'\n');
console.log(`Built feedback contract: ${contract.features.length} behaviors and ${contract.apis.length} public APIs`);

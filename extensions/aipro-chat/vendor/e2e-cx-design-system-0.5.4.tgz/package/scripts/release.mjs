import {execFileSync} from 'node:child_process';
import {mkdir,readFile,writeFile,cp,readdir,rm} from 'node:fs/promises';
import {resolve,dirname,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
execFileSync(process.execPath,['scripts/build.mjs'],{cwd:root,stdio:'inherit'});
const releases=resolve(root,'releases');await mkdir(releases,{recursive:true});
const skillArchive=resolve(releases,`cx-ui-skill-${pkg.version}.zip`);
await cp(resolve(root,'downloads/cx-ui-skill.zip'),skillArchive);
const packed=JSON.parse(execFileSync('npm',['pack','--json','--ignore-scripts','--pack-destination',releases],{cwd:root,encoding:'utf8'}))[0];
const archive=resolve(releases,packed.filename),folder=`cx-design-system-${pkg.version}`,staging=resolve(root,'.build',folder);
await rm(staging,{recursive:true,force:true});await mkdir(staging,{recursive:true});
const included=[...pkg.files,'package.json','package-lock.json','.gitignore'];
for(const path of included)await cp(resolve(root,path),resolve(staging,path),{recursive:true});
await cp(archive,resolve(staging,packed.filename));
async function files(dir){const out=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=resolve(dir,e.name);if(e.isDirectory())out.push(...await files(p));else out.push(p);}return out.sort();}
const sums=[];for(const path of await files(staging)){const digest=createHash('sha256').update(await readFile(path)).digest('hex');sums.push(`${digest}  ${relative(staging,path)}`);}
await writeFile(resolve(staging,'SHA256SUMS'),sums.join('\n')+'\n');
const zip=resolve(releases,folder+'.zip');await rm(zip,{force:true});
execFileSync('zip',['-qr',zip,folder],{cwd:dirname(staging)});
const {pagesArchive}=await import('./pages.mjs');
const archiveSums=await Promise.all([archive,zip,pagesArchive,skillArchive].map(async path=>`${createHash('sha256').update(await readFile(path)).digest('hex')}  ${relative(releases,path)}`));
await writeFile(resolve(releases,'SHA256SUMS'),archiveSums.join('\n')+'\n');
console.log(JSON.stringify({package:archive,zip,packageFiles:packed.entryCount,packageBytes:packed.size,unpackedBytes:packed.unpackedSize,sha256:createHash('sha256').update(await readFile(zip)).digest('hex')},null,2));

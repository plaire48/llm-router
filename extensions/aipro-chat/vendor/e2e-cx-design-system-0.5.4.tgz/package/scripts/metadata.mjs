import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parse} from '@babel/parser';
import {createRequire} from 'node:module';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),req=createRequire(import.meta.url);
const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
const version=pkg.version;
const {values}=JSON.parse(await readFile(resolve(root,'tokens/css-variables.json'),'utf8'));
const identity={format:'cx-identity/1',version,theme:'light',controls:{height:values['--cx-control'],smallHeight:values['--cx-control-small'],touchHeight:values['--cx-touch'],touchWhen:'(pointer: coarse)',rowHeight:values['--cx-row-height'],tableHeadHeight:values['--cx-table-head-height'],compactViewport:'Viewport width changes layout and field font size, not control density.'},font:{family:'Noto Sans KR',fallback:['Malgun Gothic','sans-serif'],weights:[400,500,700],files:'fonts/',license:'fonts/OFL.txt'},colors:[
  ['주요 동작','--brand-action'],['브랜드 강조','--brand-ink'],['선택 배경','--brand-selected'],['약한 강조','--brand-soft'],['페이지 배경','--layout-soft'],['표면','--layout-surface'],['본문','--layout-text'],['보조 글자','--layout-muted'],['테두리','--layout-border'],['성공','--cx-success'],['주의','--cx-warning'],['오류','--cx-danger']
].map(([label,token])=>({label,token,value:values[token]})),typography:[{label:'페이지 제목',size:'24px',weight:700,mobile:'20px'},{label:'모달 제목',size:'20px',weight:700,mobile:'18px'},{label:'구획 제목',size:'16px',weight:500},{label:'본문과 표',size:'14px',weight:400},{label:'보조 정보',size:'12px',weight:400}],spacing:[4,8,12,16,24,32],rules:'docs/IDENTITY.md',allVariables:'tokens/css-variables.json',contextualDeclarations:'tokens/declarations.json',note:'This is a documented CX manifest, not a DTCG format file. CSS variables and their contextual declarations remain the source for captured values.'};
await writeFile(resolve(root,'tokens/identity.json'),JSON.stringify(identity,null,2)+'\n');
const index=parse(await readFile(resolve(root,'src/index.jsx'),'utf8'),{sourceType:'module',plugins:['jsx']}),portable=[];
for(const exp of index.program.body){if(!exp.source)continue;const source='src/'+exp.source.value.replace('./','')+(exp.source.value.endsWith('Primitives')?'.jsx':['./confirmationCopy'].includes(exp.source.value)?'.js':'.jsx');const ast=parse(await readFile(resolve(root,source),'utf8'),{sourceType:'module',plugins:['jsx']});for(const spec of exp.specifiers){const name=spec.exported.name;const declaration=ast.program.body.find(n=>n.type==='ExportNamedDeclaration'&&n.declaration?.id?.name===name)?.declaration;const props=declaration?.params?.[0]?.type==='ObjectPattern'?declaration.params[0].properties.map(p=>({name:p.key?.name||'...props',hasDefault:p.value?.type==='AssignmentPattern'})):[];portable.push({name,source,import:'@e2e/cx-design-system',props,docs:['notifyToast','useFeedback','ToastNotice'].includes(name)?'docs/FEEDBACK.md':'docs/COMPONENTS.md',example:['notifyToast','useFeedback','ToastNotice'].includes(name)?'catalog/ToastExamples.jsx':['SearchField','DateRangeFilter','CommunityStatus','CommitId','CommitReference','ActionLink'].includes(name)?'docs/COMPONENTS.md':'starter/src/App.jsx',status:'portable'});}}
// Read dictionaries from source AST, so metadata cannot lag behind a build.
async function dictionary(file, name) {
  const ast=parse(await readFile(resolve(root,file),'utf8'),{sourceType:'module',plugins:['jsx']});
  for(const node of ast.program.body) {
    const declaration=node.type==='ExportNamedDeclaration'?node.declaration:node;
    for(const entry of declaration?.declarations||[]) {
      if(entry.id.name!==name)continue;
      const object=entry.init.type==='CallExpression'?entry.init.arguments[0]:entry.init;
      if(object.type!=='ObjectExpression')throw new Error('Review dictionary metadata: '+name);
      return object.properties;
    }
  }
  throw new Error('Missing dictionary: '+name);
}
const actions=(await dictionary('src/ActionButton.jsx','ACTIONS')).map(p=>({name:p.key.name||p.key.value,icon:p.value.elements[0].value,label:p.value.elements[1].value}));
const icons=(await dictionary('src/Icon.jsx','GLYPHS')).map(p=>p.key.name||p.key.value);
await mkdir(resolve(root,'agent'),{recursive:true});
await writeFile(resolve(root,'agent/manifest.json'),JSON.stringify({format:'cx-agent-manifest/1',package:pkg.name,version,entry:'agent/INSTRUCTIONS.md',styles:'@e2e/cx-design-system/styles.css',identity:'tokens/identity.json',designIndex:'agent/design-index.json',library:'agent/library.json',tokenCatalog:'tokens/catalog.json',templates:'templates/registry.json',recipes:'recipes/registry.json',skill:{name:'cx-ui',source:'skills/cx-ui/SKILL.md',guide:'docs/SKILLS.md',download:'downloads/cx-ui-skill.zip',downloadMetadata:'downloads/cx-ui-skill.json',install:'node scripts/install-skill.mjs',installOptions:['--target codex','--target claude','--target all'],targets:{codex:{directory:'.agents/skills/cx-ui',invoke:'$cx-ui'},claude:{directory:'.claude/skills/cx-ui',invoke:'/cx-ui'}}},portable,actions,icons,reference:{details:'reference/design-details.json',guide:'docs/DESIGN-INVENTORY.html',modules:'reference/modules/',inventory:'reference/inventory.json',components:'reference/components/',styles:'reference/styles/',status:'reference-only unless a portable export exists; application imports are not included'},patterns:[{name:'목록·상세·수정·저장',example:'starter/src/App.jsx',docs:'docs/PATTERNS.md'},{name:'설정·로그인·도움말·이력·서비스 데스크·Agent Flow',docs:'docs/PATTERNS.md',sources:'reference/components/'}],verification:'docs/VERIFICATION.md',consumerCheck:'cx-check src',limitations:['React 19 runtime APIs; CSS tokens are framework independent','Only light theme is supported','Global reset and full reference CSS: use one identity per document','No remote persistence or authentication','Static checks are a bounded guard, not complete design conformance']},null,2)+'\n');
await cp(resolve(dirname(req.resolve('react/package.json')),'LICENSE'),resolve(root,'catalog/REACT-LICENSE.txt'));
await cp(resolve(dirname(req.resolve('react-dom/package.json')),'LICENSE'),resolve(root,'catalog/REACT-DOM-LICENSE.txt'));

const starterPath=resolve(root,'starter/package.json');
const starter=JSON.parse(await readFile(starterPath,'utf8'));
starter.dependencies[pkg.name]=`file:vendor/e2e-cx-design-system-${version}.tgz`;
await writeFile(starterPath,JSON.stringify(starter,null,2)+'\n');
const htmlPath=resolve(root,'catalog/index.html');
await writeFile(htmlPath,(await readFile(htmlPath,'utf8')).replace(/<title>.*?<\/title>/,`<title>CX Design System · ${version}</title>`));

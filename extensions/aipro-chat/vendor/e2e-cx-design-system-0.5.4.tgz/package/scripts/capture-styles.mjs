import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import postcss from 'postcss';

// Refresh named styles without importing unrelated working-tree components or product code.
export async function captureStyles(root,source,names){
  if(!names.length||names.some(name=>!name.endsWith('.css')||name.startsWith('/')||name.split('/').includes('..')))
    throw new Error('Provide stylesheet paths relative to the source src directory.');
  const inventory=JSON.parse(await readFile(resolve(root,'reference/inventory.json'),'utf8'));
  const previous=JSON.parse(await readFile(resolve(root,'tokens/css-variables.json'),'utf8'));
  const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim();
  const capturedAt=new Date().toISOString();
  for(const name of names){
    const file='reference/styles/'+name,text=await readFile(resolve(source,'src',name),'utf8');
    postcss.parse(text); // Validate before replacing the captured source.
    await mkdir(dirname(resolve(root,file)),{recursive:true});await writeFile(resolve(root,file),text);
    const existing=inventory.styles.find(style=>style.file===file);
    if(existing)Object.assign(existing,{sourceRevision:revision,capturedAt,includesWorkingTree:true});
    else inventory.styles.push({file,sourceRevision:revision,capturedAt,includesWorkingTree:true});
  }
  const tail=['reference/styles/cx-system.css','reference/styles/cx-density.css','reference/styles/action-buttons.css'];
  const order=[...inventory.cssOrder.filter(file=>!tail.includes(file)),...inventory.styles.map(style=>style.file).filter(file=>!inventory.cssOrder.includes(file)&&!tail.includes(file)),...tail.filter(file=>inventory.styles.some(style=>style.file===file))];
  const roots={},declarations=[];
  for(const file of order){
    const text=await readFile(resolve(root,file),'utf8'),ast=postcss.parse(text),selectors=new Set(),media=new Set();
    ast.walkRules(rule=>selectors.add(rule.selector));ast.walkAtRules('media',rule=>media.add(rule.params));
    ast.walkDecls(decl=>{
      if(!decl.prop.startsWith('--'))return;
      const context=[];for(let n=decl.parent;n&&n.type!=='root';n=n.parent)context.unshift(n.selector||`@${n.name} ${n.params}`);
      declarations.push({name:decl.prop,value:decl.value,source:file,line:decl.source.start.line,context});
      if(decl.parent.type==='rule'&&decl.parent.selector===':root'&&decl.parent.parent.type==='root')roots[decl.prop]=decl.value;
    });
    Object.assign(inventory.styles.find(style=>style.file===file),{sha256:createHash('sha256').update(text).digest('hex'),bytes:Buffer.byteLength(text),selectors:[...selectors],media:[...media]});
  }
  Object.assign(roots,Object.fromEntries(Object.entries(previous.values).filter(([name])=>/^(--brand-|--layout-accent$|--layout-selected$|--cx-button-primary$|--color-bg-primary|--color-fg-primary$|--color-border-primary$|--color-effect-focus-primary$|--font-family-code$)/.test(name))));
  inventory.cssOrder=order;inventory.styles=order.map(file=>inventory.styles.find(style=>style.file===file));
  inventory.styleUpdates=[...(inventory.styleUpdates||[]),{capturedAt,sourceRevision:revision,includesWorkingTree:true,files:names.map(name=>'reference/styles/'+name)}];
  for(const [file,value] of Object.entries({'reference/inventory.json':inventory,'tokens/css-variables.json':{...previous,values:roots},'tokens/declarations.json':declarations}))
    await writeFile(resolve(root,file),JSON.stringify(value,null,2)+'\n');
  await writeFile(resolve(root,'reference/styles-entry.css'),order.map(file=>`@import './${file.replace('reference/','')}';`).join('\n')+'\n');
  console.log(JSON.stringify({updatedStyles:names,rootVariables:Object.keys(roots).length,sourceRevision:revision}));
}

import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const skillDownload=JSON.parse(await readFile(resolve(root,'downloads/cx-ui-skill.json'),'utf8'));
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const site=await servePages(resolve(root,'.build/pages'),'/CX/');
const consumer=await servePages(resolve(root,'verification/consumer-skill'));
const results=[];
try {
  for(const engine of ['chromium','firefox','webkit']) {
    const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
    try {
      for(const width of [320,390,1440]) {
        const page=await browser.newPage({viewport:{width,height:900}});page.setDefaultTimeout(6000);
        const errors=[];page.on('pageerror',e=>errors.push(e.message));
        page.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('/favicon.ico'))errors.push(r.url());});
        try {
          await page.goto(site.url);
          const nav=page.getByRole('navigation',{name:'디자인 안내'});
          await nav.getByRole('button',{name:/에이전트 사용/}).click();
          const [download]=await Promise.all([page.waitForEvent('download'),page.getByRole('link',{name:'스킬 ZIP 다운로드',exact:true}).click()]);
          assert.equal(download.suggestedFilename(),`cx-ui-skill-${skillDownload.version}.zip`);
          assert.equal(createHash('sha256').update(await readFile(await download.path())).digest('hex'),skillDownload.sha256);
          assert.ok(await page.getByText('node cx-ui/scripts/install.mjs',{exact:true}).isVisible());
          assert.ok(await page.getByText('$cx-ui 업무 관리 화면을 만들어줘.',{exact:false}).isVisible());
          assert.ok(await page.getByText('/cx-ui 기존 설정 화면을 CX로 맞춰줘.',{exact:false}).isVisible());
          await page.getByRole('link',{name:'Codex·Claude Code 스킬 사용법'}).click();
          await page.getByRole('heading',{name:'Codex·Claude Code에서 CX 사용하기',exact:true}).waitFor();
          assert.ok(await page.getByRole('heading',{name:'설치할 도구와 폴더 선택',exact:true}).isVisible());
          assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
          await page.goto(site.url+'catalog/index.html');
          await nav.getByRole('button',{name:/에이전트 사용/}).click();
          for(const href of await page.locator('a[href]').evaluateAll(links=>links.map(a=>a.href)))assert.equal((await page.request.get(href)).status(),200,href);
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
          await page.screenshot({path:resolve(root,`verification/skill-${engine}-${width}.png`),fullPage:true});
          await nav.getByRole('button',{name:/아이콘/}).click();
          await page.getByRole('searchbox',{name:'아이콘 검색'}).fill('로그인');
          assert.equal(await page.locator('.catalog-icons > div').count(),1);
          assert.equal(await page.locator('.catalog-icons code').innerText(),'logIn');
          assert.equal(await page.locator('.catalog-icons small').innerText(),'로그인');
          await nav.getByRole('button',{name:/컴포넌트/}).click();
          const login=page.getByRole('button',{name:'로그인',exact:true});
          assert.ok(await login.isVisible());assert.equal(await login.innerText(),'로그인');
          assert.equal((await login.boundingBox()).height,32);
          await page.getByRole('link',{name:'사용 설명서'}).click();
          await page.getByRole('heading',{name:'5. 에이전트로 활용하기'}).waitFor();
          assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
          assert.equal((await page.locator('body').innerText()).includes('\uFFFD'),false);
          await page.goto(consumer.url);
          const live=page.getByRole('button',{name:'로그인',exact:true});
          await live.waitFor();assert.equal(await live.innerText(),'로그인');
          assert.equal((await live.boundingBox()).height,32);
          await live.focus();await page.keyboard.press('Enter');
          assert.ok(await live.isDisabled());assert.equal(await live.getAttribute('aria-busy'),'true');
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
          assert.deepEqual(errors,[]);
          results.push({engine,version:browser.version(),width,skillZipDownload:true,codexAndClaudeGuide:true,skillLinks:true,koreanIconSearch:true,usageEncoding:true,loginCallback:true,busyBlocksRepeat:true});
        } finally {await page.close();}
      }
    } finally {await browser.close();}
  }
} finally {await site.close();await consumer.close();}
await mkdir(resolve(root,'verification'),{recursive:true});
await writeFile(resolve(root,'verification/skill-browser-results.json'),JSON.stringify(results,null,2)+'\n');
console.log(`CX skill and login browser review: ${results.length} scenarios passed`);

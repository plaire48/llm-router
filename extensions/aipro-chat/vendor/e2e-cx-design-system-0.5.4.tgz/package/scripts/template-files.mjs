import {readFile,lstat,readdir,mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
export const packageRoot=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export async function templateRegistry(){return JSON.parse(await readFile(resolve(packageRoot,'templates/registry.json'),'utf8'));}
export async function templateFiles(id) {
  const registry=await templateRegistry(),template=registry.templates.find(item=>item.id===id);
  if(!template)throw new Error('Unknown template: '+id+'. Use --list to see available templates.');
  const files=[];
  for(const entry of template.files) {
    const source=resolve(packageRoot,entry.source);
    if(!source.startsWith(resolve(packageRoot,'templates',id)+sep)||!['App.jsx','app.css'].includes(entry.target))throw new Error('Invalid template file mapping.');
    files.push({target:entry.target,content:await readFile(source)});
  }
  return {template,files};
}
export async function ensureEmpty(destination) {
  try {
    const info=await lstat(destination);
    if(info.isSymbolicLink()||!info.isDirectory())throw new Error('Destination must be a regular directory. No files were changed.');
    if((await readdir(destination)).length)throw new Error('Destination must be empty. No files were changed.');
  }catch(error){if(error.code!=='ENOENT')throw error;}
}
export async function writeTemplate(destination,id) {
  const {template,files}=await templateFiles(id),target=resolve(destination);
  await ensureEmpty(target);
  await mkdir(target,{recursive:true});
  for(const file of files)await writeFile(resolve(target,file.target),file.content,{flag:'wx'});
  const pkg=JSON.parse(await readFile(resolve(packageRoot,'package.json'),'utf8'));
  await writeFile(resolve(target,'CX-TEMPLATE.json'),JSON.stringify({template:id,version:pkg.version,source:template.entry,docs:'@e2e/cx-design-system/docs/TEMPLATES.txt',integration:template.integration},null,2)+'\n',{flag:'wx'});
  return {id,destination:target,version:pkg.version};
}

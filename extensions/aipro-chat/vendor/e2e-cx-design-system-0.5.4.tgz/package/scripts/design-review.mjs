import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const results=[];
const expected=JSON.parse(await readFile(resolve(root,'agent/design-index.json'),'utf8'));
await mkdir(resolve(root,'verification'),{recursive:true});
const server=await servePages(root,'/Manufacturing-IT/CX/');
try {
  for(const engine of ['chromium','firefox','webkit']) {
    const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
    try {
      for(const width of [390,1440]) {
        const page=await browser.newPage({viewport:{width,height:900}});
        page.setDefaultTimeout(6000);
        const errors=[];
        page.on('pageerror',error=>errors.push(error.message));
        page.on('response',response=>{if(response.status()>=400&&!response.url().endsWith('favicon.ico'))errors.push(response.url());});
        try {
          await page.goto(server.url+'docs/DESIGN-INVENTORY.html');
          await page.getByRole('heading',{name:'CX 디자인 상세 목록',exact:true}).waitFor();
          await page.evaluate(()=>document.fonts.ready);
          assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
          assert.ok((await page.locator('#source').textContent()).includes(expected.sourceRevision.slice(0,7)));
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('색상');
          assert.ok(await page.getByRole('heading',{name:'주요 동작',exact:true}).isVisible());
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('');
          await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('components');
          await page.getByRole('combobox',{name:'분류',exact:true}).selectOption('dialogs');
          assert.ok(await page.getByRole('link',{name:'reference/components/DetailPanel.jsx',exact:true}).isVisible());
          await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('surfaces');
          assert.ok((await page.locator('#count').textContent()).startsWith(expected.coverage.dialogAndPopupSites+'개'));
          await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('declarations');
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('--cx-control cx-density.css');
          assert.ok((await page.locator('#results').textContent()).includes('44px'));
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('');
          await page.getByRole('combobox',{name:'분류',exact:true}).selectOption('type');
          await page.getByRole('button',{name:'50개 더 보기',exact:true}).click();
          assert.equal(await page.locator('.cx-audit-entry').count(),100);
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
          await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('scriptDesignValues');
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('cardColors');
          assert.ok((await page.locator('#results').textContent()).includes('#2365a0'));
          await page.getByRole('searchbox',{name:'상세 검색'}).fill('');
          await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('foundations');
          await page.screenshot({path:resolve(root,`verification/design-inventory-${engine}-${width}.png`)});
          await page.goto(server.url+'catalog/index.html');
          await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/컴포넌트/}).click();
          const search=page.getByRole('searchbox',{name:'공통 검색',exact:true});
          await search.fill('테스트');await page.getByRole('button',{name:'검색 지우기',exact:true}).click();
          assert.equal(await search.inputValue(),'');assert.ok(await search.evaluate(el=>el===document.activeElement));
          const trigger=page.getByRole('button',{name:'모달 열기',exact:true});await trigger.click();
          const modal=page.getByRole('dialog',{name:'내용을 확인하세요',exact:true});
          const select=modal.getByRole('combobox',{name:'모달 선택',exact:true});
          await select.press('ArrowDown');await page.getByRole('listbox',{name:'모달 선택',exact:true}).waitFor();
          assert.equal(await select.getAttribute('aria-expanded'),'true');
          await select.press('ArrowDown');await select.press('Enter');assert.equal(await select.inputValue(),'사용 안 함');
          await select.press('ArrowDown');await select.press('Escape');assert.ok(await modal.isVisible());
          assert.equal(await page.getByRole('listbox').count(),0);
          const rangeTrigger=modal.getByRole('button',{name:'변경 기간 전체 기간',exact:true});
          await rangeTrigger.click();
          let popup=page.getByRole('dialog',{name:'변경 기간',exact:true});
          await popup.getByRole('textbox',{name:'변경 이력 시작일',exact:true}).fill('2026-09-20');
          await popup.getByRole('textbox',{name:'변경 이력 종료일',exact:true}).fill('2026-09-10');
          assert.ok(await popup.getByRole('button',{name:'적용',exact:true}).isDisabled());
          await popup.getByRole('textbox',{name:'변경 이력 종료일',exact:true}).fill('2026-09-25');
          await popup.getByRole('button',{name:'적용',exact:true}).click();
          await popup.waitFor({state:'detached'});
          const applied=modal.getByRole('button',{name:'변경 기간 2026-09-20 ~ 2026-09-25',exact:true});
          assert.ok(await applied.evaluate(el=>el===document.activeElement));
          await applied.click();popup=page.getByRole('dialog',{name:'변경 기간',exact:true});
          await popup.getByRole('textbox',{name:'변경 이력 종료일',exact:true}).fill('2026-09-30');
          await page.keyboard.press('Escape');await popup.waitFor({state:'detached'});
          assert.ok(await modal.isVisible());assert.ok(await applied.isVisible());
          await page.keyboard.press('Escape');await modal.waitFor({state:'detached'});
          assert.ok(await trigger.evaluate(el=>el===document.activeElement));
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
          assert.deepEqual(errors,[]);
          results.push({engine,version:browser.version(),width,guide:true,search:true,select:true,nestedModal:true,dateValidation:true,applyAndCancel:true,pass:true});
          console.log(`${engine} ${width}: design inventory, search, modal select and date range passed`);
        }finally{await page.close();}
      }
      if(engine==='chromium') {
        const page=await browser.newPage();
        await page.goto(pathToFileURL(resolve(root,'docs/DESIGN-INVENTORY.html')).href);
        await page.getByRole('searchbox',{name:'상세 검색'}).fill('그림자');
        assert.ok(await page.getByRole('heading',{name:'카드 그림자',exact:true}).isVisible());
        results.push({engine,offlineFileGuide:true,pass:true});
        await page.close();
      }
    }finally{await browser.close();}
  }
}finally{await server.close();}
await writeFile(resolve(root,'verification/design-browser-results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({scenarios:results.length,passed:results.length}));

import {readFile,readdir,writeFile,mkdir,rm} from 'node:fs/promises';
import {resolve,dirname,posix} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const escape=text=>text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const extensions=/\.(?:md|txt|json|jsx|js|mjs|css|yaml)$/;
const files=['README.md','AGENTS.md','CHANGELOG.md','THIRD-PARTY-NOTICES.md','fonts/font.css','fonts/OFL.txt','scripts/toast-review.mjs','catalog/ToastExamples.jsx','downloads/cx-ui-skill.json'];
async function walk(directory){
  for(const item of (await readdir(resolve(root,directory),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name,'en'))){
    const file=directory+'/'+item.name;
    if(file==='docs/read'||file==='docs/text-pages.json')continue;
    if(item.isDirectory())await walk(file);
    else if(item.isFile()&&extensions.test(file))files.push(file);
  }
}
for(const folder of ['docs','agent','skills','tokens','reference','src','templates','recipes'])await walk(folder);
await rm(resolve(root,'docs/read'),{recursive:true,force:true});
const pages=[];
for(const file of files.sort()){
  const bytes=await readFile(resolve(root,file));
  // Fail the build on invalid input rather than publishing silently replaced characters.
  const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  const page=file==='README.md'?'docs/USAGE.html':file==='docs/TEMPLATES.txt'?'docs/TEMPLATES.html':file==='docs/TABLES.txt'?'docs/TABLES.html':file==='docs/FEEDBACK.md'?'docs/FEEDBACK.html':file==='docs/SKILLS.md'?'docs/SKILLS.html':'docs/read/'+file+'.html';
  if(page.startsWith('docs/read/')){
    const from=posix.dirname(page),href=target=>escape(posix.relative(from,target));
    const html=`<!doctype html>
<html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(file)} · CX</title><link rel="stylesheet" href="${href('dist/styles.css')}"><link rel="stylesheet" href="${href('docs/usage.css')}"></head>
<body><main class="usage-guide source-guide"><nav aria-label="문서 탐색"><a href="${href('catalog/index.html')}">카탈로그로 돌아가기</a><a href="${href('docs/USAGE.html')}">사용 설명서</a><a href="${href(file)}" download>원본 파일 받기</a></nav><h1>${escape(file)}</h1><pre class="document-source" id="document-source"><code>${escape(text)}</code></pre></main></body></html>
`;
    await mkdir(resolve(root,from),{recursive:true});
    // The UTF-8 signature also protects HTML when a server sends a legacy charset header.
    await writeFile(resolve(root,page),'\uFEFF'+html);
  }
  pages.push({source:file,page,sha256:createHash('sha256').update(bytes).digest('hex')});
}
await writeFile(resolve(root,'docs/text-pages.json'),JSON.stringify({format:'cx-text-pages/1',encoding:'UTF-8',pages},null,2)+'\n');
for(const file of ['index.html','catalog/index.html','docs/USAGE.html','docs/TEMPLATES.html','docs/TABLES.html','docs/FEEDBACK.html','docs/SKILLS.html','docs/DESIGN-INVENTORY.html']){
  const content=await readFile(resolve(root,file),'utf8');
  await writeFile(resolve(root,file),'\uFEFF'+content.replace(/^\uFEFF/,''));
}
console.log(`Built ${pages.length} UTF-8 document views`);

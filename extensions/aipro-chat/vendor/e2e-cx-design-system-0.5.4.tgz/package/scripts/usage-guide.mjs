import {readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {renderReadme} from './readme-markdown.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
for(const [source,target] of [['README.md','docs/USAGE.html'],['docs/TEMPLATES.txt','docs/TEMPLATES.html'],['docs/TABLES.txt','docs/TABLES.html'],['docs/FEEDBACK.md','docs/FEEDBACK.html'],['docs/SKILLS.md','docs/SKILLS.html']]) {
const text=(await readFile(resolve(root,source),'utf8')).replace(/^\uFEFF/,'');
const escape=text=>text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
let title,body;
if(source.endsWith('.md')){
  const rendered=renderReadme(text,{source,targetPage:target});title=rendered.title;body=rendered.html;
}else{
const lines=text.trimEnd().split('\n'),blocks=[];title=lines.shift();
for(let i=0;i<lines.length;){
  if(!lines[i].trim()){i++;continue;}
  if(lines[i].startsWith('    ')){
    const code=[];
    while(i<lines.length&&(lines[i].startsWith('    ')||!lines[i].trim()))code.push(lines[i++].replace(/^ {4}/,''));
    blocks.push('<pre><code>'+escape(code.join('\n').trimEnd())+'</code></pre>');
  }else if(/^\d+\. /.test(lines[i])){
    const heading=lines[i++];blocks.push(`<h2 id="step-${heading.split('.')[0]}">${escape(heading)}</h2>`);
  }else{
    const paragraph=[];while(i<lines.length&&lines[i].trim()&&!lines[i].startsWith('    ')&&!/^\d+\. /.test(lines[i]))paragraph.push(lines[i++]);
    blocks.push('<p>'+escape(paragraph.join(' '))+'</p>');
  }
}
body=`<h1>${escape(title)}</h1>${blocks.join('\n')}`;
}
await writeFile(resolve(root,target),`<!doctype html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escape(title)}</title>
<link rel="stylesheet" href="../dist/styles.css">
<link rel="stylesheet" href="./usage.css">
</head>
<body><main class="usage-guide"><nav aria-label="설명서 탐색"><a href="../catalog/index.html">카탈로그로 돌아가기</a><a href="../${source}" download>${source==='README.md'?'README.md 받기':source.endsWith('.md')?'원본 Markdown 받기':'일반 텍스트 받기'}</a></nav><article>${body}</article></main></body>
</html>
`,'utf8');
}

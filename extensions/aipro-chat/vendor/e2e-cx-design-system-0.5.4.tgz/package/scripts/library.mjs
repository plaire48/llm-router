import {readFile,writeFile,cp} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parse} from '@babel/parser';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const read=path=>readFile(resolve(root,path),'utf8');
const json=async path=>JSON.parse(await read(path));
const save=(path,value)=>writeFile(resolve(root,path),JSON.stringify(value,null,2)+'\n');
const pkg=await json('package.json'),design=await json('agent/design-index.json'),manifest=await json('agent/manifest.json');
const recipes=await json('recipes/registry.json'),registry=await json('templates/registry.json');
const {values}=await json('tokens/css-variables.json'),declarations=await json('tokens/declarations.json');
const publicNames=new Set(manifest.portable.map(item=>item.name));
const templateIds=new Set(registry.templates.map(item=>item.id));
if(templateIds.size!==registry.templates.length||!templateIds.has(registry.default))throw new Error('Template IDs and default must be unique and valid.');
const recipeIds=new Set(recipes.recipes.map(item=>item.id));
if(recipeIds.size!==recipes.recipes.length)throw new Error('Duplicate recipe ID.');
for(const recipe of recipes.recipes) {
  for(const component of recipe.components)if(!publicNames.has(component))throw new Error('Unknown public component: '+component);
  for(const token of recipe.tokens)if(!Object.hasOwn(values,token))throw new Error('Unknown token: '+token);
  for(const id of recipe.templates)if(!templateIds.has(id))throw new Error('Unknown template: '+id);
  recipe.references=design.components.filter(item=>item.group===recipe.referenceGroup).map(item=>item.file);
}
const layoutSource=await read('src/layouts.css');
for(const layout of recipes.layouts)if(!layoutSource.includes('.'+layout.className+' '))throw new Error('Unknown layout class: '+layout.className);
function resolved(value,seen=[]) {
  return value.replace(/var\((--[\w-]+)\)/g,(match,id)=>Object.hasOwn(values,id)&&!seen.includes(id)?resolved(values[id],[...seen,id]):match);
}
function category(id) {
  if(/brand|color|surface|muted|danger|success|warning|disabled|overlay/.test(id))return 'color';
  if(/font|type-|weight|line-/.test(id))return 'type';
  if(/radius|border|shadow/.test(id))return 'shape';
  if(/motion|duration|easing/.test(id))return 'motion';
  return 'geometry';
}
const tokens=Object.entries(values).map(([id,value])=>{
  const foundation=design.foundations.find(item=>item.token===id);
  const usedBy=recipes.recipes.filter(item=>item.tokens.includes(id)).map(item=>item.id);
  const recommended=Boolean(foundation||usedBy.length);
  const tier=/^--(?:brand-\d|font-size-|line-height-|cx-(?:space|gap|weight|radius|motion))/.test(id)?'foundation':!recommended?'reference':/^--cx-(?:control|field|row|cell|table|tab|panel|popup|touch|long-input)/.test(id)?'component':'semantic';
  return {id,label:foundation?.label||id,category:foundation?.category||category(id),tier,recommended,
    css:`var(${id})`,baseValue:value,resolvedBase:resolved(value),
    aliases:[...value.matchAll(/var\((--[\w-]+)/g)].map(match=>match[1]),
    usedBy,conditions:declarations.filter(item=>item.name===id).map(({source,line,value,context})=>({source,line,value,context})),
    origin:foundation?.origin||'reference/inventory.json and tokens/declarations.json',
  };
});
const tokenCatalog={format:'cx-token-catalog/1',version:pkg.version,theme:'light',sourceRevision:design.sourceRevision,
  layers:[{id:'foundation',label:'기초 값',description:'간격·글자 스케일·팔레트의 기준 값'},{id:'semantic',label:'의미별 역할',description:'본문·표면·강조·상태에 사용하는 변수'},{id:'component',label:'컴포넌트 규격',description:'버튼·입력·표·모달의 공통 규격'},{id:'reference',label:'전체 원본 참조',description:'과거·범용 선언을 포함한 수집 값. 기본 권장 목록과 구별'}],
  categories:design.categories,tokens,
  note:'CX 전용 색인입니다. DTCG 파일이 아니며 resolvedBase는 단순 별칭을 해석한 기본값입니다. 실제 상태·조건·상속·우선순위의 최종 계산값은 브라우저에서 확인합니다.',
};
await save('tokens/catalog.json',tokenCatalog);
const templates=[];
for(const template of registry.templates) {
  if(!/^[a-z][a-z0-9-]+$/.test(template.id))throw new Error('Invalid template ID');
  for(const id of template.recipes)if(!recipeIds.has(id))throw new Error('Unknown recipe: '+id);
  const source=await read(template.entry),ast=parse(source,{sourceType:'module',plugins:['jsx']});
  const imports=ast.program.body.filter(node=>node.type==='ImportDeclaration');
  const components=imports.filter(node=>node.source.value===pkg.name).flatMap(node=>node.specifiers.map(item=>item.imported?.name));
  if(imports.some(node=>!['react',pkg.name].includes(node.source.value)))throw new Error('Template has an unreviewed dependency: '+template.id);
  for(const component of components)if(!publicNames.has(component))throw new Error('Template imports unknown API: '+component);
  const app=ast.program.body.find(node=>node.type==='ExportDefaultDeclaration')?.declaration;
  const props=app?.params?.[0]?.properties?.map(prop=>prop.key?.name)||[];
  for(const prop of Object.keys(template.props))if(!props.includes(prop))throw new Error('Documented prop is missing: '+template.id+'.'+prop);
  const files=[];
  for(const file of template.files) {
    if(!['App.jsx','app.css'].includes(file.target)||!file.source.startsWith('templates/'+template.id+'/'))throw new Error('Unexpected template file mapping');
    files.push({...file,content:await read(file.source)});
  }
  templates.push({...template,components,tokens:[...new Set(template.recipes.flatMap(id=>recipes.recipes.find(recipe=>recipe.id===id).tokens))],files});
}
const library={format:'cx-library/1',version:pkg.version,entry:'docs/TEMPLATES.txt',tokenCatalog:'tokens/catalog.json',
  tables:{guide:'docs/TABLES.txt',browserGuide:'docs/TABLES.html',contract:'agent/table-contract.json',evidence:'docs/TABLE-AUDIT.json'},
  feedback:{guide:'docs/FEEDBACK.md',browserGuide:'docs/FEEDBACK.html',contract:'agent/feedback-contract.json'},
  flow:['tokens/catalog.json','agent/manifest.json','recipes/registry.json','templates/registry.json'],
  layouts:recipes.layouts,recipes:recipes.recipes,defaultTemplate:registry.default,
  templates:templates.map(({files,...template})=>({...template,files:files.map(({content,...file})=>file)})),
};
await save('agent/library.json',library);
await save('catalog/library-data.json',{...library,templates,tokens:tokenCatalog});
await writeFile(resolve(root,'catalog/templates.jsx'),templates.map((template,i)=>`import Template${i} from '../${template.entry}';`).join('\n')+'\nexport const templatePreviews={'+templates.map((template,i)=>`${JSON.stringify(template.id)}:Template${i}`).join(',')+'};\n');
await writeFile(resolve(root,'catalog/templates.css'),templates.flatMap(template=>template.files.filter(file=>file.target.endsWith('.css')).map(file=>`@import '../${file.source}';`)).join('\n')+'\n');
// Keep the backwards-compatible starter generated from the same source shown in the template catalog.
for(const file of templates.find(template=>template.id===registry.default).files)await cp(resolve(root,file.source),resolve(root,'starter/src',file.target));
console.log(`Built CX library: ${tokens.length} tokens, ${recipes.recipes.length} recipes, ${templates.length} templates`);

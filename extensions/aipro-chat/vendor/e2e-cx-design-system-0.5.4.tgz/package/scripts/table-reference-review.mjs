// Optional product-reference audit, never part of the standalone package runtime.
// E2E_SOURCE=/path/to/e2e-report PLAYWRIGHT_MODULE_PATH=/path/to/playwright/index.mjs node scripts/table-reference-review.mjs
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';
import {servePages} from './verify-pages.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
if(!process.env.E2E_SOURCE)throw new Error('Set E2E_SOURCE to the reference product checkout. No product files are modified.');
const source=resolve(process.env.E2E_SOURCE),output=resolve(root,'.build/table-reference');
const inventory=JSON.parse(await readFile(resolve(root,'reference/inventory.json'),'utf8'));
const sourceRevision=execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim();
assert.equal(sourceRevision,inventory.sourceRevision,'Audit the captured revision, not another checkout.');
for(const entry of [...inventory.components,...inventory.modules,...inventory.styles]){
  const file=entry.source||entry.file.replace(/^reference\/(?:components|modules|styles)\//,'src/');
  const hash=createHash('sha256').update(await readFile(resolve(source,file))).digest('hex');
  assert.equal(hash,entry.sha256,file+' differs from the captured reference');
}
await mkdir(output,{recursive:true});await mkdir(resolve(root,'verification'),{recursive:true});
await build({entryPoints:[resolve(root,'scripts/fixtures/table-reference.jsx')],outfile:resolve(output,'audit.js'),bundle:true,jsx:'automatic',format:'esm',loader:{'.css':'empty','.woff2':'empty'},alias:{'e2e-source':resolve(source,'src'),react:resolve(root,'node_modules/react'),'react-dom':resolve(root,'node_modules/react-dom')},define:{'process.env.NODE_ENV':'"production"'},logLevel:'warning'});
await writeFile(resolve(output,'index.html'),'\uFEFF<!doctype html><html lang="ko"><head><meta charset="UTF-8"><link rel="stylesheet" href="../../dist/styles.css"><meta name="viewport" content="width=device-width, initial-scale=1"><style>output[data-audit-state]{display:none}body{margin:0}</style></head><body><div id="root"></div><script type="module" src="./audit.js"></script></body></html>');
const engines=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const server=await servePages(root),results=[];
const selectedEngines=(process.env.CX_AUDIT_ENGINES||'chromium,firefox,webkit').split(',');
try{
for(const engine of selectedEngines){
  const browser=await engines[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
  try{for(const width of [1440,390]){
    const context=await browser.newContext({viewport:{width,height:900},hasTouch:width===390}),page=await context.newPage(),errors=[],checks=[];
    page.on('pageerror',error=>errors.push(error.message));
    await page.route('**/*',route=>new URL(route.request().url()).origin===new URL(server.url).origin?route.continue():route.abort());
    const goto=async mode=>{await page.goto(server.url+'.build/table-reference/?case='+mode);await page.getByRole('heading',{name:'표 원본 동작 검토'}).waitFor();};
    const state=async()=>JSON.parse(await page.locator('[data-audit-state]').textContent());
    const check=description=>checks.push(description);
    await goto('table');await page.locator('tbody tr').first().waitFor();
    await page.getByRole('button',{name:'이름 오름차순 정렬',exact:true}).click();
    assert.equal(await page.locator('th[data-column="label"]').getAttribute('aria-sort'),'ascending');
    assert.equal(await page.locator('tbody tr').nth(1).locator('[data-field="label"]').innerText(),'항목 2');check('Korean numeric-aware sort and aria-sort');
    await page.getByRole('button',{name:'이름 내림차순 정렬',exact:true}).click();
    assert.equal(await page.locator('tbody tr').first().locator('[data-field="label"]').innerText(),'항목 23');check('ascending then descending');
    await page.getByRole('button',{name:'이름 오름차순 정렬',exact:true}).click();
    await page.getByRole('checkbox',{name:'항목 1 선택',exact:true}).check();
    await page.getByRole('button',{name:'다음 페이지',exact:true}).click();
    await page.getByRole('checkbox',{name:'항목 11 선택',exact:true}).check();
    assert.deepEqual((await state()).selected,['0','10']);check('selection persists across pages');
    await page.getByRole('button',{name:'이름 내림차순 정렬',exact:true}).click();
    assert.equal((await state()).page,1);assert.deepEqual((await state()).selected,['0','10']);check('sort resets page but keeps selected IDs');
    await page.getByRole('button',{name:'부서 필터',exact:true}).click();
    let popup=page.getByRole('dialog',{name:'부서 필터 설정',exact:true});
    await popup.getByRole('checkbox',{name:'개발',exact:true}).uncheck();
    await popup.getByRole('searchbox',{name:'필터 값 검색'}).press('Escape');
    assert.equal((await state()).total,23);check('Escape discards pending filter');
    await page.getByRole('button',{name:'부서 필터',exact:true}).click();
    await popup.getByRole('checkbox',{name:'개발',exact:true}).uncheck();
    await popup.getByRole('button',{name:'적용',exact:true}).click();
    assert.equal((await state()).total,12);assert.deepEqual((await state()).selected,[]);check('apply filters all rows and clears query-scoped selection');
    await page.getByRole('button',{name:'부서 필터 해제',exact:true}).click();
    await page.getByRole('button',{name:'부서 필터',exact:true}).click();
    await popup.getByRole('checkbox',{name:/전체 선택/}).uncheck();
    await popup.getByRole('button',{name:'적용',exact:true}).click();
    assert.equal((await state()).total,0);check('empty filter selection yields zero rows');
    await page.getByRole('button',{name:'부서 필터 해제',exact:true}).click();
    await page.getByRole('button',{name:'부서 필터',exact:true}).click();
    await popup.getByRole('searchbox',{name:'필터 값 검색'}).fill('개발');
    await popup.getByRole('checkbox',{name:/전체 선택/}).uncheck();
    await popup.getByRole('checkbox',{name:/전체 선택/}).check();
    await popup.getByRole('button',{name:'적용',exact:true}).click();
    assert.equal((await state()).total,23);check('search narrows options, select-all still covers the full facet');
    const resize=page.getByRole('separator',{name:'이름 열 너비'});
    const original=await page.locator('th[data-column="label"]').evaluate(el=>el.getBoundingClientRect().width);
    await resize.press('ArrowRight');assert.ok(Math.abs((await state()).widths.label-original-16)<1);check('keyboard resize uses 16 px steps');
    await resize.dblclick();assert.equal((await state()).widths.label,undefined);check('double-click clears only that width');
    await page.getByRole('button',{name:'이름 열 고정',exact:true}).click();
    assert.deepEqual((await state()).pinned,['label']);
    await page.getByRole('button',{name:'수치 열 고정',exact:true}).click();
    assert.deepEqual((await state()).pinned,['label']);check('pinning requires a contiguous left prefix');
    await page.getByRole('button',{name:'부서 열 고정',exact:true}).click();
    await page.getByRole('button',{name:'이름 열 고정',exact:true}).click();
    assert.deepEqual((await state()).pinned,[]);check('unpinning releases that column and every column to its right');
    await page.getByRole('button',{name:'표 표시 전환'}).click();await page.getByRole('button',{name:'표 표시 전환'}).click();
    assert.equal((await state()).sort.direction,'desc');check('view preferences survive component remount');
    await page.reload();await page.locator('[data-audit-state]').waitFor({state:'attached'});assert.equal((await state()).sort.key,'');check('reload resets memory-only preferences');
    const geometry=await page.locator('table').evaluate(table=>{const th=table.querySelector('th[data-column="label"]'),td=table.querySelector('[data-field="label"]'),sort=table.querySelector('.cx-column-sort'),filter=table.querySelector('.table-column-filter'),style=getComputedStyle(td),r=el=>({width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height});return{pointerCoarse:matchMedia('(pointer: coarse)').matches,header:r(th),cell:r(td),sort:r(sort),filter:r(filter),font:style.fontFamily,fontSize:style.fontSize,fontWeight:style.fontWeight,text:style.color,headerBackground:getComputedStyle(th).backgroundColor};});
    await goto('grouped');for(const name of (width<1000?['이름','부서','수치']:['이름','부서','수치','설명']))await page.getByRole('button',{name:name+' 열 고정',exact:true}).click();
    const groupPins=await page.locator('table').evaluate(table=>{const scroller=table.closest('.settings-grid-scroll'),cells=[...table.querySelectorAll('thead [data-column-pinned]')],selection=table.querySelector('th.selection-column');return{count:cells.length,viewport:scroller.clientWidth,frozenWidth:cells.reduce((n,el)=>n+el.getBoundingClientRect().width,0)+selection.getBoundingClientRect().width,budget:scroller.clientWidth*.6};});
    await goto('custom-columns');await page.getByRole('button',{name:'열 선택',exact:true}).click();
    const missingUngroupedColumn=await page.getByRole('checkbox',{name:'사용자 이름 열 표시',exact:true}).count()===0;
    await goto('visibility-modal');await page.getByRole('button',{name:'검토 모달 열기'}).click();
    await page.getByRole('button',{name:'열 선택',exact:true}).click();
    const visibilityModal=await page.evaluate(()=>{const popup=document.querySelector('.column-visibility-popover');return{present:!!popup,inert:!!popup?.closest('[inert]'),insideModal:!!popup?.closest('[aria-modal="true"]'),focusInside:!!popup?.contains(document.activeElement)};});
    await goto('filter-modal');await page.getByRole('button',{name:'검토 모달 열기'}).click();
    await page.getByRole('button',{name:'부서 필터',exact:true}).click();
    popup=page.getByRole('dialog',{name:'부서 필터 설정',exact:true});
    assert.equal(await popup.evaluate(el=>!!el.closest('[aria-modal="true"]')&&!el.closest('[inert]')),true);
    await popup.getByRole('checkbox',{name:'개발',exact:true}).uncheck();
    await popup.getByRole('button',{name:'적용',exact:true}).click();assert.equal((await state()).total,12);check('column filter remains usable inside the parent modal');
    assert.deepEqual(errors,[]);
    results.push({engine,version:browser.version(),width,checks,geometry,findings:{groupPinBudgetExceeded:groupPins.frozenWidth>groupPins.budget+1,groupPins,missingUngroupedColumn,visibilityModal}});
    console.log(`${engine} ${width}: ${checks.length} interaction checks; reference findings recorded`);
    await context.close();
  }}finally{await browser.close();}
}
}finally{await server.close();}
await writeFile(resolve(root,'verification/table-reference-results.json'),JSON.stringify({sourceRevision,scope:'Synthetic data; original product JS with the captured CX stylesheet; no repository or service writes',results},null,2)+'\n');

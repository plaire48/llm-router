#!/usr/bin/env node
import {templateRegistry,writeTemplate} from './template-files.mjs';
const [command,id,flag,destination,...extra]=process.argv.slice(2);
try {
  if(['list','--list'].includes(command)&&!id) {
    const registry=await templateRegistry();
    console.log(JSON.stringify({default:registry.default,templates:registry.templates.map(({id,label,description})=>({id,label,description}))},null,2));
  } else if(command==='add'&&id&&flag==='--to'&&destination&&!extra.length) {
    console.log(JSON.stringify(await writeTemplate(destination,id),null,2));
    console.log('Import App.jsx and app.css from the copied folder. Load the package styles.css once in your app entry. Connect the documented host callbacks; do not nest CxAppShell when using embedded.');
  } else throw new Error('Usage: cx-template list | cx-template add <id> --to ./empty-screen-folder');
}catch(error){console.error(error.message);process.exitCode=1;}

// Local browser regression: real pointer/touch/keyboard input with a controlled clock.
import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {build} from 'esbuild';
import {servePages} from './verify-pages.mjs';
import {pathToFileURL} from 'node:url';

const pw=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
await mkdir(resolve(root,'.build/toast'),{recursive:true});await mkdir(resolve(root,'verification'),{recursive:true});
await build({entryPoints:[resolve(root,'scripts/fixtures/toast.jsx')],outfile:resolve(root,'.build/toast/app.js'),bundle:true,format:'esm',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'}});
await writeFile(resolve(root,'.build/toast/index.html'),'<!doctype html><html lang="ko"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CX 토스트 검증</title><link rel="stylesheet" href="../../dist/styles.css"><link rel="stylesheet" href="../../catalog/catalog.css"><div id="root"></div><script type="module" src="app.js"></script></html>');
const server=await servePages(root,'/Manufacturing-IT/CX/'),base=server.url,results=[];
try {
for(const engine of ['chromium','firefox','webkit']){
  const browser=await pw[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
  try {for(const touch of [false,true]){
    const viewport=touch?{width:390,height:844}:{width:1440,height:900};
    // macOS WebKit's button navigation uses Option+Tab with this host preference.
    const navigationKey=engine==='webkit'?'Alt+Tab':'Tab';
    const context=await browser.newContext({viewport,hasTouch:touch}),page=await context.newPage(),errors=[],checks=[];
    let geometry;
    const check=(condition,label)=>{assert.ok(condition,label);checks.push(label);};
    page.on('pageerror',error=>errors.push(error.message));
    await page.route('**/*',r=>new URL(r.request().url()).origin===new URL(base).origin?r.continue():r.abort());
    try {
      page.setDefaultTimeout(6000);
      await page.goto(base+'.build/toast/index.html');await page.getByRole('heading',{name:'토스트와 원형 타이머'}).waitFor();await page.evaluate(()=>document.fonts.ready);
      const time=new Date('2026-09-11T12:00:00Z');await page.clock.install({time});await page.clock.pauseAt(time);
      const toast=page.locator('.cx-toast'),ring=toast.locator('.cx-toast-countdown'),tip=toast.locator('.cx-toast-countdown-tip');
      const elapsed=ms=>page.clock.runFor(ms);
      const show=async(error=false)=>{
        await page.evaluate(error=>toastReview.notifyToast(error?'저장하지 못했습니다. 입력값은 유지됩니다.':'저장했습니다.',{
          source:'countdown-review',error,actions:error?[{label:'다시 시도',onClick:()=>window.toastActionClicks=(window.toastActionClicks||0)+1}]:[],
        }),error);await toast.waitFor();
      };
      const pointer=async(locator,click=false)=>{
        await locator.scrollIntoViewIfNeeded();const b=await locator.boundingBox(),x=b.x+b.width/2,y=b.y+b.height/2;
        if(touch)await page.touchscreen.tap(x,y);else if(click)await page.mouse.click(x,y);else await page.mouse.move(x,y);
      };
      const complete=async()=>{
        check(await toast.count()===1&&Number(await ring.getAttribute('stroke-dashoffset'))===0&&await tip.getAttribute('opacity')==='0','Completed ring is unbroken before dismissal');
        await elapsed(200);check(await toast.count()===0,'Completed toast closes automatically');
      };

      await show();await elapsed(800);await pointer(toast.locator('.toast__text'));
      const before=Number(await ring.getAttribute('stroke-dashoffset')),beforeTip=await tip.boundingBox();
      const appearance=await ring.evaluate(el=>({stroke:getComputedStyle(el).stroke,width:parseFloat(getComputedStyle(el).strokeWidth),track:getComputedStyle(el.previousElementSibling).stroke,visibility:getComputedStyle(el).visibility,offset:parseFloat(getComputedStyle(el).strokeDashoffset)}));
      check(appearance.visibility==='visible'&&appearance.width===3.5&&appearance.stroke!==appearance.track,'Progress ring is visible and distinct from its pale track');
      check(Math.abs(appearance.offset-before)<.01,'Painted countdown uses the animated offset');
      if(engine==='chromium'&&!touch)await toast.screenshot({path:'verification/toast-visible-start.png'});
      await elapsed(1800);
      check(Number(await ring.getAttribute('stroke-dashoffset'))<before-60,'Hover or a touch does not freeze progress');
      const afterTip=await tip.boundingBox();
      check(Math.hypot(afterTip.x-beforeTip.x,afterTip.y-beforeTip.y)>5,'Leading dot visibly moves along the outline');
      if(engine==='chromium'&&!touch)await toast.screenshot({path:'verification/toast-visible-end.png'});
      await elapsed(350);await complete();

      await show();await elapsed(800);await page.clock.fastForward(6000);
      await complete();

      await show(true);await elapsed(1000);await pointer(toast.getByRole('button',{name:'다시 시도'}),true);
      check(await page.evaluate(()=>window.toastActionClicks)===1,'Pointer action runs once');
      await elapsed(1950);await complete();

      await show();await elapsed(1000);
      await toast.getByRole('button',{name:'알림 닫기'}).focus();await page.keyboard.press('ArrowRight');
      const paused=await ring.getAttribute('stroke-dashoffset');await elapsed(6000);
      check(await toast.count()===1&&await ring.getAttribute('stroke-dashoffset')===paused,'Keyboard operation retains the toast and remaining time');
      await page.locator('#toast-review-outside').focus();await elapsed(1950);await complete();

      await show(true);await elapsed(1000);await toast.getByRole('button',{name:'다시 시도'}).focus();await page.keyboard.press('ArrowRight');
      const previous=await toast.getAttribute('data-toast-id');await show();
      check(await toast.getAttribute('data-toast-id')!==previous&&await toast.count()===1,'Replacement uses one fresh toast');
      await elapsed(2950);await complete();

      await show();await elapsed(1000);
      await page.getByRole('button',{name:'모달 안에서 확인',exact:true}).click();
      check(await toast.evaluate(el=>el.closest('[role="dialog"]')!==null),'Toast remains in the public active modal');
      await elapsed(1000);
      await page.getByRole('button',{name:'모달 닫기',exact:true}).click();
      await elapsed(950);await complete();

      await show();await elapsed(1000);
      await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));});
      // Visibility changes are not discrete React events. Allow its layout effect
      // to account for the last frame before measuring the paused position.
      await elapsed(32);
      const hiddenProgress=await ring.getAttribute('stroke-dashoffset');await elapsed(6000);
      check(await toast.count()===1&&await ring.getAttribute('stroke-dashoffset')===hiddenProgress,'Hidden tab retains remaining reading time');
      await page.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'));});
      await elapsed(1950);await complete();

      await show();await elapsed(1000);await toast.getByRole('button',{name:'알림 닫기'}).focus();
      // The first Escape may dismiss the keyboard tooltip; the next closes feedback.
      await page.keyboard.press('Escape');if(await toast.count())await page.keyboard.press('Escape');
      check(await toast.count()===0,'Escape closes feedback without waiting for the timer');
      await show();await elapsed(2000);
      check(await toast.count()===1,'Dismissed toast cannot expire a newer notification');
      await elapsed(950);await complete();

      await page.emulateMedia({reducedMotion:'reduce'});await show();
      check(await ring.evaluate(el=>getComputedStyle(el).visibility)==='visible'&&await tip.evaluate(el=>getComputedStyle(el).visibility)==='hidden','Reduced motion retains the countdown and suppresses only the moving dot');
      await elapsed(1100);const firstStep=Number(await ring.getAttribute('stroke-dashoffset'));
      check(Math.abs(firstStep-200/3)<.01,'Reduced motion visibly fills the first third');
      await elapsed(200);check(Number(await ring.getAttribute('stroke-dashoffset'))===firstStep,'Reduced motion holds still between countdown steps');
      if(engine==='chromium'&&!touch)await toast.screenshot({path:'verification/toast-visible-reduced-motion.png'});
      await elapsed(1650);await complete();
      await page.emulateMedia({reducedMotion:'no-preference'});
      await page.getByRole('button',{name:'일반 안내',exact:true}).click();
      check(await toast.getByRole('status').count()===1&&await toast.locator('.cx-toast-icon svg path').getAttribute('d')==='M16 16v6','Ordinary information uses status and i icon');
      check(await toast.locator('[aria-hidden="true"]').count()>=1&&await toast.getByRole('status').getAttribute('aria-atomic')==='true','Decorative icon is hidden and message is atomic');
      geometry=await toast.evaluate(el=>{const style=getComputedStyle(el),close=el.querySelector('.cx-toast-close').getBoundingClientRect();return {font:style.fontFamily,fontSize:getComputedStyle(el.querySelector('.toast__text')).fontSize,closeWidth:close.width,closeHeight:close.height};});
      check(geometry.font.includes('Noto Sans KR')&&geometry.fontSize==='14px'&&geometry.closeHeight===(touch?44:32),'Local font and shared pointer-dependent close size');
      await toast.getByRole('button',{name:'알림 닫기'}).click();
      await page.getByRole('button',{name:'완료 알림',exact:true}).click();
      check(await toast.locator('.cx-toast-icon svg path').getAttribute('d')==='m10 16 4 4 8-9','Successful message uses check icon');
      await page.getByRole('button',{name:'오류와 재시도',exact:true}).click();
      check(await toast.getByRole('alert').count()===1&&await toast.locator('.cx-toast-icon svg path').getAttribute('d')==='M16 10v8','Error uses alert and exclamation icon');
      await toast.getByRole('button',{name:'다시 시도',exact:true}).click();
      check(await page.getByText(/예제 재시도: 1회/).count()===1&&await toast.getByRole('status').count()===1,'Catalog retry callback replaces the error with a success');
      await toast.getByRole('button',{name:'알림 닫기'}).click();

      // Synthetic clipboard outcomes validate UI wiring, not deployment permissions.
      await page.evaluate(()=>Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.copiedToastDiagnostic=text;}}}));
      await page.getByRole('button',{name:'오류와 재시도',exact:true}).click();
      await toast.getByRole('button',{name:'오류 정보 복사'}).click();
      await toast.getByRole('button',{name:'복사 완료'}).waitFor();
      check((await page.evaluate(()=>window.copiedToastDiagnostic)).includes('DEMO_SAVE_FAILED'),'Diagnostic clipboard success displays confirmation');
      await page.evaluate(()=>Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw new Error('Mock denied');}}}));
      await page.getByRole('button',{name:'오류와 재시도',exact:true}).click();
      await toast.getByRole('button',{name:'오류 정보 복사'}).click();
      await toast.getByRole('status').waitFor();
      check((await toast.getByRole('status').innerText()).includes('복사하지 못했습니다'),'Diagnostic clipboard failure displays readable status');
      await toast.getByRole('button',{name:'알림 닫기'}).click();

      await page.getByRole('button',{name:'긴 알림',exact:true}).click();
      check(await toast.locator('.toast__text').evaluate(el=>el.scrollHeight>el.clientHeight&&getComputedStyle(el).whiteSpace==='pre-line'&&el.scrollWidth<=el.clientWidth+1),'Long Korean and identifiers wrap with internal vertical scrolling');
      check(await toast.evaluate(el=>{const b=el.getBoundingClientRect();return b.left>=0&&b.right<=innerWidth+1;}),'Long toast remains inside mobile and desktop viewport');
      await toast.getByRole('button',{name:'알림 닫기'}).click();

      await page.getByRole('button',{name:'처리 중 예제',exact:true}).click();
      const busy=page.getByRole('button',{name:'처리 중 예제',exact:true});
      check(await busy.isDisabled()&&await busy.getAttribute('aria-busy')==='true'&&await busy.locator('.status-spinner').count()===1,'Busy demo shows spinner and blocks repeated clicks');
      await elapsed(1000);check(await toast.count()===0,'Pending demo does not announce success');
      await elapsed(250);await toast.waitFor();
      check(await toast.getByRole('status').count()===1&&await page.getByRole('button',{name:'처리 중 예제',exact:true}).isEnabled(),'Demo completion resets busy and announces success');
      await toast.getByRole('button',{name:'알림 닫기'}).click();

      await page.getByRole('button',{name:'폼 오류',exact:true}).click();await elapsed(3200);
      check(await toast.count()===0&&await page.locator('[data-local-error]').innerText()==='폼 오류입니다.','Local hook error persists after toast timeout');
      await page.getByRole('button',{name:'폼 오류',exact:true}).click();
      await page.getByRole('button',{name:'폼 표시 전환',exact:true}).click();
      check(await toast.count()===0,'Unmount clears its own error toast');
      await page.getByRole('button',{name:'폼 표시 전환',exact:true}).click();
      await page.getByRole('button',{name:'폼 오류',exact:true}).click();await show(true);
      await page.getByRole('button',{name:'폼 표시 전환',exact:true}).click();
      check(await toast.count()===1,'Unmount does not clear another owner toast');
      await toast.getByRole('button',{name:'알림 닫기'}).click();
      await page.getByRole('button',{name:'폼 표시 전환',exact:true}).click();
      await page.getByRole('button',{name:'폼 완료',exact:true}).click();
      await page.getByRole('button',{name:'폼 표시 전환',exact:true}).click();
      check(await toast.count()===1,'Ordinary completion survives its owner unmount');
      await elapsed(3200);check(await toast.count()===0,'Unmounted completion still expires');
      await page.getByRole('button',{name:'선언형 오류',exact:true}).click();
      await toast.waitFor();check(await toast.getByRole('alert').innerText()==='선언형 오류입니다.','ToastNotice publishes a declarative error');
      await page.getByRole('button',{name:'선언형 해제',exact:true}).click();
      check(await toast.count()===0,'Declarative owner cleanup clears the error');

      const modalTrigger=page.getByRole('button',{name:'모달 안에서 확인',exact:true});
      await modalTrigger.click();const dialog=page.getByRole('dialog',{name:'모달 안의 토스트',exact:true});
      const announce=dialog.getByRole('button',{name:'모달 오류 알림',exact:true});await announce.click();
      // Establish keyboard focus, then exercise Tab through the public modal trap.
      await announce.focus();let entered=false;
      for(let step=0;step<8;step++){
        await page.evaluate(()=>{window.toastPreviousFocus=document.activeElement;});
        await page.keyboard.press(navigationKey);
        if(await toast.getByRole('button',{name:'다시 시도',exact:true}).evaluate(el=>el===document.activeElement)){entered=true;break;}
        assert.ok(await dialog.evaluate(el=>el.contains(document.activeElement)),'Tab must stay in the modal');
      }
      check(entered,'Tab enters modal toast actions');
      await page.keyboard.press('Escape');await elapsed(32);
      check(await toast.count()===0&&await dialog.count()===1,'Toast Escape keeps its containing modal open');
      check(await page.evaluate(()=>document.activeElement===window.toastPreviousFocus),'Dismiss restores previous modal focus');
      await page.getByRole('button',{name:'모달 닫기',exact:true}).click();await elapsed(32);
      check(await modalTrigger.evaluate(el=>el===document.activeElement),'Modal close restores the outside trigger');
      check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'Fixture has no page-wide horizontal overflow');
      assert.deepEqual(errors,[]);
      results.push({engine,version:browser.version(),viewport,touch,navigationKey,geometry,passed:checks.length,checks});console.log(engine,touch?'touch':'mouse',checks.length,'passed');
    }catch(error){results.push({engine,viewport,touch,passed:false,checks,error:error.stack,errors});console.error(engine,touch,checks.length,error.message);}
    finally{await context.close();}
  }}finally{await browser.close();}
}
} finally {await server.close();}
await writeFile(resolve(root,'verification/toast-results.json'),JSON.stringify(results,null,2));
if(results.some(result=>result.passed===false))process.exitCode=1;

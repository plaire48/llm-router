#!/usr/bin/env node
import {realpath} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runInstallCli} from '../skills/cx-ui/scripts/install.mjs';

export {installSkill} from '../skills/cx-ui/scripts/install.mjs';

if (process.argv[1] && await realpath(process.argv[1]) === await realpath(fileURLToPath(import.meta.url))) {
  await runInstallCli();
}

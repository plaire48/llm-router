import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {servePages} from './verify-pages.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const directory=resolve(process.env.CX_PAGES_DIRECTORY||root);
const playwright=await import(process.env.PLAYWRIGHT_MODULE_PATH?pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href:'playwright');
const manifest=JSON.parse(await readFile(resolve(directory,'docs/text-pages.json'),'utf8'));
const decode=bytes=>new TextDecoder('utf-8',{fatal:true}).decode(bytes);
const results=[];
await mkdir(resolve(root,'verification'),{recursive:true});
for(const engine of ['chromium','firefox','webkit']){
  const browser=await playwright[engine].launch({headless:true,...(engine==='chromium'?{channel:'chrome'}:{})});
  try{
    for(const charset of ['windows-1252','euc-kr'])for(const base of ['/','/Manufacturing-IT/CX/']){
      const server=await servePages(directory,base,{charset});
      const page=await browser.newPage({viewport:{width:base==='/'?390:1440,height:900}});page.setDefaultTimeout(7000);
      const failures=[];page.on('pageerror',error=>failures.push(error.message));page.on('response',res=>{if(res.status()>=400&&!res.url().endsWith('favicon.ico'))failures.push(res.url());});
      try{
        // Reproduce the old direct-text path under the same server headers.
        await page.goto(server.url+'docs/COMPONENTS.md');
        assert.ok(!(await page.locator('body').textContent()).includes('공통 컴포넌트'),'raw UTF-8 markdown must reproduce the legacy-header fault');
        await page.goto(server.url);
        await page.getByRole('heading',{name:/하나의 기준으로/}).waitFor();assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        await page.getByRole('link',{name:'사용 설명서',exact:true}).click();
        await page.getByRole('heading',{name:'CX Design System 사용 방법',exact:true}).waitFor();
        assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.equal(await page.locator('article table').count(),3);
        await page.getByRole('link',{name:'5. 에이전트로 활용하기',exact:true}).click();
        assert.equal(await page.evaluate(()=>document.getElementById(decodeURIComponent(location.hash.slice(1)))?.tagName),'H2');
        assert.equal(await page.getByRole('link',{name:'README.md 받기',exact:true}).getAttribute('href'),'../README.md');
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
        await page.getByRole('link',{name:'스킬 설치·호출 안내',exact:true}).click();
        await page.getByRole('heading',{name:'Codex·Claude Code에서 CX 사용하기',exact:true}).waitFor();
        assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.match(await page.locator('article').innerText(),/\.agents\/skills\/cx-ui/);
        assert.match(await page.locator('article').innerText(),/\.claude\/skills\/cx-ui/);
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
        await page.goto(server.url+'docs/USAGE.html');
        await page.getByRole('link',{name:'공통 컴포넌트',exact:true}).first().click();
        await page.getByRole('heading',{name:'docs/COMPONENTS.md',exact:true}).waitFor();
        await page.goto(server.url+'catalog/index.html');
        if(engine==='chromium'&&charset==='windows-1252'&&base==='/'){
          for(const section of ['전체 참조','에이전트 사용','토큰 라이브러리','화면 템플릿']){
            await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:new RegExp(section)}).click();
            for(const href of await page.locator('a[href]:not([download])').evaluateAll(links=>links.map(link=>link.href))){
              const url=new URL(href);assert.ok(url.pathname.endsWith('.html'),href+' must use a readable HTML view');
            }
          }
        }
        await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/화면 템플릿/}).click();
        await page.getByRole('link',{name:'템플릿 사용 안내',exact:true}).click();
        await page.getByRole('heading',{name:'CX 토큰·조합·템플릿 사용 안내',exact:true}).waitFor();assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
        await page.goto(server.url+'catalog/index.html');
        await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/컴포넌트/}).click();
        await page.getByRole('link',{name:'토스트·로딩 상세 동작과 사용법',exact:true}).click();
        await page.getByRole('heading',{name:'토스트·로딩 사용 방법',exact:true}).waitFor();
        assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.match(await page.locator('article').innerText(),/2,850ms/);
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
        for(const href of await page.locator('article a[href]').evaluateAll(links=>links.map(link=>link.href)))assert.equal((await page.request.get(href)).status(),200,href);
        await page.goto(server.url+'catalog/index.html');
        await page.getByRole('navigation',{name:'디자인 안내'}).getByRole('button',{name:/컴포넌트/}).click();
        await page.getByRole('link',{name:'표 상세 기능과 동작 기준',exact:true}).click();
        await page.getByRole('heading',{name:'CX 표 사용과 동작 기준',exact:true}).waitFor();
        assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.match(await page.locator('article').innerText(),/정렬.*필터.*고정/s);
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
        for(const source of ['docs/COMPONENTS.md','skills/cx-ui/SKILL.md','agent/library.json','agent/table-contract.json','agent/feedback-contract.json','tokens/catalog.json','reference/modules/reportInteractions.js','reference/components/DetailPanel.jsx','reference/styles/cx-density.css']){
          const entry=manifest.pages.find(item=>item.source===source);assert.ok(entry,source);
          await page.goto(server.url+entry.page);assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
          const expected=decode(await readFile(resolve(directory,source))).replaceAll('\r\n','\n');
          assert.equal(await page.locator('#document-source code').textContent(),expected,source);
          assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,source);
          const download=page.getByRole('link',{name:'원본 파일 받기',exact:true});
          assert.equal(new URL(await download.getAttribute('href'),page.url()).href,server.url+source);
        }
        await page.goto(server.url+'docs/DESIGN-INVENTORY.html');
        await page.getByRole('combobox',{name:'목록',exact:true}).selectOption('components');
        await page.getByRole('searchbox',{name:'상세 검색'}).fill('DetailPanel');
        await page.getByRole('link',{name:'reference/components/DetailPanel.jsx',exact:true}).click();
        await page.getByRole('heading',{name:'reference/components/DetailPanel.jsx',exact:true}).waitFor();
        assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
        assert.deepEqual(failures,[]);
        results.push({engine,version:browser.version(),charset,base,rawFaultReproduced:true,utf8Views:true,dualSkillGuide:true,relativeLinks:true,pass:true});
        console.log(`${engine} ${charset} ${base}: raw failure reproduced; HTML reading passed`);
      }finally{await page.close();await server.close();}
    }
    const page=await browser.newPage({viewport:{width:390,height:844}});
    const source='skills/cx-ui/SKILL.md',entry=manifest.pages.find(item=>item.source===source);
    await page.goto(pathToFileURL(resolve(directory,entry.page)).href);
    assert.equal(await page.locator('#document-source code').textContent(),decode(await readFile(resolve(directory,source))).replaceAll('\r\n','\n'));
    assert.equal(await page.evaluate(()=>document.characterSet),'UTF-8');
    results.push({engine,offlineFileView:true,pass:true});await page.close();
  }finally{await browser.close();}
}
await writeFile(resolve(root,'verification/text-pages-results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({scenarios:results.length,passed:results.length}));

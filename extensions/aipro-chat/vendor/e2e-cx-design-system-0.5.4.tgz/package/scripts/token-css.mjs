import postcss from 'postcss';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

// Retain original selector/media/supports contexts. A flat :root export loses touch and viewport overrides.
export async function tokenCss(root,inventory,brand) {
  const output=postcss.root();
  for(const file of inventory.cssOrder) {
    const ast=postcss.parse(await readFile(resolve(root,file),'utf8'));
    ast.walkDecls(decl=>{if(!decl.prop.startsWith('--'))decl.remove();});
    ast.walkComments(comment=>comment.remove());
    function prune(container) {
      for(const node of [...(container.nodes||[])]) {
        if(node.nodes){prune(node);if(!node.nodes.length)node.remove();}
        else if(node.type!=='decl')node.remove();
      }
    }
    prune(ast);output.append(ast.nodes);
  }
  const fixed=postcss.rule({selector:':root'});
  for(const [prop,value] of Object.entries(brand))fixed.append(postcss.decl({prop,value}));
  output.append(fixed);
  return '/* CX variables only. Import fonts.css for fonts or styles.css for complete components. */\n'+output.toString()+'\n';
}

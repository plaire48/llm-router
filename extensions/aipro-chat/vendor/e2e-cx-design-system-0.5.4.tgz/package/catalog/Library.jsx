import React,{useMemo,useState} from 'react';
import {CxPageHeader,CxCard,CxField,CxInput,CxSelect,CxCheckbox,CxButton,CxNotice,CxTabs} from '../dist/index.js';
import data from './library-data.json';
import {documentLink} from './documentLink.js';
import {templatePreviews} from './templates';

function Code({children}){return <pre className="catalog-code"><code>{children}</code></pre>;}
export function TokenLibrary({initialQuery='',onTemplate}) {
  const [query,setQuery]=useState(initialQuery),[category,setCategory]=useState(''),[recommended,setRecommended]=useState(true),[limit,setLimit]=useState(40);
  const words=query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const tokens=data.tokens.tokens.filter(token=>(!recommended||token.recommended)&&(!category||token.category===category)&&words.every(word=>JSON.stringify({...token,categoryLabel:data.tokens.categories.find(item=>item.id===token.category)?.label}).toLowerCase().includes(word)));
  return <>
    <CxPageHeader title="토큰 라이브러리" description="사용할 역할을 찾고 CSS 변수로 연결하세요. 크기·상태·반응형 조건은 공통 스타일이 처리합니다."/>
    <div className="catalog-library-filters"><CxField label="토큰 검색"><CxInput type="search" value={query} onChange={e=>{setQuery(e.target.value);setLimit(40);}} placeholder="색상, 모달, --cx-control…"/></CxField><CxField label="토큰 분류"><CxSelect value={category} onChange={e=>{setCategory(e.target.value);setLimit(40);}}><option value="">전체 분류</option>{data.tokens.categories.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect></CxField></div>
    <CxCheckbox label="권장 사용 토큰만 보기" checked={recommended} onChange={e=>{setRecommended(e.target.checked);setLimit(40);}}/>
    <p className="cx-layout-note" role="status">{tokens.length}개 중 {Math.min(limit,tokens.length)}개 표시 · {data.tokens.tokens.length}개 전체 값 보존</p>
    <div className="catalog-token-grid">{tokens.slice(0,limit).map(token=><article key={token.id} className="catalog-token-entry">
      <div className="cx-layout-actions">{/^#[a-f\d]{3,8}$/i.test(token.resolvedBase)&&<i className="catalog-token-color" aria-hidden="true" style={{background:token.css}}/>}<strong>{token.label}</strong><small>{data.tokens.layers.find(layer=>layer.id===token.tier)?.label}</small></div>
      <code>{token.css}</code><p>{token.resolvedBase}</p>
      <details><summary>정의·조건·관련 조합</summary><p className="cx-layout-note">기본 표현: {token.baseValue}</p><p className="cx-layout-note">{token.origin}</p>{token.conditions.map((condition,i)=><p key={i} className="catalog-token-condition"><a href={documentLink(condition.source)}>{condition.source}:{condition.line}</a><br/><code>{condition.value}</code><br/>{condition.context.join(' → ')}</p>)}
        {token.usedBy.map(id=>{const recipe=data.recipes.find(item=>item.id===id);return <div key={id} className="cx-layout-stack"><strong>{recipe.label}</strong><p className="cx-layout-note">{recipe.when}</p><div className="cx-layout-actions">{recipe.templates.map(id=><CxButton key={id} onClick={()=>onTemplate(id)}>{data.templates.find(item=>item.id===id).label} 템플릿</CxButton>)}</div></div>;})}
      </details>
    </article>)}</div>
    {tokens.length>limit&&<CxButton onClick={()=>setLimit(value=>value+40)}>토큰 40개 더 보기</CxButton>}
    {!tokens.length&&<p>일치하는 토큰이 없습니다. 검색어나 분류를 바꿔 보세요.</p>}
    <CxNotice>표시한 값은 기본값과 선언 근거입니다. 전체 원본에는 과거·조건부 값도 포함됩니다. 화면에는 값을 복사하기보다 CSS 변수를 사용하세요.</CxNotice>
    <Code>{"import '@e2e/cx-design-system/styles.css';\n\n/* 화면 고유 배치 */\n.my-section {\n  display: grid;\n  gap: var(--cx-space-4);\n  color: var(--layout-text);\n}"}</Code>
    <div className="catalog-demo-row"><a href={documentLink('tokens/catalog.json')}>전체 토큰 색인</a><a href="../docs/DESIGN-INVENTORY.html">선언 상세와 원본</a></div>
  </>;
}

function TemplatePreview({template}) {
  const [scenario,setScenario]=useState('sample');
  const loadHistory=useMemo(()=>scenario==='sample'?undefined:async()=>{
    if(scenario==='error')throw new Error('불러오지 못했습니다. 다시 시도하세요.');
    if(scenario==='loading')await new Promise(resolve=>setTimeout(resolve,1500));
    return [];
  },[scenario]);
  const login=async()=>{await new Promise(resolve=>setTimeout(resolve,400));throw new Error('로그인하지 못했습니다. 다시 시도하세요.');};
  const Preview=templatePreviews[template.id];
  return <div className="cx-layout-stack">
    {template.id==='history-list'&&<CxField label="이력 예제 상태"><CxSelect value={scenario} onChange={e=>setScenario(e.target.value)}><option value="sample">샘플 이력</option><option value="empty">빈 결과</option><option value="error">조회 오류</option><option value="loading">로딩 후 빈 결과</option></CxSelect></CxField>}
    {template.id==='login'&&<p className="cx-layout-note">이 미리보기는 처리 중·실패를 체험합니다. 실제 인증 요청을 보내지 않습니다.</p>}
    <div className="catalog-example"><Preview embedded {...(template.id==='history-list'?{loadHistory}:template.id==='login'?{onLogin:login}:{})}/></div>
  </div>;
}
export function TemplateLibrary({initialTemplate='list-detail',onToken}) {
  const [id,setId]=useState(initialTemplate),[view,setView]=useState('preview');
  const template=data.templates.find(item=>item.id===id);
  return <>
    <CxPageHeader title="화면 템플릿" description="미리보기에서 동작을 확인한 뒤 새 프로젝트를 만들거나 기존 화면 폴더에 복사하세요."/>
    <CxField label="화면 템플릿 선택"><CxSelect value={id} onChange={e=>setId(e.target.value)}>{data.templates.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</CxSelect></CxField>
    <p>{template.description}</p>
    <CxTabs items={[{key:'preview',label:'미리보기'},{key:'use',label:'사용 방법'},{key:'source',label:'소스 코드'}]} active={view} onChange={setView} label="템플릿 보기" idPrefix="template-view" panelId="template-view-panel"/>
    <div role="tabpanel" id="template-view-panel" aria-labelledby={'template-view-'+view} className="cx-layout-stack cx-layout-stack--loose">
      {view==='preview'&&<TemplatePreview key={id} template={template}/>}
      {view==='use'&&<>
        <CxCard title="새 프로젝트"><Code>{`node scripts/create.mjs ../my-cx-app --template ${id} \\\n  --package ./releases/e2e-cx-design-system-${data.version}.tgz\ncd ../my-cx-app\nnpm install\nnpm run dev`}</Code></CxCard>
        <CxCard title="기존 프로젝트에 화면 추가"><Code>{`node node_modules/@e2e/cx-design-system/scripts/template.mjs \\\n  add ${id} --to src/screens/${id}`}</Code><p>빈 폴더에 App.jsx와 app.css를 복사합니다. 기존 파일이 있으면 중단합니다. 앱 진입점에서 CX styles.css를 한 번 불러오고, 화면의 app.css도 연결하세요.</p><Code>{`import Screen from './screens/${id}/App.jsx';\nimport './screens/${id}/app.css';\n\n// 기존 CxAppShell 안에서 사용합니다.\n<Screen embedded />`}</Code></CxCard>
        <CxCard title="서비스 연결"><dl className="cx-layout-description">{Object.entries(template.props).map(([name,description])=><React.Fragment key={name}><dt><code>{name}</code></dt><dd>{description}</dd></React.Fragment>)}</dl>{template.integration.map(line=><p key={line}>{line}</p>)}</CxCard>
      </>}
      {view==='source'&&template.files.map(file=><CxCard key={file.target} title={file.target}><a href={'../'+file.source} download={file.target}>파일 내려받기</a><Code>{file.content}</Code></CxCard>)}
    </div>
    <CxCard title="사용한 구성"><p>{template.components.join(' · ')}</p><p className="cx-layout-note">상태: {template.states.join(' · ')}</p><p className="cx-layout-note">확인: {template.checks.join(' · ')}</p><div className="catalog-token-links">{template.tokens.map(token=><button key={token} onClick={()=>onToken(token)}><code>{token}</code></button>)}</div></CxCard>
    <CxCard title="컴포넌트 조합 규칙"><div className="cx-layout-stack">{data.recipes.map(recipe=><details key={recipe.id} className="catalog-recipe"><summary>{recipe.label} · {recipe.status==='reference-extension'?'제품 참조 확장':'공통 조합'}</summary><p>{recipe.when}</p><p>{recipe.components.join(' · ')}</p>{recipe.rules.map(rule=><p key={rule}>{rule}</p>)}<div className="catalog-token-links">{recipe.tokens.map(token=><button key={token} onClick={()=>onToken(token)}><code>{token}</code></button>)}</div><p className="cx-layout-note">제품 참고: {recipe.references.map(file=><React.Fragment key={file}><a href={documentLink(file)}>{file.split('/').pop()}</a>{' '}</React.Fragment>)}</p></details>)}</div></CxCard>
    <div className="catalog-demo-row"><a href={documentLink('docs/TABLES.txt')}>표 상세 기능과 동작 기준</a><a href={documentLink('docs/TEMPLATES.txt')}>템플릿 사용 안내</a><a href={documentLink('agent/library.json')}>에이전트용 통합 색인</a></div>
  </>;
}

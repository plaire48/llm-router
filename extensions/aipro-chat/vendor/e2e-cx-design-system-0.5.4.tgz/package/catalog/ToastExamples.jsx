import React,{useEffect,useRef,useState} from 'react';
import {CxCard,CxButton,ActionButton,DetailPanel,useFeedback} from '../dist/index.js';
import {documentLink} from './documentLink.js';

export function ToastExamples() {
  const [modal,setModal]=useState(false),[busy,setBusy]=useState(false),[retries,setRetries]=useState(0);
  const timer=useRef(null);
  const [,notify]=useFeedback([{label:'다시 시도',onClick:retry}]);
  function retry(){setRetries(value=>value+1);notify('저장했습니다.');}
  function fail(){const error=new Error('저장하지 못했습니다. 입력값은 유지됩니다.');error.diagnosticText='CX 카탈로그 예제\ncode: DEMO_SAVE_FAILED\n실제 서비스 요청은 발생하지 않았습니다.';notify(error,true);}
  function save(){if(timer.current)return;setBusy(true);timer.current=setTimeout(()=>{timer.current=null;setBusy(false);notify('저장했습니다.');},1200);}
  useEffect(()=>()=>clearTimeout(timer.current),[]);
  const normal=()=>notify('변경 사항이 없습니다.');
  const success=()=>notify('저장했습니다.');
  return <CxCard title="토스트와 원형 타이머">
    <p>왼쪽 원이 채워지는 동안 약 3초 표시됩니다. 키보드로 알림을 조작하거나 탭이 숨겨지면 남은 시간이 멈춥니다. 이 예제는 실제 저장 요청을 보내지 않습니다.</p>
    <div className="catalog-demo-row">
      <CxButton onClick={normal}>일반 안내</CxButton>
      <CxButton onClick={success}>완료 알림</CxButton>
      <CxButton onClick={fail}>오류와 재시도</CxButton>
      <CxButton onClick={()=>notify('긴 한국어 안내도 줄바꿈을 유지합니다.\n'+('상세 내용을 확인하고 필요한 항목을 수정하세요. '.repeat(32))+'\n참조: '+('sample-id-'.repeat(30)))}>긴 알림</CxButton>
      <CxButton onClick={()=>setModal(true)}>모달 안에서 확인</CxButton>
      <ActionButton action="save" label="처리 중 예제" busy={busy} onClick={save}/>
    </div>
    <p className="catalog-muted">일반 안내 i · 완료 체크 · 오류 느낌표 / 새 알림은 이전 알림을 교체합니다. 오류·재시도 알림도 같은 타이머를 사용합니다.</p>
    <p className="catalog-muted">예제 재시도: {retries}회 · 운영체제의 모션 감소 설정에서는 이동 점을 숨기고 원을 3단계로 채웁니다.</p>
    <a href={documentLink('docs/FEEDBACK.md')}>토스트·로딩 상세 동작과 사용법</a>
    {modal&&<DetailPanel title="모달 안의 토스트" variant="modal" onClose={()=>setModal(false)} footer={<CxButton onClick={()=>setModal(false)}>모달 닫기</CxButton>}>
      <p>알림을 연 뒤 Tab으로 이동해 보세요. 토스트 안에서 Esc를 누르면 알림을 닫습니다. 닫기 버튼의 도움말이 열려 있으면 첫 Esc는 도움말을 닫습니다.</p>
      <div className="catalog-demo-row"><CxButton onClick={success}>모달 완료 알림</CxButton><CxButton onClick={fail}>모달 오류 알림</CxButton></div>
    </DetailPanel>}
  </CxCard>;
}

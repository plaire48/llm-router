import Template0 from '../templates/app-shell/App.jsx';
import Template1 from '../templates/list-detail/App.jsx';
import Template2 from '../templates/settings-form/App.jsx';
import Template3 from '../templates/history-list/App.jsx';
import Template4 from '../templates/login/App.jsx';
export const templatePreviews={"app-shell":Template0,"list-detail":Template1,"settings-form":Template2,"history-list":Template3,"login":Template4};

// Human readers use prebuilt UTF-8 HTML. Machine-readable source files stay unchanged.
export function documentLink(file) {
  if(file==='README.md')return '../docs/USAGE.html';
  if(file==='docs/TEMPLATES.txt')return '../docs/TEMPLATES.html';
  if(file==='docs/TABLES.txt')return '../docs/TABLES.html';
  if(file==='docs/SKILLS.md')return '../docs/SKILLS.html';
  if(file==='docs/FEEDBACK.md')return '../docs/FEEDBACK.html';
  return '../docs/read/'+file+'.html';
}

# 변경과 배포

공통 기준 담당자가 토큰·기본 컴포넌트·규칙을 관리하고 제품 개발자가 실제 사용 사례로 확장을 제안합니다. 담당자는 저장소의 CODEOWNERS나 리뷰 담당 설정으로 지정할 수 있습니다. 현재 키트는 특정 개인이나 조직을 지정하지 않습니다.

새 요소는 목적, 기존 조합으로 해결되지 않는 이유, props, 상태, 토큰, 접근성, 반응형, 사용 예제를 함께 제출합니다. 공통 요소 변경은 관련 카탈로그·문서·검증을 같은 변경에서 갱신합니다.

0.x에서도 의도하지 않은 시각 변경을 패치에 숨기지 않습니다. 사소한 수정은 patch, 공개 API 추가·시각 기준 변경은 minor로 안내하며 동작이 바뀌는 경우 이전/이후와 적용 방법을 명시합니다. 1.0 이후 API·주요 동작·기존 화면을 깨는 변경은 major로 안내합니다. 서비스는 버전을 고정하고 검토 후 업그레이드합니다.

폐기 예정 항목에는 대체 예제와 제거 버전을 안내합니다. 기계적 검사 결과를 맞추기 위해 기준 화면을 자동으로 재승인하지 않습니다. 실제 제품 요구가 있는 확장은 공통 규칙과 구별해 기록합니다.

사내 배포 저장소는 [Manufacturing-IT/CX](https://code.sdsdev.co.kr/Manufacturing-IT/CX)입니다. 외부 준비 저장소 [plaire48/CX](https://github.com/plaire48/CX)는 비공개 상태로 관리하며 main 전체를 다운로드해 사내 main 최상위에 옮깁니다. [사내 Pages 절차](INTERNAL-PAGES.md)를 따릅니다. 배포 담당자는 검증된 릴리스 파일을 사내에 전달하고, 서비스 개발자는 전달받은 ZIP·TGZ의 버전을 고정해 사용합니다. package.json의 private 설정은 실수로 공용 npm에 게시되는 것을 막으면서 tarball 설치를 허용합니다.

## 외부 개발 패키지 버전 배포 절차

1. 작업 브랜치에서 디자인·소스·문서·예제를 변경합니다.
2. `npm version patch --no-git-tag-version` 등으로 package.json과 lockfile의 버전을 올립니다. 변경에 맞는 patch/minor/major를 선택합니다.
3. CHANGELOG.md를 작성하고 `npm run build`로 manifest와 실행 번들, 안내서·템플릿 버전을 갱신합니다. README에 특정 버전으로 적힌 사용 예시도 함께 갱신합니다.
4. `npm test`, `npm run check`, `npm run test:distribution`과 변경된 UI의 브라우저 검증을 수행합니다.
5. 생성물까지 포함해 커밋하고 PR 또는 main의 GitHub Actions 결과를 확인합니다.
6. 검증된 커밋에 package.json과 같은 `v<version>` 태그를 만들고 푸시합니다.
7. 태그 워크플로가 검증 후 ZIP·TGZ·SHA256SUMS를 GitHub Releases에 게시합니다. 이미 있는 릴리스는 덮어쓰지 않습니다. 수정이 필요하면 다음 버전을 만듭니다.

로컬 `npm run release`는 파일 생성만 수행합니다. 원격 게시 권한은 태그 배포 작업에만 부여했습니다. 사내 사이트는 별도의 main/root 자동 설정을 사용하며, 외부 릴리스와 자동으로 동기화하지 않습니다. 저장소 공개 전환은 수행하지 않습니다.

## E2E 변경을 다시 수집할 때

```sh
npm run capture -- /absolute/path/to/e2e-report
npm run build
npm test
npm run check
npm run test:distribution
```

capture는 원본을 읽고 CX의 수집 전용 폴더를 갱신합니다. 원본에서 제거된 CSS·JSX는 현재 참조에서도 제거합니다. `reference/updates.json`에서 추가·수정·제거를 검토하고, `inventory.json`의 원본 커밋과 작업 중 변경 포함 여부를 확인합니다. 이전 상태가 필요하면 CX의 Git 이력을 사용합니다.

build는 수집본으로 상세 JSON·분류 색인·오프라인 HTML을 다시 만듭니다. 새로운 JSX가 생기면 `scripts/design-inventory.mjs`의 UI 분류에 배정해야 빌드가 통과합니다. CSS 변수뿐 아니라 리터럴 값·상태·미디어 쿼리도 자동 추적합니다. 수집한 JSX·UI 보조 모듈의 팔레트·크기 상수·스타일 속성도 별도 목록에 기록합니다. 제품에 새긴 업무 로직은 참조에 보존하고, 공통 API로 공개할 때는 의존성 분리·문서·카탈로그·검증을 함께 추가합니다.

`reference/modules/`는 지정한 UI 보조 코드의 근거입니다. 모든 제품 JavaScript를 실행 패키지에 포함하지 않습니다. 동적 색상과 위치의 최종 결과, 네트워크·권한·업무 상태는 해당 제품에서 따로 검증해야 합니다. 수집된 역사적 검토 문서는 현행 버전의 검증 결과로 간주하지 않습니다.

## 템플릿과 조합의 기준 파일

`templates/<id>/`와 `templates/registry.json`을 화면 소스의 기준으로, `recipes/registry.json`을 조합 규칙의 기준으로 관리합니다. build가 공개 API·토큰·교차 참조·파일 범위·props를 검사하고 `agent/library.json`, `tokens/catalog.json`, 카탈로그 데이터와 미리보기를 생성합니다. `starter/src/App.jsx`와 app.css는 기본 list-detail에서 생성하므로 직접 수정하지 않습니다.

추가 템플릿은 빈 프로젝트 생성과 기존 프로젝트 복사, 패키지 설치 빌드, 기본·실패·빈 상태·반응형을 검증합니다. CX-TEMPLATE.json은 소비자 복사본의 출처만 기록하며 업그레이드는 서비스가 차이를 검토해 적용합니다. 관련 설명은 [TEMPLATES.txt](TEMPLATES.txt)에 유지합니다.

## Pages 문서 보기

`docs/read/`, `docs/text-pages.json`, `docs/TEMPLATES.html`은 build 생성물입니다. 원본 Markdown·텍스트·JSON·소스를 수정한 뒤 build로 다시 생성합니다. HTML은 UTF-8 BOM과 메타 선언을 사용하고, 원문은 escape해 코드로 실행되지 않도록 표시합니다. 기계가 읽는 원본 JSON과 수집 파일에 BOM을 추가하지 않습니다. `scripts/text-pages-review.mjs`는 잘못된 서버 문자셋에서의 재현·복구와 오프라인 읽기를 검증합니다.

## 표 기능 계약

`recipes/table-contract.json`과 `docs/TABLES.txt`가 표 계약의 작성 원본입니다. build는 캡처 파일과 공개 API를 검증하고 `agent/table-contract.json`, `docs/TABLES.html`을 생성합니다. `docs/TABLE-AUDIT.json`은 합성 데이터로 원본 UI를 실행한 관찰 결과이며, 원본 커밋이 바뀌면 계약을 다시 검토해야 합니다. `scripts/table-reference-review.mjs`는 E2E_SOURCE와 Playwright를 명시한 선택적 검증이며 소비 프로젝트에 제품 의존성을 추가하지 않습니다. 미해결 발견을 구현 완료로 바꾸려면 수정과 재검증 근거가 필요합니다.

## README와 사용 설명서

사용자 안내의 기준은 루트 `README.md`입니다. README는 사내에 전달된 배포본을 사용하는 개발자를 대상으로 하며, 외부 준비·CX 자체 빌드·릴리스 절차는 이 관리 문서에서 안내합니다. 설치·활용·컴포넌트·템플릿·에이전트 예제를 이 파일에서 관리하고 build가 `docs/USAGE.html`을 생성합니다. Pages에서는 Markdown의 제목·목차·표·코드를 HTML로 표시하고 문서 링크를 UTF-8 보기로 연결합니다. Markdown 변환기는 빌드 의존성으로만 사용하며 게시 사이트에 런타임 다운로드를 추가하지 않습니다. `test:distribution`은 README의 App.jsx·app.css 코드 블록을 그대로 추출해 독립 소비 프로젝트에서 빌드합니다.

## 피드백 동작 계약

`recipes/feedback-contract.json`과 `docs/FEEDBACK.md`에서 토스트·로딩의 기준을 관리합니다. build가 공개 API·토큰·근거 파일을 확인하고 소스 해시를 포함한 `agent/feedback-contract.json`, 한글 읽기용 `docs/FEEDBACK.html`을 생성합니다. 타이밍 변경은 계약 검토 없이 통과하지 않습니다. 카탈로그의 ToastExamples와 `scripts/toast-review.mjs`에서 포인터·터치·키보드·모달·모션 감소·오류 복사를 함께 검증합니다.

## 두 에이전트의 공통 스킬

스킬은 `skills/cx-ui` 한 곳에서 관리하고 설치기가 Codex의 `.agents/skills`와 Claude Code의 `.claude/skills`에 같은 파일을 복사합니다. 설치기 원본도 skills/cx-ui/scripts/install.mjs에 두고 패키지의 scripts/install-skill.mjs가 호출합니다. ZIP과 패키지 모두 도구와 프로젝트 폴더를 선택한 뒤 설치합니다. 비대화형 환경에서는 경로·--target을 모두 명시해야 하며, 도구별 원본을 따로 수정하지 않습니다. SKILL.md는 공통 frontmatter와 핵심 경로만 유지하고 상세 작업은 references/workflows.md로 나눕니다. 디자인 기준은 소비 프로젝트에 설치된 패키지에서 조회합니다. 설치·CLI·검색·새 프로젝트 생성·배포 예제와 문서를 함께 검증합니다.

build는 같은 원본 전체로 `downloads/cx-ui-skill.zip`과 버전·SHA-256 메타데이터를 생성합니다. ZIP 엔트리 순서·시간을 고정해 로컬과 CI에서 같은 바이트를 만들며 생성물은 main에 함께 커밋합니다. Pages와 개발 키트에 downloads를 포함하고, 릴리스에는 `cx-ui-skill-<version>.zip`을 별도 첨부합니다. 카탈로그는 외부 링크 대신 같은 사이트의 ZIP을 내려받습니다. 다른 도구에서의 수동 등록·실행 도구 없는 환경은 references/portable.md에서 안내하며 전체 런타임을 스킬에 복제하지 않습니다.

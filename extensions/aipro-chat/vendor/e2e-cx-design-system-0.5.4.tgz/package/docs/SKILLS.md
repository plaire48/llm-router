# Codex·Claude Code에서 CX 사용하기

`cx-ui`는 화면 요구를 CX 컴포넌트와 실제 서비스 코드로 연결하는 개발 스킬입니다. 설치된 버전을 확인하고 필요한 자료를 검색한 뒤, 화면 구현과 상태·동작 검증까지 진행하도록 구성했습니다.

스킬 원본은 `skills/cx-ui/` 한 곳에서 관리합니다. 도구마다 복사되는 경로만 다르며 두 도구가 같은 기준을 읽습니다.

| 도구 | 프로젝트 설치 경로 | 호출 |
| --- | --- | --- |
| Codex | `.agents/skills/cx-ui/SKILL.md` | `$cx-ui 만들 화면과 동작` |
| Claude Code | `.claude/skills/cx-ui/SKILL.md` | `/cx-ui 만들 화면과 동작` |

## ZIP으로 내려받기

**[CX UI 스킬 ZIP 다운로드](../downloads/cx-ui-skill.zip)** — 설치 명령 없이 스킬 폴더를 받을 수 있습니다. 이 링크는 현재 카탈로그와 같은 배포본에 있는 파일이므로 사내 Pages에서도 외부 GitHub 접속 없이 내려받습니다. [파일 버전·SHA-256](../downloads/cx-ui-skill.json)으로 전달받은 파일을 확인할 수 있습니다.

ZIP은 다음 구조이며 cx-ui 폴더 전체를 사용합니다.

```text
cx-ui/
  SKILL.md
  agents/openai.yaml
  references/workflows.md
  references/portable.md
  scripts/install.mjs
  scripts/lookup.mjs
```

### 설치할 도구와 폴더 선택

ZIP을 내려받아 압축을 푼 폴더에서 실행합니다. Node.js 22 이상이 필요하며 npm 설치나 인터넷 연결은 필요하지 않습니다.

```sh
node cx-ui/scripts/install.mjs
```

설치기가 다음 순서로 묻습니다.

```text
설치할 도구를 선택하세요.
1. Codex
2. Claude Code
3. 둘 다
0. 취소
선택:

설치할 프로젝트 폴더의 경로:
```

사용할 도구와 기존 프로젝트 폴더를 지정하면 **실제 설치 경로를 표시하고 확인 후 복사**합니다. 기본 선택은 없으며 0을 선택하거나 마지막 확인에서 Enter를 누르면 취소합니다. 선택하지 않은 도구의 폴더는 만들지 않습니다.

| 선택 | 지정한 프로젝트 안에 만드는 폴더 |
| --- | --- |
| Codex | `.agents/skills/cx-ui` |
| Claude Code | `.claude/skills/cx-ui` |
| 둘 다 | 위 두 폴더 |

설치 후 프로젝트를 도구에서 다시 열고 Codex는 `$cx-ui`, Claude Code는 `/cx-ui`로 사용합니다. 같은 파일이면 재실행해도 중복 복사하지 않습니다. 기존 스킬이 다르면 선택한 모든 경로를 확인한 뒤 복사 전에 중단합니다. 변경 내용을 비교하고 이전 폴더를 스킬 경로 밖에 백업한 다음 다시 실행하세요.

터미널에서 질문에 답할 수 없는 CI·스크립트 환경에서는 **프로젝트와 도구를 모두 명시**해야 합니다. 생략하면 파일을 복사하지 않고 사용 방법을 표시합니다.

```sh
node cx-ui/scripts/install.mjs "/path/to/my-app" --target codex
node cx-ui/scripts/install.mjs "/path/to/my-app" --target claude
node cx-ui/scripts/install.mjs "/path/to/my-app" --target all

# 선택한 도구의 설치 상태만 확인
node cx-ui/scripts/install.mjs "/path/to/my-app" --target codex --check
```

이 명령은 프로젝트에 CX 스킬을 복사합니다. Codex·Claude Code 프로그램 자체를 설치하거나 사용자 전체 설정을 바꾸지는 않습니다.

### 수동 등록·다른 도구에서 사용

Node.js 없이 복사하려면 cx-ui 폴더를 Codex의 `.agents/skills/`와 Claude Code의 `.claude/skills/` 아래에 각각 둡니다. 설치기에서 둘 다를 선택하면 이 두 번의 복사를 처리합니다.

다른 도구가 스킬 ZIP 업로드를 지원하면 ZIP을 등록하고, 폴더 등록을 지원하면 cx-ui 폴더를 그 도구의 스킬 경로에 둡니다. 등록 기능이 없으면 폴더를 작업공간에 두고 다음처럼 지침 파일을 지정합니다. 파일 첨부만 지원하면 필요한 참조 문서도 함께 전달합니다.

```text
cx-ui/SKILL.md를 읽고 CX 기준으로 업무 관리 화면을 만들어줘.
제공한 CX 개발 키트의 컴포넌트와 템플릿을 사용하고,
기존 저장 API를 유지하면서 실패·재시도와 모달 동작도 확인해줘.
```

기존 cx-ui 폴더가 있으면 변경 내용을 비교하고 백업한 뒤 갱신하세요. ZIP 해제·복사에는 Node.js가 필요하지 않습니다. 검색 스크립트 실행에는 Node.js가 필요하며, 실행 도구가 없는 환경에서 문서를 직접 읽는 방법은 [다른 에이전트 안내](../skills/cx-ui/references/portable.md)에 있습니다.

ZIP은 스킬 지침과 조회 도구입니다. **실제 컴포넌트·CSS·폰트는 CX 개발 키트/TGZ를 별도로 연결**합니다. 스킬 다운로드가 각 도구의 인증·파일 접근·빌드 기능을 추가하지는 않습니다.

## 1. 프로젝트에 설치하기

CX 패키지를 설치한 프로젝트에서 실행합니다. 도구를 지정하지 않으면 선택 메뉴를 표시합니다. ZIP 안의 설치기와 같은 구현을 사용합니다.

```sh
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs .
```

질문 없이 설치하려면 원하는 도구를 명시합니다.

```sh
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs . --target codex
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs . --target claude
```

CX를 아직 설치하지 않았다면 내려받은 **전체 CX 개발 키트 또는 저장소**에서 스킬부터 복사할 수 있습니다. 아래 경로는 실제 폴더로 바꿉니다.

```sh
node /path/to/CX/scripts/install-skill.mjs /path/to/my-app --target all
```

대상은 존재하는 프로젝트 폴더여야 합니다. package.json이 없는 비 React 프로젝트에도 스킬을 설치할 수 있습니다. 설치기는 Node.js 22에서 실행하며 로컬 파일만 복사합니다. 기존 AGENTS.md·CLAUDE.md와 개인 설정을 수정하지 않습니다. 새 프로젝트 생성기 `create.mjs`는 `--skill-target codex|claude|all`을 명시했을 때 해당 스킬과 지침 파일만 만듭니다. 옵션을 생략하면 스킬을 설치하지 않으며 나중에 설치기를 실행해 선택할 수 있습니다.

**스킬은 디자인 패키지를 대신하지 않습니다.** React 컴포넌트를 쓰려면 CX TGZ와 React 의존성이 필요합니다. 비 React 프로젝트는 CSS·폰트·토큰을 연결합니다. [기본 사용 방법](../README.md)의 설치 절차를 함께 따르세요.

## 2. 작업을 요청하기

설치한 프로젝트를 Codex 또는 Claude Code에서 엽니다. 호출 명령 뒤에 화면 목적, 필요한 동작, 연결할 기존 함수를 적습니다.

Codex 예시:

```text
$cx-ui 업무 관리 화면을 만들어줘.
검색·목록·상세 수정·저장 실패 복구가 필요해.
기존 saveTask 함수에 연결하고 좁은 화면도 확인해줘.
```

Claude Code 예시:

```text
/cx-ui 현재 설정 화면을 CX로 맞춰줘.
기존 API와 입력값은 유지하고 버튼·폼·모달·토스트를 적용해줘.
저장 중 중복 실행을 막고 실패 후 재시도까지 확인해줘.
```

요청에 따라 다음처럼 활용합니다. 같은 요청의 호출 앞부분만 도구에 맞춰 바꾸면 됩니다.

```text
$cx-ui 정렬·필터·열 고정이 있는 목록을 만들어줘.
현재 CxTable의 지원 범위와 표 계약을 먼저 확인하고 필요한 기능을 구현해줘.
```

```text
/cx-ui 이 저장 화면에 공통 로딩과 토스트를 적용해줘.
원형 타이머와 3초 표시, 오류·재시도, 모달 안 키보드 조작을 유지해줘.
```

```text
$cx-ui 이 화면을 검토만 해줘.
색·폰트·버튼 크기·모달·표·토스트가 CX와 다른 부분과 근거를 알려줘.
```

새 서비스는 원하는 템플릿과 업무 흐름을 말합니다. 기존 화면 변경은 보존할 데이터·API·권한과 변경할 UI를 말합니다. 단순 검토 요청을 임의의 전체 재작성으로 확대하지 않도록 지침을 포함했습니다.

## 3. 스킬이 실제로 읽는 기준

스킬은 `lookup.mjs --summary`로 설치된 CX 버전·공개 API·템플릿·검사 명령부터 확인합니다. 이어 키워드에 해당하는 API·토큰·문서·예제만 찾습니다.

- 화면 틀과 배치: 템플릿과 조합 규칙, IDENTITY.md.
- 버튼·폼·모달: manifest의 공개 API, COMPONENTS.md와 실제 props.
- 표: table-contract.json의 지원 범위와 서비스 소유 상태.
- 토스트·로딩: feedback-contract.json의 시간·모션·초점·재시도.
- 구현 확인: 프로젝트 검사 명령, 변경 화면의 브라우저 동작과 실제 서비스 연결.

CSS·폰트·컴포넌트를 스킬 안에 다시 복제하지 않습니다. 소비 프로젝트가 설치한 CX 버전을 기준으로 읽으므로 여러 버전을 쓰는 프로젝트에도 연결할 수 있습니다. `reference/`의 제품 전용 파일을 공개 API처럼 import하지 않도록 구분합니다.

직접 조회하려면 설치한 도구 경로 중 하나를 사용합니다.

```sh
node .agents/skills/cx-ui/scripts/lookup.mjs . --summary
node .claude/skills/cx-ui/scripts/lookup.mjs . 토스트
```

반환된 packageRoot가 문서 경로의 기준입니다. 모노레포는 마지막 `.` 대신 CX를 사용하는 프런트엔드 폴더를 지정합니다. 패키지를 찾지 못하면 스킬이 포함된 다른 저장소를 대신 읽지 않고 설치 위치 확인을 요청합니다.

## 4. 팀 공유·업데이트·문제 확인

설치된 `.agents/skills/cx-ui`와 `.claude/skills/cx-ui`, CX TGZ, package.json과 lockfile을 프로젝트와 함께 관리합니다. 팀원은 같은 브랜치를 받아 같은 스킬과 패키지를 사용합니다. 개인 전역 설치나 별도 MCP 서버는 필요하지 않습니다.

복사본이 현재 배포본과 일치하는지 확인합니다. `--check`는 파일을 바꾸지 않고 `current`, `missing`, `different`를 출력하며 모두 current일 때만 종료 코드 0을 반환합니다.

```sh
node node_modules/@e2e/cx-design-system/scripts/install-skill.mjs . --target all --check
```

이미 같은 스킬이면 재설치해도 파일이 바뀌지 않습니다. 다르면 설치 전에 중단합니다. 변경 내용을 비교하고 기존 폴더를 각 도구의 skills 폴더 밖에 백업한 뒤 다시 설치하세요. 팀이 추가한 지침은 프로젝트 AGENTS.md·CLAUDE.md에서 관리하면 공통 스킬 업데이트와 구분하기 쉽습니다.

호출이 보이지 않으면 현재 연 프로젝트와 도구별 폴더·SKILL.md 첫 줄의 frontmatter를 확인하고 새 세션에서 다시 확인합니다. 같은 이름의 개인 스킬이나 도구의 비활성 설정이 있으면 어떤 스킬이 선택되는지도 확인하세요. `--check` 성공은 파일 설치 확인이며 도구의 권한·정책이나 로그인 상태까지 검증한 뜻은 아닙니다.

## 5. 관리 구조와 검증

- `skills/cx-ui/SKILL.md`: 호출 조건, 프로젝트 확인, 자료 선택, 구현·검증 지침.
- `skills/cx-ui/references/workflows.md`: 도입·새 화면·기존 화면 전환·검토의 상세 절차와 JSX 예제.
- `skills/cx-ui/scripts/lookup.mjs`: 소비 프로젝트의 패키지·토큰·템플릿·계약 검색.
- `skills/cx-ui/agents/openai.yaml`: Codex의 스킬 이름·설명·기본 요청 예제.
- `skills/cx-ui/scripts/install.mjs`: ZIP·패키지 공통 설치기. 두 도구 설치와 읽기 전용 상태 확인. `scripts/install-skill.mjs`는 같은 설치기를 호출합니다.

설치·동일 파일 재실행·사용자 수정 보호·다중 대상 사전 확인·패키지 버전 일치와 예제 빌드를 자동 검증합니다. LLM이 생성한 모든 화면의 품질까지 파일 검증으로 보장하지는 않습니다. 실제 실행·배포 검증 범위는 [검증 기록](VERIFICATION.md)에 남깁니다.

설치 위치와 호출 형식은 [Codex 공식 스킬 안내](https://developers.openai.com/codex/skills)와 [Claude Code 공식 스킬 안내](https://code.claude.com/docs/en/skills)를 기준으로 확인했습니다. 사내망에서는 위 사이트에 접속하지 않아도 이 키트의 파일과 문서로 사용할 수 있습니다.

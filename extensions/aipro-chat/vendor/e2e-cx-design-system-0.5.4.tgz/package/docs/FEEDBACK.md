# 토스트·로딩 사용 방법

CX의 토스트는 **짧게 알릴 결과**를 표시합니다. 왼쪽의 원은 알림을 읽는 시간이 지나가는 것을 보여줍니다. 저장·다운로드의 진행률이 아닙니다. 작업 중에는 버튼의 `busy`나 본문의 `CommunityStatus`를 사용하고, 결과가 확인된 뒤 토스트를 띄웁니다.

카탈로그의 **컴포넌트 → 토스트와 원형 타이머**에서 일반 안내, 완료, 오류·재시도, 긴 한국어, 모달 안 알림과 버튼 로딩을 실행할 수 있습니다. 예제 저장·복사는 실제 업무 API와 연결되지 않습니다. 에이전트는 [동작 계약](../agent/feedback-contract.json)에서 같은 기준을 조회합니다.

## 1. 왼쪽 원과 3초 표시

토스트는 옅은 원형 트랙, 채워지는 선, 선 끝을 따라 움직이는 점, 중앙 상태 아이콘, 메시지, 선택적 동작과 닫기 버튼으로 구성합니다. 선은 위쪽에서 시작해 시계 방향으로 채워집니다.

| 활성 표시 시간 | 보이는 상태 |
| --- | --- |
| 0~2,850ms | 원이 채워지고 선두의 점이 함께 이동 |
| 2,850~3,000ms | 점을 숨기고 완성된 원을 최소 150ms 유지 |
| 이후 | 자동 닫기 |

일반·완료·오류·재시도 버튼이 있는 알림에 모두 같은 타이머를 적용합니다. 원과 점, 닫기는 하나의 `requestAnimationFrame` 시계를 사용합니다. 프레임 지연과 일시 정지가 있으면 실제 벽시계 시간은 3초보다 길어질 수 있습니다. 오래 남아야 하는 오류와 필수 재시도는 화면에도 제공하세요.

| 상황 | 타이머 동작 |
| --- | --- |
| 마우스를 올리거나 터치·포인터로 누름 | 계속 진행 |
| 토스트 안에서 키보드로 조작하거나 키보드 초점이 표시됨 | 남은 시간 보존 |
| 초점이 토스트 밖으로 이동 | 남은 시간부터 재개 |
| 탭이 숨겨져 `document.hidden`이 됨 | 남은 시간 보존 |
| 탭으로 돌아옴 | 키보드 정지 조건이 없으면 재개 |
| 새 알림 도착 | 이전 알림을 교체하고 새 타이머 시작 |

운영체제가 모션 감소를 요청하면 움직이는 점을 숨기고 원을 3단계로 채웁니다. 원형 시간 안내와 완료 후 닫기는 유지합니다. 모달이 열리거나 닫혀 토스트의 부모가 바뀌어도 진행하던 시간을 이어갑니다.

## 2. 가장 간단하게 결과 알리기

앱 진입점에서 CX 스타일을 한 번 불러옵니다. 별도의 ToastProvider나 화면별 토스트 컨테이너는 필요하지 않습니다.

```jsx
import '@e2e/cx-design-system/styles.css';
import { notifyToast } from '@e2e/cx-design-system';

// 조회·저장 등 실제 동작의 결과를 확인한 위치에서 호출합니다.
notifyToast('변경 사항이 없습니다.');
notifyToast('저장했습니다.');
notifyToast('저장하지 못했습니다. 입력값은 유지됩니다.', { error: true });
```

| 종류 | 중앙 아이콘·색 | 메시지 접근성 |
| --- | --- | --- |
| 일반 안내 | i · 브랜드 블루 | `role="status"` |
| 완료 | 체크 · 브랜드 블루 | `role="status"` |
| 오류 | 느낌표 · 오류색 | `role="alert"` |

메시지에는 `aria-atomic="true"`가 있고 원형 SVG는 장식으로 숨깁니다. 알림이 열려도 현재 초점을 강제로 옮기지 않습니다. 음성 안내 방식은 실제 보조기기에서 별도 확인해야 합니다.

완료 체크는 현재 `저장했습니다`, `저장 완료`, `복사했습니다`, `초기화했습니다`, `불러왔습니다`, `내보냈습니다`, `적용했습니다`를 포함한 비오류 문구로 판정합니다. 다른 성공 문구는 일반 안내 아이콘으로 표시될 수 있습니다. `success`·`variant` 옵션이나 `toast.success()` 메서드는 제공하지 않습니다. `Error` 객체만 전달해도 자동으로 오류색이 되지는 않으므로 `{error: true}`를 함께 지정합니다.

## 3. 저장 중·실패·재시도 연결하기

`useFeedback(errorActions)`는 `[message, notify, error]`를 반환합니다. `notify(message, isError, actions?)`로 로컬 상태와 전역 토스트를 함께 갱신합니다. 두 번째 인자는 옵션 객체가 아닌 **오류 여부 boolean**입니다. `notifyToast`와 호출 형식을 구별하세요.

아래 컴포넌트의 `onSave`는 서비스에서 제공하는 비동기 함수입니다. 실패하면 예외를 던지고, 실제 저장이 확인됐을 때 완료하도록 연결합니다. 입력값은 부모 폼에서 유지합니다.

```jsx
import { useRef, useState } from 'react';
import { ActionButton, CxButton, CxNotice, useFeedback } from '@e2e/cx-design-system';

export function SaveActions({ onSave }) {
  const inFlight = useRef(false);
  const [saving, setSaving] = useState(false);
  const [message, notify, error] = useFeedback([
    { label: '다시 시도', onClick: save },
  ]);

  async function save() {
    if (inFlight.current) return;
    inFlight.current = true;
    setSaving(true);
    try {
      await onSave();
      notify('저장했습니다.');
    } catch (cause) {
      const failure = new Error('저장하지 못했습니다. 입력값은 유지됩니다.', { cause });
      notify(failure, true);
    } finally {
      inFlight.current = false;
      setSaving(false);
    }
  }

  return (
    <div className="cx-layout-stack">
      <ActionButton action="save" busy={saving} onClick={save} />
      {error && <CxNotice tone="danger">
        <p>{message}</p>
        <CxButton busy={saving} onClick={save}>다시 시도</CxButton>
      </CxNotice>}
    </div>
  );
}
```

`busy`는 버튼 아이콘을 회전 표시로 바꾸고 중복 실행을 막습니다. 작업 종료 시점과 요청 취소·서버 중복 처리 정책은 서비스가 관리합니다. 토스트의 `actions`는 콜백 호출만 제공하며 자체적으로 요청을 보내거나 닫거나 처리 중 상태로 바꾸지 않습니다. 따라서 예제처럼 요청 중복 방지와 완료·실패 결과를 연결해야 합니다.

토스트가 3초 후 닫혀도 hook의 `message`·`error`는 지워지지 않습니다. 예제의 화면 오류와 재시도는 남으며, 다음 `notify('저장했습니다.')`가 오류 상태를 해제합니다. `errorActions`는 오류일 때 기본 동작으로 사용하고, `notify`의 세 번째 인자로 동작 배열을 전달하면 그 배열을 우선합니다.

조회 중에는 콘텐츠 위치에서 다음처럼 표시합니다. `loading`과 `loadError`는 실제 요청 상태입니다.

```jsx
import { CommunityStatus } from '@e2e/cx-design-system';

<CommunityStatus loading={loading} error={loadError} label="불러오는 중…" />
```

비오류 문구가 `중…` 또는 `중...`으로 끝나면 토스트는 표시하지 않습니다. 같은 소유자의 기존 알림은 해제하지만 다른 소유자의 오류는 유지합니다. 모든 진행 문장을 자동 분류하는 것은 아니므로 작업 중 메시지를 토스트로 반복 호출하지 마세요.

## 4. 진단 정보 복사

`Error.diagnosticText` 또는 `Error.cause.diagnosticText`가 있으면 **오류 정보 복사**를 제공합니다. 복사할 정보는 서비스에서 작성합니다. 아래 값은 예시입니다.

```jsx
const failure = new Error('저장하지 못했습니다. 입력값은 유지됩니다.');
failure.diagnosticText = 'code: SAVE_FAILED\nrequestId: example-123';
notifyToast(failure, { error: true });
```

Clipboard API가 성공하면 버튼 이름이 **복사 완료**로 바뀝니다. 실패하면 토스트 안에 `role="status"`로 실패를 알립니다. 오류 stack을 자동으로 수집하거나 일반 옵션의 `diagnosticText`를 읽지는 않습니다. 실제 배포 호스트의 클립보드 권한·지원 여부는 별도로 확인합니다.

## 5. 한 번에 하나, 화면을 닫을 때의 정리

동시에 한 토스트만 보입니다. 새 알림은 이전 알림을 교체하며 같은 문구도 새 ID와 시간을 받습니다. 대기열이나 여러 위치의 스택은 없습니다. 이전 알림의 닫기 작업으로 새 알림이 사라지지 않도록 ID를 확인합니다.

`notifyToast(message, {source: 'settings'})`의 `source`는 소유자 구분에 사용합니다. 별도 채널이나 화면 영역이 아닙니다. 같은 source에 빈 문구를 보내면 그 소유자의 현재 알림만 해제합니다. 반환값은 `undefined`이며 공개 dismiss handle은 없습니다.

React 상태를 선언형으로 연결할 때는 `ToastNotice`를 사용합니다.

```jsx
import { ToastNotice } from '@e2e/cx-design-system';

// saveError는 서비스가 관리하는 오류 문자열입니다.
{saveError && <ToastNotice message={saveError} error />}
```

`ToastNotice` 자체는 인라인 박스를 그리지 않고 전역 알림으로 전달합니다. message, error, 동작 label 구성이 바뀌면 다시 표시하며, 콜백 함수만 바뀌면 타이머를 다시 시작하지 않고 최신 함수를 사용합니다. 같은 문자열로 다시 알리려면 `notifyToast` 또는 hook의 `notify`를 호출합니다.

`useFeedback`이나 `ToastNotice`의 화면이 해제될 때 자신이 소유한 **오류 또는 동작이 있는 알림**을 정리합니다. 일반 안내·완료는 남은 시간 후 닫힙니다. 다른 화면에서 새로 띄운 알림을 지우지는 않습니다.

## 6. 모달·키보드·닫기

`DetailPanel` 등의 공통 모달을 사용하면 토스트가 최상위 활성 모달 안으로 이동합니다. 모달의 배경 `inert`와 Tab 초점 순환을 유지하면서 오류 복사·재시도·닫기를 조작할 수 있습니다. 모달이 없으면 body에 표시됩니다.

닫기 버튼 또는 **토스트 안에서** Esc를 누르면 알림을 닫습니다. 닫기 아이콘의 키보드 도움말이 열려 있으면 첫 Esc는 도움말, 다음 Esc는 알림을 닫을 수 있습니다. 토스트에서 처리한 Esc가 모달까지 닫지는 않습니다. 화면 다른 곳에서 누른 Esc를 전역 토스트 닫기로 사용하지 않습니다.

검증한 macOS WebKit 환경은 버튼 탐색에 Option+Tab을 사용했습니다. 일반 Tab만 누르면 브라우저 UI로 이동할 수 있으므로 해당 브라우저의 키보드 탐색 설정도 확인하세요.

닫을 때 토스트 안에 초점이 있으면 유효한 이전 초점으로 복귀합니다. 이전 대상이 제거되거나 inert이면 활성 모달 제목 또는 모달로 돌아갑니다. 열기→Tab 진입→닫기→초점 복귀와 모달 열기·닫기 중 남은 시간을 함께 검증하세요.

## 7. 색상·크기·긴 문구

| 요소 | 기준 |
| --- | --- |
| 본문 | 로컬 Noto Sans KR, 14px / 400 / 줄 높이 1.6 |
| 동작 | 브랜드 글자색, 밑줄, 굵기 500, 여러 개면 줄바꿈 |
| 표면 | 흰 배경, 1px 브랜드 테두리, 8px 모서리, 오버레이 그림자 |
| 일반·완료 원 | `--brand-action`, 옅은 `--brand-border`·`--brand-surface` 트랙 |
| 오류 원 | `--cx-danger`, `--cx-error-surface`, 느낌표 함께 표시 |
| 원형 SVG | 32×32, 중심 16/16, 반지름 13, 채움 선 3.5px, 트랙 3px |
| 이동 점 | 반지름 2.5px, 표면색 테두리 1.25px |
| 기본 위치 | 하단 중앙, 하단 24px 또는 safe area, 최대 너비 `min(560px, 100vw - 32px)` |
| 600px 이하 | 좌우 12px, 하단 12px 또는 safe area |
| 긴 메시지 | 입력 줄바꿈 유지, 긴 ID도 줄바꿈, 본문 높이 최대 45dvh 이후 내부 스크롤 |
| 레이어 | z-index 2000, 바깥 영역은 클릭 통과, 토스트만 포인터 동작 |

닫기는 공통 `ActionButton`입니다. 검증한 배포 CSS에서 마우스는 32×32px, 터치는 44×44px입니다. 조작 크기는 최종 공통 CSS와 `(pointer: coarse)` 조건을 따릅니다. 원형 SVG의 32px와 버튼의 조작 영역을 같은 크기로 가정하지 마세요. 선언별 근거는 [토스트 CSS](../reference/styles/toast.css), [공통 버튼 CSS](../reference/styles/action-buttons.css), [밀도 CSS](../reference/styles/cx-density.css)에 있습니다.

## 8. 에이전트에게 요청하기

```text
$cx-ui 이 화면의 저장 피드백을 공통 CX로 맞춰줘.
agent/feedback-contract.json과 docs/FEEDBACK.md를 먼저 확인해줘.
작업 중에는 ActionButton busy, 성공 후에는 완료 토스트를 사용하고,
실패하면 입력값과 화면 오류·재시도를 유지해줘.
원형 3초 타이머, 키보드 일시 정지, 모달 초점 복귀,
모션 감소와 긴 한국어를 확인해줘.
```

```sh
node .agents/skills/cx-ui/scripts/lookup.mjs . 토스트
```

`duration`, `position`, `variant`, `success` 옵션은 현재 공개 API에 없습니다. `ToastViewport`와 store를 내부 경로에서 가져오거나 화면마다 별도 타이머 CSS를 덧씌우지 않습니다. 공통 동작을 바꾸려면 구현·이 문서·계약·카탈로그·브라우저 검증을 같은 변경으로 갱신합니다.

검증용 [toast-review.mjs](../scripts/toast-review.mjs)는 합성 데이터와 제어된 시계로 포인터·터치·키보드·가시성·모달·모션 감소를 확인합니다. 가시성 이벤트와 클립보드 응답 일부는 모의 조건이며 실제 사내 호스트, 저장 API, 클립보드 권한, 스크린리더 검증을 대신하지 않습니다. 실행 환경과 결과는 [검증 기록](VERIFICATION.md)을 참고하세요.

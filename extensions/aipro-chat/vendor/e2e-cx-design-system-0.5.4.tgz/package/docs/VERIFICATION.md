# 0.5.4 사내 사용자 README 검증

검증일: 2026-09-16. README를 사내 배포본을 받아 프로젝트에 적용하는 개발자 기준으로 정리하고 같은 원본으로 Pages 사용 설명서를 생성했습니다. 런타임 JS·CSS와 스킬 ZIP의 바이트는 0.5.3과 동일합니다.

- Node 22.23.2의 npm ci, build, Node 테스트 42개, 디자인 검사와 Python Pages 테스트 13개 통과.
- 전체 개발 키트에 포함된 TGZ로 독립 프로젝트 설치·빌드, 템플릿 5종 생성·복사, README의 JSX·CSS 및 스킬·토스트 코드 예제를 검증했습니다. ZIP·TGZ 체크섬과 루트·CX·Manufacturing-IT/CX·pages/Manufacturing-IT/CX 경로의 자원·문서·스킬 다운로드를 확인했습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 390/1440px에서 README 예제 6개 시나리오 통과. 빈 입력 오류, 한국어 업무 추가, 입력 초기화와 가로 넘침을 확인했습니다.
- 잘못된 windows-1252/euc-kr 헤더·중첩 경로·오프라인 문서의 15개 브라우저 시나리오 통과. README 목차, 스킬·템플릿·표·토스트 안내로 이동, 한글과 화면 너비를 확인했습니다.
- 사내 사용 절차에서 CX 자체 빌드·릴리스 요구를 제거하고 개발 키트 최상위의 실제 TGZ 경로로 예제를 수정했습니다. 배포 담당자의 패키징·게시 안내는 별도 문서로 연결합니다.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright 환경에서 scripts/readme-review.mjs와 scripts/text-pages-review.mjs를 실행합니다. 근거는 verification/distribution-results.json, readme-browser-results.json, text-pages-results.json에 기록했습니다.

사내 npm 레지스트리·캐시 접근, 저장소 권한과 실제 Pages 게시는 이 환경에서 검증하지 않았습니다. 사내 반입 뒤 해당 환경에서 확인합니다.

# 0.5.3 선택형 스킬 설치 검증

검증일: 2026-09-16. ZIP 안의 독립 설치기와 패키지 설치기를 같은 구현으로 연결했습니다. Codex·Claude Code·둘 다 중에서 설치할 도구와 프로젝트를 선택하며 자동 all 기본값을 제거했습니다. 공개 React API·JS·CSS는 0.5.2와 같습니다.

- Node 22.23.2의 build, Node 테스트 42개, 디자인 검사와 Python Pages 테스트 13개, skill-creator quick_validate 통과.
- 선택 없음·잘못된 옵션·비대화형 인자 누락은 파일을 복사하지 않습니다. Codex만·Claude만·둘 다의 파일 일치, 다른 도구 폴더 미생성, --check 읽기 전용 조회, 재실행·기존 지침·수정 스킬 보존을 확인했습니다.
- 독립 ZIP을 임시 위치에 풀고 실제 터미널에서 Codex·Claude Code·둘 다·최종 확인 거부·메뉴 취소의 5개 시나리오를 실행했습니다. 프로젝트 경로에 한글·공백을 넣었고 설치 확인 전에는 파일이 없으며 선택한 경로만 생기는 것을 확인했습니다.
- 새 프로젝트 생성은 --skill-target을 명시했을 때만 해당 스킬·지침을 만듭니다. none(옵션 생략)·codex·claude·all의 결과를 검증했습니다.
- 독립 소비 프로젝트와 템플릿 5종·README/스킬/토스트 예제 빌드, ZIP·TGZ·Pages 파일 체크섬, 4개 Pages 경로의 정적 자원과 다운로드를 검증했습니다. ZIP만 가지고 실행한 설치 결과와 패키지 설치 복사본은 같습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 320/390/1440px의 9개 스킬 다운로드·설치 안내·로그인 예제 시나리오 통과. 한글·잘못된 문자셋 헤더·중첩 경로·오프라인 문서 읽기 15개 시나리오 통과.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright 환경에서 scripts/skill-review.mjs와 scripts/text-pages-review.mjs를 실행합니다. 터미널 실행 근거는 verification/skill-installer-terminal.json에 기록했습니다.

이번 검증은 설치 대상 선택·파일 복사·패키지 연결·문서·다운로드 동작에 대한 것입니다. 임의 모델의 생성 결과와 사내 Pages 실제 게시는 해당 환경에서 별도로 확인합니다. 기존 0.5.2의 무옵션 자동 설치를 사용하던 스크립트는 프로젝트와 --target을 명시해야 합니다.

# 0.5.2 스킬 전용 다운로드 검증

검증일: 2026-09-16. 설치기와 같은 skills/cx-ui 원본에서 스킬 ZIP을 생성합니다. 공개 React API·런타임 JS·CSS는 0.5.1과 같습니다.

- Node 22.23.2에서 npm ci, build, Node 테스트 38개, 디자인 검사와 Python Pages 테스트 13개 통과. skill-creator의 quick_validate도 통과했습니다.
- 스킬 ZIP의 CRC·압축 해제·전체 파일 및 상대 참조 일치, 버전·SHA-256을 확인했습니다. 원본 파일의 수정 시간을 바꿔도 같은 ZIP을 생성하며 내용 변경은 해시에 반영됩니다. ZIP에는 cx-ui 폴더와 5개 파일만 들어 있습니다.
- 독립 소비 프로젝트 설치·템플릿 5종·문서 예제 빌드와 함께 설치기를 거치지 않고 압축을 푼 스킬의 조회를 확인했습니다. 임의 위치의 검색 스크립트가 작업 대상 프로젝트에 설치한 CX 버전을 읽습니다. 수동 ZIP·Codex 복사본·Claude Code 복사본의 모든 파일이 같습니다.
- 네 릴리스 파일의 체크섬과 Pages·개발 키트·TGZ 안의 스킬 ZIP 일치를 확인했습니다. 루트·CX·Manufacturing-IT/CX·pages/Manufacturing-IT/CX 경로에서 다운로드 응답과 SHA-256이 일치합니다. 같은 사이트의 파일을 사용하며 외부 다운로드 주소를 요구하지 않습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 320/390/1440px의 9개 스킬 시나리오 통과. 실제 버튼 클릭으로 ZIP을 받아 파일명·SHA-256을 확인하고 안내 이동·한글·가로 넘침·기존 로그인 예제 동작을 함께 검증했습니다.
- 잘못된 문자셋 헤더·중첩 경로·오프라인 읽기의 15개 문서 시나리오 통과. 문서 보기는 235개이며 새 다운로드 안내와 메타데이터의 상대 링크를 검사했습니다.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright 환경에서 scripts/skill-review.mjs와 scripts/text-pages-review.mjs를 실행합니다. 결과는 verification/skill-browser-results.json, text-pages-results.json, distribution-results.json에 저장됩니다.

다른 도구의 스킬 업로드 화면이나 임의의 모델 실행을 검증한 결과는 아닙니다. ZIP·폴더·지침 파일로 전달하는 구조와 실행 도구가 없을 때의 문서 사용 흐름을 제공합니다. 해당 도구의 등록·파일 접근 기능에 따라 사용하며, CX 컴포넌트·CSS·폰트는 별도로 연결합니다. 실제 사내 Pages 게시는 파일 반입 후 확인합니다.

# 0.5.1 최종 배포 검증

검증일: 2026-09-16. 공개 컴포넌트·스킬·템플릿·카탈로그·배포 파일을 검토했습니다. 공개 API는 34개, 토큰은 568개, 조합은 12개, 템플릿은 5개입니다. 원본 E2E src와 수집 참고 파일은 수정하지 않았습니다.

발견·수정: TableEditModeButton의 저장 콜백이 null로 실패하면 reason.message 접근에서 처리되지 않은 JavaScript 예외가 발생했습니다. 저장·변경 취소의 null 오류를 안전하게 안내하도록 수정했습니다. 비동기 onEnter도 예외를 처리하고 진행 중 중복 실행을 차단합니다. 초안은 호스트에 보존하며 기존 true/false 반환 규칙을 유지합니다.

- Node 22.23.2에서 npm ci, build, Node 테스트 36개, Python Pages 테스트 13개와 디자인 검사 통과. 스킬 형태 검사 quick_validate도 통과했습니다.
- TGZ를 새 프로젝트에 설치해 5개 템플릿의 생성·복사·빌드와 서비스 콜백 예제를 검증했습니다. README·스킬·토스트 안내의 JSX를 그대로 빌드했습니다. Codex·Claude 두 경로의 파일 일치·설치 버전 조회·기존 지침 보존·재설치·충돌 거부를 확인했습니다. 두 CLI의 발견 검사는 아래 0.5.0의 기록이며, 스킬 4개 파일의 바이트가 그 커밋과 동일함을 재확인했습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5에서 공개 컴포넌트 추가 회귀 검사 126개(21개 × 390/1440px × 3엔진) 통과. 수정 진입·저장·변경 취소의 실패와 거절, 재시도·중복 차단·busy Esc, 비활성 링크, 선택 메뉴의 옵션 제거·fieldset 잠금·키보드·native form 값, 혼합 체크박스, 탭 이동 거절·초점, 커밋 링크를 포함합니다.
- 카탈로그 9개 메뉴 × 320/390/768/1440px와 독립 소비 화면의 검색·저장·미저장 확인·중첩 도움말·초점 복귀 등 439개 검사 통과. JS 오류·자원 누락·외부 요청은 0개였습니다.
- 템플릿·토큰·호스트 콜백 9개, Pages 경로·너비·터치 60개, 디자인 목록·중첩 모달·날짜 필터 7개, README 실행 예제 6개, 스킬 안내·로그인 예제 6개 시나리오 통과. 실패 후 초안 유지와 재시도, 조회 응답 역전·빈 결과, 폰트·버튼의 포인터 조건도 확인했습니다.
- 토스트 342개 동작 검사 재실행 통과. 2,850ms 채움 + 150ms 유지, 키보드·숨긴 탭의 정지, 모션 감소, 모달 이동, 오류·재시도·복사, 교체와 수명을 확인했습니다. 시계·visibility·클립보드는 기존 검증의 모의 조건을 사용했습니다.
- 한글 문서 15개 브라우저 시나리오 통과. windows-1252/euc-kr 응답 헤더, 루트·중첩 경로와 오프라인 읽기를 포함합니다. Pages의 문서 보기 233개·로컬 폰트 124개 및 ZIP·TGZ 체크섬을 검증했고, 4개 게시 경로에서 자원 누락은 0개였습니다.
- 제품 참고 표는 동일한 E2E 873f70d의 90개 동작을 재확인했습니다. 기존 미해결 재사용 제한 4건(모달 안 열 선택, 그룹 표 고정 한도, 미분류 열 목록, 터치 헤더 크기)은 그대로 기록합니다. 참고 원본을 공통 DataGrid로 보장하지 않습니다. 공개 CxTable의 기본 표시 기능과 구분하며 수정 완료로 간주하지 않습니다.

재실행은 npm run build, npm test, npm run check, npm run test:distribution과 Python 테스트로 시작합니다. Playwright가 설치된 환경에서 scripts/components-review.mjs, library-review.mjs, pages-review.mjs, design-review.mjs, readme-review.mjs, skill-review.mjs, text-pages-review.mjs, toast-review.mjs를 실행합니다. browser-review.mjs는 CX_CATALOG_URL과 빌드된 verification/consumer-starter의 CX_CONSUMER_URL을 지정합니다. 참고 표 검사는 E2E_SOURCE에 캡처와 일치하는 원본을 지정합니다. 별도 Playwright 모듈은 PLAYWRIGHT_MODULE_PATH로 지정하며 결과는 verification/에 기록됩니다.

최종 판단: 공개 패키지의 위 검증 범위에서 남은 배포 차단 문제는 없습니다. 스킬을 사용한 임의의 LLM 생성 결과, 실제 인증·원격 저장·사내 Pages 게시, 물리 모바일·스크린리더 음성은 이 검증 범위에 포함하지 않습니다. 사내 배포는 파일 반입 후 해당 환경에서 확인합니다.

# 0.5.0 Codex·Claude Code 공통 스킬

검증일: 2026-09-16. skills/cx-ui 원본 하나를 두 도구의 프로젝트 경로로 복사하도록 구성했습니다. CX의 공개 React API·런타임 JS·CSS와 원본 E2E src는 변경하지 않았습니다.

- Node 22.23.2에서 npm ci, build, 패키지 테스트 36개, 디자인 검사 통과. Python Pages 설정 테스트 13개와 skill-creator의 quick_validate 통과.
- 두 도구 동시 설치·선택 설치·동일 파일 재설치·읽기 전용 --check·잘못된 CLI 입력·기존 파일 보호·한 대상 충돌 시 다른 대상에 쓰지 않음·심볼릭 링크 보호를 검증했습니다. package.json 없는 프로젝트에도 설치할 수 있고 AGENTS.md·CLAUDE.md를 보존합니다.
- 독립 TGZ 설치와 5개 템플릿 생성·복사·빌드, 두 도구의 스킬 전체 파일 일치, AGENTS.md·CLAUDE.md 생성, 설치 패키지를 기준으로 한 두 경로의 조회를 확인했습니다. references/workflows.md의 JSX, README와 FEEDBACK.md 예제도 그대로 추출해 소비 프로젝트에서 빌드했습니다. 요약 조회는 전체 원본/토큰 목록을 출력하지 않고 버전·공개 범위·검사 명령·자료 경로를 제공합니다.
- Codex CLI 0.153.4의 로컬 app-server skills/list에서 실제 설치한 cx-ui가 scope=repo, enabled=true이며 UI 설명·기본 요청이 일치함을 확인했습니다. 파싱 오류는 없었습니다. 모델 작업을 시작하지 않은 읽기 전용 발견 검사입니다.
- Claude Code 2.1.234의 격리된 검증 폴더에서 /cx-ui 자동완성에 새 스킬의 한국어 설명이 표시됐습니다. 명령을 모델에 제출하지 않고 종료했습니다. 이 CLI는 로그인되지 않은 상태였으므로 모델 응답·생성 코드 품질을 검증한 결과는 아닙니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 390/1440px 총 6개 시나리오 통과. 카탈로그의 두 호출 예제와 스킬 안내서 이동, 문서 링크, 한글·가로 넘침 없음, 스킬 JSX 예제의 로그인 콜백·busy 중복 차단을 확인했습니다. 실제 인증은 합성 콜백입니다.
- text-pages-review 15개 시나리오 통과. 새 SKILLS.html과 README, 스킬 원문을 windows-1252/euc-kr 헤더 및 루트·Manufacturing-IT/CX 하위 경로에서 UTF-8로 확인했습니다. 오프라인 소스 보기와 상대 링크도 포함합니다. Pages는 문서 보기 233개와 로컬 폰트 124개를 포함합니다.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright 환경에서 scripts/skill-review.mjs와 scripts/text-pages-review.mjs를 실행합니다. 스킬 형태 검사에는 skill-creator의 quick_validate.py를 사용했습니다. 선택한 CLI가 인식하는지는 해당 버전·설정에서 별도 확인합니다.

위 결과는 설치·발견·검색·예제 빌드·브라우저 동작의 근거입니다. LLM이 스킬로 임의의 화면을 생성하는 평가, 사내 정책·실제 로그인/저장 API·GHES Pages 게시는 수행하지 않았습니다. 기존 토스트 342개 동작 검증은 아래 0.4.4 기록이며 이번 문서·설치 변경에서 재실행한 결과는 아닙니다.

# 0.4.4 토스트·로딩 동작 정리

검증일: 2026-09-16. E2E 원본 `873f70d`와 CX의 기존 공개 토스트 구현을 확인했습니다. 런타임 JS·CSS와 원본 제품 src는 바꾸지 않고 동작 계약·사용 예제·카탈로그·스킬·배포 구성을 추가했습니다.

- Node 22.23.2에서 npm ci, build, 패키지 테스트 31개, 디자인 검사 통과. Python Pages 설정 테스트 13개 통과. 15개 피드백 동작과 공개 API 6개를 계약으로 제공하며 근거 소스의 SHA-256을 기록합니다.
- 독립 TGZ 설치, 5개 템플릿 생성·복사·빌드, README 예제와 FEEDBACK.md의 SaveActions 코드 그대로 빌드, 설치한 스킬의 토스트 조회를 확인했습니다. 전체 키트 ZIP·Pages ZIP·TGZ와 해시를 검증했습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 1440px 마우스·390px 터치: 환경별 57개, 총 342개 동작 확인. 2,850ms 원 채움과 최소 150ms 완성 유지, 프레임 지연, hover·터치 중 진행, 키보드 정지, 알림 교체, 모달 이동 중 시간 보존, 숨김 상태, Esc, 모션 감소, 아이콘·ARIA, 오류 복사·재시도, 긴 한국어·ID, busy 완료, hook·선언형 수명, 초점 복귀를 포함합니다. 페이지 실행 오류는 없었습니다.
- macOS WebKit의 기본 Tab은 이 환경에서 버튼을 건너뛰고 브라우저 UI로 이동했습니다. 버튼 순환 검증에는 Option+Tab을 사용했습니다. Chrome·Firefox는 Tab을 사용하며, 이 입력 차이를 문서·계약과 결과의 navigationKey에 기록합니다. 모든 환경의 기본 Tab 설정을 동일하게 검증했다고 간주하지 않습니다.
- 실제 계산된 본문은 Noto Sans KR / 14px, 닫기 버튼은 마우스 32×32px·터치 44×44px였습니다. 원·점의 캡처와 카탈로그 390/1440px 캡처를 검토했습니다. 실제 카탈로그에서도 오류→재시도→완료와 안내서 이동, 가로 넘침 없음을 확인했습니다.
- text-pages-review 15개 시나리오 통과. Chrome·Firefox·WebKit에서 windows-1252/euc-kr 응답 헤더의 원문 깨짐을 재현하고, 루트·Manufacturing-IT/CX 경로의 HTML 안내서·계약·소스는 UTF-8로 읽었습니다. 새 안내서의 상대 링크, 코드·한국어, 좁은 화면과 오프라인 보기까지 확인했습니다. 총 231개 문서 보기와 폰트 124개를 포함합니다.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright와 세 브라우저가 설치된 환경에서 `node scripts/toast-review.mjs`, `node scripts/text-pages-review.mjs`를 실행합니다. 별도 Playwright는 PLAYWRIGHT_MODULE_PATH로 지정합니다. 결과는 verification/toast-results.json, verification/text-pages-results.json에 기록합니다.

타이머는 제어된 시계, 가시성은 document.hidden/visibilitychange 모의 조건, 클립보드는 성공·실패 응답 모의 조건으로 확인했습니다. 실제 백그라운드 운영체제 스케줄링, 물리 모바일 기기, 사내 클립보드 권한, 스크린리더 음성 출력, 실제 저장 API와 사내 Pages 게시를 검증한 결과는 아닙니다. 예제 재시도와 저장 완료는 합성 동작입니다.

# 0.4.3 Markdown README와 사용 안내 검증

검증일: 2026-09-16. README.txt를 README.md로 대체하고 활용 목적 → 설치 → 템플릿/컴포넌트 → 에이전트 → 디자인 기준 → 배포 순서로 정리했습니다. 제품 런타임과 E2E 원본은 변경하지 않았습니다.

- Node 22.23.2에서 build, 패키지 테스트 27개, 디자인 검사, 독립 소비 프로젝트 설치·5개 템플릿·README 예제 빌드와 배포 패키지 검증을 통과했습니다. README의 fenced JSX/CSS를 그대로 추출해 검사합니다.
- docs/USAGE.html을 같은 Markdown에서 생성합니다. 목차의 한글 앵커, 표 3개, 코드 블록, README 다운로드와 문서 상대 링크를 검증했습니다. 일반 문서 링크는 UTF-8 HTML 보기를 사용하고 원본 코드는 escape해 표시합니다. Markdown 변환기는 빌드 시에만 사용합니다.
- text-pages-review 15개 시나리오 통과: Chrome/Firefox/WebKit, windows-1252/euc-kr 헤더, 루트와 Manufacturing-IT/CX 하위 경로, 오프라인 보기. 새 사용 설명서의 UTF-8·목차 이동·문서 링크·모바일 가로 넘침 없음까지 포함합니다.
- readme-review 6개 시나리오 통과: 3개 브라우저 × 390/1440px, 빈 업무 이름 오류·한글 업무 추가·입력과 오류 초기화·폰트 로드·가로 넘침 없음. 앱 내 브라우저에서도 사용 설명서의 한국어·9개 사용 단계·Markdown 표·README.md 다운로드 연결을 확인했습니다.
- TGZ·전체 키트 ZIP·Pages ZIP에 README.md와 생성된 사용 설명서를 포함합니다. 실제 사내 Pages 게시와 예시 서비스 API 저장은 수행하지 않았습니다.

# 0.4.2 표 기능 정밀 검토

검증일: 2026-09-16. E2E 원본 `873f70dab58f700d6469e0da1119565b24f1b251`의 src는 수정하지 않았습니다. 공개 API 34개와 기존 CxTable을 유지하고 표 동작 계약·사용 안내·에이전트 조회·참고 모듈을 보완했습니다.

- 18개 기능과 7개 표 유형, 상태 전이와 서비스 책임을 정리했습니다. 기존 소스에 남은 보고 표와 현재 라우트, interactive 기본 단순 모드를 구별합니다. 보조 모듈은 7개에서 9개로 늘었으며 원본 해시를 유지합니다.
- 원본 대상 검사: `tests/table-feedback.test.mjs` 5개, `tests/core.test.mjs`의 table/CSV/pagination/column/selection 관련 선택 실행 16개 통과. 전체 E2E 서비스 테스트를 실행한 것은 아닙니다.
- 독립 합성 데이터 23행, 원본 UI JS + CX의 수집 CSS + app-shell 문맥으로 Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5를 검사했습니다. 1440px 마우스와 390px 터치 각각 15개 동작, 총 90개 확인. 정렬, 필터 적용/취소/0건/검색과 전체 선택, 페이지 간 선택, 조회 변경 시 해제, 키보드 너비, 연속 고정/해제, 재진입·새로고침 수명, 모달 안 열 필터를 확인했습니다. 모든 원본 CSS/JSX/수집 모듈의 해시가 일치해야 실행합니다.
- 확인 동작과 별도로 재사용 문제 4개를 공개 기록했습니다: 모달 내 열 선택 메뉴 inert, 그룹 interactive 확장의 고정 한도 누락, 미분류 열의 체크 목록 누락, 터치 헤더 조작 크기 차이. 현행 그룹 제품 화면은 interactive=false이며 모달 내 열 선택은 재사용 조합입니다. 기본 CxTable이나 실제 운영 화면 전체에 동일 문제가 발생한다고 주장하지 않습니다. 발견 사항을 수정 완료로 표시하지 않습니다.
- 측정: 합성 SettingsGrid의 본문 14px/400, 행 40px 및 터치 52px, 헤더 37px/49px. 터치 정렬 28×44px, 필터 32×36px. 기준 토큰과 실제 계산 크기를 구분하고 `docs/TABLE-AUDIT.json`에 6개 환경별 측정·관찰을 보존했습니다.
- Node 22.23.2에서 build·25개 패키지 테스트·디자인 검사·독립 설치/5개 템플릿/배포 구조 검증을 통과했습니다. `scripts/text-pages-review.mjs`에는 새 TABLES.html 카탈로그 링크와 표 계약·보조 코드의 문자셋 검증을 추가했습니다. 잘못된 windows-1252/euc-kr 헤더와 루트·중첩 경로/오프라인을 포함한 15개 시나리오를 통과했습니다. 앱 내 브라우저에서도 카탈로그 → 컴포넌트 → 표 안내 이동, UTF-8, 15개 문서 절과 가로 넘침 없음을 확인했습니다.

재실행 방법은 TABLES.txt 마지막 절에 있습니다. 원격 데이터, GHES 권한/저장, 사내 Pages는 검증하지 않았습니다. 소스 기반 분석과 합성 브라우저 동작 결과이며 제품 저장 연동이나 고급 공통 DataGrid 구현 완료를 뜻하지 않습니다.

# 0.4.1 Pages 문자 인코딩 검증

검증일: 2026-09-16. 기존 원본 자료의 UTF-8 바이트는 유효했으나 카탈로그 일부 링크가 Markdown·JSON·소스를 직접 열고 있었습니다. 로컬 미리보기 서버는 UTF-8 헤더를 지정하므로 서버 문자셋이 다른 배포 환경을 재현하지 못했습니다.

- 문서·소스 220개에 UTF-8 HTML 보기를 제공하고, 카탈로그·토큰·조합·상세 목록·스킬 링크를 연결했습니다. 템플릿 안내는 별도 TEMPLATES.html로 생성합니다. README.txt와 기계용 JSON·수집 소스의 형식은 유지합니다.
- HTML에는 UTF-8 메타 선언과 BOM을 함께 사용합니다. 빌드에서 잘못된 UTF-8 입력을 거부하고, 원문은 HTML escape해 표시합니다. Pages ZIP에는 보기 파일과 원본 다운로드에 필요한 src·AGENTS·CHANGELOG도 포함합니다.
- `npm run build`, `npm test` 23개, `npm run check`, 독립 설치·5개 템플릿 빌드·배포 패키지 검증을 통과했습니다. 전체 보기의 원문 일치, UTF-8 BOM, 문자셋 선언, CSS·다운로드 경로를 검사합니다.
- `scripts/text-pages-review.mjs`: Chrome·Firefox·WebKit에서 서버가 windows-1252 또는 euc-kr을 보내는 조건과 루트·중첩 경로를 조합했습니다. 같은 헤더 아래 기존 Markdown 직접 열기의 한글 깨짐을 재현하고, 새 문서·JSON·소스 보기와 템플릿 안내는 UTF-8으로 원문을 표시하는 것을 확인했습니다. 엔진별 오프라인 file:// 읽기를 포함해 15개 시나리오 통과. 390·1440px에서 페이지 가로 넘침 없음, JSX가 실행되지 않고 원문으로 표시됨을 확인했습니다.
- 앱 내 브라우저에서도 카탈로그 → 템플릿 사용 안내의 이동·한국어·UTF-8 표시를 확인했습니다. 테스트 서버에 charset을 지정하는 기능을 추가해 실제 로컬 미리보기의 UTF-8 헤더에 의존하지 않습니다.

사내 서버의 실제 응답·업로드된 바이트는 접근하지 못했습니다. 위 결과는 로컬의 재현 검증이며, 실제 Pages 게시 완료나 모든 사내 프록시 설정의 검증을 의미하지 않습니다. 이전 직접 파일 URL 대신 새 카탈로그의 문서 링크로 확인하세요. 아래는 이전 버전 기록입니다.

# 0.4.0 토큰·조합·화면 템플릿 검증

검증일: 2026-09-16. E2E 원본은 이전 수집본 `873f70dab58f700d6469e0da1119565b24f1b251`을 유지하며 src 변경이 없습니다. 기존 브랜드·폰트·기본 규격을 보존하고 CX의 구성·탐색·복사 기능을 확장했습니다.

- 구성: 전체 토큰 568개, 조합 규칙 12개, 독립 템플릿 5개(app-shell, list-detail, settings-form, history-list, login), 공개 배치 클래스 9개. 공개 React API는 기존 34개를 유지합니다.
- `npm run build`, `npm test` 21개, `npm run check`, Pages 설정 Python 테스트 13개 통과. 토큰 전용 CSS의 선택자·조건별 선언 보존, CLI의 기존 파일·심볼릭 링크 보호, 한글 템플릿·토큰 조회를 포함합니다.
- `npm run test:distribution`: 전체 ZIP·TGZ·Pages ZIP의 SHA-256, 독립 소비 프로젝트 설치, 5개 템플릿 선택 생성 및 각각의 Vite 빌드, 설치 패키지에서 기존 프로젝트로 5개 화면 복사와 소스 일치, 라이브러리 메타데이터·스킬 조회, README·스킬 예제 빌드를 통과했습니다. 같은 의존성을 설치한 소비 프로젝트에서 각 선택 화면을 차례로 빌드했습니다. 4개 게시 경로에서 CSS 8개(템플릿 import 포함)·JS 1개·폰트 124개의 누락은 0개입니다.
- `scripts/library-review.mjs`: Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 390·1440px에서 카탈로그의 5개 미리보기·사용 방법·소스, 토큰 → 템플릿 이동, 독립 생성 화면과 호스트 콜백을 확인했습니다. 설정의 A→B→A 변경 없음·저장 중 잠금·실패 및 잘못된 응답 후 초안 유지·재시도·변경 취소, 목록 저장 결과 반영, 이력의 늦은 응답 무시·오류 복구·빈 결과·상세 Esc 초점 복귀, 로그인 콜백 없음·예외·false·정상 콜백 처리를 확인했습니다. 엔진별 터치 입력을 포함해 9개 시나리오 통과. 토큰 CSS만 사용하거나 styles.css 뒤에 불러와도 터치 44px·좁은 입력 16px 조건이 유지됩니다.
- `scripts/browser-review.mjs`: 카탈로그 9개 메뉴 × 320·390·768·1440px와 기존 소비 앱의 키보드·모달·수정·실패·미저장 회귀 검사 439개 통과. JS 오류·자원 누락·외부 요청 0개입니다.
- `scripts/pages-review.mjs`의 60개 경로·너비·터치 시나리오와 `scripts/design-review.mjs`의 7개 상세 색인·검색·중첩 모달 시나리오 통과. 앱 내 브라우저에서도 토큰 검색과 설정 템플릿의 한국어·실패 후 초안 유지·화면 배치를 확인했습니다.
- README.txt와 TEMPLATES.txt는 UTF-8 BOM 텍스트입니다. 테스트 결과와 스크린샷은 추적하지 않는 verification/에 저장합니다.

위 API 검증은 배포 템플릿에 테스트용 호스트 콜백을 연결한 결과입니다. 실제 인증·원격 저장·서버 검색·사내 GHES Pages 게시 완료를 뜻하지 않습니다. 미저장 라우트 이동 정책, 실제 모바일 기기, 제품 전용 참고 화면의 모든 업무 동작은 서비스에서 검증해야 합니다. 아래는 이전 버전 기록입니다.

# 0.3.0 전체 디자인 수집·공통 API 검증

검증일: 2026-09-16. 원본 E2E Report `873f70dab58f700d6469e0da1119565b24f1b251`, 소스 작업 중 변경 없음. CX 0.3.0에만 반영했으며 원본 src의 변경 없음과 모든 수집 CSS·JSX의 원본 해시 일치를 확인했습니다.

- 수집: 비폰트 CSS 41개, JSX 73개(앱 진입점 포함), UI 보조 모듈 7개, WOFF2 124개와 font.css·OFL. CSS 선언 12,373개, 루트 변수 568개, 조건별 변수 선언 1,052개, 모달·팝업 사용 위치 48곳, 인라인 표현 25곳, 스크립트 디자인 값 209개를 색인했습니다. 스크립트 표현은 실행하지 않은 원문 근거입니다.
- `npm run build`, `npm test` 18개, `npm run check`, Pages 설정 Python 테스트 13개 통과. 원본 해시·수집 누락·조건 보존·공개 API·날짜 검증·한글 색인 검색을 확인했습니다.
- `npm run test:distribution`: TGZ·전체 ZIP·Pages ZIP의 SHA-256, 별도 프로젝트 설치·빌드, README·스킬 예제 빌드, 현재 버전 조회와 설치, 런타임·상세 목록 파일 일치를 확인합니다. 4개 게시 경로의 정적 자원 누락은 0개입니다. 로컬 산출물은 releases/에 생성합니다.
- `scripts/browser-review.mjs`: Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5에서 카탈로그 7개 화면 × 320·390·768·1440px와 독립 소비 앱의 검색·탭·수정·실패 후 재시도·미저장 취소·중첩 도움말·초점 복귀를 검증했습니다. 367개 검사 통과, JS 오류·자원 누락·외부 요청 0개.
- `scripts/pages-review.mjs`: 위 3개 엔진 × 게시 경로 4개 × 390·700·701·1440px 및 1440px 주 터치 입력 에뮬레이션, 총 60개 시나리오 통과. 기본 조작 32px·작은 토큰 28px, `(pointer: coarse)`에서 44px를 확인했습니다. 좁은 마우스 화면은 32px입니다. 한글 사용 설명서·글꼴·CSS·초점 복귀도 확인했습니다.
- `scripts/design-review.mjs`: 3개 엔진 × 390·1440px와 오프라인 file:// 상세 목록, 총 7개 시나리오 통과. 기본 규격·UI 분류·모달 사용 위치·CSS 조건·스크립트 팔레트 검색, 페이지당 50개 추가, 한글·가로 넘침, 검색 지우기 후 초점 복귀, 모달 내 선택 메뉴와 Esc, 기간 역전 차단·적용·취소·상위 모달 유지·초점 복귀를 확인했습니다.
- 앱 내 브라우저에서도 모달·선택 메뉴·기간 팝업과 상세 목록의 표시·한글·검색을 직접 확인했습니다. README.txt는 UTF-8 BOM의 일반 텍스트를 유지합니다.

재현 시 브라우저 검증 스크립트에 설치된 Playwright의 경로를 `PLAYWRIGHT_MODULE_PATH`로 지정할 수 있습니다. browser-review는 `CX_CATALOG_URL`과 `CX_CONSUMER_URL`에 각각 카탈로그와 `verification/consumer-starter/` 서버 주소를 전달합니다. 브라우저 실행 결과 JSON과 스크린샷은 추적하지 않는 verification/에 저장됩니다.

수집 범위와 실행 검증은 다릅니다. 제품 참고 JSX 73개 전체의 업무·권한·네트워크 동작을 이 패키지에서 실행한 검증이 아닙니다. 원본 E2E의 전체 회귀 테스트, 실제 모바일 기기, 전체 WCAG 인증, 사내 GHES·Pages·로그인·메일·원격 저장은 이번 검증에 포함하지 않습니다. 외부 라이브러리 CSS는 제품 의존성으로 표시합니다. 아래 기록은 당시 버전에 대한 과거 검증이며 현행 크기 기준은 위의 0.3.0을 따릅니다.

---

# 0.2.0 CX UI 스킬·로그인 검증

검증일: 2026-09-12.

- CX UI 스킬의 frontmatter·이름·메타데이터 형식 검사 통과. Codex CLI 0.153.4의 app-server skills/list를 별도 Git 프로젝트에 실행해 cx-ui가 repo 범위, enabled=true, 오류 없음으로 검색되는 것을 확인했습니다. 모델 작업은 실행하지 않은 읽기 전용 발견 검사입니다.
- 설치 검증은 새 프로젝트 자동 포함, 기존 프로젝트에 TGZ 안의 설치 스크립트 실행, 동일 파일 재설치, 사용자 수정 파일 거부, 심볼릭 링크를 통한 다른 폴더 변경 거부, 기존 AGENTS.md 보존을 포함합니다.
- 조회 스크립트는 스킬 배포 폴더가 아닌 소비 프로젝트의 패키지를 사용합니다. 별도 버전 fixture, 한글 로그인 검색, 패키지 누락 및 manifest 버전 불일치를 검사했습니다. macOS의 /var → /private/var 경로에서 직접 실행 판별 문제가 발견되어 실제 경로를 비교하도록 수정했습니다.
- npm test 13개, 사내 Pages 모의 테스트 13개, 빌드·디자인 검사 통과. 전체 키트·TGZ·Pages ZIP의 해시, 독립 설치, 런타임 파일 일치, 생성 프로젝트 및 README 예제 빌드 통과. SKILL.md의 JSX 예제도 그대로 추출해 별도 소비 프로젝트에서 디자인 검사·빌드했습니다.
- Chrome 152.0.7977.83·Firefox 153.0·WebKit 26.5 × 390px·1440px의 6개 시나리오 통과. 배포용 Pages 폴더의 /CX/ 경로에서 스킬 안내·링크, 로그인 한글 검색, 아이콘 이름 logIn, 로그인 글자, 32px/44px 높이, 한글 설명서 인코딩과 넘침을 확인했습니다. 스킬 예제에는 검증용 콜백을 연결해 Enter 입력 시 busy 상태 전환과 중복 실행 차단을 확인했습니다. 실제 인증 서버에 로그인한 검증은 아닙니다.
- 같은 세 브라우저에서 4개 게시 경로 × 5개 화면·터치 조건의 기존 Pages 검사 60개 통과. 공통 버튼·입력·모달 크기, Esc·초점 복귀, 폰트 로딩, UTF-8 설명서, 누락 자산과 가로 넘침을 포함합니다.

재실행: npm run build, npm test, npm run check, npm run test:distribution. Playwright와 세 브라우저를 준비한 환경에서 node scripts/skill-review.mjs 및 node scripts/pages-review.mjs를 실행합니다. PLAYWRIGHT_MODULE_PATH로 별도 Playwright 설치를 지정할 수 있습니다.

스킬의 실제 로컬 발견과 예제 동작을 검증했습니다. 자연어별 자동 스킬 선택률이나 에이전트가 만드는 모든 화면의 디자인 적합성을 보장하는 평가는 아닙니다. 사내 GHES 운영 배포와 실제 서비스 인증·저장은 이번에도 직접 검증하지 않았습니다.

아래는 이전 버전의 검증 기록입니다.

# 0.1.2 버튼 크기·일반 텍스트 사용 설명서 검증

검증일: 2026-09-11.

- 원본 작업 폴더의 cx-density.css와 action-buttons.css 두 파일만 선택적으로 수집했습니다. 원본 JSX·다른 CSS·업무 데이터는 이번 변경에서 가져오지 않았으며 파일 해시와 작업 트리 수집 여부를 inventory에 기록했습니다.
- 기본 조작 32px·작은 조작 토큰 28px, 700px 이하 또는 any-pointer: coarse에서 44px로 전환되는 실제 크기를 확인했습니다. 일반·비활성·처리 중 버튼, 아이콘 버튼, 입력, 모달 닫기를 포함합니다.
- Chrome 152.0.7977.83·Firefox 153.0·WebKit 26.5에서 390px, 700px, 701px, 1440px, 1440px 터치 에뮬레이션 × 4개 게시 경로: 60개 시나리오 통과. 실제 모바일 기기 검증은 아닙니다.
- 같은 60개 시나리오에서 사용 설명서 링크, UTF-8 문서 인코딩, 한글 문장, Noto Sans KR, 가로 넘침과 누락 자산을 확인했습니다. Chrome에서 file:// 설명서 실행과 PC·모바일 캡처도 확인했습니다. 사내 서버의 응답 헤더는 직접 검증하지 못했습니다.
- README.txt의 JSX·CSS를 그대로 별도 소비 프로젝트에 복사해 설치·디자인 검사·빌드했습니다. 최초 실행에서 React import 누락을 발견해 예제를 수정했습니다. 수정한 예제로 세 브라우저 × 모바일·PC 6개 시나리오에서 빈 입력 오류, 한글 업무 추가, 입력·오류 초기화를 확인했습니다.
- 기존 전체 화면·상태 검사 367개를 다시 통과했습니다. 카탈로그 7개 화면, 반응형, 독립 설치 예제의 검색·수정·저장 실패·재시도·미저장 취소·키보드·모달 초점 복귀를 포함합니다.
- 패키지 검사 8개, 사내 Pages 설정 모의 테스트 13개, 빌드·디자인 검사·독립 소비 프로젝트 빌드·배포 ZIP 무결성 검사 통과.

설명서 HTML은 README.txt에서 생성됩니다. npm run build로 동기화합니다. npm run test:distribution 후 Playwright 환경에서 node scripts/readme-review.mjs와 node scripts/pages-review.mjs로 재검증할 수 있습니다. 전체 화면 검사는 scripts/browser-review.mjs를 사용합니다. 생성된 검증 결과는 verification/에 있습니다.

아래는 이전 작업의 검증 기록입니다.

# 사내 main 배포 구성 검증 · 2026-09-11

대상 설정: `https://code.sdsdev.co.kr/Manufacturing-IT/CX`, 기본 브랜치 `main`, 게시 원본 `main / (root)`.

- Pages 설정 모의 테스트 13개 통과: 최초 생성, 기존 설정 유지, 원본만 변경, 파일 누락, 저장소 404, 권한 부족, 서버 500, 오래된 성공 배제, queued→built, 빌드 실패, 새 커밋에 양보, 다른 호스트 실행 거부.
- 빌드·기존 패키지 테스트 8개·디자인 검사·ZIP 및 독립 소비 프로젝트 설치·프로덕션 빌드 통과.
- **저장소 루트 파일 자체**를 일반 정적 서버에 제공하고 Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5에서 390px·1440px × `/`, `/CX/`, `/Manufacturing-IT/CX/`, `/pages/Manufacturing-IT/CX/`를 검사했습니다. 총 24개 시나리오 통과. 실제 폰트·브랜드 색상, 모달 Esc·초점 복귀, 가로 넘침, 참조 링크, 실행 오류와 누락 자산을 확인했습니다.
- ZIP 자산 검사에서도 위 4개 기본 경로마다 CSS 3개·JS 1개·폰트 124개를 확인했습니다. 경로 예시는 정적 상대 경로 검증용이며 사내 Pages의 실제 게시 URL이라는 의미는 아닙니다.
- Python 자동화는 표준 라이브러리와 사내 API만 사용합니다. workflow YAML 구문과 실행 코드 구문을 확인했습니다.
- **실제 사내 GHES에는 연결하지 못했습니다.** 현재 환경에서 도메인 DNS 조회가 실패했습니다. 서버 Pages·Actions 활성화, 실행기, 관리 권한, 실제 응답과 게시 URL은 사내 실행 결과로 확인해야 합니다. 모의 테스트 성공을 운영 배포 완료로 간주하지 않습니다.

재실행: `python3 -m unittest discover -s tests -p '*_test.py'`, `python3 scripts/configure-ghes-pages.py --dry-run`, `npm run test:distribution`, Playwright 환경에서 `node scripts/pages-review.mjs`. 브라우저 검사는 기본적으로 저장소 루트를 사용하며 `CX_PAGES_DIRECTORY`로 다른 정적 폴더를 지정할 수 있습니다.

아래는 이전 패키지 버전의 검증 기록입니다.

# Pages 배포 검증 · 0.1.1

검증일: 2026-09-11. 이 패치는 디자인 CSS를 바꾸지 않고 루트 진입과 정적 배포 파일 구성을 수정했습니다.

- `npm run build`, 패키지 테스트 8개, `npm run check` 통과.
- Pages ZIP을 별도 임시 폴더에 풀어 `/`, `/CX/`, `/pages/team/CX/`에서 일반 정적 서버로 제공했습니다. 경로마다 CSS 3개, JS 1개, 폰트 124개의 HTTP 200·파일 형식·게시 폴더 내 상대 경로를 확인했습니다.
- Chrome 152.0.7977.83, Firefox 153.0, WebKit 26.5 × 위 3개 주소 × 390px·1440px: 총 18개 시나리오 통과. 루트 이동 시 쿼리·해시 유지, 실제 Noto Sans KR 로드, 브랜드 버튼 색상, 가로 넘침 없음, 모달 Esc·초점 복귀, 안내서의 참조 링크를 확인했습니다. 실행 오류와 누락 자산은 없었습니다.
- 배포 아카이브 3개의 SHA-256과 전체 키트 내부 파일 해시, 별도 소비 프로젝트의 설치·디자인 검사·프로덕션 빌드·런타임 일치를 확인했습니다.
- 실제 사용자 Pages 주소는 제공되지 않아 해당 서버의 배포·인증·응답 헤더는 검증하지 않았습니다. 로컬 서버 검증이 GitHub/GHES 운영 배포 완료를 의미하지 않습니다.

재실행: `npm run test:distribution`은 ZIP과 독립 설치를 검사합니다. `npm run build:pages` 후 Playwright·Chrome·Firefox·WebKit이 있는 환경에서 `node scripts/pages-review.mjs`를 실행하면 브라우저 결과가 `verification/pages-browser-results.json`에 기록됩니다. 별도 Playwright 설치는 `PLAYWRIGHT_MODULE_PATH`로 지정합니다.

아래는 이전 0.1.0의 전체 화면·상태 검증 기록입니다. 367개 전체 검사를 이번 패치에서 반복한 결과는 아닙니다.

## 이전 배포 검증 · 0.1.0

검증일: 2026-09-11. 현재 소스의 수집 기준과 시간은 reference/inventory.json에 기록했습니다. 같은 폴더의 참조 파일은 전체 SHA-256을 보존합니다.

## 확인 결과

| 검사 | 결과 |
| --- | --- |
| 독립 패키지 빌드 | ESM·통합 CSS·토큰·로컬 폰트·정적 카탈로그 생성 성공 |
| 패키지 테스트 | 8개 통과: 원본 해시, 폰트 경로, 공개 API, 입력 접근성, 상태·처리 중 버튼, 전체 아이콘, 정적 검사, 기존 파일 보호 |
| 시작 템플릿 정적 검사 | 위반 0건 |
| 기존 저장소 밖에서 tarball 설치 | /tmp의 별도 프로젝트에 npm install 성공. 원래 src나 node_modules 경로를 참조하지 않음 |
| 독립 프로젝트 프로덕션 빌드 | Vite 7.3.6 성공, React 19.2.8, 로컬 폰트 124개 포함 |
| 실제 Chrome 152.0.7977.83 | 아래 화면·상태 검사 통과 |
| Firefox 153.0 | 같은 검사 통과 |
| WebKit 26.5 | 같은 검사 통과. 버튼 포인터 초점 동작을 패키지에서 보완 |
| 브라우저 확인 항목 | 총 367개 통과 |
| 카탈로그 file:// 실행 | 서버 없이 로컬 HTML과 번들로 표시·폰트 로드 확인 |
| 실행 중 오류 | 세 브라우저 JavaScript 오류 0, 누락 자산 0, 외부 요청 0 |

## 브라우저 범위

안내서의 7개 화면을 320×568, 390×844, 768×1024, 1440×900에서 검사했습니다. 페이지 가로 넘침, 푸터 겹침, 실제 로컬 폰트 로드를 확인했습니다. 열린 상태에서 화면 크기를 변경합니다.

독립 프로젝트에서는 320px와 1440px에서 검색 결과 없음, 키보드 탭 전환, 수정 모달, 배경 inert, 저장 전 변경 없음, A → B → A, 저장 실패 시 초안 유지, 중첩 확인창의 안전한 초기 초점, Esc의 최상위 창 닫기, 재시도 저장, 원래 버튼으로 초점 복귀, 미저장 초안 폐기를 확인했습니다.

공통 버튼의 브랜드 색상과 44px 조작 영역, 중첩 도움말과 모달 초점도 확인했습니다. Chrome의 포인터 기본 동작과 다른 WebKit에서 같은 초점 복귀를 보장하도록 배포용 ActionButton·CxButton을 보완했습니다. 원래 E2E Report 소스에는 이 어댑터 변경을 적용하지 않았습니다.

## 재실행

1. `npm run build && npm test && npm run check`.
2. `npm run preview`로 안내서를 실행합니다. 기본 URL은 http://127.0.0.1:5188/catalog/index.html 입니다.
3. tarball로 독립 프로젝트를 생성·설치·빌드하고 `npm run preview -- --port 5191`로 실행합니다.
4. Playwright 및 Chrome·Firefox·WebKit 실행 환경에서 `node scripts/browser-review.mjs`를 실행합니다. Playwright가 별도 설치되어 있다면 `PLAYWRIGHT_MODULE_PATH`로 index.mjs 경로를 지정할 수 있습니다. URL은 `CX_CATALOG_URL`, `CX_CONSUMER_URL`로 지정합니다.

스크립트는 verification/browser-results.json과 브라우저별 캡처를 생성합니다. 해당 폴더는 개발용 검증 산출물이며 npm 패키지에는 넣지 않습니다.

## 확인하지 않은 범위

제품 참고 JSX 46개를 모두 독립 컴포넌트로 실행한 검증은 아닙니다. 공개 API와 시작 예제가 검증 대상이며 제품 전용 그리드·Agent Flow·에디터의 전체 업무 동작은 reference와 패턴 문서의 범위를 따릅니다. 전체 WCAG 인증, 실제 모바일 기기, 서버 렌더링, 실제 로그인·원격 저장·접수는 이번 검증에 포함하지 않았습니다. 원본 E2E Report의 전체 회귀 테스트를 재실행한 결과도 아닙니다.

정적 검사는 색상·폰트 리터럴과 일부 내부 선택자 덮어쓰기를 찾는 제한된 검사입니다. 모든 시각·접근성 요구를 자동으로 증명하지 않습니다. 과거 reference/decisions 문서의 테스트 숫자는 당시 원본 제품의 기록이며 이 패키지의 검증 숫자에 합산하지 않습니다.

# 사내 main Pages 배포

대상 저장소: **https://code.sdsdev.co.kr/Manufacturing-IT/CX**. 기본 브랜치와 게시 브랜치는 `main`, 게시 폴더는 `/`입니다. 저장소 URL을 Pages URL로 가정하거나 CSS의 절대 경로로 고정하지 않습니다.

## 파일 전달

외부 [main ZIP](https://github.com/plaire48/CX/archive/refs/heads/main.zip)을 내려받아 사내로 전달합니다. 압축을 푼 `CX-main/` 안의 파일·폴더 전체를 사내 저장소 최상위에 넣고 main에 반영합니다. `.github/`와 `.nojekyll`을 빠뜨리지 않습니다. 빌드된 `catalog/`, `dist/`, 폰트와 예제 CSS를 이미 포함하므로 사내에서 Node, npm, 레지스트리 연결이 필요하지 않습니다.

Actions는 이 사내 저장소의 main push 또는 수동 실행에서만 작동합니다. 외부 GitHub에 push하는 것만으로 사내에 전달되지는 않습니다. `.github/workflows/validate-and-release.yml`의 외부 검증·릴리스 작업은 사내에서 건너뜁니다.

## 자동 설정

사내 Actions의 `Publish CX main on internal Pages`가 실행합니다.

1. self-hosted Linux 실행기에서 Python 3.9 이상을 사용합니다. 기본 라벨은 `self-hosted`, `linux`이며 다른 라벨은 Actions 변수 `CX_PAGES_RUNNER`에 `['...']` 형식이 아닌 유효한 JSON 배열(예: `["self-hosted","linux","cx"]`)로 지정합니다.
2. 사내 Contents API에서 실행 커밋의 `scripts/configure-ghes-pages.py`를 읽습니다. 외부 액션·pip·npm 다운로드가 없습니다. 실행기의 사내 DNS와 HTTPS 인증서 신뢰가 필요합니다.
3. 대상 저장소와 main 커밋, 루트 HTML·CSS·JS·폰트 파일 존재를 확인합니다. 파일이 빠졌거나 접근 권한이 없으면 설정을 변경하지 않고 실패합니다.
4. Pages가 없으면 생성하고, 있으면 게시 원본을 `legacy`(Deploy from a branch)와 `main / (root)`로 맞춥니다. 기존 도메인·HTTPS·공개 범위는 변경 요청에 포함하지 않습니다.
5. 빌드를 요청하고 **그 main 커밋이 built가 된 경우에만** 게시 완료로 기록합니다. 이전 커밋의 성공이나 단순 queued 응답을 완료로 표시하지 않습니다. 실제 URL은 GHES가 반환한 `html_url`을 실행 요약에 씁니다.

Pages 서비스와 Actions, 실행기, 권한은 사내 서버에 있어야 합니다. 파일이나 YAML로 조직의 서비스·실행기·권한을 자동 생성할 수는 없습니다.

## 최초 설정 권한

기본 `GITHUB_TOKEN`에는 Contents read와 Pages write를 요청합니다. Pages 최초 생성과 게시 원본 변경은 관리 권한이 추가로 필요할 수 있습니다. 실패 로그가 권한 부족을 안내하면 저장소 **Settings → Secrets and variables → Actions → New repository secret**에 `CX_PAGES_TOKEN`을 등록하고 같은 워크플로를 다시 실행하세요.

토큰 소유 계정은 이 저장소의 admin, maintainer 또는 Pages 설정 관리 권한이 필요합니다. classic PAT는 `repo` 범위, fine-grained 토큰은 해당 저장소에 Pages write·Administration write·Contents read를 부여합니다. 조직 승인·SSO 요구는 사내 정책을 따릅니다. 토큰은 비밀 설정에만 등록하며 HTML·JS·JSON·워크플로 본문에는 넣지 않습니다. [GHES Pages REST API의 생성·변경 권한](https://docs.github.com/en/enterprise-server@3.16/rest/pages/pages#create-a-github-enterprise-server-pages-site).

사내 실행기가 없거나 Actions가 금지되어 있다면 **Settings → Pages → Deploy from a branch → main → /(root) → Save**를 한 번 선택합니다. 이 경우에도 같은 main 파일을 그대로 사용하며, 이후 main 변경은 GHES의 브랜치 게시 기능으로 반영됩니다. [공식 브랜치 게시 안내](https://docs.github.com/en/enterprise-server@3.16/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

사내 PC에서 직접 설정하려면 main의 루트에서 `python3 scripts/configure-ghes-pages.py`를 실행할 수도 있습니다. 이때 토큰은 `CX_PAGES_TOKEN` 환경변수로 주입합니다. `--dry-run` 옵션은 인증·네트워크·변경 없이 대상과 게시 원본만 표시합니다.

## 실패 시 확인

| 현상 | 확인할 내용 |
| --- | --- |
| 작업이 실행기 대기 중 | 저장소에서 사용할 수 있는 runner, 라벨, Python 3.9 이상 |
| DNS·인증서 연결 실패 | 실행기의 사내 네트워크 및 사내 CA 신뢰 설정 |
| 저장소 조회 401/403/404 | 토큰의 대상 저장소 접근, 조직 승인, 정확한 저장소 이름 |
| Pages 생성·변경 403/404 | CX_PAGES_TOKEN의 관리 권한과 서버의 Pages 사용 허용 |
| 배포 파일 누락 | CX-main 안의 전체 내용이 main 최상위에 있는지 확인 |
| 게시 원본 적용 실패 | Pages 설정 관리 권한과 서버가 반환하는 설정 |
| 빌드 실패·시간 초과 | Settings → Pages의 빌드 상태와 오류; 설정·요청 성공만으로 게시 완료는 아님 |
| 게시 후 CSS 누락 | 실제 Pages 주소에서 catalog/, dist/, starter/ 상대 경로의 HTTP 상태 확인 |

현재 개발 환경에서는 사내 호스트 DNS가 조회되지 않습니다. API 모의 테스트와 정적 파일의 브라우저 검증은 수행하지만 실제 사내 설정·게시 성공은 사내 실행 결과로 확인해야 합니다.

## Pages에서 일부 문자의 인코딩이 깨질 때

0.4.1부터 카탈로그의 문서·JSON·소스 링크는 UTF-8 HTML 보기로 연결합니다. `docs/read/`, `docs/TEMPLATES.html`, `docs/text-pages.json`도 함께 게시해야 합니다. 원본 자료는 보기 화면의 다운로드 링크로 받습니다. JSON과 수집 소스의 바이트는 그대로 유지합니다.

HTML에는 UTF-8 메타 선언과 BOM을 함께 넣어 서버의 누락되거나 잘못된 문자셋 헤더에 대비합니다. 기존 배포를 갱신할 때 파일을 편집기로 열어 ANSI/EUC-KR로 다시 저장하지 말고 다운로드한 파일을 그대로 복사합니다. 배포가 반영된 뒤 카탈로그 상단 버전이 전달한 배포본의 package.json 버전과 일치하는지, 사용 설명서·템플릿 사용 안내·공개 API 문서의 한글이 정상인지 확인하세요.

카탈로그를 통해 연 문서까지 깨지면 실제 Pages URL과 응답의 Content-Type, 받은 HTML 첫 바이트를 확인해야 합니다. 이 저장소의 로컬 검증은 잘못된 헤더 조건을 재현한 결과이며 사내 서버 설정을 직접 확인한 결과는 아닙니다.

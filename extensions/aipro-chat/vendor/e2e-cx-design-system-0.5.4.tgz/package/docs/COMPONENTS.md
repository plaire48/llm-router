# 공통 컴포넌트

모든 예제의 import는 `@e2e/cx-design-system`이며 앱 진입점에서 `@e2e/cx-design-system/styles.css`를 한 번 읽습니다. React 19의 ref prop을 사용합니다. 자식 콘텐츠와 이벤트·데이터는 호스트 앱이 제공합니다.

| API | 주요 입력 | 쓰는 곳과 규칙 |
| --- | --- | --- |
| `CxAppShell` | brand, navigation, actions, footer, children | 앱 한 개의 최상위 프레임. 본문 건너뛰기·문서 흐름 푸터 |
| `CxPageHeader` | title, description, actions | 페이지의 h1 한 개와 주요 동작 |
| `CxCard` | title, actions, children | 구획. 제목은 h2; 필요 없는 중복 제목은 생략 |
| `CxButton` | variant: primary/secondary/danger, busy, disabled, onClick | 텍스트가 필요한 일반 동작. busy는 중복 실행 차단 |
| `ActionButton` | action, label, iconOnly, busy, success, disabled, onClick | 사전 정의된 추가·수정·닫기·저장 등. 저장은 기본적으로 아이콘+텍스트 |
| `ActionLink` | ActionButton 입력 + href, target, rel | 이동 액션. anchor로 렌더링하며 disabled/busy는 href와 탭 진입 제거 |
| `SearchField` | label, value, onChange(value), clearLabel, disabled | 이름·검색·지우기·초점 복귀를 포함한 검색창. onChange는 문자열 전달 |
| `DateRangeFilter` | from, to, onChange({from,to}) | 변경 기간 필터. YYYY-MM-DD 문자열; 적용을 눌렀을 때만 전달 |
| `CommunityStatus` | loading, error, label, className | 콘텐츠 옆 로딩·오류. 로딩은 status, 오류는 alert; 상태 없으면 렌더링하지 않음 |
| `CommitId` | sha | 40자리 SHA의 앞 6자와 전체 ID 접근성 이름·title. 잘못된 값은 — |
| `CommitReference` | sha, url | 같은 커밋 표현. http(s) URL이 있을 때만 새 창 링크 |
| `Icon` | name, size, className | `ICON_NAMES`의 SVG. 장식용이므로 부모 버튼에 이름 제공 |
| `SearchInput` | children | 검색 아이콘이 있는 입력 래퍼. 실제 input의 label은 호스트가 제공 |
| `CxField` | label, hint, error, required, children | 입력 1개를 label·안내·오류와 연결. 자식이 id/aria props를 DOM에 전달해야 함 |
| `CxInput` | 표준 input props | text, search, number, date 등. label은 CxField로 연결 |
| `CxSelect` | 표준 select props, children | native select의 값·form 의미 유지 + 공통 listbox. multiple/size>1은 native 유지 |
| `CxTextarea` | 표준 textarea props | 긴 글과 줄바꿈. 오류에도 현재 값 유지 |
| `CxCheckbox` | label, checked, mixed, disabled, onChange | 사용 여부·행 선택. checked와 mixed는 호스트가 제어 |
| `CxTabs` | items: {key,label}[], active, onChange, label, idPrefix, panelId | 방향키·Home·End 지원. 하나의 연결된 tabpanel은 호스트가 제공 |
| `CxTable` | caption, columns: {key,label,numeric?,render?}[], rows, rowKey | 기본 표. 행은 고유 key를 가짐. 정렬·필터·페이지 처리는 호스트 소유 |
| `CxStatus` | tone: neutral/success/warning/danger, children | 상태 글자와 점. 색상만으로 의미 전달 금지 |
| `CxNotice` | tone: info/danger, children | 안내 또는 복구 가능한 오류를 해당 위치에 표시 |
| `EmptyState` | icon, title, description, children | 최초 데이터 없음·검색 결과 없음. 필요한 다음 동작을 children으로 제공 |
| `DetailPanel` | title, subtitle, variant: drawer/modal/confirmation, onClose, footer, onHelp, hideHelp, busy, children | 배경 inert, Tab 순환, Esc, 초점 복귀. busy는 닫기 차단 |
| `CxConfirmation` | title, message, confirmLabel, cancelLabel, onConfirm, onCancel, onDiscard?, busy | 안전한 취소 선택에 초기 초점. 실제 변경은 명시적 콜백에서 수행 |
| `HelpTrigger` | onClick | 도움말을 여는 공통 액션 |
| `TableEditModeButton` | active, onChange, onEnter?, dirty, onSave, onDiscard, disabled | 읽기↔전체 수정. onSave는 성공 시 true, 실패 시 false 또는 throw |
| `notifyToast` | message, {error?,actions?,source?} | 모든 종류 약 3초 표시. 키보드 조작·숨겨진 탭에서 일시 정지; 상세는 [토스트 안내](FEEDBACK.md) |
| `ToastNotice` | message, error, actions | 선언형 알림 |
| `useFeedback` | errorActions? | [message, notify, error] 반환. 앱의 오류 상태와 알림 연결 |
| `confirmationCopy` | kind, overrides? | 공통 확인 문구. 제품 이름이 포함된 문구는 호스트에서 교체 |

`ACTIONS`, `ICON_NAMES`, `CONFIRMATION_COPY`는 열거 가능한 사전입니다. `agent/manifest.json`의 공개 목록과 이 문서에 있는 API를 사용합니다. `reference/components/`에는 독립 실행되지 않는 제품 UI도 있습니다.

버튼·입력은 기본 높이 32px이며 주 입력 장치가 터치인 (pointer: coarse)일 때 44px로 전환합니다. 작은 조작 토큰은 28px에서 44px로 전환합니다. 공통 버튼에는 size prop을 제공하지 않습니다. 화면별 고정 높이를 덧씌우지 않고 공통 CSS를 사용합니다.

700px 이하에서는 입력 글자만 16px / 줄 높이 24px로 전환합니다. 화면 너비만으로 버튼을 키우지 않습니다. 기본 표 헤더/행은 32px/40px, 주 터치 입력 시 48px/52px이며 내용에 따라 행 높이는 늘어납니다. 저장·로그인·로그아웃·문의 액션은 기본적으로 글자를 표시합니다.

## 로그인과 아이콘 이름

로그인 액션 이름은 `login`, 아이콘 이름은 `logIn`입니다. `logOut`은 로그아웃 아이콘입니다. `agent/manifest.json`의 actions에서 액션 이름·아이콘·표시 문구를, icons에서 정확한 아이콘 이름을 검색할 수 있습니다.

```jsx
<ActionButton action="login" iconOnly={false} busy={signingIn} onClick={signIn} />
<Icon name="logIn" />
```

signIn은 호스트 앱의 인증 함수입니다. 아이콘만 사용하는 경우 부모 버튼에 이름을 제공합니다. 로그인 예제는 인증 서버와 세션을 포함하지 않습니다.

## 폼

```jsx
<CxField label="이름" required error={error}>
  <CxInput value={name} onChange={event => setName(event.target.value)} />
</CxField>
<CxField label="설명" hint="필요한 내용만 간단히 입력하세요.">
  <CxTextarea value={description} onChange={event => setDescription(event.target.value)} />
</CxField>
```

## 탭

```jsx
<CxTabs items={[{key:'all',label:'전체'},{key:'active',label:'사용 중'}]}
  active={tab} onChange={setTab} label="업무 보기" idPrefix="work-tab" panelId="work-panel" />
<div role="tabpanel" id="work-panel" aria-labelledby={`work-tab-${tab}`}>
  {content}
</div>
```

탭 이동 시 변경 사항 확인이 필요하면 onChange에서 확인 후 false를 반환해 이동을 취소할 수 있습니다. items는 비어 있지 않아야 하고 key는 고유한 짧은 식별자를 사용합니다.

## 모달과 저장

```jsx
<DetailPanel title="업무 수정" variant="modal" onClose={requestClose} busy={saving}
  footer={<><CxButton onClick={requestClose} disabled={saving}>취소</CxButton>
    <ActionButton action="save" busy={saving} onClick={save}/></>}>
  {error && <CxNotice tone="danger">{error}</CxNotice>}
  {fields}
</DetailPanel>
```

`DetailPanel` 자체는 미저장 여부를 알지 못합니다. requestClose에서 dirty를 확인하고 CxConfirmation을 띄우세요. 저장 실패 시 모달을 닫거나 입력값을 초기화하지 않습니다. 중첩 도움말은 onHelp로 연결합니다. 패키지의 모달은 브라우저 전용이며 서버 렌더링 시에는 닫힌 상태로 시작합니다.

## 표

```jsx
<CxTable caption="업무별 적용 현황" rows={rows}
  columns={[{key:'name',label:'업무'},
    {key:'hours',label:'시간',numeric:true},
    {key:'status',label:'상태',render:value=><CxStatus>{value}</CxStatus>}]}/>
```

데이터 그리드의 열 고정·크기 조절·다중 선택·그룹 편집은 `reference/components/TableControls.jsx`, `SettingsGrid.jsx`, `GroupedSettingsGrid.jsx`에 원래 구조를 보존했습니다. 이 세부 기능 전체를 독립 공통 API로 제공하는 버전은 아닙니다. 필요 시 호스트 데이터 모델을 분리해 확장하고 기존 CSS와 패턴을 적용합니다.

`TableEditModeButton`의 `onEnter`는 수정 진입 전에 실행하는 선택적 비동기 콜백입니다. false를 반환하면 읽기 모드를 유지하고, 실패하면 오류를 표시합니다. 진입·저장 중에는 중복 실행을 막습니다. `onSave`가 실패해도 초안을 지우지 않으며, 실제 저장·초기화는 호스트가 담당합니다. `onDiscard`는 동기 콜백이며 false를 반환하거나 예외가 발생하면 수정 모드와 확인 창을 유지합니다.

## 검색·선택·기간 필터

```jsx
import React, {useState} from 'react';
import {SearchField, CxField, CxSelect, DateRangeFilter} from '@e2e/cx-design-system';

export function HistoryFilters() {
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [range, setRange] = useState({from:'', to:''});
  return <div className="history-filters">
    <SearchField label="변경 이력 검색" value={query} onChange={setQuery} />
    <CxField label="상태"><CxSelect value={status} onChange={event => setStatus(event.target.value)}>
      <option value="all">전체</option><option value="active">사용 중</option>
    </CxSelect></CxField>
    <DateRangeFilter {...range} onChange={setRange} />
  </div>;
}
```

검색창의 지우기는 검색어만 초기화하고 해당 입력에 초점을 돌려줍니다. 선택 메뉴는 방향키·Home·End·Enter·Esc·문자 검색을 지원하며 disabled 상태와 제거된 option을 다시 확인합니다. 모달 안에서 열면 같은 레이어 안에 표시합니다. 커스텀 UI에서도 호스트 onChange는 native select 이벤트를 받습니다.

기간 팝업은 초안을 따로 보관합니다. Esc·외부 클릭으로 닫으면 적용하지 않으며, 날짜 오류와 종료일 역전은 적용을 막습니다. 초기화 후 적용하면 `{from:'',to:''}`로 돌아옵니다. 화살표·Home·End·PageUp·PageDown으로 달력을 이동합니다. 현재 라벨은 ‘변경 기간’과 ‘변경 이력 시작일/종료일’로 고정되어 있으므로 범용 날짜 입력을 대체하지 않습니다. 실제 조회와 날짜 경계의 서버 처리는 호스트 책임입니다.

## 조회 상태·커밋·링크

```jsx
<CommunityStatus loading={loading} error={error} label="변경 이력을 불러오는 중…" />
<CommitId sha="873f70dab58f700d6469e0da1119565b24f1b251" />
<CommitReference sha={commit.sha} url={commit.url} />
<ActionLink action="openExternal" href={detailUrl} target="_blank" rel="noreferrer"
  label="원본 보기" iconOnly={false} />
```

커밋은 12px·400 굵기의 시스템 모노스페이스를 사용합니다. 링크는 옅은 배경과 밑줄로 hover/focus를 표시합니다. 커밋 미리보기의 데이터 조회는 포함하지 않습니다. `CommunityStatus`는 성공을 자동 판단하지 않으며 호스트의 loading/error 상태만 표현합니다.

전체 UI를 찾으려면 [디자인 상세 목록](DESIGN-INVENTORY.html)의 12개 분류를 사용합니다. 사용자·프로필·알림·문의·Talk·Agent Flow 등의 제품 화면, 그 안의 모달·팝업과 인라인 표현은 원본 참조로 수집되어 있습니다. 공개 목록에 없는 이름을 패키지 API로 추측하지 않습니다.

## 화면 배치와 템플릿

공개 CSS 배치 클래스는 `cx-layout-stack`, `cx-layout-stack--loose`, `cx-layout-grid`, `cx-layout-full`, `cx-layout-toolbar`, `cx-layout-actions`, `cx-layout-actions--end`, `cx-layout-note`, `cx-layout-description`입니다. modifier는 기본 클래스와 함께 사용합니다. 모든 값은 기존 토큰을 참조하며 2열 grid는 700px 이하에서 1열이 됩니다.

`templates/registry.json`의 5개 화면은 공개 API를 조합한 복사 가능한 소스입니다. React export가 추가되는 것은 아닙니다. `agent/library.json`에서 관련 토큰·조합·props를 찾고 [템플릿 사용 안내](TEMPLATES.txt)에 따라 새 프로젝트 또는 기존 화면에 연결합니다.

표의 정렬·필터·고정·너비·열 표시·페이지·선택·편집·CSV 세부 동작은 [표 동작 기준](TABLES.html)에 정리했습니다. `agent/table-contract.json`에서 18개 기능과 상태 전이, 원본 파일, 재사용 전 보완할 4개 항목을 찾을 수 있습니다. 이 계약은 새로운 공개 DataGrid API가 아닙니다.

## 토스트와 작업 중 표시

왼쪽 원은 2,850ms 동안 채워지고 완성된 원을 최소 150ms 유지한 뒤 닫습니다. 오류·액션 알림도 같은 시간을 사용하므로 지속적 오류와 필수 재시도는 `CxNotice` 등으로 화면에 남깁니다. 실제 작업 중에는 `ActionButton busy` 또는 `CommunityStatus loading`을 사용합니다. `useFeedback`의 로컬 오류 상태는 토스트가 닫혀도 유지됩니다.

API 호출 형식, 원·점·상태 아이콘, 교체·소유권, 진단 복사, 모달·키보드·모션 감소와 사용 예제는 [토스트·로딩 사용 방법](FEEDBACK.md)에 있습니다. 에이전트용 기준은 `agent/feedback-contract.json`입니다.

import React from 'react';
import {CxAppShell,CxPageHeader,CxCard,CxButton,EmptyState} from '@e2e/cx-design-system';

// Supply route content and navigation from the host. This template contains no router or persistence.
export default function App({embedded=false,title='서비스 홈',children,navigation,onStart}) {
  const content=<div className="cx-layout-stack cx-layout-stack--loose">
    <CxPageHeader title={title} description="필요한 업무를 선택하고 시작하세요."/>
    {children || <CxCard><EmptyState title="아직 등록된 업무가 없습니다." description="새 업무를 등록하면 이곳에서 확인할 수 있습니다.">
      {onStart&&<CxButton variant="primary" onClick={onStart}>업무 시작</CxButton>}
    </EmptyState></CxCard>}
  </div>;
  return embedded?content:<CxAppShell brand="우리 서비스" navigation={navigation} footer="우리 서비스">{content}</CxAppShell>;
}

import React,{useEffect,useState} from 'react';
import {CxAppShell,CxPageHeader,CxCard,CxTable,CxStatus,SearchField,DateRangeFilter,ActionButton,CommunityStatus,CommitReference,DetailPanel} from '@e2e/cx-design-system';

const sample=[
  {id:'change-1',name:'문서 검토',actor:'서비스 관리자',date:'2026-09-16',status:'수정',before:'검토 중',after:'사용 중',sha:'a'.repeat(40)},
  {id:'change-2',name:'문의 분류',actor:'업무 담당자',date:'2026-09-12',status:'추가',before:'',after:'검토 중',sha:'b'.repeat(40)},
];
// loadHistory({query,from,to}) must return a Promise<Array>. The host owns auth, date boundaries and paging.
export default function App({embedded=false,initialRows=sample,loadHistory}) {
  const [query,setQuery]=useState(''),[range,setRange]=useState({from:'',to:''}),[rows,setRows]=useState(initialRows);
  const [loading,setLoading]=useState(Boolean(loadHistory)),[error,setError]=useState(''),[retry,setRetry]=useState(0),[detail,setDetail]=useState(null);
  useEffect(()=>{
    if(!loadHistory){setRows(initialRows);setLoading(false);setError('');return;}
    let cancelled=false;setLoading(true);setError('');
    Promise.resolve().then(()=>loadHistory({query,...range})).then(result=>{
      if(!Array.isArray(result))throw new Error('변경 이력을 확인하지 못했습니다. 다시 시도하세요.');
      if(!cancelled)setRows(result);
    }).catch(reason=>{if(!cancelled)setError(reason?.message||'불러오지 못했습니다. 다시 시도하세요.');}).finally(()=>{if(!cancelled)setLoading(false);});
    return()=>{cancelled=true;};
  },[query,range.from,range.to,retry,loadHistory,initialRows]);
  const filtered=loadHistory?rows:rows.filter(row=>(row.name+' '+row.actor).includes(query)&&(!range.from||row.date>=range.from)&&(!range.to||row.date<=range.to));
  const content=<div className="cx-layout-stack cx-layout-stack--loose">
    <CxPageHeader title="변경 이력" description="변경한 내용과 적용 시점을 확인합니다." actions={<ActionButton action="refresh" label="이력 새로고침" busy={loading} onClick={()=>setRetry(value=>value+1)}/>}/>
    <CxCard><div className="cx-layout-stack">
      <div className="cx-layout-toolbar"><SearchField label="변경 이력 검색" value={query} onChange={setQuery}/><DateRangeFilter {...range} onChange={setRange}/></div>
      <CommunityStatus loading={loading} error={error} label="변경 이력을 불러오는 중…"/>
      {!loading&&!error&&<CxTable caption="변경 기록" rows={filtered} columns={[
        {key:'name',label:'대상'}, {key:'status',label:'구분',render:value=><CxStatus>{value}</CxStatus>},
        {key:'date',label:'변경일'},{key:'sha',label:'커밋',render:(value,row)=><CommitReference sha={value} url={row.url}/>},
        {key:'id',label:'상세',render:(_,row)=><ActionButton action="history" label={`${row.name} 변경 내용`} onClick={()=>setDetail(row)}/>},
      ]}/>}
    </div></CxCard>
    {!loadHistory&&<p className="cx-layout-note">샘플 이력입니다. 실제 저장소를 조회하지 않습니다.</p>}
    {detail&&<DetailPanel title="변경 내용" subtitle={detail.name} variant="modal" onClose={()=>setDetail(null)}><dl className="cx-layout-description"><dt>변경일</dt><dd>{detail.date}</dd><dt>변경자</dt><dd>{detail.actor}</dd><dt>이전 값</dt><dd>{detail.before||'—'}</dd><dt>변경 값</dt><dd>{detail.after}</dd><dt>커밋</dt><dd><CommitReference sha={detail.sha} url={detail.url}/></dd></dl></DetailPanel>}
  </div>;
  return embedded?content:<CxAppShell brand="우리 서비스" footer="우리 서비스">{content}</CxAppShell>;
}

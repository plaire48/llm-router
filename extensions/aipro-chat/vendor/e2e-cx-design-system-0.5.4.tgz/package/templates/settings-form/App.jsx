import React,{useRef,useState} from 'react';
import {CxAppShell,CxPageHeader,CxCard,CxField,CxInput,CxSelect,CxTextarea,CxCheckbox,CxNotice,CxButton,ActionButton,CxConfirmation,notifyToast} from '@e2e/cx-design-system';

const defaults={name:'우리 서비스',visibility:'team',description:'팀이 함께 사용하는 업무 공간입니다.',notifications:true};
// onSave(draft) must resolve to the saved settings object. The fallback changes memory only.
export default function App({embedded=false,initialValue=defaults,onSave}) {
  const [saved,setSaved]=useState(()=>({...initialValue})),[draft,setDraft]=useState(()=>({...initialValue}));
  const [error,setError]=useState(''),[busy,setBusy]=useState(false),[confirm,setConfirm]=useState(false),[fail,setFail]=useState(false);
  const pending=useRef(false),dirty=JSON.stringify(saved)!==JSON.stringify(draft);
  const change=(key,value)=>setDraft(current=>({...current,[key]:value}));
  async function save(event) {
    event.preventDefault();if(pending.current||!dirty)return;
    if(!draft.name.trim()){setError('서비스 이름을 입력하세요.');return;}
    pending.current=true;setBusy(true);setError('');
    try {
      let next;
      if(onSave)next=await onSave({...draft});
      else {await new Promise(resolve=>setTimeout(resolve,250));if(fail)throw new Error('저장하지 못했습니다. 입력 내용은 유지됩니다.');next={...draft,name:draft.name.trim()};}
      if(!next||typeof next.name!=='string'||typeof next.description!=='string'||!['team','private'].includes(next.visibility)||typeof next.notifications!=='boolean')throw new Error('저장 결과를 확인하지 못했습니다. 다시 시도하세요.');
      setSaved({...next});setDraft({...next});notifyToast('저장했습니다.');
    }catch(reason){setError(reason?.message||'저장하지 못했습니다. 다시 시도하세요.');}
    finally{pending.current=false;setBusy(false);}
  }
  const content=<div className="cx-layout-stack cx-layout-stack--loose">
    <CxPageHeader title="서비스 설정" description="변경한 내용은 저장한 뒤 적용됩니다."/>
    <form onSubmit={save} className="cx-layout-stack">
      {error&&<CxNotice tone="danger">{error}</CxNotice>}
      <CxCard title="기본 정보"><div className="cx-layout-grid">
        <CxField label="서비스 이름" required error={error&&!draft.name.trim()?'서비스 이름을 입력하세요.':undefined}><CxInput value={draft.name} disabled={busy} onChange={e=>change('name',e.target.value)}/></CxField>
        <CxField label="공개 범위"><CxSelect value={draft.visibility} disabled={busy} onChange={e=>change('visibility',e.target.value)}><option value="team">팀</option><option value="private">나만 보기</option></CxSelect></CxField>
        <div className="cx-layout-full"><CxField label="서비스 설명"><CxTextarea value={draft.description} disabled={busy} onChange={e=>change('description',e.target.value)}/></CxField></div>
        <CxCheckbox label="변경 알림 받기" checked={draft.notifications} disabled={busy} onChange={e=>change('notifications',e.target.checked)}/>
      </div></CxCard>
      <div className="cx-layout-toolbar"><p className="cx-layout-note" role="status">{dirty?'저장하지 않은 변경이 있습니다.':'저장된 설정과 같습니다.'}</p><div className="cx-layout-actions"><CxButton disabled={busy||!dirty} onClick={()=>setConfirm(true)}>변경 취소</CxButton><ActionButton action="save" type="submit" busy={busy} disabled={!dirty}/></div></div>
      {!onSave&&<><CxCheckbox label="저장 실패 상태 체험" checked={fail} disabled={busy} onChange={e=>setFail(e.target.checked)}/><p className="cx-layout-note">예제 설정은 메모리에만 저장됩니다. 새로고침하면 초기화됩니다.</p></>}
    </form>
    {confirm&&<CxConfirmation title="변경을 취소할까요?" message="저장된 설정으로 돌아갑니다." confirmLabel="변경 취소" cancelLabel="계속 수정" onCancel={()=>setConfirm(false)} onConfirm={()=>{setDraft({...saved});setError('');setConfirm(false);}}/>}
  </div>;
  return embedded?content:<CxAppShell brand="우리 서비스" footer="우리 서비스">{content}</CxAppShell>;
}

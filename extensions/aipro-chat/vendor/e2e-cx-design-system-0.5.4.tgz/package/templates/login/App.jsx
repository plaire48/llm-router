import React,{useRef,useState} from 'react';
import {CxAppShell,CxPageHeader,CxCard,CxNotice,ActionButton,Icon} from '@e2e/cx-design-system';

// onLogin() is supplied by the host and owns redirects/session creation. This template never stores credentials.
export default function App({embedded=false,onLogin}) {
  const [busy,setBusy]=useState(false),[error,setError]=useState('');const pending=useRef(false);
  async function login(){
    if(pending.current||!onLogin)return;
    pending.current=true;setBusy(true);setError('');
    try{const result=await onLogin();if(result===false)throw new Error('로그인하지 못했습니다. 다시 시도하세요.');}
    catch(reason){setError(reason?.message||'로그인하지 못했습니다. 다시 시도하세요.');}
    finally{pending.current=false;setBusy(false);}
  }
  const content=<div className="cx-template-login">
    <CxCard><div className="cx-layout-stack cx-layout-stack--loose">
      <Icon name="report" size={32}/><CxPageHeader title="우리 서비스 로그인" description="계정으로 로그인하고 업무를 이어가세요."/>
      {error&&<CxNotice tone="danger">{error}</CxNotice>}
      <ActionButton action="login" iconOnly={false} busy={busy} disabled={!onLogin} onClick={login}/>
    </div></CxCard>
    {!onLogin&&<p className="cx-layout-note">화면 예제입니다. 인증 서비스가 연결되면 로그인할 수 있습니다.</p>}
  </div>;
  return embedded?content:<CxAppShell brand="우리 서비스" footer="우리 서비스">{content}</CxAppShell>;
}

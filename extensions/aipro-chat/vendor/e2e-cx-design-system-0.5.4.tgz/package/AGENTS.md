# CX Design System 작업 지침

이 폴더는 제품과 분리한 배포 키트다. README.md, docs/IDENTITY.md, docs/COMPONENTS.md, docs/GOVERNANCE.md를 먼저 읽는다.

사내 배포 대상은 https://code.sdsdev.co.kr/Manufacturing-IT/CX 이며, 외부 준비 저장소는 https://github.com/plaire48/CX 이다. 외부 main 전체를 다운로드해 사내 main 최상위에 옮긴다. 다른 제품 안에 남은 이전 design-system 폴더를 기준으로 삼지 않는다.

- 기존 E2E Report의 브랜드·폰트·레이아웃을 보존한다.
- `reference/`와 전체 토큰 목록은 `scripts/capture.mjs`로 생성한다. 생성물에 직접 디자인 변경을 숨기지 않는다.
- 공개 API는 src/index.jsx, 에이전트 검색 목록은 agent/manifest.json이다. 변경 시 같이 갱신한다.
- 글꼴과 OFL을 포함하고 원본 데이터를 패키지 런타임에 추가하지 않는다.
- 폴더 바깥 앱의 소스와 배포 assets는 이 패키지 빌드에서 수정하지 않는다.
- 배포 전 독립 설치 빌드·키보드와 모달·반응형 검증 결과를 docs/VERIFICATION.md에 기록한다.
- Node 22와 npm ci로 설치한다. package-lock.json을 함께 관리한다.
- package.json이 버전의 기준이다. npm run build는 manifest·카탈로그·시작 템플릿 버전을 동기화한다.
- main 또는 PR 변경 시 npm run build, npm test, npm run check, npm run test:distribution을 통과시킨다. UI 변경이면 브라우저 검증도 수행한다.
- 외부 개발 패키지 릴리스는 검증한 커밋의 v<version> 태그를 사용한다. 기존 릴리스 파일을 덮어쓰지 않는다.
- 사내 사이트는 main / (root)를 직접 게시한다. .github/workflows/ghes-pages.yml과 scripts/configure-ghes-pages.py는 사내 호스트·저장소에서만 실행한다. 사내 배포에 외부 npm·Actions 다운로드를 추가하지 않는다.
- 사내 API를 직접 검증하지 못했으면 로컬 모의 테스트와 운영 게시 완료를 구별한다.

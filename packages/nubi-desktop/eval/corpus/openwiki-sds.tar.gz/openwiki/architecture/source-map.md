---
type: architecture-map
title: Source Map
description: Maps the OpenWiki /src directory to its owned subsystems, giving each one a responsibility and its principal entry files, and identifies the largest, most central files that anchor agent execution, configuration, and repository generation.
tags: [source-map, architecture, subsystems, entrypoints, src-layout]
sources:
  - id: openwiki-source-c45a528335f5cf7306567dc9
    resource: repo://evals/deepswe/README.md
  - id: openwiki-source-a0ae0064681def9d035f11b2
    resource: repo://evals/deepswe/run.py
  - id: openwiki-source-92ae12d8c88734df7ebc7663
    resource: repo://evals/ledger/core/types.ts
  - id: openwiki-source-8fe49b679bb29b6d5403548c
    resource: repo://evals/ledger/reevaluate.ts
  - id: openwiki-source-bdd14aa92ae4a01628e282cd
    resource: repo://evals/ledger/run.ts
  - id: openwiki-source-97ffedc1258986c2ef57fb85
    resource: repo://evals/ledger/run/runner.ts
  - id: openwiki-source-2dc719639f40452478188d6b
    resource: repo://evals/ledger/system/openwiki-system.ts
  - id: openwiki-source-33844b1c2c98eca457fd6142
    resource: repo://evals/ledger/tsconfig.json
  - id: openwiki-source-5b54a58d1b51cd490b0e7162
    resource: repo://package.json
  - id: openwiki-source-f8b008ed89162a0e204fc02d
    resource: repo://src/agent/bob.ts
  - id: openwiki-source-a953060a04ccefcf777de48e
    resource: repo://src/agent/index.ts
  - id: openwiki-source-8b316b2a9d744597bffd9c56
    resource: repo://src/agent/repository-prompts.ts
  - id: openwiki-source-6cb3236b8c1412a26d832fcf
    resource: repo://src/agent/repository-runner.ts
  - id: openwiki-source-69abc6f0f641147820a274bc
    resource: repo://src/agent/utils.ts
  - id: openwiki-source-239b2968fb2bcd073e89cedc
    resource: repo://src/claims/brains/code/runtime.ts
  - id: openwiki-source-2b28ddc861d155a44b3cc432
    resource: repo://src/claims/brains/code/store.ts
  - id: openwiki-source-75ba41da829774fe72b7a0af
    resource: repo://src/claims/evidence/repository/resolver.ts
  - id: openwiki-source-638173446de4138fa3a622a8
    resource: repo://src/claims/guidance.ts
  - id: openwiki-source-5c43e3fe562cf274dd6a5564
    resource: repo://src/cli/cli.tsx
  - id: openwiki-source-278e7e180eac811fc1a24f7a
    resource: repo://src/config/constants.ts
  - id: openwiki-source-c2770ac037a7f4b0116a0dc5
    resource: repo://src/config/env.ts
  - id: openwiki-source-f1dd0edb129e50f253618ff4
    resource: repo://src/config/reasoning.ts
  - id: openwiki-source-3632bcf6292cc01fef69c5b7
    resource: repo://src/connectors/registry.ts
  - id: openwiki-source-1197594de038075f3570340c
    resource: repo://src/generation/page-jobs.ts
  - id: openwiki-source-674d6e5badef7368ab04f064
    resource: repo://src/generation/page-manifest.ts
  - id: openwiki-source-7c5ecb56558cc061dab24f9d
    resource: repo://src/generation/repository-run.ts
  - id: openwiki-source-080c4525024a9b689e361cbb
    resource: repo://src/generation/run-state.ts
  - id: openwiki-source-c6189f89b3f67d0cbf87739f
    resource: repo://src/ingestion/ingestion.ts
  - id: openwiki-source-410e7efbe6dee8c4d43e9b4d
    resource: repo://src/integrations/core/protocol.ts
  - id: openwiki-source-58835b77ce38a0dd1fed8d09
    resource: repo://src/integrations/core/session-manager.ts
  - id: openwiki-source-eab9328975981f427c4218d0
    resource: repo://src/integrations/mcp/server.ts
  - id: openwiki-source-1324a62ac93d0625148b498e
    resource: repo://src/mermaid/dom-shim.ts
  - id: openwiki-source-4fbeebe90bb8c6910ecd1b3d
    resource: repo://src/mermaid/fences.ts
  - id: openwiki-source-3a971b24f14be56fa16b8e4b
    resource: repo://src/mermaid/validate.ts
  - id: openwiki-source-54432f9303757678a104d85f
    resource: repo://src/okf/frontmatter.ts
  - id: openwiki-source-2f1e489d53c52a0582582659
    resource: repo://src/platform/fs-errors.ts
  - id: openwiki-source-c923e23504de7a6af7799a24
    resource: repo://src/scheduling/schedules.ts
  - id: openwiki-source-a1d0931b37e6e9efdee37e97
    resource: repo://src/telemetry/index.ts
  - id: openwiki-source-d92f623adbf6b31c3542d58d
    resource: repo://src/visualize/graph.ts
  - id: openwiki-source-4d856d692c32be213c8c46b4
    resource: repo://src/visualize/server.ts
  - id: openwiki-source-d485c898eb60ebb173072eab
    resource: repo://test/agent/stream-redaction.test.ts
generated: { by: "openwiki/0.5.2", at: "2026-09-15T08:09:47.649Z" }
verified:
  - by: openwiki/0.5.2
    at: 2026-09-15T08:09:47.649Z
---

# Source Map

This page maps the `/src` tree to the subsystems it owns. It is organized by
responsibility, not as a file listing: each subsystem gets a one-line role and
its principal entry file(s). Use it to find where a concern lives before diving
into a subsystem's own page.

Related reading: [architecture overview](/openwiki/architecture/overview.md),
[agent runtime](/openwiki/architecture/agent-runtime.md),
[grounded claims](/openwiki/concepts/grounded-claims.md),
[connectors](/openwiki/integrations/connectors.md), and
[evaluation subsystem](/openwiki/testing/evals.md).

## The central files

Three files carry a disproportionate share of the system and are worth knowing
before anything else.

- **`src/agent/index.ts`** (the largest source file) owns the LLM agent surface.
  It builds and runs the OpenWiki agent (`runOpenWikiAgent`,
  `createOpenWikiAgent`), resolves and constructs the chat model across every
  supported provider (`resolveModelId`, `createModel`), manages the LangGraph
  checkpoint thread and its history (`createOpenWikiThreadId`,
  `pruneCheckpointHistory`, `resolveCheckpointTarget`), and parses streamed
  agent events into `OpenWikiRunEvent`s (`parseStreamEvent`,
  `parseAgentStreamChunk`, and the `parseUpdatesChunk` helper it dispatches to
  for `'updates'`-mode LangGraph state-delta chunks, which extracts the first
  non-empty assistant text from the per-node output objects). While streaming,
  `parseAgentStreamChunk` suppresses content blocks whose `type` includes
  `file` or `image` (notably `file`, `input_file`, and `image_url` base64
  blobs) so they never reach the terminal — behavior pinned by
  `test/agent/stream-redaction.test.ts`.
- **`src/config/constants.ts`** is the single large registry of stable strings:
  the `openwiki` directory name and the page-manifest/update-metadata paths, plus
  the provider environment-variable key names and defaults for every supported
  provider (`OPENAI_API_KEY_ENV_KEY`, `ANTHROPIC_API_KEY_ENV_KEY`, Bedrock/Vertex,
  Gemini, OpenRouter, Baseten, Copilot, Fireworks, Nebius, NVIDIA, the IBM Bob
  keys (`BOB_API_KEY_ENV_KEY`, `BOB_BASE_URL_ENV_KEY`), the `openai-compatible`
  keys — including the `OPENAI_COMPATIBLE_STREAM_MESSAGES_ENV_KEY` and
  `OPENAI_COMPATIBLE_REASONING_EFFORT_SUPPORTED_ENV_KEY` gates — and the
  connector OAuth keys) and the `OpenWikiProvider` union (which includes the
  `bob` provider). It also owns the output-token ceilings:
  `resolveConfiguredMaxOutputTokens` picks the right provider-specific setting
  (OpenRouter's legacy `OPENWIKI_OPENROUTER_MAX_TOKENS` first, then
  `OPENWIKI_MAX_OUTPUT_TOKENS`), and `resolveBedrockMaxTokens` falls back to
  `BEDROCK_DEFAULT_MAX_TOKENS` (16000) so Bedrock's 4096-token default does not
  truncate long pages. It additionally gates reasoning effort and stream mode
  for `openai-compatible` providers: it exports
  `OPENAI_COMPATIBLE_REASONING_EFFORT_SUPPORTED_ENV_KEY` and
  `resolveOpenAiCompatibleReasoningEffortSupported`, which `reasoning.ts` consults
  to decide whether an `openai-compatible` model advertises a reasoning
  capability, `providerUsesResponsesApi`, which selects the
  `responses-reasoning` vs `chat-completions-reasoning-effort` transport, and
  `resolveOpenAiCompatibleStreamMessages` (the
  `OPENAI_COMPATIBLE_STREAM_MESSAGES_ENV_KEY` resolver), which opts an
  `openai-compatible` endpoint back into LangGraph's `"messages"` stream mode.
  Nearly every subsystem imports its identifiers from here.
- **`src/generation/repository-run.ts`** owns the repository-generation
  lifecycle. It drives the plan-then-page workflow across a six-operation
  surface: `beginRepositoryRun`, `submitRepositoryPlan`, `nextRepositoryPage`,
  `inspectRepositoryPageClaims`, `submitRepositoryPage`, and
  `finishRepositoryRun`, wiring together the run state, claims runtime, wiki
  finalizer, and OKF frontmatter validation — including deterministic
  frontmatter repair (`repairPersistedFile`) before a page job is accepted.
  `beginRepositoryRun` resolves the requested language up front
  (`resolveLanguage`) and rejects an unrecognized language with
  `invalid_input` rather than falling back to English, since run state cannot
  change its language after a start. `nextRepositoryPage` returns the first
  pending job plus its `existingClaimCount` and only the
  `claimsRequiringAttention` (Claims carrying a stale or unresolved issue), so
  focused updates need not re-emit issue-free Claims; `inspectRepositoryPageClaims`
  exposes the page's complete compact Claim set on demand for workers that
  intend to revise or remove otherwise-current content. `submitRepositoryPage`
  takes sparse Claim decisions (`confirmedClaimIds`/`claims`/`retractedClaimIds`)
  which `reconcilePageClaims` turns into confirm/update/add/retract operations,
  retaining omitted issue-free Claims. It also owns the skip-failed-page-workers
  path: `captureRepositoryPageSnapshot` records the pending page and its
  claims sidecar before a worker runs, `skipRepositoryPage` rolls a failed
  worker back (restoring the page markdown and sidecar, marking the job
  `skipped`), and `restoreRepositoryPageMarkdown` re-applies the snapshot
  during `finishRepositoryRun` for every skipped job, tolerating a not-found
  page when the snapshot recorded no markdown.

## Subsystems

### agent — LLM agent construction and repository authoring loop

Owns model/provider wiring, the agent tool loop, and the machinery that turns a
run into wiki pages. Principal entry: `src/agent/index.ts`. Supporting owners
include `src/agent/repository-runner.ts` (the native plan/page tool loop that
calls into `generation/repository-run.ts`), `src/agent/utils.ts` (run-context
construction, content/source snapshots, and update-metadata persistence shared
by the generation lifecycle), `src/agent/docs-only-backend.ts`
(the sandboxed shell/filesystem backend), the OKF and translation middleware
(`okf-middleware.ts`, `translation-middleware.ts`), the prompt builders
(`prompt.ts`, `repository-prompts.ts`), read-boundary enforcement
(`openwiki-ignore.ts`), wiki post-processing (`wiki-finalizer.ts`,
`wiki-link-validator.ts`, `wiki-replacement.ts`), and the ChatGPT/Vertex auth
surfaces (`openai-chatgpt-oauth.ts`, `vertex-surface.ts`), and the IBM Bob fetch
adapter (`bob.ts`, whose `createBobFetch` rewrites `Authorization: Bearer …` to
`Apikey <key>` and sets the `ibm-bob-openwiki-provider` `User-Agent` required by
Bob's Cloudflare WAF — wired into `createModel`'s `bob` branch).
`runNativeRepositoryGeneration` drives the full loop: it begins the run, runs
the planning agent, then calls `runPendingPageAgents` to spawn one fresh
shell-free worker per pending page. Each `runPageAgent` worker is given an
`inspect_claims` tool (backing `inspectRepositoryPageClaims`) and a
`submit_page` tool (backing the sparse `submitRepositoryPage`); it captures a
`RepositoryPageSnapshot` via `captureRepositoryPageSnapshot` before any model
work, and on a worker that exits without submitting it calls
`skipRepositoryPage` to restore the page and mark it `skipped`, collecting the
snapshots and passing them to `finishRepositoryRun` so skipped pages keep their
pre-work content and are reconsidered on the next update.

### generation — repository run lifecycle and page jobs

Orchestrates a full repository wiki build. Principal entry:
`src/generation/repository-run.ts`, which imports `resolveLanguage`/
`requireResolvedLanguage` from `platform/language.ts` so `beginRepositoryRun`
can reject an unrecognized language before any run state is written.
`src/generation/run-state.ts` owns the durable on-disk checkpoint (`.run.json`,
schema-versioned, with `planning`/`generating` phases and `pending`/`skipped`/
`complete` page-job statuses) so runs resume after interruption.
`src/generation/page-jobs.ts` builds the plan (`createRepositoryPlan`) and
reconciles per-page Claims (`reconcilePageClaims`), turning sparse
`confirmedClaimIds`/`claims`/`retractedClaimIds` decisions into
confirm/update/add/retract operations while retaining omitted issue-free
Claims. `src/generation/page-manifest.ts`
owns the committed page-correctness ledger (`openwiki/.page-manifest.json`,
schema-versioned), recording each completed page's source fingerprint, page
version, and producer provenance. `src/generation/errors.ts` defines
`RepositoryRunError`. The lifecycle exposes a six-operation surface
(`beginRepositoryRun`, `submitRepositoryPlan`, `nextRepositoryPage`,
`inspectRepositoryPageClaims`, `submitRepositoryPage`, `finishRepositoryRun`).
`nextRepositoryPage` returns `claimsRequiringAttention` and
`existingClaimCount` rather than the full Claim set; `inspectRepositoryPageClaims`
returns the complete compact Claim set on demand. Its snapshot/skip/restore
operations (`captureRepositoryPageSnapshot`, `skipRepositoryPage`,
`restoreRepositoryPageMarkdown`) let a failed page worker be rolled back to its
pre-work state and marked `skipped` rather than failing the whole run;
`restoreRepositoryPageMarkdown` tolerates a not-found page when the snapshot
held no markdown, so deleting a newly added page counts as a clean restore;
`finishRepositoryRun` requires a snapshot for every skipped job and re-applies
those snapshots before finalizing.

### claims — grounded-claim persistence, reconciliation guidance, and evidence resolution

Owns the grounded-claims model: strict per-page claim sidecars and the evidence
that backs them. `src/claims/brains/code/runtime.ts` (`prepareClaimsRuntime`)
assembles process-local claims state used by a repository run;
`src/claims/brains/code/store.ts` (`ClaimsStore`) validates and persists claim
sidecars with a schema version; `session.ts` inspects and replaces page claims;
`preflight.ts` computes stable grounding issues. `src/claims/core/` holds
mutations, error types, and the resolver cache. `src/claims/evidence/repository/`
resolves and relocates `repo://` evidence resources (`resolver.ts`,
`resource.ts`), including opaque line-range relocation metadata.
`src/claims/guidance.ts` is the shared model-facing Claims standard: it exports
`CLAIMS_SUBSTANCE_GUIDANCE` (the rules for selecting substantive, atomic
propositions over shallow per-symbol facts) and `CLAIMS_RECONCILIATION_GUIDANCE`
(the sparse-reconciliation rules), consumed verbatim by the page-worker prompt
(`repository-prompts.ts`), the `submit_page` tool description, and the MCP
server `INSTRUCTIONS` so the model sees one standard across every surface.

### okf — Open Knowledge Format frontmatter, indexing, and verification

Owns OKF concept-page structure. `src/okf/frontmatter.ts` is the principal
entry: it validates OKF frontmatter (`validateOkfFrontmatter`), including the
OKF v0.2 trust families — `generated`, `verified`, `sources`, `status`, and
`stale_after` — via `validateTrustFamilies`. It reads and writes individual
fields while preserving unrelated front-matter lines byte-for-byte
(`parseFrontmatterFields`, `readFrontmatterField`, `setFrontmatterField`), and
stamps producer-owned control fields (`setGeneratedEvent`, `setOkfSources`,
`setOkfVerified`). It also deterministically repairs persisted pages
(`repairOkfFrontmatter`, `repairPersistedFile`), which the repository lifecycle
calls before accepting a page. `index-sync.ts` and `index-labels.ts` keep index
pages and concept-type labels in sync; `claims-verification.ts` synchronizes
and rolls back claim verification; `generated-provenance.ts` and
`claim-sources.ts` handle provenance metadata.

### connectors — external read-only knowledge sources

Owns the built-in source connectors and their MCP plumbing.
`src/connectors/registry.ts` (`createConnectorRegistry`, `CONNECTOR_IDS`) is the
central registry mapping ids (`git-repo`, `slack`, `x`, `google`, `web-search`,
`hackernews`, `langsmith`, `notion`, `custom-mcp`) to runtimes. `tools.ts`
exposes connectors to the agent as tools; `mcp-client.ts` and `mcp-runtime.ts`
run MCP transports; `src/connectors/sources/` holds one file per connector
implementation.

### ingestion — pulling connector content into the wiki

Owns the ingestion command that fetches from configured connectors and feeds the
generation pipeline. Principal entry: `src/ingestion/ingestion.ts`
(`runOpenWikiIngestion`). `src/ingestion/code-mode.ts` prepares repository
("code mode") setup consumed by repository runs.

### cli — command parsing and terminal UI

Owns the executable entrypoint and terminal experience. `src/cli/cli.tsx` is the
`#!/usr/bin/env node` entry that installs the crash guard, parses the command,
and dispatches to the Ink app or a non-interactive runner. `src/cli/commands.ts`
is the large command parser/router (`parseCommand`, and predicates such as
`commandLoadsEnvironment`). `runners.ts` and `integrations.ts` host per-command
handlers; `app/`, `components/`, and `input/` hold the Ink UI.

### auth — provider and OAuth credential management

Owns credential acquisition and storage. Principal entries: `src/auth/oauth.ts`
(OAuth flows) and `src/auth/tokens.ts` (token persistence), with
`oauth-discovery.ts`, `providers.ts`, `configure.ts`, `external-cli-auth.ts`, and
`ngrok.ts` for discovery, provider selection, and tunneling.

### config — environment, home directory, reasoning, and constants

Owns runtime configuration. `src/config/constants.ts` is the central identifier
registry (path constants, provider env keys — including the IBM Bob
`BOB_API_KEY_ENV_KEY`/`BOB_BASE_URL_ENV_KEY`, the `bob` provider in the
`OpenWikiProvider` union, and the `openai-compatible` streaming/responses-API
gates plus `OPENAI_COMPATIBLE_STREAM_MESSAGES_ENV_KEY` and
`OPENAI_COMPATIBLE_REASONING_EFFORT_SUPPORTED_ENV_KEY` — provider defaults), and
also owns the output-token resolution helpers
(`resolveConfiguredMaxOutputTokens`, `resolveBedrockMaxTokens`,
`BEDROCK_DEFAULT_MAX_TOKENS`) plus `resolveOpenAiCompatibleReasoningEffortSupported`,
`resolveOpenAiCompatibleStreamMessages`, and `providerUsesResponsesApi`, which
gate reasoning effort, stream mode, and the responses API transport for
`openai-compatible` providers; `env.ts` loads and saves the OpenWiki `.env` and
is the single source of truth for the managed-keys list (`MANAGED_ENV_KEYS`,
now including `BOB_API_KEY_ENV_KEY`, `BOB_BASE_URL_ENV_KEY`,
`OPENAI_COMPATIBLE_STREAM_MESSAGES_ENV_KEY`, and
`OPENWIKI_OPENAI_COMPATIBLE_REASONING_EFFORT_SUPPORTED`), from which the
credential-diagnostic and debug key lists derive; `openwiki-home.ts` resolves the
home/wiki directories; `reasoning.ts` resolves reasoning settings, owning the
three reasoning transports (`responses-reasoning`,
`chat-completions-reasoning-effort`, `gemini-thinking-level`) and the
`openai-compatible` capability resolution that consults
`resolveOpenAiCompatibleReasoningEffortSupported` and
`providerUsesResponsesApi` from `constants.ts`.

### integrations — host-tool integration and MCP server surface

Owns embedding OpenWiki into external hosts. `src/integrations/core/session-manager.ts`
is the principal entry: `HostSessionManager` is a thin single-run MCP adapter over
the transport-neutral lifecycle core, serializing one lifecycle operation at a time
(`runOperation`) and mapping `RepositoryRunError` codes into stable
`HostIntegrationError`s at the boundary. Its `begin`, `submitPlan`, `nextPage`,
`inspectPageClaims`, `submitPage`, and `finish` methods delegate to the
`generation/repository-run.ts` lifecycle, and `tools()` returns exactly the six
OpenWiki lifecycle tools (`openwiki_begin`, `openwiki_submit_plan`,
`openwiki_next_page`, `openwiki_inspect_page_claims`, `openwiki_submit_page`,
`openwiki_finish`) for an MCP transport to expose. The
tool descriptions are the host-facing contract: `openwiki_begin` advertises that
an unrecognized `language` returns `invalid_input` instead of starting a run,
`openwiki_next_page` returns only the stale or unresolved Claims requiring an
explicit decision (plus an `existingClaimCount`),
`openwiki_inspect_page_claims` returns the complete Claim set on demand,
`openwiki_submit_page` states the sparse Claim-reconciliation rules (reuse ids
for revisions, omit to retain, omit id for new, `retractedClaimIds` for removals),
and `openwiki_finish` requires every job complete before deterministic
deletion/validation/indexing. `src/integrations/core/protocol.ts` defines the
`ProtocolToolName` union (the six tool names), the strict Zod input schemas
including the sparse `SubmitPageInput` (optional `confirmedClaimIds`,
`claims`, and `retractedClaimIds`) and `InspectPageClaimsInput`, and host-id
validation; `repository-root.ts` resolves the repository root.
`src/integrations/mcp/server.ts` exposes OpenWiki over MCP, advertising an
`INSTRUCTIONS` preamble that incorporates `CLAIMS_RECONCILIATION_GUIDANCE` from
`claims/guidance.ts` so the host model follows the same sparse-reconciliation
standard as the native page-worker prompt (stdio in
`stdio.ts`); `src/integrations/install/` handles host installation.

### visualize — local graph viewer

Owns the interactive wiki/graph viewer. `src/visualize/server.ts`
(`createRequestHandler`) serves the app; `graph.ts` builds the graph model;
`page.ts`, `client.ts`, `client-lib.ts`, and `static-export.ts` render and export
it.

### scheduling — recurring connector and generation runs

Owns cron/launchd scheduling. Principal entry: `src/scheduling/schedules.ts`,
which validates cron expressions and installs, lists, pauses, resumes, and
deletes connector and "power" schedules.

### telemetry — run recording and error classification

Owns opt-out usage telemetry and error taxonomy. `src/telemetry/index.ts` is the
public barrel re-exporting `recordRun`/`recordRunSafe`, `withRunTelemetry`,
error classification (`classifyError`, `tagErrorStage`), and the opt-out gates
(`isTelemetryDisabled`, `isCiEnvironment`). `senders.ts`, `errors.ts`, and
`taxonomy.ts` carry the implementation.

### platform — OS and filesystem primitives

Owns cross-platform helpers shared by other subsystems: `fs-errors.ts`
(`isFileNotFoundError`), `diagnostics.ts` (secret redaction), `language.ts`
(language resolution), `windows-acl.ts`, and `utils.ts`.

### mermaid — diagram validation for generated pages

Owns Mermaid handling in generated wikis: `fences.ts` extracts fences,
`validate.ts` parses/validates them (degrading invalid diagrams), `wiki.ts`
applies the policy to pages, and `dom-shim.ts` provides the headless render
environment.

### evals — longitudinal documentation evaluation

Owns the offline evaluation harnesses that measure whether generated wikis stay
accurate as their source of truth evolves, and whether OpenWiki improves a
coding agent. Unlike every other subsystem, the evals live under `evals/`
(not `src/`) and are invoked via `pnpm` scripts — `eval:ledger` and
`eval:ledger:reevaluate` — rather than the main CLI binary, with their own
TypeScript project (`evals/ledger/tsconfig.json`). It is split into two
independent sub-harnesses.

**LEDGER** (`evals/ledger/`) — the Longitudinal Evaluation of Documentation
Grounding, Evolution, and Revision — replays a benchmark's Git checkpoints, runs
OpenWiki at each checkpoint, and judges the frozen wiki snapshot. Principal
entry: `evals/ledger/run.ts` (`eval:ledger`), which loads the benchmark,
constructs the `OpenWikiSystem` adapter, runs `runBenchmark`, and persists the
fully auditable result. `evals/ledger/reevaluate.ts` (`eval:ledger:reevaluate`)
re-runs the evaluator over a completed run without invoking the system under
test. `evals/ledger/run/runner.ts` (`runBenchmark`) owns the benchmark
lifecycle: it preflight-validates the trace (every checkpoint SHA resolves,
each is an ancestor of the next, and none tracks the wiki directory), then
walks it running `init` then `update`, captures an immutable artifact at each
checkpoint, and evaluates it; the workspace and worktree are always torn down.
`evals/ledger/core/types.ts` owns the benchmark and claim types
(`LedgerBenchmark`, `LedgerTrace`, `LedgerCheckpoint`, `SemanticEvidenceMap`,
`KnowledgeArtifact`, `EvidenceCorpus`, `SystemUnderTest`) and the claim-state
model (`supported`/`stale`/`invented`/`unverified`). `evals/ledger/system/openwiki-system.ts`
(`OpenWikiSystem`) is the baseline System Under Test: it drives OpenWiki through
its single `runOpenWikiAgent` entrypoint with `outputMode: "repository"` and no
user message, so update change-detection is driven purely by the real source
deltas between checkpoints.

**DeepSWE** (`evals/deepswe/`) is a Python paired-evaluation harness that
measures whether OpenWiki improves a coding agent on DeepSWE SWE-bench tasks.
Principal entry: `evals/deepswe/run.py`, which exposes the `prepare`,
`baseline`, `openwiki`, `paired`, and `summarize` subcommands. The `paired`
command runs both conditions with the same tasks, seed, model, reasoning effort,
and Harbor environment: `baseline` gives Codex only the task and repository,
while `openwiki` restores or generates OpenWiki in an isolated clone and merges
its managed instructions into the root `AGENTS.md` before the same Codex adapter
solves the unchanged task. The harness pins the DeepSWE commit, Harbor, litellm,
and Codex CLI versions for reproducibility, and uses Harbor's official LangSmith
plugin so both conditions record their trials in the same shared dataset.

See the full [evaluation subsystem](/openwiki/testing/evals.md) page for the
benchmark contract, claim-state definitions, and run instructions.

## How the central subsystems connect

The CLI entrypoint parses a command and, for repository generation, the agent
constructs a model and runs the plan/page loop, which calls the generation
lifecycle; that lifecycle reconciles sparse Claim decisions, persists claims,
and validates OKF frontmatter as it writes each page. Both the native
page-worker prompt and the MCP host instructions share the same Claims
reconciliation guidance from `claims/guidance.ts`.

```mermaid
flowchart TD
  CLI["cli/cli.tsx parses and dispatches"] --> Agent["agent/index.ts runOpenWikiAgent"]
  Agent --> Runner["agent/repository-runner.ts plan and page loop"]
  Runner --> Gen["generation/repository-run.ts six-operation lifecycle"]
  Gen --> State["generation/run-state.ts durable checkpoint"]
  Gen --> Claims["claims runtime and store"]
  Gen --> OKF["okf/frontmatter.ts validation"]
  Guidance["claims/guidance.ts substance and reconciliation standard"] -.-> Runner
  Guidance -.-> MCP["integrations/mcp/server.ts INSTRUCTIONS"]
  Agent --> Connectors["connectors/tools.ts source tools"]
  Config["config/constants.ts identifiers"] -.-> Agent
  Config -.-> Gen
```

Caption: Control flow from the CLI through the agent into the repository
generation lifecycle, with the shared Claims guidance feeding both the native
page-worker prompt and the MCP host instructions, and config identifiers
shared across subsystems.

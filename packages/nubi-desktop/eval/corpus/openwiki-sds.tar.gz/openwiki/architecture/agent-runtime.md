---
type: architecture
title: Agent Runtime, Models, and Middleware
description: How OpenWiki builds and runs its DeepAgents documentation agent — resolving a model provider and model id, instantiating the right LangChain chat model, mounting a sandboxed docs-only filesystem backend, running the OKF, translation, and crash-guard middleware, and parsing the agent graph stream into display events.
tags:
  - agent-runtime
  - model-providers
  - middleware
  - stream-parsing
  - deepagents
  - filesystem-sandbox
  - langchain
verified:
  - by: openwiki/0.5.2
    at: 2026-09-15T08:09:47.649Z
sources:
  - id: openwiki-source-0ad86abe7202c4e4d6897f34
    resource: repo://src/agent/agent-backend.ts
  - id: openwiki-source-f8b008ed89162a0e204fc02d
    resource: repo://src/agent/bob.ts
  - id: openwiki-source-fcb06f91f699f462b4d84a90
    resource: repo://src/agent/crash-guard.ts
  - id: openwiki-source-12c17ed8ca9c89ec61f28df7
    resource: repo://src/agent/docs-only-backend.ts
  - id: openwiki-source-a953060a04ccefcf777de48e
    resource: repo://src/agent/index.ts
  - id: openwiki-source-6fd9c8ed42336141de43b3c2
    resource: repo://src/agent/okf-middleware.ts
  - id: openwiki-source-8bf337d8927152d7d30230b4
    resource: repo://src/agent/prompt.ts
  - id: openwiki-source-73e36256f612bf9dbe62d127
    resource: repo://src/agent/translation-middleware.ts
  - id: openwiki-source-06902db4574f065a9a6ad95d
    resource: repo://src/agent/vertex-surface.ts
  - id: openwiki-source-278e7e180eac811fc1a24f7a
    resource: repo://src/config/constants.ts
  - id: openwiki-source-f1dd0edb129e50f253618ff4
    resource: repo://src/config/reasoning.ts
  - id: openwiki-source-ebe194cbeaa2594a6699f9a1
    resource: repo://src/model-availability.ts
  - id: openwiki-source-21fe6d4741a8225393c37599
    resource: repo://test/agent/create-model.test.ts
  - id: openwiki-source-d485c898eb60ebb173072eab
    resource: repo://test/agent/stream-redaction.test.ts
generated: { by: "openwiki/0.5.2", at: "2026-09-15T08:09:47.649Z" }
---

# Agent Runtime, Models, and Middleware

OpenWiki drives documentation generation through a [DeepAgents](https://github.com/langchain-ai/deepagents) agent graph built on LangChain chat models. The runtime is responsible for turning a user command into a configured agent: it resolves which provider and model to use, instantiates the correct LangChain client for that provider, wraps the filesystem in a sandboxed docs-only backend, and mounts the middleware that keeps the wiki OKF-conformant and (on updates) in the right language. A separate crash guard records and stamps runs that die outside every normal `catch`.

`runOpenWikiAgent` is the top-level entrypoint for a run. It loads persisted environment, resolves the run configuration, builds the model and agent, opens the graph stream, and consumes it while a run record is registered with the crash guard.

For provider setup and credentials see [Model Providers](/openwiki/concepts/model-providers.md) and [Configuration](/openwiki/operations/configuration.md); for the repository init/update flow that bypasses the shared agent graph see [Repository Generation](/openwiki/workflows/repository-generation.md).

## Two execution paths

`runOpenWikiAgent` splits on output mode and command. Repository `init`/`update` runs are recognized as "repository generation" and delegated to `runNativeRepositoryGeneration` (the OpenWiki page-job runner), which builds the model directly and never constructs the shared DeepAgent graph. Everything else — chat in any mode, and personal/local-wiki commands — runs through `runOpenWikiAgentCore`, which builds and streams the DeepAgent graph described on this page.

The shared graph factory `createOpenWikiAgentGraph` refuses to build for repository `init`/`update`, and the prompt builders throw for that combination too, so those commands are structurally forced down the native page-job path rather than the agent-graph path.

```mermaid
flowchart TD
  Start["runOpenWikiAgent(command, cwd, options)"] --> Load["loadOpenWikiEnv and syncBundledSkills"]
  Load --> Repo{"repository init or update"}
  Repo -->|yes| Native["resolveRunConfig then createModel then runNativeRepositoryGeneration"]
  Repo -->|no| Core["runOpenWikiAgentCore"]
  Core --> Cfg["resolveRunConfig: provider, credentials, modelId, limits"]
  Cfg --> Model["createModel builds LangChain chat model"]
  Model --> Graph["createOpenWikiAgentGraph: backend, middleware, prompt, checkpointer"]
  Graph --> Stream["agent.stream with messages or updates mode"]
  Stream --> Register["registerActiveRun for the stream window"]
  Register --> Consume["consume chunks, emit events, finalize metadata"]
```

Control flow from the entrypoint to either the native page-job runner or the shared DeepAgent graph stream.

## Resolving the run configuration

`resolveRunConfig` performs all pre-build resolution and tags any throw with the `config` stage for failure telemetry. It resolves the provider first and reports it immediately through `onProviderResolved`, so a failure later in resolution is still attributed to the right provider.

Provider selection is `resolveConfiguredProvider`: an explicit `OPENWIKI_PROVIDER` wins, otherwise the provider is inferred from whichever provider API-key (or Bedrock AWS credential) environment variable is present, in a fixed precedence order, falling back to a default provider. After the provider is known, resolution loads any external-CLI credential, validates and ensures the provider's credentials, base URL, secret key, and region, and — for `openai-chatgpt` — refreshes the ChatGPT OAuth tokens before the model is built so `createModel` can stay synchronous.

The model id comes from `resolveModelId`: it prefers an explicit option or `OPENWIKI_MODEL_ID`, else the provider's default; a provider with no built-in model options requires the id to be set. The id is normalized and validated, and if it is a known model of a different provider a non-fatal mismatch warning is emitted (the run still proceeds, since a custom gateway may serve it). Resolution also queries `getSelectedModelAvailability`, which aborts the run when a model is provably `unavailable`, but treats an `unknown` result as fine — a catalogue lookup failure is not proof a model cannot be invoked, and only the direct `openai` provider (with an API key and no custom base URL) is actually checked.

After model resolution, `resolveRunConfig` resolves three provider-neutral operational settings that flow into `createModel`: the retry count (`OPENWIKI_PROVIDER_RETRY_ATTEMPTS`), the per-request output-token cap via `resolveConfiguredMaxOutputTokens` (`OPENWIKI_MAX_OUTPUT_TOKENS` translated to each SDK's field name, with Bedrock falling back to a 16,000-token default when the neutral setting is unset), and — for `bedrock` only — the stream idle-timeout watchdog (`OPENWIKI_STREAM_IDLE_TIMEOUT`). These are reported through the debug log so a run's effective limits are observable.

## The provider matrix and model instantiation

`createModel` maps the resolved provider and model id onto a concrete LangChain chat model. The provider enum spans direct API-key providers (`anthropic`, `openai`, `gemini`, the IBM `bob` inference gateway, plus OpenAI-compatible gateways `baseten`/`fireworks`/`nebius`/`nvidia`/`openai-compatible`), OAuth (`openai-chatgpt`, `copilot`), AWS-SDK (`bedrock`), a routing gateway (`openrouter`), and Google Vertex (`gemini-enterprise`).

Each branch constructs a purpose-built client:

- **Anthropic** builds `ChatAnthropic`, applying a modern-Claude default output-token limit (raised above LangChain's 4,096 fallback only for known Claude 4/5 families) unless an explicit provider-neutral limit is set.
- **Gemini (AI Studio)** builds `ChatGoogle` with `platformType: "gai"`, disabling streaming and pinning `outputVersion: "v0"` so Gemini 3.x thought-signatures round-trip correctly across tool-calling turns; when `gemini-3.6-flash` declares a reasoning capability, the resolved effort is passed as `ChatGoogle`'s `thinkingLevel` option.
- **Gemini Enterprise (Vertex)** delegates to `createGeminiEnterpriseModel`, which picks the client from the model family: Claude via the Anthropic Vertex SDK, partner/open-weight models over Vertex's OpenAI-compatible MaaS surface, and Gemini/Gemma over native `generateContent`. Auth is uniform ADC + project + region; only the transport differs.
- **ChatGPT OAuth** reuses `ChatOpenAI` against the Codex Responses backend with `useResponsesApi`, `zdrEnabled` (forcing `store: false`), forced streaming, and the account/originator/beta headers the Codex backend requires.
- **OpenRouter** builds `ChatOpenRouter` against the OpenRouter base URL, optionally pinning an upstream provider allowlist; a legacy OpenRouter-specific output cap still takes precedence there over the provider-neutral cap.
- **Bedrock** builds `ChatBedrockConverse` with the resolved AWS region, the resolved output-token cap (now always threaded as `maxTokensOptions` because Bedrock falls back to a default of 16,000 tokens rather than letting the Converse API cap at 4,096), and, when `OPENWIKI_STREAM_IDLE_TIMEOUT` is set, a stream idle-timeout watchdog that aborts a generation stalled waiting for its first or next chunk (0 disables it).
- **Copilot** shares the `ChatOpenAI` fallthrough below, but `providerUsesStreaming` forces the streaming HTTP transport for every Copilot model: non-GPT-5 models (Claude, Gemini) are served over chat completions and reject or return empty responses for non-streaming requests, so without `streaming: true` a repository worker can exit without calling `submit_plan`/`submit_page`. The flag is redundant but harmless for GPT-5 models that use the Responses API, matching the `openai-chatgpt` pattern.
- **IBM Bob** is a ChatOpenAI-over-chat-completions client against the Bob inference endpoint. Bob declares a single fixed model (`premium`) that `resolveModelId` returns unconditionally via `getProviderFixedModel`, so no model id is ever configured for it. Because Bob authenticates with an `Apikey` scheme and requires a registered User-Agent, the branch passes a placeholder API key to satisfy `ChatOpenAI`'s constructor and injects the real key per request through a `createBobFetch` fetch adapter that rewrites the `Authorization` header to `Apikey <key>` (read from the environment at call time) and sets `User-Agent: ibm-bob-openwiki-provider`, which Bob's Cloudflare WAF requires.
- **OpenAI and all OpenAI-compatible gateways** fall through to a shared `ChatOpenAI` branch that honors a per-provider base URL, chooses the Responses API when the provider config asks for it, and forces the streaming HTTP transport for gateways that only serve SSE.

The provider-neutral output limit is the single `OPENWIKI_MAX_OUTPUT_TOKENS` setting: because a run constructs only one model, one value is mapped to each SDK's field name (`maxTokens` for OpenAI/Anthropic/MaaS/Bedrock, `maxOutputTokens` for Gemini), with OpenRouter's older `OPENWIKI_OPENROUTER_MAX_TOKENS` cap retained for backward compatibility and taking precedence on OpenRouter runs. When unset the limit is omitted so the provider default applies — except for Bedrock, where `resolveConfiguredMaxOutputTokens` falls back to `resolveBedrockMaxTokens` (default `BEDROCK_DEFAULT_MAX_TOKENS` = 16,000, overridable via `OPENWIKI_BEDROCK_MAX_TOKENS`) so the Converse API no longer truncates at its built-in 4,096-token ceiling; Anthropic's modern-Claude default is a separate, Anthropic-only behavior.

`createModel` also threads a resolved reasoning config: `OPENWIKI_REASONING_EFFORT` is applied only to models that declare a reasoning capability, and it is dispatched by the model's declared transport — a Responses-API `reasoning.effort` payload for `responses-reasoning`, a chat-completions `reasoning_effort` kwarg for `chat-completions-reasoning-effort`, and `ChatGoogle`'s `thinkingLevel` for `gemini-thinking-level`; an unsupported provider/model or an invalid effort value throws.

### Reasoning capability table and transports

`resolveReasoningConfig` returns a `ResolvedReasoningConfig` whose `transport` is one of three values, each mapped to the SDK field the model's provider accepts. The `REASONING_CAPABILITIES` table declares which (provider, model id) pairs expose a capability and which effort values each accepts:

| Provider | Model id | Transport | Accepted effort values |
| --- | --- | --- | --- |
| `openai` / `openai-chatgpt` | `gpt-5.6-terra` / `gpt-5.6-luna` / `gpt-5.6-sol` | `responses-reasoning` | `none` / `low` / `medium` / `high` / `xhigh` / `max` |
| `nvidia` | `nvidia/nemotron-3-super-120b-a12b` | `chat-completions-reasoning-effort` | `none` / `low` / `high` |
| `gemini` | `gemini-3.6-flash` | `gemini-thinking-level` | `low` / `medium` / `high` |

The `openai-compatible` provider has no static entry: its capability is gated by `OPENWIKI_OPENAI_COMPATIBLE_REASONING_EFFORT_SUPPORTED`. When that opt-in is set, `getOpenAiCompatibleReasoningCapability` returns a capability whose transport depends on `useResponsesApi` — `responses-reasoning` when the provider is configured to use the Responses API, `chat-completions-reasoning-effort` otherwise — and accepts the full effort range including `max`. Without the opt-in the capability is `undefined`, so any `OPENWIKI_REASONING_EFFORT` value throws "not supported" for `openai-compatible` (mirroring the behavior for any other provider/model pair that declares no capability).

### Vertex surface routing

For `gemini-enterprise`, the API surface is a function of the model id, not the provider: `resolveVertexSurface` classifies an id as `anthropic`, `openai-maas`, or (default) `gemini`. IDs matching the Anthropic pattern (`anthropic`/`claude` family, whether bare or publisher-pathed) route to the Anthropic Vertex surface; IDs matching the MaaS pattern — including the `xai`/`grok` family in addition to `ai21`, `codellama`, `codestral`, `deepseek`, `jamba`, `llama`/`meta`, `mistral`, and `qwen` — route to the OpenAI-compatible MaaS surface; everything else defaults to native Gemini/Gemma. The Claude-on-Vertex bridge neutralizes any ambient `ANTHROPIC_API_KEY`/`ANTHROPIC_AUTH_TOKEN` around the synchronous `AnthropicVertex` constructor so a stray native Anthropic key cannot clobber the Google OAuth token, and the MaaS surface injects a fresh ADC bearer token per request via a `fetch` wrapper so long sessions survive token expiry while `createModel` stays synchronous.

## Building the agent graph

`createOpenWikiAgentGraph` constructs the DeepAgent from the initialized model. It creates an `OpenWikiLocalShellBackend` rooted at the run cwd (with `docsOnly` enabled for every command except chat), wraps it in a composite backend that adds fixed virtual mounts, and passes the middleware pipeline, connector tools, filesystem permissions, and command-specific system prompt to `createDeepAgent`.

The composite backend (`createAgentBackend`) mounts two additional read-only virtual filesystems alongside the wiki backend: `/conversation_history/` for DeepAgents' history offload and `/skills/` for the bundled skills. A shared filesystem permission set additionally denies writes under both `/skills/**` and the conversation-history mount, and the composite backend converts a known upstream broad-glob recursion overflow into a bounded, model-facing "narrow your search" error instead of crashing the run.

The agent is streamed with `subgraphs: true`. Stream mode is normally `messages` + `tools`, but the `openai-compatible` provider defaults to the safer `updates` + `tools` mode because arbitrary endpoints (e.g. GLM emitting reasoning deltas before the first assistant delta) can aggregate to a chunk the agent loop rejects; a known-good endpoint can opt back into `messages` mode with `OPENWIKI_OPENAI_COMPATIBLE_STREAM_MESSAGES`. Regardless of mode, every raw LangGraph chunk emitted by `agent.stream` is reduced to a display event by the stream parsing pipeline described next.

## Stream parsing pipeline

The stream-consumption loop iterates `agent.stream` and hands each chunk to `parseAgentStreamChunk`, which returns an `OpenWikiRunEvent` (forwarded to the caller's `onEvent`) or `null` (logged as an unhandled chunk shape in debug, capped at three samples so a noisy provider cannot flood the log). Three runtime event types are produced: `text` (assistant prose), `tool_start`/`tool_end` (tool lifecycle), and `debug`.

`parseAgentStreamChunk` first validates the chunk is a three-tuple `[namespace, mode, payload]` where `namespace` is a string array and `mode` is one of `messages`, `tools`, or `updates`; anything else is rejected as `null`. It then dispatches on mode:

- **`tools`** delegates to `parseToolStreamEvent`, which normalizes the LangGraph tool lifecycle events `on_tool_start`, `on_tool_end`, and `on_tool_error` into `tool_start` and `tool_end` events. The tool-call display string is built from the tool name and sanitized input (`execute` is renamed `Execute`), and a tool-end carries a `finished` or `error` status keyed by the tool call id.
- **`updates`** delegates to `parseUpdatesChunk`. This is the default mode for `openai-compatible` providers. LangGraph `updates` chunks carry a per-node state diff (`{ nodeName: { messages: [...] }, ... }`) rather than raw message tokens, so `parseUpdatesChunk` iterates the node outputs and returns the first non-empty assistant text extracted from any node's messages via `extractMessageText`. Without this handler, plain-text replies from openai-compatible endpoints are silently dropped and the TUI shows no assistant output.
- **`messages`** (the default for every provider except `openai-compatible`) extracts assistant text directly from the message content blocks via `extractMessageText`.

Both `messages` and `updates` paths tag the resulting `text` event with a `source` computed by `getStreamSource(namespace)`. DeepAgents wraps the primary model call in a single top-level `model_request:` namespace; a namespace that is exactly one element starting with `model_request:` is classified `main` (the assistant output that belongs in the transcript). A deeper namespace — a nested `task`/subgraph namespace — is classified `subgraph` (prose that should stay hidden from the main transcript), and an empty namespace falls back to `main`. This is how assistant text emitted from a top-level model-request stream is rendered as the main conversation while nested subgraph output is kept out of it.

`extractMessageText` is a recursive, cycle-guarded walker that extracts text from the many shapes LangChain/LangGraph payloads can take: message tuples `[message, metadata]`, `chunk`/`message` wrappers, serialized message records (`kwargs`/`lc_kwargs`/`generations`), and content arrays. It only reads records whose role is `ai`/`assistant` (or untyped), skipping `human`/`system`/`tool` messages so user input and tool results are never echoed as assistant text.

The content-block redaction layer is `extractContentBlockText`. Before returning any text from a content block, it checks the block's `type`: a type whose string includes `tool`, `reasoning`, `file`, or `image` is suppressed (returns an empty string). This ensures base64 `file`, `input_file`, `image`, and `image_url` payloads never reach the terminal, while adjacent `text` blocks in the same chunk stream through normally. A block that survives the type check yields text from its `text`/`content`/`output_text` field, recursing into `fields` (block deltas) and `delta` (content deltas such as `text-delta` and `block-delta`) as needed.

```mermaid
flowchart TD
  Chunk["agent.stream chunk"] --> Valid{"isAgentStreamChunk: tuple namespace, mode, payload"}
  Valid -->|no| Null1["return null, debug-log shape"]
  Valid -->|yes| Mode{"mode"}
  Mode -->|tools| Tool["parseToolStreamEvent: on_tool_start/end/error"]
  Mode -->|updates| Updates["parseUpdatesChunk: iterate node state diff"]
  Mode -->|messages| Msg["extractMessageText from payload"]
  Updates --> Extract["extractMessageText from first node with text"]
  Tool --> ToolEvt["tool_start or tool_end event"]
  Extract --> Source["getStreamSource: main vs subgraph"]
  Msg --> Source
  Source --> TextEvt["text event with source tag"]
  Null1 --> Forward["onEvent or skipped"]
  ToolEvt --> Forward
  TextEvt --> Forward
```

Stream-chunk classification by mode and namespace, reducing each raw LangGraph chunk to a display event or null.

## The docs-only filesystem backend

`OpenWikiLocalShellBackend` extends the DeepAgents `LocalShellBackend` and layers three independent security boundaries on top, all enforced after canonicalizing paths so `..` traversal cannot escape:

1. **`.openwikiignore` exclusion.** Reads/writes/edits of an ignored path are hard-denied with an error; discovery tools (`ls`/`glob`/`grep`) silently drop ignored entries; and while any ignore rule is active, shell `execute` is restricted to a tiny anchored allowlist (`pwd`, `git rev-parse HEAD`) because arbitrary shell cannot be proven not to read an ignored path.
2. **Docs-only confinement.** In repository mode with `docsOnly` set, writes, edits, and deletes are refused unless the canonicalized path is under the `openwiki/` tree; `local-wiki` mode relaxes this. An optional `writableWikiPages` allowlist can further scope a worker to a specific set of pages.
3. **Claims ownership.** Repository `openwiki/.claims` state is hidden from generic filesystem discovery and read/write tools, and is also refused when a shell command references it, because those sidecars are owned by OpenWiki's own persistence layer, not the agent.

The backend also refuses unbounded root globs and globs that target `.git` metadata, steering the agent toward `ls` at the root followed by targeted searches. Every successful write/edit/delete records the mutated path in the tool-result metadata (`openwikiMutationPath`) so downstream validation knows which page changed.

These boundaries exist because the agent may be prompt-injected via untrusted repository content, so they are treated as security controls rather than mere conveniences.

## The middleware pipeline

Chat runs use no middleware. For non-chat runs, `createOpenWikiAgentGraph` mounts, in order:

1. **Translation middleware** (updates only, and only when a translation plan is resolved). Its `beforeAgent` hook brings every existing page into the run's target language before the agent starts, so an incremental update never leaves a mix of old and new language. `resolveTranslationPlan` returns a plan for every `update`: a real language switch (different primary subtag) retranslates every page, while a plain update only retries pages a prior run marked `openwiki_translation_pending`, and a sweep with nothing to do makes zero model calls. A single page's failure never aborts the run — the page keeps its previous language, is stamped pending for the next update, and the failure is reported through a sanitized warning sink. Translation model calls are tagged `langsmith:nostream` so their raw Markdown stays out of the token stream; one status line is shown instead.
2. **OKF index middleware** (always, for non-chat runs). Its `beforeAgent` hook migrates existing pages to valid OKF front matter and snapshots their bodies; its `wrapToolCall` decorates successful write/edit results with a front-matter warning without catching tool throws (LangChain's tool node already converts a thrown tool error into a recoverable `ToolMessage`, so catching and rethrowing here would make every recoverable tool error fatal); and its `afterAgent` hook synchronizes the deterministic directory indexes and stamps code-owned `generated` provenance on every new or changed page, using the single run timestamp threaded through the run. A deferred `claimSources` projection supplied by a repository Claims runtime is read only during finalization, so it reflects every mutation accepted during the run.

Both middleware hooks operate purely on file text read and written through the sandboxed docs-only backend; model output is never executed.

## Run lifecycle, persistence, and the crash guard

`runOpenWikiAgentCore` builds the run context and a pre-run content snapshot, instantiates the model and a SQLite checkpointer keyed to a thread id, and streams the graph while forwarding parsed events to the caller. Around the stream-consumption window it calls `registerActiveRun` / `clearActiveRun` so the run is attributable if it dies.

On success it persists run metadata as `complete` (skipping the write when content is unchanged, or always for chat) and locks down a persistent checkpoint file. If the stream throws, it persists metadata as `interrupted` — best-effort, swallowing persistence errors so the original run error propagates — so the next scheduled update does not no-op against a possibly partial wiki.

The crash guard is the last-resort boundary for failures that escape every `catch`. `installCrashGuard` registers idempotent `unhandledRejection` and `uncaughtException` handlers once at startup. `handleFatal` claims the single registered active run synchronously before any `await` — making the claim atomic against a burst of rejections so one crash produces one record, not hundreds — then best-effort records the crash as a telemetry failure, stamps the run `interrupted`, prints the raw error to the user's stderr, and exits non-zero. OpenWiki runs one run per process, so a single module-level active-run slot is sufficient.
